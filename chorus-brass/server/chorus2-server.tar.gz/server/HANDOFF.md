# Chorus handoff (2026-10-25 16:10, from the thread that started it)

Everything Ali asked for is in project memory `aichat-app.md` (read it first). Branch: `claude/aichat-app`.

## Done
- `aichat-app/`: native Android app (Kotlin 2.0.21, Compose BOM 2024.10.01, AGP 8.5.2, minSdk 26). Compiles:
  `export ANDROID_HOME=/root/android-sdk; gradle -q :app:compileDebugKotlin` (local.properties `sdk.dir=...`).
  Screens: Home (projects, quota rings), Chat (group + DM, live typing, media, web-video offer card, job card), sheets
  (new project, members, model/effort), Gate (server + password), picture/video viewer. Design = `tools/aichat/web/app.html`
  (previews in /mnt/project-files/aichat-app/, Ali approved).
  **Still talks to the OLD relay JSON format** (`Data.kt` Net/Store: `/ds/aichat/c-<cid>*.json`, PUT `/say/<cid>/…`).
- `aichat-server/server.py` (+ `importers.py`): the new standalone aiohttp server. Tested locally end to end (fake
  OpenAI stream, CLI member, long-poll, queue/stop, upload, yt-dlp, imports, memory). Not yet tested: Anthropic kind,
  real balances, TTS (Doubao 2.0 / OpenAI), skill install (codeload is 403 behind this sandbox proxy; fine on a real server).

## API (all under Bearer token = sha256(password)[:32], or ?t=)
- `GET /api/index?v=` long-poll (25 s, 304) → projects (last, working), quota.
- `GET /api/chat/{pid}?v=` → only messages with rev > v (v=0: all), members (options.models/efforts), status (queue, progress), jobs.
- `POST /api/say {project,to,text,files[{name,url}],model,effort,priority:"now"|"queue",reply_to}`; `POST /api/stop/{name}`;
  `POST /api/msg {project,seq,op:edit|recall|react,...}`.
- Projects: `POST /api/projects`, `PATCH|DELETE /api/projects/{pid}`. Files: `PUT /api/upload/{name}` → `{url:/files/x}`, `GET /files/{x}` (Range).
- `POST /api/video {project,to,url,id}` (yt-dlp job in chat payload `jobs`).
- Settings: `GET /api/config`, `PUT|DELETE /api/providers`, `GET /api/providers/{id}/models`, `PUT|DELETE /api/members`.
- Skills: `GET /api/skills`, `POST /api/skills/install {url}`, `POST|DELETE /api/skills/{dir}`. "/name" in a message injects SKILL.md.
- Memory: `GET|PUT /api/memory`, `DELETE /api/memory/{scope}/{id}`, `POST /api/memory/import` (scopes all, m-<member>, p-<pid>).
- Import chats: `POST /api/import {url|text}` → list + token; `POST /api/import/commit {token,picks,mode:projects|one|dm,member,project}`.
- Voices: `POST /api/tts {project,seq}|{member,text,voice}`, `GET|PUT /api/voices`.

## Next (checklist order)
1. App: rewrite `Data.kt` Net/Store for the API above (long-poll, merge by seq/rev), settings screens (providers with
   model list, members incl. CLI cmd + voice, skills + "/" popup, memory, import, multi-address auto-pick), long-press
   send = 插队, first-run wizard, icon (Ali leaning to candidate B 合唱弧光, `/mnt/project-files/aichat-app/图标候选.png`).
2. Deploy package: Dockerfile + docker-compose + install.sh + relay mode + DEPLOY.md written for AIs.
3. Ali's instance on the build server (CLIs live there), SSH reverse tunnel to relay 47.100.106.26, nginx `/aichat/`,
   import old transcripts (branch ai-groupchat transcript.md / video.md), APK with server + token baked in
   (AICHAT_SERVER / AICHAT_CHAT_ID env in app/build.gradle.kts).
4. Agora batch (approved): threads/reactions, decision cards, task cards, voice + TTS, notifications (no FCM), files
   page (`GET /api/chat/{pid}/files` exists), search/edit/recall/drafts, session templates, scheduled messages.
