"""协作接口（N11/N12/统计回传）：把 profiles / artifacts / telemetry 接到服务端 HTTP。
所有路由都在 /api/collab/ 下，走服务端统一的登录校验。设置存在 CFG["collab"]。"""
from __future__ import annotations

import time
from aiohttp import web

TIERS = {"save": "轻奏", "standard": "正奏", "max": "华彩"}
DEFAULTS = {"tier": "standard", "profile_mode": "shadow", "telemetry": True, "consent": True}
S = None


def _json(data, status=200):
    return web.json_response(data, status=status, dumps=lambda o: __import__("json").dumps(o, ensure_ascii=False))


def settings() -> dict:
    cur = dict(DEFAULTS)
    cur.update((S.CFG.get("collab") or {}) if S else {})
    return cur


async def h_settings(request):
    if request.method == "PUT":
        body = await request.json()
        cur = settings()
        if body.get("tier") in TIERS:
            cur["tier"] = body["tier"]
        if body.get("profile_mode") in ("off", "shadow", "on"):
            cur["profile_mode"] = body["profile_mode"]
        if isinstance(body.get("consent"), bool):
            cur["consent"] = body["consent"]
        if isinstance(body.get("telemetry"), bool):
            cur["telemetry"] = body["telemetry"]
        S.CFG["collab"] = cur
        S.save_cfg()
        import os, orchestra
        os.environ["CHORUS_PROFILE_MODE"] = cur["profile_mode"]
    cur = settings()
    return _json({**cur, "tier_name": TIERS[cur["tier"]], "tiers": TIERS})


def _store(pid):
    import artifacts
    return artifacts.default_store(S.DATA, pid, enabled=True)


async def h_artifacts(request):
    pid = request.match_info["pid"]
    items = await _store(pid).list_by_project(pid, kind=request.query.get("kind"))
    return _json({"artifacts": items})


async def h_continue(request):
    pid, aid = request.match_info["pid"], request.match_info["aid"]
    body = await request.json()
    member = str(body.get("member") or "").strip()
    if not member:
        return _json({"error": "请选择让谁基于它继续改"}, 400)
    import artifacts
    try:
        task = await _store(pid).continue_from(aid, member, str(body.get("instruction") or ""))
    except artifacts.ArtifactNotFoundError:
        return _json({"error": "找不到这个产物"}, 404)
    return _json({"task": task})


async def h_assign_log(request):
    import orchestra
    return _json({"mode": orchestra.profile_mode(), "log": orchestra.PROFILE_SHADOW_LOG[-50:]})


async def h_rank(request):
    import profiles
    skill = request.query.get("skill", "code")
    members = [{"id": m.get("name"), "name": m.get("name"), "model": m.get("model")}
               for m in S.CFG.get("members", [])]
    return _json({"skill": skill, "rank": [{"member": m["name"], "score": s} for s, m in profiles.rank(members, skill)]})


async def h_telemetry_preview(request):
    import telemetry
    rep = telemetry.build_daily_report([], str(getattr(S, "VERSION", "brass")))
    clean, dropped = telemetry.sanitize(rep)
    return _json({"enabled": settings()["telemetry"], "report": clean, "dropped": len(dropped),
                  "note": "只上传按模型汇总的统计数字，不含聊天内容、文件、密钥和 IP"})


async def record_segment_artifacts(pid: str, producer: str, paths, title: str = ""):
    """段落验收通过后，把交付的文件登记进产物线（只收 DATA/files 下已存在的文件；失败不影响主流程）。"""
    try:
        import pathlib
        root = (S.DATA / "files").resolve()
        store = _store(pid)
        out = []
        for raw in paths or []:
            raw = str(raw).strip()
            if "/files/" not in raw:
                continue  # 只收 DATA/files 下的文件，其他路径一律不碰
            name = raw.split("/files/", 1)[1].split("?", 1)[0]
            f = (root / name).resolve()
            if not f.is_relative_to(root) or not f.is_file():
                continue
            prev = [a for a in await store.list_by_project(pid) if a["head"].get("origin_path") == str(f)]
            kw = dict(content=f, kind=__import__("artifacts").guess_kind(f), producer=producer, title=title or f.name, origin_path=str(f))
            if prev:
                h = prev[0]["head"]
                kw.update(line=h["line"], parent=h["id"], op="edit", version=h["version"] + 1)
            out.append((await store.add_artifact(**kw)).id)
        return out
    except Exception as e:
        print("record_segment_artifacts:", type(e).__name__, e)
        return []


async def h_profiles(request):
    """每个已接入声部的能力分（先验，随实测校正）和当前排名依据。"""
    import profiles
    db = profiles.load_defaults()
    members = [{"name": m.get("name"), "model": m.get("model")} for m in S.CFG.get("members", [])]
    out = []
    for m in members:
        p = profiles.find_profile(m["model"], db) or {}
        sk = {k: profiles.skill_score(m["model"], k, db) for k in db.get("skill_keys", [])}
        best = sorted(sk.items(), key=lambda kv: -kv[1])[:3]
        out.append({"name": m["name"], "model": m["model"], "label": p.get("label") or p.get("name") or m["model"],
                    "skills": sk, "best": best})
    return _json({"members": out, "as_of": db.get("as_of")})


def consent_block(member: dict) -> str:
    """定音：api 声部第一次用某把 key 前必须手动允许；返回空串表示放行，否则是给用户看的原因。CLI 声部没有 key，不拦。"""
    import os
    if not S or os.environ.get("CHORUS_CONSENT", "").lower() == "off" or not settings().get("consent", True) or member.get("kind") != "api":
        return ""
    import consent
    prov = next((p for p in S.CFG.get("providers", []) if p.get("id") == member.get("provider")), {})
    key, model = str(prov.get("key") or ""), str(member.get("model") or "")
    if consent.status(S.DATA, model, key) == "allowed":
        return ""
    try:
        c = consent.request(S.DATA, member.get("name", ""), model, key, "第一次使用这把 key")
    except OSError as e:
        print("consent_block:", e)
        return "pending"  # 写不进台账时宁可先拦下，也不放行未授权的 key
    return "denied" if c["state"] == "denied" else "pending"


async def h_consent(request):
    import consent
    if request.method == "POST":
        body = await request.json()
        fp, act = str(body.get("id") or ""), str(body.get("action") or "")
        ok = consent.revoke(S.DATA, fp) if act == "revoke" else consent.decide(S.DATA, fp, act == "allow")
        if not ok:
            return _json({"error": "找不到这条定音"}, 404)
    st = consent.load(S.DATA)
    return _json({"items": [{"id": k, **v} for k, v in st.items()], "enabled": settings().get("consent", True)})


async def h_skills(request):
    import skills
    if request.method == "PUT":
        body = await request.json()
        if not skills.set_enabled(S.DATA, request.match_info["sid"], bool(body.get("enabled"))):
            return _json({"error": "没有这个乐谱"}, 404)
    return _json({"skills": skills.listing(S.DATA, request.query.get("q", ""), request.query.get("category", ""))})


def register(app, server_module):
    global S
    S = server_module
    import os
    os.environ.setdefault("CHORUS_PROFILE_MODE", settings()["profile_mode"])
    r = app.router
    r.add_get("/api/collab/settings", h_settings)
    r.add_put("/api/collab/settings", h_settings)
    r.add_get("/api/collab/{pid}/artifacts", h_artifacts)
    r.add_post("/api/collab/{pid}/artifacts/{aid}/continue", h_continue)
    r.add_get("/api/collab/assign_log", h_assign_log)
    r.add_get("/api/collab/rank", h_rank)
    r.add_get("/api/collab/profiles", h_profiles)
    r.add_get("/api/collab/consent", h_consent)
    r.add_post("/api/collab/consent", h_consent)
    r.add_get("/api/collab/skills", h_skills)
    r.add_put("/api/collab/skills/{sid}", h_skills)
    r.add_get("/api/collab/telemetry/preview", h_telemetry_preview)
