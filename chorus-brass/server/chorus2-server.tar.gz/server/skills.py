"""乐谱库（技能库）：只存目录，用到时才装；GPL/AGPL 不打包；开关存 DATA/skills.json。纯标准库。"""
from __future__ import annotations
import json, os, pathlib, time

_CAT = pathlib.Path(__file__).parent / "profiles" / "skill_catalog.json"
BLOCKED_LICENSES = ("GPL", "AGPL")  # 由用户自己下载，不随包安装


def catalog() -> dict:
    try:
        return json.loads(_CAT.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"entries": []}


def _state_path(data) -> pathlib.Path:
    return pathlib.Path(data) / "skills.json"


def load_state(data) -> dict:
    try:
        return json.loads(_state_path(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_state(data, st: dict) -> None:
    p = _state_path(data)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


def installable(entry: dict) -> bool:
    lic = str(entry.get("license") or "").upper()
    return bool(entry.get("bundle_ok")) and not any(b in lic for b in BLOCKED_LICENSES)


def listing(data, q: str = "", category: str = "") -> list:
    st = load_state(data)
    out = []
    for e in catalog().get("entries", []):
        if category and e.get("category") != category:
            continue
        hay = " ".join([e.get("id", ""), e.get("desc", ""), " ".join(e.get("tags", []))]).lower()
        if q and q.lower() not in hay:
            continue
        s = st.get(e["id"], {})
        out.append({**e, "enabled": s.get("enabled", True), "uses": s.get("uses", 0), "passed": s.get("passed", 0),
                    "installable": installable(e), "installed": bool(s.get("installed"))})
    return out


def set_enabled(data, sid: str, enabled: bool) -> bool:
    if sid not in {e["id"] for e in catalog().get("entries", [])}:
        return False
    st = load_state(data)
    st.setdefault(sid, {})["enabled"] = bool(enabled)
    save_state(data, st)
    return True


def matches(data, task_type: str, text: str = "", limit: int = 3) -> list:
    """按任务类型和关键词挑最多 limit 个已启用的乐谱，只返回 id，正文用到才加载。"""
    st = load_state(data)
    scored = []
    for e in catalog().get("entries", []):
        if st.get(e["id"], {}).get("enabled", True) is False:
            continue
        s = (2 if task_type in e.get("task_types", []) else 0) + sum(1 for t in e.get("tags", []) if t and t in (text or ""))
        if s:
            scored.append((s, e.get("stars") or 0, e["id"]))
    scored.sort(reverse=True)
    return [x[2] for x in scored[:limit]]


def record_use(data, sid: str, passed: bool) -> None:
    st = load_state(data)
    s = st.setdefault(sid, {})
    s["uses"] = s.get("uses", 0) + 1
    s["passed"] = s.get("passed", 0) + (1 if passed else 0)
    s["last"] = int(time.time())
    save_state(data, st)
