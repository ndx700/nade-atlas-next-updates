"""夜曲 / 节拍器 / 序曲：确定性的夜间调度，不调模型、不联网。

* Duty     —— 一个乐章里值夜的一个成员；
* 节拍器   —— cron / event / interval 三类触发器；
* 序曲     —— 早上的晨报，按规则把昨晚的记录拼成几行中文；
* 通知     —— 夜里只在「要你定音 / 卡住 / 完成」时出声。
"""

import math
from dataclasses import dataclass, field

NOTIFY_KINDS = ("decide", "stopped", "done")

#: 需要人点头的合并/评审默认交给这位
OWNER = "Ali"


@dataclass
class Duty:
    """一个成员在一个乐章上的夜班安排。"""

    id: str
    pid: str
    member: str
    task: str
    window: tuple[int, int] = (23, 7)
    every_min: int = 60
    daily_cap: float = 5.0
    triggers: list[dict] = field(default_factory=list)
    connectors: dict[str, str] = field(default_factory=dict)
    enabled: bool = True


def in_window(d: Duty, local_hour: int) -> bool:
    """判断本地某点是否落在值班窗口内（end 为开区间的边界）。"""
    start, end = d.window[0] % 24, d.window[1] % 24
    hour = local_hour % 24
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end


def interval_for(d: Duty, quota_pct: float | None, local_hour: int | None = None) -> int | None:
    """按额度剩余决定巡逻间隔（分钟）；None 表示今夜别动。"""
    base = int(d.every_min)
    if quota_pct is None:
        return base
    if quota_pct >= 50:
        return base
    if quota_pct >= 20:
        return max(base, 240)
    if quota_pct >= 5:
        if local_hour is not None and not in_window(d, local_hour):
            return None
        return 480
    return None


def due(
    d: Duty,
    last_run: float | None,
    now: float,
    local_hour: int,
    quota_pct: float | None,
    spent_today: float,
) -> bool:
    """这一轮该不该叫醒它。"""
    if not d.enabled:
        return False
    if spent_today >= d.daily_cap:
        return False
    if not in_window(d, local_hour):
        return False
    interval = interval_for(d, quota_pct, local_hour)
    if interval is None:
        return False
    if last_run is None:
        return True
    return (now - last_run) >= interval * 60


def match_event(d: Duty, event: dict) -> bool:
    """事件是否命中这条 duty 的某个 event 触发器。"""
    if not d.enabled or not event:
        return False
    source = event.get("source")
    name = event.get("event")
    repo = event.get("repo")
    for trigger in d.triggers or []:
        if not isinstance(trigger, dict) or trigger.get("kind") != "event":
            continue
        if trigger.get("source") != source:
            continue
        if trigger.get("event") != name:
            continue
        wanted_repo = trigger.get("repo")
        if wanted_repo and repo and wanted_repo != repo:
            continue
        return True
    return False


def event_task(d: Duty, event: dict) -> str:
    """把事件翻成一句中文任务卡文字。"""
    source = event.get("source") or "外部"
    kind = event.get("event") or "unknown"
    repo = event.get("repo") or ""
    ref = event.get("run") or event.get("number") or event.get("n") or ""

    if repo and ref:
        head = "%s #%s" % (repo, ref)
    elif repo:
        head = repo
    elif ref:
        head = "#%s" % ref
    else:
        head = source

    if kind == "ci_failed":
        return "CI 失败（%s）：读日志、修复、开 PR，等 %s 合并" % (head, OWNER)
    if kind == "issue_opened":
        return "新 issue（%s）：能修就开 PR，修不动就留一条结论" % head
    if kind == "pr_review":
        return "PR 待评审（%s）：先读 diff，再列三条意见，等 %s 定音" % (head, OWNER)
    return "夜里收到 %s 的 %s（%s）：先看一眼要不要动，拿不准就问，别乱改" % (
        source,
        kind,
        head,
    )


def _parse_hhmm(at: str) -> tuple[int, int]:
    text = (at or "").strip()
    parts = text.split(":")
    if len(parts) != 2:
        raise ValueError("时间格式应为 HH:MM，收到 %r" % (at,))
    try:
        hour = int(parts[0])
        minute = int(parts[1])
    except ValueError:
        raise ValueError("时间格式应为 HH:MM，收到 %r" % (at,)) from None
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("时间超出范围：%r" % (at,))
    return hour, minute


def next_cron(at: str, now: float, tz_offset_h: int = 8) -> float:
    """返回 "HH:MM"（本地时间）下一次触发的时间戳（UTC 秒）。"""
    hour, minute = _parse_hhmm(at)
    offset = tz_offset_h * 3600
    local = now + offset
    day = math.floor(local / 86400.0)
    seconds_of_day = local - day * 86400.0
    target = hour * 3600 + minute * 60
    if target <= seconds_of_day + 1e-9:
        day += 1
    return day * 86400.0 + target - offset


class Overture:
    """序曲：早上的简报，纯规则拼装（之后可以再用便宜模型润色）。"""

    @staticmethod
    def build(
        records: list[dict],
        pending: list[dict],
        deliverables: list[dict],
        spend: dict,
        date: str,
    ) -> dict:
        records = list(records or [])
        pending = list(pending or [])
        deliverables = list(deliverables or [])
        spend = spend or {}

        by_member: dict[str, dict] = {}
        for rec in records:
            member = rec.get("member") or "未署名"
            slot = by_member.setdefault(member, {"runs": 0, "ok": 0, "cost": 0.0})
            slot["runs"] += 1
            if rec.get("ok"):
                slot["ok"] += 1
            try:
                slot["cost"] += float(rec.get("cost") or 0.0)
            except (TypeError, ValueError):
                pass

        for member, value in (spend.get("by_member") or {}).items():
            slot = by_member.setdefault(member, {"runs": 0, "ok": 0, "cost": 0.0})
            if isinstance(value, dict):
                if value.get("cost") is not None:
                    slot["cost"] = float(value["cost"])
            else:
                try:
                    slot["cost"] = float(value)
                except (TypeError, ValueError):
                    pass

        total = spend.get("total")
        if total is None:
            total = sum(slot["cost"] for slot in by_member.values())
        total = float(total)

        quiet = not records and not pending and not deliverables
        lines: list[str] = []

        if quiet:
            lines.append("昨夜安静：没有成员开工，也没有新交付。")
        else:
            groups: dict[tuple, list[dict]] = {}
            order: list[tuple] = []
            for rec in records:
                key = (rec.get("pid") or "", rec.get("name") or rec.get("pid") or "未命名乐章")
                if key not in groups:
                    groups[key] = []
                    order.append(key)
                groups[key].append(rec)

            for key in order:
                rows = groups[key]
                cost = 0.0
                for row in rows:
                    try:
                        cost += float(row.get("cost") or 0.0)
                    except (TypeError, ValueError):
                        pass
                ok_count = sum(1 for row in rows if row.get("ok"))
                lines.append(
                    "《%s》跑了 %d 件事，%d 件落地，花费 %.2f"
                    % (key[1], len(rows), ok_count, cost)
                )
                for row in rows:
                    mark = "✔" if row.get("ok") else "✘"
                    lines.append(
                        "· %s %s：%s"
                        % (mark, row.get("member") or "未署名", row.get("what") or "")
                    )

            if deliverables:
                titles = "、".join(
                    d.get("title") or "" for d in deliverables if d.get("title")
                )
                if titles:
                    lines.append("早上可取 %d 件：%s" % (len(deliverables), titles))
                else:
                    lines.append("早上可取 %d 件交付物" % len(deliverables))

            if pending:
                lines.append("待你定音 %d 张卡" % len(pending))

            cap_value = spend.get("cap")
            if total > 0 or cap_value is not None:
                if cap_value is None:
                    lines.append("昨夜花费 %.2f" % total)
                else:
                    lines.append("昨夜花费 %.2f / 上限 %.2f" % (total, float(cap_value)))

        return {
            "title": "序曲 · %s" % date,
            "lines": lines,
            "deliverables": deliverables,
            "pending_count": len(pending),
            "spent": total,
            "by_member": by_member,
            "quiet": quiet,
        }


def should_notify(kind: str) -> bool:
    """夜里只有这三种事允许吵醒人。"""
    return kind in NOTIFY_KINDS
