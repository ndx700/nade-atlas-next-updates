"""Public errors contain fixed Chinese copy, never upstream bodies or credentials."""
import asyncio
import json
import re

from aiohttp import ClientConnectionError, web


FIXES = frozenset({"retry", "repaste", "relogin", "topup", "edit_base", "settings", "none"})
DEFAULTS = {
    400: ("请求内容不对，请检查后重试", "none"),
    401: ("密码不对或登录已失效，请重新登录", "relogin"),
    403: ("没有权限执行这一步，请检查设置", "settings"),
    404: ("找不到这项内容，请刷新后重试", "retry"),
    405: ("这个操作方式不支持，请刷新后重试", "retry"),
    409: ("内容已变化，请刷新后重试", "retry"),
    410: ("这项内容已过期，请重新操作", "retry"),
    413: ("文件太大，请换一个小些的文件", "none"),
    415: ("文件格式不支持，请换一个文件", "none"),
    429: ("操作太频繁，请稍后重试", "retry"),
}


def payload(error, fix="none", **extra):
    if fix not in FIXES:
        raise ValueError("未知的修复操作")
    return {**extra, "error": error, "fix": fix}


def response(error, fix="none", *, status=400, **extra):
    return web.json_response(payload(error, fix, **extra), status=status)


async def json_object(request):
    try:
        body = await request.json()
    except (ValueError, UnicodeError):
        raise http_error(web.HTTPBadRequest, "请求内容无法读取，请检查后重新发送", "none") from None
    if not isinstance(body, dict):
        raise http_error(web.HTTPBadRequest, "请求内容必须包含要填写的项目，请重新操作", "none")
    return body


def http_error(kind, text=None, fix=None):
    message, action = DEFAULTS.get(kind.status_code, ("服务器暂时没能完成，请稍后重试", "retry"))
    exc = kind(text=json.dumps(payload(text or message, fix or action), ensure_ascii=False),
               content_type="application/json")
    exc.public_error = True
    return exc


def from_http(exc):
    if getattr(exc, "public_error", False) or exc.status < 400:
        return web.Response(body=exc.body, status=exc.status, headers=exc.headers)
    message, fix = DEFAULTS.get(exc.status, ("服务器暂时没能完成，请稍后重试", "retry"))
    # Older modules may raise text exceptions. Do not echo arbitrary text here.
    result = response(message, fix, status=exc.status)
    for key in ("Allow", "Retry-After", "WWW-Authenticate"):
        if key in exc.headers:
            result.headers[key] = exc.headers[key]
    return result


def upstream_http(kind, error):
    data = upstream(error)
    return http_error(kind, data["error"], data["fix"])


def upstream(error, *, fallback=None):
    """Classify privately; only these fixed messages may cross the API boundary."""
    text = str(error)
    rules = (
        (r"402|insufficient|余额|balance|arrear|quota|out of credits", "接口账户没余额了，请充值后重试", "topup"),
        (r"401|invalid.*key|unauthor|incorrect.*key|凭证", "接口密钥不对或已失效，请重新粘贴", "repaste"),
        (r"403|forbidden|permission denied", "接口没有访问权限，请检查设置", "settings"),
        (r"429|rate.?limit|限流", "对方暂时限流了，请稍后重试", "retry"),
        (r"HTTP\s+5\d\d|service unavailable|temporarily unavailable", "对方服务暂时不可用，请稍后重试", "retry"),
        (r"timeout|timed out|network|cannot connect|connect.*fail|name resolution|ssl|连不上|超时", "暂时连不上服务，请稍后重试", "retry"),
        (r"404|不是接口数据|不是模型列表|接口地址|base.?url|endpoint", "接口地址不对，请检查地址（中转站通常以 /v1 结尾）", "edit_base"),
        (r"没有.*接口|还没.*设置|还没填|先在.*设置|没有.*成员|没有.*命令", "请先在设置中配置可用的接口或成员", "settings"),
    )
    for pattern, message, fix in rules:
        if re.search(pattern, text, re.I):
            return payload(message, fix)
    if isinstance(error, (asyncio.TimeoutError, ClientConnectionError)):
        return payload("暂时连不上服务，请稍后重试", "retry")
    return fallback if fallback is not None else payload("服务暂时没能完成，请检查设置后重试", "settings")
