"""Antigravity (agy) /usage, read the only way it exists: drive the interactive CLI in a pseudo-terminal, type /usage,
read the screen. Ported from the old tools/aichat/publish_web.py gemini_quota (minus its GitHub debug push).
parse_usage() is pure and tested; read_screen() needs a real agy. Fallback only — structured sources win."""
from __future__ import annotations

import os
import re
import time


def parse_usage(screen: str, now: float | None = None) -> dict:
    """{'left': {'5小时': pct, '本周': pct}, 'reset': {...: epoch}} for the GEMINI MODELS group."""
    now = time.time() if now is None else now
    text = re.sub(r"\x1b\[[0-9;?]*[Hf]", "\n", screen)
    text = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[()][0-9A-Za-z]|\x1b[=>]|[\x00-\x08\x0e-\x1f]", " ", text)
    group, label, found, resets = "", "", {}, {}
    for line in text.splitlines():
        line = re.sub(r"[│┃|█▓▒░■□━─\[\]]+", " ", line)
        line = re.sub(r"\s+", " ", line).strip()
        if re.fullmatch(r"[A-Z][A-Z &]+MODELS", line):
            group = line
        elif re.search(r"limit remaining", line, re.I):
            label = "本周" if "week" in line.lower() else "5小时" if "five" in line.lower() or "5" in line else line
        r = re.search(r"resets?\s+(?:in\s+)?((?:\d+\s*[dhm]\w*\s*)+)", line, re.I)
        if r and label and (group, label) not in resets:
            secs = sum(int(n) * {"d": 86400, "h": 3600, "m": 60}[u[0].lower()] for n, u in re.findall(r"(\d+)\s*([dhmDHM])", r.group(1)))
            resets[(group, label)] = now + secs
        m = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
        if m and label and (group, label) not in found:
            found[(group, label)] = float(m.group(1))
    return {"left": {k[1]: v for k, v in found.items() if "GEMINI" in k[0]},
            "reset": {k[1]: v for k, v in resets.items() if "GEMINI" in k[0]}}


def read_screen(agy: str = "~/.local/bin/agy") -> str:
    agy = os.path.expanduser(agy)
    if not os.path.exists(agy):
        return ""
    import fcntl, pty, select, signal, struct, tempfile, termios
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(tempfile.gettempdir())
        os.environ.update(TERM="xterm-256color", COLUMNS="160", LINES="50")
        os.execv(agy, [agy])
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", 50, 160, 0, 0))
    raw = b""

    def read(seconds):
        nonlocal raw
        end = time.time() + seconds
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.3)
            if r:
                try:
                    raw += os.read(fd, 65536)
                except OSError:
                    return
    try:
        read(12)
        mark = 0
        for keys in ([b"\r"], [b"\t", b"\t", b"\r"], [b"\x1b[C", b"\r"], [b"\r"], [b"\t", b"\r"], [b"\r"]):  # first-run wizard
            if not re.search(r"\[(Done|Next|Previous|Continue|Finish)\]|I agree", raw[mark:].decode(errors="replace")[-300:]):
                break
            mark = len(raw)
            for k in keys:
                os.write(fd, k)
                read(1)
            read(3)
        start = len(raw)
        os.write(fd, b"/usage\r")
        read(12)
        screen = raw[start:].decode(errors="replace")
        os.write(fd, b"\x1b")
        read(1)
        os.write(fd, b"/exit\r")
        read(2)
    finally:
        try:
            os.kill(pid, signal.SIGKILL)
            os.waitpid(pid, 0)
        except OSError:
            pass
    return screen
