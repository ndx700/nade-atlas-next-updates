#!/bin/sh
# 小克 as a Chorus CLI member: Claude Code on the token the Claude CLI workflow saved. $1 is the model picked in the app.
# In -p mode nobody can answer a permission prompt, so every request counted as refused (Ali 10-26). Prompts now go to
# approve_mcp.py, which puts a 同意/拒绝 card in the chat and waits for Ali's tap.
d=$(dirname "$0")
cfg=$(printf '{"mcpServers":{"chorus":{"command":"python3","args":["%s/approve_mcp.py"]}}}' "$d")
CLAUDE_CODE_OAUTH_TOKEN="$(cat "$HOME/.config/chorus/claude_token")" \
  exec claude -p --model "${1:-claude-opus-5-5}" --mcp-config "$cfg" --permission-prompt-tool mcp__chorus__approve
