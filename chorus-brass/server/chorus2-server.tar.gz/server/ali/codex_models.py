#!/usr/bin/env python3
"""龙娘's models for Chorus (models_cmd): the Codex CLI keeps the models its account offers in ~/.codex/models_cache.json;
print them as "slug<TAB>name". Nothing printed (no cache yet) keeps the list Chorus has."""
import json
import pathlib


def walk(o):
    if isinstance(o, dict):
        if isinstance(o.get("slug"), str):
            yield o
        for v in o.values():
            yield from walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from walk(v)


f = pathlib.Path.home() / ".codex" / "models_cache.json"
if f.exists():
    seen = set()
    for m in walk(json.loads(f.read_text())):
        if m["slug"] in seen or m.get("visibility") in ("hide", "hidden"):
            continue
        seen.add(m["slug"])
        print(f"{m['slug']}\t{m.get('display_name') or m['slug']}")
