#!/usr/bin/env python3
"""猫猫's quota for Chorus (member quota type "cmd"): reads the Antigravity CLI's /usage panel the way the old group-chat
page did (ported into ali/agy_usage.py) and prints {pct, reset, week, week_reset, short} as JSON.
Reading it drives agy in a terminal for half a minute, so the answer is kept for 10 minutes."""
import datetime
import json
import os
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import agy_usage  # noqa: E402

CACHE = pathlib.Path(os.environ.get("AICHAT_DATA", "/var/lib/chorus")) / "agy_quota.json"


def when(ts):
    tz = datetime.timezone(datetime.timedelta(hours=8))
    at = datetime.datetime.fromtimestamp(ts, tz)
    return at.strftime("%H:%M 刷新" if at.date() == datetime.datetime.now(tz).date() else "%m-%d %H:%M 刷新")


if CACHE.exists() and time.time() - CACHE.stat().st_mtime < 600:
    print(CACHE.read_text())
    sys.exit()
u = agy_usage.parse_usage(agy_usage.read_screen())
left, reset = u["left"], u["reset"]
if not left:
    print("{}")
    sys.exit()
q = {"pct": round(left["5小时"]) if "5小时" in left else None, "reset": when(reset["5小时"]) if "5小时" in reset else "",
     "week": round(left["本周"]) if "本周" in left else None, "week_reset": when(reset["本周"]) if "本周" in reset else ""}
q["short"] = f"{q['pct'] if q['pct'] is not None else q['week']}%"
out = json.dumps(q, ensure_ascii=False)
CACHE.write_text(out)
print(out)
