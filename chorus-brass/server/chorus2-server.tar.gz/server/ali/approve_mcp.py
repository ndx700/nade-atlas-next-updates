#!/usr/bin/env python3
"""小克's permission prompts as Chorus cards (Ali 10-26: 她让我选择同意安装的弹窗我看不到).

A tiny MCP server (stdio, JSON-RPC) with one tool, `approve`, which Claude Code calls through --permission-prompt-tool
whenever it needs permission. The request goes to the Chorus server (CHORUS_APPROVE_URL, set for each CLI run), which
shows a card in the chat and answers once Ali taps 同意 or 拒绝.
"""
import json
import os
import sys
import urllib.request

TOOL = {
    "name": "approve",
    "description": "Ask Ali in the Chorus chat whether this tool call may run.",
    "inputSchema": {"type": "object", "properties": {"tool_name": {"type": "string"}, "input": {"type": "object"},
                                                     "tool_use_id": {"type": "string"}}, "required": ["tool_name", "input"]},
}


def ask(args):
    body = json.dumps({"pid": os.environ.get("CHORUS_PID", ""), "who": os.environ.get("CHORUS_WHO", "小克"),
                       "dm": os.environ.get("CHORUS_DM", ""), "tool": args.get("tool_name", ""), "input": args.get("input") or {}}).encode()
    req = urllib.request.Request(os.environ.get("CHORUS_APPROVE_URL", ""), data=body,
                                 headers={"content-type": "application/json", "X-Key": os.environ.get("CHORUS_APPROVE_KEY", "")})
    try:
        with urllib.request.urlopen(req, timeout=660) as r:
            a = json.load(r)
    except Exception as e:  # noqa: BLE001 - no answer is a refusal
        a = {"allow": False, "why": f"没能问到 Ali：{e}"}
    if a.get("allow"):
        return {"behavior": "allow", "updatedInput": args.get("input") or {}}
    return {"behavior": "deny", "message": a.get("why") or "Ali 没有同意"}


def send(o):
    sys.stdout.write(json.dumps(o, ensure_ascii=False) + "\n")
    sys.stdout.flush()


for line in sys.stdin:
    try:
        msg = json.loads(line)
    except ValueError:
        continue
    mid, method = msg.get("id"), msg.get("method", "")
    if mid is None:
        continue  # notifications need no answer
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": mid, "result": {"protocolVersion": msg.get("params", {}).get("protocolVersion", "2024-11-05"),
                                                      "capabilities": {"tools": {}}, "serverInfo": {"name": "chorus", "version": "1"}}})
    elif method == "tools/list":
        send({"jsonrpc": "2.0", "id": mid, "result": {"tools": [TOOL]}})
    elif method == "tools/call":
        res = ask(msg.get("params", {}).get("arguments") or {})
        send({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": json.dumps(res, ensure_ascii=False)}]}})
    else:
        send({"jsonrpc": "2.0", "id": mid, "result": {}})
