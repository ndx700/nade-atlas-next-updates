#!/usr/bin/env python3
"""Ali's own Chorus server (10-25): his members with his names and personas, his keys, and the two old groups' history.
Run on the build server by chorus.yml. Distributed servers never run this (Ali: 不给模型带任何东西).
  DATA=/var/lib/chorus DEEPSEEK_KEY=... ARK_API_KEY=... python3 setup_ali.py transcript.md video.md
Running it again refreshes members and keys and keeps everything else (chats, memory, projects)."""
import json
import os
import pathlib
import re
import sys
import time

DATA = pathlib.Path(os.environ.get("DATA", "/var/lib/chorus"))
TOOLS = pathlib.Path(os.environ.get("AICHAT_TOOLS", "/opt/chorus/tools/aichat"))


def section(text, head):
    try:
        start = text.index(head)
    except ValueError:
        return ""
    end = text.find("\n## ", start + 1)
    return text[start:end if end > 0 else None].split("\n", 1)[-1].strip()


def main():
    (DATA / "chats").mkdir(parents=True, exist_ok=True)
    cfg_p = DATA / "config.json"
    cfg = json.loads(cfg_p.read_text()) if cfg_p.exists() else {}
    P = (TOOLS / "personas.md").read_text()
    V = (TOOLS / "personas_video.md").read_text()
    cfg["name"] = "Ali 的 AI 群"
    cfg["password"] = os.environ.get("CHORUS_PASSWORD") or cfg.get("password", "")
    cfg["helper"] = "大肥鱼"
    cfg["summary_helper"] = "大肥鱼"
    cfg["price_helper"] = "猫猫"  # browses the web (一键查价格)
    # Ali 10-26 (以后只推正式版): his phone runs the 正式版 too (build 128 wrote his login into the app first), so his
    # server follows the public channel like a friend's.
    cfg["update_from"] = "http://47.100.106.26/ds/chorus/public/latest.json"
    cfg["update_every"] = 300  # Ali tests every build: a new one reaches his phone within 5 minutes
    provs = {p["id"]: p for p in cfg.get("providers", [])}
    provs["deepseek"] = {**provs.get("deepseek", {}), "id": "deepseek", "name": "DeepSeek", "kind": "openai", "base": "https://api.deepseek.com",
                         "key": os.environ.get("DEEPSEEK_KEY", provs.get("deepseek", {}).get("key", ""))}
    provs["ark"] = {**provs.get("ark", {}), "id": "ark", "name": "火山方舟", "kind": "openai", "base": "https://ark.cn-beijing.volces.com/api/v3",
                    "key": os.environ.get("ARK_API_KEY", provs.get("ark", {}).get("key", ""))}
    if os.environ.get("VOLC_AK") and os.environ.get("VOLC_SK"):  # 火山 balance (billing API needs the account's AccessKey)
        provs["ark"].update(volc_ak=os.environ["VOLC_AK"], volc_sk=os.environ["VOLC_SK"])
    cfg["providers"] = list(provs.values())
    high = [["high", "高"], ["xhigh", "超高"], ["medium", "中"], ["low", "低"]]
    mine = [
        {"name": "龙娘", "kind": "cli", "model": "gpt-6.1-sol", "models": [["gpt-6.1-sol", "GPT-6.1 Sol"]], "efforts": high, "effort": "high",
         "cmd": "codex exec -m {model} -c model_reasoning_effort={effort} -s read-only --skip-git-repo-check -o {out} -",
         "persona": section(P, "## 二、"), "quota": {"type": "codex"}, "timeout": 1800,
         "models_cmd": "python3 /opt/chorus/aichat-server/ali/codex_models.py"},
        {"name": "猫猫", "kind": "cli", "model": "gemini-3.8-flash-high", "models": [["gemini-3.8-flash-high", "Gemini 3.8 Flash (High)"]], "efforts": [],
         "cmd": "python3 /opt/chorus/aichat-server/ali/agy_say.py {model}", "models_cmd": "$HOME/.local/bin/agy models",
         "persona": section(P, "## 三、"), "quota": {"type": "cmd", "cmd": "python3 /opt/chorus/aichat-server/ali/agy_quota.py"}, "timeout": 1800},
        # 小克 (Ali 10-25: 安一个): Claude Code on the build server, signed in by the Claude CLI workflow.
        {"name": "小克", "kind": "cli", "model": "claude-opus-5-5", "efforts": [],
         "models": [["claude-opus-5-5", "Claude Opus 5.5"], ["claude-sonnet-5-5", "Claude Sonnet 5.5"], ["claude-haiku-5-5", "Claude Haiku 5.5"],
                    ["claude-fable-5-1", "Claude Fable 5.1"]],
         "cmd": "sh /opt/chorus/aichat-server/ali/claude_say.sh {model}",
         "quota": {"type": "cli", "exe": "claude"}  # read via `claude -p /usage` (cli_quota.py); no saved-token API calls,
         "persona": section(P, "## 一、"), "timeout": 1800},
        {"name": "大肥鱼", "kind": "api", "provider": "deepseek", "model": "deepseek-flash", "efforts": [],
         "models": [["deepseek-flash", "DeepSeek 4.1 Flash (10.17)"], ["deepseek-v4-pro", "DeepSeek V4 Pro"]], "persona": section(P, "## 四、")},
        {"name": "豆包", "kind": "api", "provider": "ark", "model": "doubao-seed-2-1-pro-260915", "effort": "high",
         "models": [["doubao-seed-2-1-pro-260915", "Doubao Seed 2.1 Pro"], ["doubao-seed-2-1-lite-260915", "Doubao Seed 2.1 Lite"]],
         "efforts": [["high", "高"], ["medium", "中"], ["low", "低"], ["minimal", "关闭"]], "persona": section(V, "## 豆包娘")},
        {"name": "Kimi", "kind": "api", "provider": "ark", "model": "kimi-k3-1-pro-261024", "efforts": [],
         "models": [["kimi-k3-1-pro-261024", "Kimi K3.1 Pro"]], "persona": section(V, "## Kimi娘")},
        {"name": "GLM", "kind": "api", "provider": "ark", "model": "glm-5-3-flash-260828", "efforts": [],
         "models": [["glm-5-3-flash-260828", "GLM 5.3 Flash"]], "persona": section(V, "## GLM娘")},
    ]
    old = {m["name"]: m for m in cfg.get("members", [])}
    for m in mine:
        o = old.get(m["name"], {})
        keep = {k: v for k, v in o.items() if k in ("avatar", "voice", "auto", "daily_cap", "daily_tokens", "context", "role", "price")}
        if m.get("models_cmd"):  # its list comes from the CLI itself: keep what it read and what was picked
            keep.update({k: o[k] for k in ("model", "models") if o.get(k)})
        elif o.get("model") and any(x[0] == o["model"] for x in m.get("models") or []):
            keep["model"] = o["model"]
        old[m["name"]] = {**m, **keep}
    cfg["members"] = list(old.values())
    cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=1))

    pj = DATA / "projects.json"
    projects = json.loads(pj.read_text()) if pj.exists() else []
    plan = [("work", "NadeAtlas 开发", "NadeAtlas：CS2 道具教学 Android 应用的开发协作群。", ["龙娘", "猫猫", "大肥鱼"], sys.argv[1] if len(sys.argv) > 1 else None),
            ("video", "AI 剧本杀视频", "一起拍 B 站的《AI 剧本杀》系列视频。", ["龙娘", "猫猫", "大肥鱼", "豆包", "Kimi", "GLM"], sys.argv[2] if len(sys.argv) > 2 else None),
            # Ali 10-26: 把咱们这个项目也加进去.
            ("chorus", "Chorus 开发", "Chorus：这个 AI 群聊 app 本身的开发协作群（Android 原生 app + 可一键部署的服务器）。",
             ["小克", "龙娘", "猫猫", "大肥鱼"], None)]
    for pid, name, brief, members, src in plan:
        if any(p["id"] == pid for p in projects):
            continue
        projects.append({"id": pid, "name": name, "brief": brief, "members": members, "created": time.time()})
        if src and pathlib.Path(src).exists():
            msgs = parse_transcript(pathlib.Path(src).read_text(errors="replace"))[-1500:]
            with (DATA / "chats" / f"{pid}.jsonl").open("w") as f:
                for i, m in enumerate(msgs, 1):
                    f.write(json.dumps({"seq": i, "who": m["who"], "at": m["at"], "text": m["text"], "dm": "", "ts": time.time()}, ensure_ascii=False) + "\n")
            print(pid, len(msgs), "messages imported")
    # 小克 joins both groups once (Ali 10-25); after that the app's 加减成员 decides.
    if not cfg.get("added_xiaoke"):
        for p in projects:
            if p["id"] in ("work", "video") and "小克" not in p["members"]:
                p["members"].append("小克")
        cfg["added_xiaoke"] = True
        cfg_p.write_text(json.dumps(cfg, ensure_ascii=False, indent=1))
    pj.write_text(json.dumps(projects, ensure_ascii=False, indent=1))


HEAD = re.compile(r"^### (\d\d-\d\d \d\d:\d\d)\s*$")
SAY = re.compile(r"^\*\*([^*]{1,30})\*\*(?:（[^）]*）)?[：:]\s?(.*)$")


def parse_transcript(s):
    """The old chat files: "### MM-DD HH:MM" headings, then "**Name**：text" (or "**Name**（第 2 轮）：")."""
    out, at = [], ""
    for line in s.splitlines():
        h = HEAD.match(line)
        if h:
            at = h.group(1)
            continue
        m = SAY.match(line)
        if m:
            out.append({"who": m.group(1).strip(), "at": at, "text": m.group(2)})
        elif out and line.strip() != "---":
            out[-1]["text"] += "\n" + line
    for m in out:
        m["text"] = m["text"].strip()
    return [m for m in out if m["text"]]


if __name__ == "__main__":
    main()
