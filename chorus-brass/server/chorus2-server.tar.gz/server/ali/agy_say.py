#!/usr/bin/env python3
"""猫猫 as a Chorus CLI member: the prompt on stdin, her answer on stdout, through the Antigravity CLI sign-in (the
same path the old group chat used: tools/aichat/group.py ask_gemini, with its retries for empty answers).
The first argument, when given, is the agy model (`agy models`) picked in the app."""
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(os.environ.get("AICHAT_TOOLS", "/opt/chorus/tools/aichat"))))
os.environ.setdefault("GEMINI_VIA", "agy")
import group  # noqa: E402

model = sys.argv[1] if len(sys.argv) > 1 else ""
if model:
    run = group.run_agy
    group.run_agy = lambda prompt, attempt, asked, extra=(), **k: run(prompt, attempt, asked, extra=("--model", model, *extra), **k)

print(group.ask_gemini("", sys.stdin.read()) or "")
