"""Chorus — 强带弱 orchestration core (pure logic, no server import).

乐章=project, 段落=segment, 声部=member, 指挥=lead, 谱稿=plan, 回响=deliverables, 定音=decision.

All functions are pure with respect to the running server: integration happens
through an injected module object ``s`` (the running server module) passed to the
few functions that need config/prices/quota.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "TIER_RULES",
    "CLARIFY_LIMIT",
    "PLAN_PROMPT",
    "ADVISOR_PROMPT",
    "tier_of",
    "pick_lead",
    "need_tier",
    "assign",
    "parse_plan",
    "task_card_text",
    "ready",
    "stage_weight",
    "segment_pct",
    "project_pct",
    "eta_seconds",
    "ladder_next",
    "advisor_request",
    "review_needed",
    "on_chunk",
    "on_checklist",
    "record_spend",
    "budget_state",
    "baseline_cost",
    "decide_or_ask",
    "concerto_route",
    "parallel_conflicts",
    "snapshot",
    "diff",
]

# --------------------------------------------------------------------------- #
# tiers
# --------------------------------------------------------------------------- #

TIER_RULES: List[Tuple[str, "re.Pattern[str]"]] = [
    (
        "strong",
        re.compile(
            r"opus|fable|mythos|gpt-5(?!.*mini)|o3|grok-4(?!.*fast)"
            r"|gemini-.*pro|deepseek-v4-pro|mimo-v2\.6-pro|kimi-k2.*thinking|glm-5",
            re.I,
        ),
    ),
    (
        "weak",
        re.compile(
            r"flash|mini|lite|haiku|nano|small|turbo|air|fast",
            re.I,
        ),
    ),
]

_TIER_RANK = {"weak": 0, "mid": 1, "strong": 2}

# tier default price per MTok (in, out, cached) — relative units
TIER_DEFAULT_PRICE = {"strong": (8.0, 2.0, 0.5), "mid": (3.0, 0.8, 0.2), "weak": (1.0, 0.3, 0.05)}


def tier_of(member: dict) -> str:
    """Explicit member["tier"] wins, else inferred from the model name."""
    if not isinstance(member, dict):
        return "mid"
    explicit = str(member.get("tier") or "").strip().lower()
    if explicit in _TIER_RANK:
        return explicit
    model = str(member.get("model") or member.get("name") or "")
    for tier, pat in TIER_RULES:
        if pat.search(model):
            return tier
    return "mid"


def _tier_rank(t: str) -> int:
    return _TIER_RANK.get(t, 1)


# --------------------------------------------------------------------------- #
# availability / prices
# --------------------------------------------------------------------------- #

def _member_name(m: dict) -> str:
    return str(m.get("name") or m.get("id") or "")


def _is_auto(m: dict) -> bool:
    return m.get("auto", True) is not False


def _quota_entry(quota: Any, name: str) -> dict:
    if not quota:
        return {}
    try:
        q = quota.get(name) if isinstance(quota, dict) else None
    except Exception:
        q = None
    return q if isinstance(q, dict) else {}


def _quota_pct(q: dict) -> float:
    pct = q.get("pct")
    try:
        pct = float(pct)
    except (TypeError, ValueError):
        return 100.0
    return max(0.0, min(100.0, pct))


def _quota_kind(q: dict) -> str:
    return str(q.get("kind") or "").strip().lower()


def _available(m: dict, quota: Any) -> bool:
    if not isinstance(m, dict) or not _member_name(m):
        return False
    if not _is_auto(m):
        return False
    if m.get("available") is False:
        return False
    q = _quota_entry(quota, _member_name(m))
    if str(q.get("state") or "").strip().lower() == "arrears":
        return False
    if "pct" in q and _quota_pct(q) < 5.0:
        return False
    return True


def _price_of(m: dict, s: Any = None) -> Tuple[float, float, float]:
    """(in, out, cached) per MTok. Unknown price -> tier default."""
    t = tier_of(m)
    default = TIER_DEFAULT_PRICE.get(t, TIER_DEFAULT_PRICE["mid"])
    price_fn: Optional[Callable[..., Any]] = None
    if s is not None:
        price_fn = getattr(s, "price", None)
    if callable(price_fn):
        try:
            p = price_fn(m, m.get("model"))
        except Exception:
            p = None
        if isinstance(p, dict):
            try:
                return (
                    float(p.get("in", default[0])),
                    float(p.get("out", default[1])),
                    float(p.get("cached", default[2])),
                )
            except (TypeError, ValueError):
                return default
        if isinstance(p, (list, tuple)) and len(p) >= 2:
            try:
                return (
                    float(p[0]),
                    float(p[1]),
                    float(p[2]) if len(p) > 2 else default[2],
                )
            except (TypeError, ValueError):
                return default
    return default


def _is_subscription(m: dict, quota: Any) -> bool:
    if str(m.get("kind") or "").strip().lower() == "cli":
        return True
    return _quota_kind(_quota_entry(quota, _member_name(m))) in ("plan", "window")


def _stat(stats: Any, name: str) -> dict:
    if not stats:
        return {}
    try:
        v = stats.get(name) if isinstance(stats, dict) else None
    except Exception:
        v = None
    return v if isinstance(v, dict) else {}


def _pass_rate(stats: Any, name: str) -> float:
    st = _stat(stats, name)
    try:
        p = float(st.get("pass", 0.8))
    except (TypeError, ValueError):
        p = 0.8
    return max(0.0, min(1.0, p))


def _fail_rate(stats: Any, name: str) -> float:
    return 1.0 - _pass_rate(stats, name)


# --------------------------------------------------------------------------- #
# lead
# --------------------------------------------------------------------------- #

def pick_lead(project: dict, members: Sequence[dict], quota: Any = None, stats: Any = None) -> str:
    """Resolve the 指挥 for a 乐章. Returns "" when nobody is available."""
    members = list(members or [])
    by_name = {_member_name(m): m for m in members if _member_name(m)}

    explicit = str((project or {}).get("lead") or "").strip()
    if explicit:
        m = by_name.get(explicit)
        if m is not None and _available(m, quota):
            return explicit

    pool = [m for m in members if _available(m, quota)]
    if not pool:
        return ""

    def key(m: dict) -> Tuple:
        name = _member_name(m)
        q = _quota_entry(quota, name)
        has_quota = 1 if q else 0
        pin, pout, _ = _price_of(m, None)
        price = pin * 0.7 + pout * 0.3
        return (
            -_tier_rank(tier_of(m)),
            -_pass_rate(stats, name),
            -has_quota,
            price,
            name,
        )

    pool.sort(key=key)
    return _member_name(pool[0])


# --------------------------------------------------------------------------- #
# difficulty -> tier
# --------------------------------------------------------------------------- #

def need_tier(difficulty: Any) -> str:
    try:
        d = int(difficulty)
    except (TypeError, ValueError):
        d = 3
    if d <= 2:
        return "weak"
    if d == 3:
        return "mid"
    return "strong"


# --------------------------------------------------------------------------- #
# assign
# --------------------------------------------------------------------------- #

def _est_cost(seg: dict, m: dict, quota: Any, s: Any = None) -> float:
    est = _tokens(seg)
    if _is_subscription(m, quota):
        q = _quota_entry(quota, _member_name(m))
        pct = _quota_pct(q) if ("pct" in q) else 100.0
        return (est / 1e6) * 1.0 * (1.0 + (100.0 - pct) / 50.0)
    pin, pout, _ = _price_of(m, s)
    return (est / 1e6) * (pin * 0.7 + pout * 0.3)


def _tokens(seg: dict) -> float:
    try:
        v = float(seg.get("est_tokens", 4000) or 0)
    except (TypeError, ValueError):
        v = 4000.0
    return max(0.0, v)


def _assign_legacy(
    segment: dict,
    candidates: Sequence[dict],
    quota: Any = None,
    stats: Any = None,
    queue: Any = None,
    s: Any = None,
) -> str:
    """Pick the cheapest capable member. Returns "" if no candidate."""
    candidates = list(candidates or [])
    need = need_tier((segment or {}).get("difficulty"))
    need_rank = _tier_rank(need)

    required = [str(x).strip().lower() for x in (segment or {}).get("skills") or [] if str(x).strip()]

    pool: List[dict] = []
    for m in candidates:
        if not _available(m, quota):
            continue
        if _tier_rank(tier_of(m)) < need_rank:
            continue
        if m.get("priority") == "low" and need_rank > 0:
            continue
        pool.append(m)
    if not pool:
        return ""

    def overlap(m):
        return set(required) & {str(x).strip().lower() for x in m.get("skills") or []}

    preferred = [m for m in pool if not m.get("skills") or overlap(m)]
    pool = preferred or pool

    def q_len(name: str) -> float:
        if not queue:
            return 0.0
        try:
            v = queue.get(name) if isinstance(queue, dict) else None
        except Exception:
            v = None
        if v is None:
            return 0.0
        try:
            return max(0.0, float(v))
        except (TypeError, ValueError):
            return 0.0

    scored: List[Tuple[float, int, str, dict]] = []
    for m in pool:
        name = _member_name(m)
        est = _est_cost(segment, m, quota, s)
        score = est * (1.0 + 2.0 * _fail_rate(stats, name)) + 0.15 * est * q_len(name)
        if overlap(m):
            score *= 0.8
        scored.append((score, -_tier_rank(tier_of(m)), name, m))

    scored.sort(key=lambda t: (t[0], t[1], t[2]))
    return _member_name(scored[0][3])


# --- 能力画像层（N12）：off=不用 / shadow=只记录对比（默认）/ on=按强项派活 ---------- #
import os as _os

_SKILL_HINTS = (
    ("image_gen", ("出图", "生成图", "海报", "image")),
    ("video_gen", ("视频", "video")),
    ("tts", ("配音", "朗读", "语音合成")),
    ("ui_design", ("界面", "UI", "设计", "动效")),
    ("vision", ("看图", "截图", "识图")),
    ("writing_zh", ("文案", "写作", "润色", "翻译")),
    ("data", ("数据", "表格", "统计")),
    ("plan", ("规划", "拆分", "方案")),
    ("code", ("代码", "实现", "修复", "编译", "接口", "测试")),
)
PROFILE_SHADOW_LOG: List[dict] = []


def profile_mode() -> str:
    m = _os.environ.get("CHORUS_PROFILE_MODE", "shadow").strip().lower()
    return m if m in ("off", "shadow", "on") else "shadow"


def segment_skill(segment: dict) -> str:
    seg = segment or {}
    try:
        import profiles
        keys = set(profiles.load_defaults().get("skill_keys") or [])
    except Exception:
        keys = set()
    for k in [seg.get("skill_key")] + list(seg.get("skills") or []):
        if k and str(k).strip().lower() in keys:
            return str(k).strip().lower()
    text = " ".join(str(seg.get(f) or "") for f in ("title", "goal", "deliverable"))
    for key, words in _SKILL_HINTS:
        if any(w.lower() in text.lower() for w in words):
            return key
    return "code"


def assign(segment: dict, candidates: Sequence[dict], quota: Any = None, stats: Any = None,
           queue: Any = None, s: Any = None) -> str:
    """原有「最省够用」选择之上叠加能力画像：on 时同档位内谁强给谁，shadow 只记录差异。"""
    legacy = _assign_legacy(segment, candidates, quota, stats, queue, s)
    mode = profile_mode()
    if mode == "off" or not legacy:
        return legacy
    try:
        import profiles
        pool = [m for m in (candidates or []) if _available(m, quota)]
        for m in pool:
            m.setdefault("model", m.get("model") or m.get("name"))
        skill = segment_skill(segment)
        best = profiles.pick(pool, skill)
        who = _member_name(best["member"]) if "member" in best else ""
        rec = {"t": int(time.time()), "skill": skill, "legacy": legacy, "profile": who or None,
               "missing": best.get("missing"), "score": best.get("score")}
        PROFILE_SHADOW_LOG.append(rec)
        del PROFILE_SHADOW_LOG[:-200]
        if mode == "on" and who and who != legacy and not (segment or {}).get("assignee"):
            return who
    except Exception:
        pass
    return legacy


# --------------------------------------------------------------------------- #
# plan parsing
# --------------------------------------------------------------------------- #

_FENCE_RE = re.compile(r"```(?:json|JSON)?\s*(.*?)```", re.S)

_SEGMENT_FIELDS = (
    "id",
    "title",
    "goal",
    "inputs",
    "deliverable",
    "acceptance",
    "difficulty",
    "est_tokens",
    "skills",
    "context",
    "assignee",
    "stage",
    "progress",
    "ladder",
    "spend",
    "started",
    "done_at",
    "events",
)


def _new_segment() -> dict:
    return {
        "id": "",
        "title": "",
        "goal": "",
        "inputs": [],
        "deliverable": "",
        "acceptance": [],
        "difficulty": 3,
        "est_tokens": 4000,
        "skills": [],
        "context": "",
        "assignee": "",
        "stage": "waiting",
        "progress": 0.0,
        "ladder": [],
        "spend": {
            "in": 0,
            "out": 0,
            "cached": 0,
            "cost": 0.0,
            "by_role": {"plan": 0.0, "exec": 0.0, "advisor": 0.0, "review": 0.0},
        },
        "started": None,
        "done_at": None,
        "events": [],
    }


def _extract_json(text: str) -> Any:
    if not text:
        return None
    candidates: List[str] = []
    for m in _FENCE_RE.finditer(text):
        candidates.append(m.group(1))
    candidates.append(text)

    for chunk in candidates:
        chunk = chunk.strip()
        if not chunk:
            continue
        # direct parse
        try:
            return json.loads(chunk)
        except Exception:
            pass
        # scan for the first balanced [...] or {...}
        for opener, closer in (("[", "]"), ("{", "}")):
            start = chunk.find(opener)
            while start != -1:
                depth = 0
                in_str = False
                esc = False
                for i in range(start, len(chunk)):
                    ch = chunk[i]
                    if in_str:
                        if esc:
                            esc = False
                        elif ch == "\\":
                            esc = True
                        elif ch == '"':
                            in_str = False
                        continue
                    if ch == '"':
                        in_str = True
                    elif ch == opener:
                        depth += 1
                    elif ch == closer:
                        depth -= 1
                        if depth == 0:
                            frag = chunk[start : i + 1]
                            try:
                                return json.loads(frag)
                            except Exception:
                                break
                start = chunk.find(opener, start + 1)
    return None


def _as_str_list(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, str):
        return [v] if v.strip() else []
    if isinstance(v, (list, tuple)):
        out: List[str] = []
        for x in v:
            if isinstance(x, str):
                if x.strip():
                    out.append(x.strip())
            elif isinstance(x, dict):
                t = x.get("t") or x.get("title") or x.get("name") or x.get("q")
                if isinstance(t, str) and t.strip():
                    out.append(t.strip())
            else:
                out.append(str(x))
        return out
    return [str(v)]


def _drop_cycles(segments: List[dict]) -> None:
    """Remove input edges that would create a cycle (keep earlier edges)."""
    ids = {s["id"] for s in segments}
    order = {s["id"]: i for i, s in enumerate(segments)}
    for seg in segments:
        keep: List[str] = []
        for dep in seg.get("inputs") or []:
            if dep not in ids or dep == seg["id"]:
                continue
            # accept only deps that appear earlier in the list order (topological)
            if order.get(dep, 0) < order.get(seg["id"], 0):
                keep.append(dep)
        seg["inputs"] = keep


def parse_plan(text: str, brief: Optional[str] = None) -> List[dict]:
    """Extract and normalise the 谱稿 JSON array. Max 24 segments."""
    data = _extract_json(text if isinstance(text, str) else str(text))
    if isinstance(data, dict):
        data = data.get("segments", data.get("items", data.get("plan", [])))
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return []

    raw = [x for x in data if isinstance(x, dict)][:24]
    segments: List[dict] = []
    seen_ids: set = set()
    for i, item in enumerate(raw):
        seg = _new_segment()
        for key in _SEGMENT_FIELDS:
            if key in item and item[key] is not None:
                seg[key] = item[key]

        sid = str(seg.get("id") or "").strip()
        if not sid or sid in seen_ids:
            suffix = i + 1
            sid = f"s{suffix}"
            while sid in seen_ids:
                suffix += 1
                sid = f"s{suffix}"
        seg["id"] = sid
        seen_ids.add(sid)

        seg["title"] = str(seg.get("title") or f"段落 {seg['id']}").strip()
        seg["goal"] = str(seg.get("goal") or seg["title"]).strip()
        seg["deliverable"] = str(seg.get("deliverable") or "").strip()
        seg["context"] = str(seg.get("context") or "").strip()
        seg["assignee"] = str(seg.get("assignee") or "").strip()

        try:
            d = int(seg.get("difficulty", 3))
        except (TypeError, ValueError):
            d = 3
        seg["difficulty"] = max(1, min(5, d))

        try:
            est = int(seg.get("est_tokens", 4000))
        except (TypeError, ValueError):
            est = 4000
        seg["est_tokens"] = max(0, est)

        seg["acceptance"] = _as_str_list(seg.get("acceptance"))
        seg["skills"] = _as_str_list(seg.get("skills"))
        seg["inputs"] = _as_str_list(seg.get("inputs"))

        if not isinstance(seg.get("ladder"), list):
            seg["ladder"] = []
        if not isinstance(seg.get("spend"), dict):
            seg["spend"] = _new_segment()["spend"]
        else:
            sp = seg["spend"]
            base = _new_segment()["spend"]
            for k, v in base.items():
                if k not in sp:
                    sp[k] = v
            if not isinstance(sp.get("by_role"), dict):
                sp["by_role"] = dict(base["by_role"])
            else:
                for k, v in base["by_role"].items():
                    sp["by_role"].setdefault(k, 0.0)

        stage = str(seg.get("stage") or "waiting").strip().lower()
        seg["stage"] = stage if stage in {
            "waiting",
            "running",
            "selfcheck",
            "review",
            "rework",
            "done",
            "blocked",
        } else "waiting"

        try:
            p = float(seg.get("progress", 0.0))
        except (TypeError, ValueError):
            p = 0.0
        seg["progress"] = max(0.0, min(1.0, p))

        if not isinstance(seg.get("events"), list):
            seg["events"] = []
        seg["events"] = seg["events"][-50:]

        segments.append(seg)

    _drop_cycles(segments)
    if brief is not None:
        segments = compact_plan(segments, brief)
    return segments


def segment_target(brief: str) -> int:
    """Deterministic budget from brief size and explicit complexity cues."""
    size = len(brief.strip())
    complex_brief = bool(re.search(r"分布式|微服务|distributed|microservices", brief, re.I))
    return min(24, (5 if size <= 2000 else 8 if size <= 8000 else 12) +
               (3 if complex_brief and size > 2000 else 0))


def compact_plan(segments: List[dict], brief: str) -> List[dict]:
    """Merge adjacent work without losing deliverables or dependency edges."""
    target = segment_target(brief)
    trivial = re.compile(r"readme|examples?|packaging|文档|示例|打包", re.I)

    def merge(left, right):
        old = right["id"]
        for key in ("title", "goal", "deliverable", "context"):
            left[key] = "\n".join(x for x in (left[key], right[key]) if x)
        for key in ("inputs", "acceptance", "skills"):
            left[key] = list(dict.fromkeys(left[key] + right[key]))
        left["difficulty"] = max(left["difficulty"], right["difficulty"])
        left["est_tokens"] += right["est_tokens"]
        segments.remove(right)
        for seg in segments:
            seg["inputs"] = list(dict.fromkeys(left["id"] if dep == old else dep for dep in seg["inputs"]))
            seg["inputs"] = [dep for dep in seg["inputs"] if dep != seg["id"]]

    for seg in list(segments):
        if seg not in segments:
            continue
        if len(segments) > 1 and seg["difficulty"] <= 2 and trivial.search(seg["title"]):
            i = segments.index(seg)
            if i:
                merge(segments[i - 1], seg)
            else:
                merge(seg, segments[1])
    while len(segments) > target:
        i = min(range(len(segments) - 1), key=lambda j: segments[j]["est_tokens"] + segments[j + 1]["est_tokens"])
        merge(segments[i], segments[i + 1])
    _drop_cycles(segments)
    return segments


# --------------------------------------------------------------------------- #
# prompts
# --------------------------------------------------------------------------- #

PLAN_PROMPT = (
    "你是 Chorus 的指挥（lead）。请把用户的需求拆解成一份「谱稿」，"
    "只输出一个 JSON 数组（或 {\"segments\": [...]}），不要输出任何解释文字。\n"
    "每个段落对象必须且只能包含这些字段：\n"
    "{\"id\",\"title\",\"goal\",\"inputs\",\"deliverable\",\"acceptance\",\"difficulty\",\"est_tokens\",\"skills\",\"context\"}\n"
    "规则：\n"
    "1. 每个段落只做一件事（单一目标 goal），标题 title 简短。\n"
    "2. acceptance 必须是机器可校验的清单（可被脚本或规则判定通过/不通过）。\n"
    "3. context 只写完成该段落所必需的最小上下文，不要复述需求全文。\n"
    "4. difficulty 如实标注 1-5（1-2 简单，3 中等，4-5 困难），est_tokens 为预估输出 token 数。\n"
    "5. inputs 只填依赖的段落 id，不得出现环；能并行的段落尽量并行（inputs 为空或互不依赖）。\n"
    "6. skills 为该段落需要的能力标签，可为空数组。\n"
    "7. 段落数量不超过 24 个。\n"
    "8. 如果需求有歧义，不要硬猜：改为只输出 "
    "{\"questions\":[{\"q\":\"问题\",\"default\":\"默认答案\"}]}，最多 3 个问题，每个 q 只问一件事；options 只能是该问题的备选答案，不要把不同问题的答案混为选项。"
)

CLARIFY_LIMIT = 3

ADVISOR_PROMPT = (
    "你是 Chorus 的指挥（lead），现在作为顾问介入一个失败的段落。\n"
    "请只给出纠正性指导（corrective guidance），不超过 600 token：\n"
    "指出失败原因、给出可执行的修正步骤与验收要点，不要重写完整产物，不要寒暄。"
)


def task_card_text(segment: dict, upstream: Optional[Dict[str, str]] = None) -> str:
    """The message sent to the executor."""
    seg = segment or {}
    upstream = upstream or {}
    lines: List[str] = []
    lines.append(f"# 任务卡 {seg.get('id', '')}：{seg.get('title', '')}".rstrip())
    lines.append("")
    lines.append(f"【目标】{seg.get('goal', '')}")
    lines.append(f"【交付物】{seg.get('deliverable', '')}")
    acc = seg.get("acceptance") or []
    if acc:
        lines.append("【验收标准】")
        for i, a in enumerate(acc, 1):
            lines.append(f"{i}. {a}")
    else:
        lines.append("【验收标准】（无，按交付物自检）")
    ctx = str(seg.get("context") or "").strip()
    if ctx:
        lines.append("")
        lines.append(f"【上下文】{ctx}")
    if upstream:
        lines.append("")
        lines.append("【上游段落摘要】")
        for uid, summary in upstream.items():
            lines.append(f"- {uid}: {summary}")
    lines.append("")
    lines.append(
        "【进度要求】在回复中维护一个进度清单，以 `[进度]` 开始、`[/进度]` 结束；"
        "每行以 ✓（已完成）、✱（进行中）、○（待办）开头。"
    )
    lines.append(
        "【收尾要求】回复最后给出 `[产物]...[/产物]` 摘要，不超过 200 字，说明交付物与关键结论。"
    )
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# progress / stages
# --------------------------------------------------------------------------- #

def ready(segments: Sequence[dict]) -> List[dict]:
    segs = list(segments or [])
    done_ids = {s.get("id") for s in segs if str(s.get("stage")) == "done"}
    out: List[dict] = []
    for s in segs:
        if str(s.get("stage")) != "waiting":
            continue
        deps = s.get("inputs") or []
        if all(d in done_ids for d in deps):
            out.append(s)
    return out


def stage_weight(seg: dict) -> float:
    stage = str((seg or {}).get("stage") or "waiting")
    try:
        prog = float((seg or {}).get("progress", 0.0) or 0.0)
    except (TypeError, ValueError):
        prog = 0.0
    prog = max(0.0, min(1.0, prog))
    if stage == "waiting":
        return 0.0
    if stage == "running":
        return 0.8 * prog
    if stage == "selfcheck":
        return 0.85
    if stage == "review":
        return 0.9
    if stage == "rework":
        return 0.5
    if stage == "done":
        return 1.0
    if stage == "blocked":
        return 0.8 * prog
    return 0.0


def segment_pct(seg: dict) -> float:
    return max(0.0, min(100.0, stage_weight(seg) * 100.0))


def project_pct(project: dict) -> float:
    segs = list((project or {}).get("segments") or [])
    if not segs:
        return 0.0
    total = 0.0
    acc = 0.0
    for s in segs:
        w = _tokens(s)
        if w <= 0:
            try:
                w = float(s.get("difficulty", 3) or 3)
            except (TypeError, ValueError):
                w = 3.0
        if w <= 0:
            w = 1.0
        total += w
        acc += w * segment_pct(s)
    if total <= 0:
        return 0.0
    return max(0.0, min(100.0, acc / total))


def eta_seconds(project: dict, history: Sequence[Tuple[float, float]]) -> Optional[int]:
    """Remaining weight / weight-per-second over the last 10 minutes."""
    cur = project_pct(project or {})
    remaining = max(0.0, 100.0 - cur)
    if remaining <= 0:
        return 0
    now = time.time()
    window = [h for h in (history or []) if isinstance(h, (list, tuple)) and len(h) >= 2]
    window = [h for h in window if float(h[0]) >= now - 600.0]
    if len(window) < 2:
        return None
    window = sorted(window, key=lambda h: float(h[0]))
    t0, p0 = float(window[0][0]), float(window[0][1])
    t1, p1 = float(window[-1][0]), float(window[-1][1])
    dt = t1 - t0
    if dt <= 0:
        return None
    rate = (p1 - p0) / dt  # pct per second
    if rate <= 1e-9:
        return None
    return int(round(remaining / rate))


# --------------------------------------------------------------------------- #
# ladder
# --------------------------------------------------------------------------- #

LADDER_ORDER = ["retry", "advisor", "upgrade", "ask"]


def ladder_next(seg: dict) -> str:
    """Next escalation step after a failed check."""
    used = [str(x.get("step") or "").strip().lower() for x in ((seg or {}).get("ladder") or []) if isinstance(x, dict)]
    for step in LADDER_ORDER:
        if step not in used:
            return step
    return "ask"


def advisor_request(seg: dict, failure_log: Any = None) -> str:
    seg = seg or {}
    if isinstance(failure_log, (list, tuple)):
        log = "\n".join(str(x) for x in failure_log)
    else:
        log = str(failure_log or "")
    acc = seg.get("acceptance") or []
    acc_text = "\n".join(f"- {a}" for a in acc) if acc else "- （无）"
    return (
        f"{ADVISOR_PROMPT}\n\n"
        f"段落 id: {seg.get('id', '')}\n"
        f"标题: {seg.get('title', '')}\n"
        f"目标: {seg.get('goal', '')}\n"
        f"交付物: {seg.get('deliverable', '')}\n"
        f"验收标准:\n{acc_text}\n"
        f"失败记录:\n{log}\n"
        f"请给出不超过 600 token 的纠正性指导。"
    )


# --------------------------------------------------------------------------- #
# review
# --------------------------------------------------------------------------- #

def review_needed(seg: dict, stats: Any = None) -> bool:
    seg = seg or {}
    try:
        d = int(seg.get("difficulty", 3) or 3)
    except (TypeError, ValueError):
        d = 3
    if d >= 3:
        return True
    who = str(seg.get("assignee") or "")
    if who and _pass_rate(stats, who) < 0.7:
        return True
    sid = str(seg.get("id") or "")
    h = hashlib.sha256(sid.encode("utf-8")).hexdigest()
    bucket = int(h[:8], 16) % 100
    return bucket < 30


# --------------------------------------------------------------------------- #
# streaming / checklist
# --------------------------------------------------------------------------- #

def on_chunk(seg: dict, out_tokens_so_far: int) -> float:
    """Update progress from streaming tokens. Caps at 0.95."""
    seg = seg or {}
    if seg.get("_checklist_progress") is not None:
        return float(seg.get("progress", 0.0) or 0.0)
    est_out = _tokens(seg) * 0.3
    if est_out <= 0:
        return float(seg.get("progress", 0.0) or 0.0)
    try:
        out = max(0.0, float(out_tokens_so_far))
    except (TypeError, ValueError):
        out = 0.0
    p = min(0.95, out / est_out)
    seg["progress"] = max(0.0, min(0.95, p))
    return seg["progress"]


def on_checklist(seg: dict, todo: Sequence[dict]) -> float:
    """todo = [{"t","s"}] with s in done/doing/todo."""
    seg = seg or {}
    items = [x for x in (todo or []) if isinstance(x, dict)]
    if not items:
        return float(seg.get("progress", 0.0) or 0.0)
    done = 0.0
    doing = 0.0
    for x in items:
        st = str(x.get("s") or "todo").strip().lower()
        if st == "done":
            done += 1.0
        elif st == "doing":
            doing += 0.5
    p = (done + doing) / len(items)
    p = max(0.0, min(1.0, p))
    seg["progress"] = p
    seg["_checklist_progress"] = p
    return p


# --------------------------------------------------------------------------- #
# spend / budget
# --------------------------------------------------------------------------- #

def record_spend(seg: dict, role: str, u: Any, cost: float) -> None:
    """u: {"in","out","cached"} token counts (ints)."""
    seg = seg or {}
    spend = seg.setdefault("spend", _new_segment()["spend"])
    if not isinstance(spend, dict):
        spend = _new_segment()["spend"]
        seg["spend"] = spend
    spend.setdefault("in", 0)
    spend.setdefault("out", 0)
    spend.setdefault("cached", 0)
    spend.setdefault("cost", 0.0)
    by_role = spend.setdefault("by_role", {"plan": 0.0, "exec": 0.0, "advisor": 0.0, "review": 0.0})
    if not isinstance(by_role, dict):
        by_role = {"plan": 0.0, "exec": 0.0, "advisor": 0.0, "review": 0.0}
        spend["by_role"] = by_role

    u = u if isinstance(u, dict) else {}
    try:
        tin = int(u.get("in", 0) or 0)
    except (TypeError, ValueError):
        tin = 0
    try:
        tout = int(u.get("out", 0) or 0)
    except (TypeError, ValueError):
        tout = 0
    try:
        tcached = int(u.get("cached", 0) or 0)
    except (TypeError, ValueError):
        tcached = 0
    try:
        c = float(cost or 0.0)
    except (TypeError, ValueError):
        c = 0.0

    spend["in"] = int(spend.get("in", 0)) + tin
    spend["out"] = int(spend.get("out", 0)) + tout
    spend["cached"] = int(spend.get("cached", 0)) + tcached
    spend["cost"] = float(spend.get("cost", 0.0)) + c
    key = str(role or "exec").strip().lower()
    if key not in by_role:
        by_role[key] = 0.0
    by_role[key] = float(by_role[key]) + c


def budget_state(project: dict) -> dict:
    project = project or {}
    budget = project.get("budget") or {}
    try:
        cap = float(budget.get("cap", 0.0) or 0.0)
    except (TypeError, ValueError):
        cap = 0.0
    spent = 0.0
    for s in project.get("segments") or []:
        sp = s.get("spend") or {}
        try:
            spent += float(sp.get("cost", 0.0) or 0.0)
        except (TypeError, ValueError):
            pass
    if project.get("cost_split"):
        # Project-wide usage already includes execution, planning and review.
        # Segment spend is a legacy fallback, not an additional charge ledger.
        spent = sum(float((row.get("cost") or {}).get(budget.get("cur", "¥"), 0) or 0)
                    for row in project["cost_split"].values())
    pct = (spent / cap * 100.0) if cap > 0 else 0.0
    if pct >= 100.0:
        level = "stop"
    elif pct >= 80.0:
        level = "warn"
    else:
        level = "ok"
    return {
        "spent": round(spent, 6),
        "cap": cap,
        "cur": str(budget.get("cur", "¥")),
        "pct": round(pct, 4),
        "level": level,
    }


def baseline_cost(project: dict, lead_price: Any) -> float:
    """Counterfactual: all recorded tokens priced at the lead's price (per MTok)."""
    if isinstance(lead_price, dict):
        pin = float(lead_price.get("in", 0.0) or 0.0)
        pout = float(lead_price.get("out", 0.0) or 0.0)
        pcached = float(lead_price.get("cached", 0.0) or 0.0)
    elif isinstance(lead_price, (list, tuple)) and len(lead_price) >= 2:
        pin = float(lead_price[0])
        pout = float(lead_price[1])
        pcached = float(lead_price[2]) if len(lead_price) > 2 else 0.0
    else:
        try:
            pin = float(lead_price or 0.0)
        except (TypeError, ValueError):
            pin = 0.0
        pout = pin
        pcached = 0.0

    total = 0.0
    for s in (project or {}).get("segments") or []:
        sp = s.get("spend") or {}
        try:
            total += (
                float(sp.get("in", 0) or 0) / 1e6 * pin
                + float(sp.get("out", 0) or 0) / 1e6 * pout
                + float(sp.get("cached", 0) or 0) / 1e6 * pcached
            )
        except (TypeError, ValueError):
            continue
    return round(total, 6)


# --------------------------------------------------------------------------- #
# decisions
# --------------------------------------------------------------------------- #

_ASK_KINDS = {
    "ambiguous",
    "ladder_exhausted",
    "over_budget",
    "irreversible",
    "external",
    "plan_quota_over_50",
}


def decide_or_ask(kind: str, info: Any = None) -> str:
    k = str(kind or "").strip().lower()
    if k in _ASK_KINDS:
        return "ask"
    return "auto"


# --------------------------------------------------------------------------- #
# concerto routing
# --------------------------------------------------------------------------- #

_MENTION_RE = re.compile(r"@([\w\-\u4e00-\u9fff]{1,32})")

_SHORT_Q_STARTS = ("什么", "怎么", "为什么", "是不是", "能不能", "what", "how", "why")


def _capable(m: dict, text: str) -> bool:
    return True


def concerto_route(text: str, project: dict, members: Sequence[dict], quota: Any = None, stats: Any = None) -> dict:
    text = str(text or "")
    members = list(members or [])
    by_name = {_member_name(m): m for m in members if _member_name(m)}
    available = [m for m in members if _available(m, quota)]

    mentions = []
    for name in _MENTION_RE.findall(text):
        if name in by_name and name not in mentions:
            mentions.append(name)
    if mentions:
        return {"action": "answer", "who": mentions[:2]}

    stripped = text.strip()
    is_short_q = False
    if len(stripped) <= 60:
        low = stripped.lower()
        if stripped.endswith("？") or stripped.endswith("?"):
            is_short_q = True
        elif any(stripped.startswith(p) or low.startswith(p) for p in _SHORT_Q_STARTS):
            is_short_q = True

    if is_short_q and available:
        def price_key(m: dict) -> Tuple:
            pin, pout, _ = _price_of(m, None)
            return (pin * 0.7 + pout * 0.3, _member_name(m))

        cheapest = sorted(available, key=price_key)[0]
        return {"action": "answer", "who": [_member_name(cheapest)]}

    lead = str((project or {}).get("lead_resolved") or (project or {}).get("lead") or "").strip()
    if lead and lead in by_name:
        return {"action": "plan", "who": [lead]}
    if available:
        return {"action": "plan", "who": [_member_name(available[0])]}
    return {"action": "plan", "who": []}


# --------------------------------------------------------------------------- #
# conflicts
# --------------------------------------------------------------------------- #

_PATH_RE = re.compile(r"[\w\-\./\\]+\.[A-Za-z0-9]{1,8}")


def _norm_title(t: str) -> str:
    return re.sub(r"[\s\u3000\-—_·:：,，。.;；!！?？()（）\[\]【】]+", "", str(t or "").strip().lower())


def parallel_conflicts(segments: Sequence[dict]) -> List[Tuple[str, str, str]]:
    segs = [s for s in (segments or []) if isinstance(s, dict) and str(s.get("stage")) == "running"]
    out: List[Tuple[str, str, str]] = []
    for i in range(len(segs)):
        for j in range(i + 1, len(segs)):
            a, b = segs[i], segs[j]
            ta = f"{a.get('context', '')} {a.get('deliverable', '')}"
            tb = f"{b.get('context', '')} {b.get('deliverable', '')}"
            pa = {p.lower() for p in _PATH_RE.findall(ta)}
            pb = {p.lower() for p in _PATH_RE.findall(tb)}
            common = sorted(pa & pb)
            if common:
                out.append((a.get("id", ""), b.get("id", ""), f"同文件冲突: {common[0]}"))
                continue
            if _norm_title(a.get("title")) and _norm_title(a.get("title")) == _norm_title(b.get("title")):
                out.append((a.get("id", ""), b.get("id", ""), "标题重复"))
    return out


# --------------------------------------------------------------------------- #
# snapshot / diff
# --------------------------------------------------------------------------- #

def snapshot(project: dict, members_state: Any = None, history: Any = None) -> dict:
    project = project or {}
    segs = list(project.get("segments") or [])
    seg_view = []
    for s in segs:
        seg_view.append(
            {
                "id": s.get("id", ""),
                "title": s.get("title", ""),
                "assignee": s.get("assignee", ""),
                "stage": s.get("stage", "waiting"),
                "pct": round(segment_pct(s), 2),
                "difficulty": s.get("difficulty", 3),
                "ladder_len": len(s.get("ladder") or []),
                "spend_cost": round(float((s.get("spend") or {}).get("cost", 0.0) or 0.0), 6),
            }
        )
    ms: Dict[str, dict] = {}
    if isinstance(members_state, dict):
        for name, v in members_state.items():
            if isinstance(v, dict):
                ms[str(name)] = {
                    "stage": v.get("stage", ""),
                    "segment": v.get("segment", ""),
                    "pct": v.get("pct", 0.0),
                }
    return {
        "mode": str(project.get("mode") or "concerto"),
        "lead": str(project.get("lead") or ""),
        "lead_resolved": str(project.get("lead_resolved") or ""),
        "pct": round(project_pct(project), 2),
        "eta": eta_seconds(project, history or []),
        "budget": budget_state(project),
        "segments": seg_view,
        "members": ms,
    }


def diff(prev: dict, cur: dict) -> dict:
    prev = prev or {}
    cur = cur or {}
    out: Dict[str, Any] = {}

    for key in ("mode", "lead", "lead_resolved", "pct", "eta", "budget"):
        if prev.get(key) != cur.get(key):
            out[key] = cur.get(key)

    prev_segs = {s.get("id"): s for s in (prev.get("segments") or []) if isinstance(s, dict)}
    cur_segs = {s.get("id"): s for s in (cur.get("segments") or []) if isinstance(s, dict)}

    changed = []
    for sid, s in cur_segs.items():
        if prev_segs.get(sid) != s:
            changed.append(s)
    if changed:
        out["segments"] = changed

    removed = [sid for sid in prev_segs if sid not in cur_segs]
    if removed:
        out["removed"] = removed

    if prev.get("members") != cur.get("members"):
        out["members"] = cur.get("members")

    return out
