"""模型能力画像（N12）。只在用户自己接入的声部里比分；强项不定死由谁做。
默认分库 server/profiles/defaults.json；实测结果可通过 observe() 收缩校正。无开关外副作用，纯函数为主。"""
import json, os, re, pathlib

_DEF = pathlib.Path(__file__).parent / "profiles" / "defaults.json"
_cache = None
HARD_SKILLS = {"image_gen", "image_edit", "video_gen", "tts"}


def load_defaults(path=None):
    global _cache
    if path is None and _cache is not None:
        return _cache
    d = json.loads(pathlib.Path(path or _DEF).read_text(encoding="utf-8"))
    if path is None:
        _cache = d
    return d


def find_profile(model, db=None):
    """按 match 正则（不区分大小写）找画像，找不到返回 None。"""
    db = db or load_defaults()
    m = (model or "").lower()
    best, best_len = None, -1
    for p in db["profiles"]:  # 取匹配最长（最具体）的一条，避免 deepseek-v4.1-flash 被 Pro 抢走
        hit = re.search(p.get("match", "$^"), m, re.I)
        if hit and len(hit.group(0)) > best_len:
            best, best_len = p, len(hit.group(0))
    return best


def skill_score(model, skill, db=None, observed=None):
    """某模型某项能力分 0..1。未知模型/未知项用中性先验；observed={(model,skill):(passed,total)} 做收缩校正。"""
    db = db or load_defaults()
    prior = db.get("unknown_prior", 0.6)
    p = find_profile(model, db)
    if skill in HARD_SKILLS:  # 生成类能力：没声明就是不会，不套中性先验
        base = (p or {}).get("skill", {}).get(skill, 0.0)
    else:
        base = prior if not p else p.get("skill", {}).get(skill, prior)
    if observed:
        ok, n = observed.get((model, skill), (0, 0))
        if n > 0:
            k = 5.0  # 先验权重相当于 5 次实测
            base = (base * k + ok) / (k + n)
    return round(base, 4)


def rank(members, skill, db=None, observed=None, need_kind="member", min_score=0.0):
    """在用户已接入的声部里按分排序。members: [{'id','model'}]。
    返回 [(分, member)] 降序，同分便宜优先。不含「缺声部」判断，见 pick()。"""
    db = db or load_defaults()
    out = []
    for m in members:
        p = find_profile(m.get("model"), db)
        if p and p.get("kind", "member") != need_kind:
            continue
        s = skill_score(m.get("model"), skill, db, observed)
        if s >= min_score:
            cost = ((p or {}).get("cost") or {}).get("out")  # 乐器 cost 为 null、部分模型价格未知
            out.append((s, cost if cost is not None else float("inf"), m))
    out.sort(key=lambda t: (-t[0], t[1]))
    return [(s, m) for s, _, m in out]


def pick(members, skill, db=None, observed=None, floor=0.5, need_kind="member"):
    """选最强者。返回 {'member':..., 'score':...} 或 {'missing': skill}（缺声部，提示用户接入，不硬做）。"""
    r = rank(members, skill, db, observed, need_kind)
    if not r or r[0][0] < floor:
        return {"missing": skill}
    return {"member": r[0][1], "score": r[0][0]}
