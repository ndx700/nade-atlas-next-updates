# Round 3B 服务端验收记录：G / H

分支 `codex/round3`。已先读 `ROUND3_SERVER.md`，保留 B、D 的实现和记录。本轮只编辑 `server/`；工作区中其他人的 `app/` 改动未触碰、未回退。未访问 `/var/lib/chorus`。测试 DATA 全部为 `TemporaryDirectory`，HTTP 上传和 CLI 子进程均用 mock，无真实外发或模型调用。

## G：日报任务

新增 `telemetry_job.py`，通过 `make_app().cleanup_ctx` 启停后台任务；每分钟检查一次，启动时也检查。按 `CFG.tz`（默认 UTC+8）自然日每天最多执行一次。

- 只有持久配置 `CFG["collab"]["telemetry"] is True` 才执行。缺失、false、数字 1、字符串均不执行，不因 UI 的默认展示值自行联网。
- 调用已有 `build_daily_report` 和 `sanitize`。仅保存/发送 clean report，不写入或发送含原值的 dropped 记录。
- 每次生成的脱敏报告写到 `DATA/telemetry_out.json`；未配置 URL（包括空白）时只写本地，不创建网络会话。
- 配置 `CFG["telemetry_url"]` 后，以 JSON PUT 发送同一份报告，30 秒网络总超时，不跟随重定向，只有 2xx 视为成功。
- `DATA/telemetry_job.json` 在网络 await 前原子持久化 `last_attempt_date`。同进程重复 tick、常规重启、HTTP 错误及连接失败均不会导致当天重复回传；次日可再尝试。不是跨多个服务进程的分布式锁。
- cleanup 会取消并等待任务退出；请求异常不打印 URL、响应正文或凭据。

统计口径及未做事项：复用现有 `RESULTS` 中当天的完成记录，模型来自当前成员配置，task_type 为 reply，passed 表示回答执行成功，不等价于产物审核 PASS。`RESULTS` 是进程内最多 256 条历史，重启会清空；启动立即生成的日报可能为空，不能视为完整全天统计。未新增永久事件采集账本，未虚构 token/耗时分位、返工或审核通过率（无数据时保持空值/零值）。未修改既有 Telemetry 客户端类、协作 UI 默认值、预览接口或配置 UI。没有真实遥测端点可验收，PUT 通过 mock 验证。

## H：超时分级现状及明确修复

| 层级 | 现状 | 本轮处理 |
| --- | --- | --- |
| `member_timeout_ms` | 默认 0；非法值回退 0。非零时每 5 秒扫描，单次执行只提醒一次，不取消、不交接、不额外调用 AI；排队等待锁不计时 | 保持不变，原有 12 项回归全绿 |
| `run_member` | 自身没有 `wait_for` 总时限；锁、预算、监控登记以及 finally 清理；手动停止可取消任务 | 保持不变 |
| `server.call_cli`：codex / claude 命令行及其他 CLI | 原本缺省 timeout 为 3600 秒，会杀掉超过一小时的长任务 | 修复为未配置 / null / 0 不设硬超时；显式正数秒数保留。超时或取消后的进程组清理保持原有路径 |
| `chorus2.lead_call`：规划 / 审核 | 原本不分声部类型，外层缺省 600 秒，会先于 CLI 内层截断任务并换指挥 | CLI / dsh 缺省不设外层硬超时；API 指挥仍默认 600 秒。显式 `lead_timeout` 正数秒数保留，0 / null 不设限 |
| 普通 `call_api` | HTTP total=None，sock_read=600 秒，sock_connect=20 秒 | 保持不变；这不是 CLI 超时 |
| API workspace_tools | 外层 `m.timeout` 默认 3600 秒 | 保持不变 |
| `adapters.CliAdapter` / `AcpAdapter` | 独立 adapter 路径，构造参数 timeout 默认 3600 秒；`designopts` 使用 ACP adapter | 保持不变，未把独立 adapter 路径视为 `run_member`；因此不能宣称所有 adapter 长任务均无超时 |
| `ensemble` 卡片 | `card_timeout` 默认 None，显式设置时对单卡及重试有外层限时 | 保持不变 |
| 价格查询 / 模型探测等 | 有各自短任务限时，例如 lookup_prices 外层 120 秒、CLI 副本 95 秒 | 保持不变，不扩大后台短任务的执行时长 |

普通 CLI 回答及 CLI 指挥在未显式配置硬超时的情况下，不再因服务器缺省 3600 / 600 秒被截断。用户显式时限、CLI 自身限制、服务关闭和手动停止仍然适用。未运行真实 codex / claude 一小时任务；通过 mock 子进程验证两种命令的默认无时限、0 无时限、显式 7200 秒传递；额外用阻塞假流验证显式短超时确实触发并清理进程。

## 验证

```sh
PYTHONPATH=server python -m unittest test_telemetry_job test_member_timeout test_dm_notify test_import_handlers test_hooks test_redline -q
# Ran 231 tests — OK

PYTHONPATH=server python -m pytest tests/test_telemetry.py -q
# 50 passed

git diff --check -- server tests
# 通过
```

新增 unittest 共 9 项：遥测 6 项，CLI/指挥超时分级与清理 3 项。覆盖严格开关、无 URL 本地模式、脱敏、精确 PUT 内容、每日去重持久化、次日恢复、时区跨日、并发 tick、HTTP/连接失败、后台生命周期。

另尝试扩大到既有 `test_chorus2`，其 HTTP 测试在 TestServer 创建 socket 时被沙箱以 `PermissionError: [Errno 1] Operation not permitted` 拒绝；不能据此宣称 HTTP 集成全绿，未修改这些已有测试以掩盖限制。包含 `test_collab_api` 的额外组合运行也遇到等待阻塞，已中止；不计入通过数。没有运行全量测试，也没有发布、部署或提交。
