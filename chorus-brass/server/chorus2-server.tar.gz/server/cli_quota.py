"""Subscription quotas read only through each vendor's own CLI (no saved OAuth tokens, no impersonation, no cookies).

  Claude Code : `claude -p "/usage" --output-format json`  -> "Current session: 60% used · resets …" lines
  Gemini CLI  : `gemini -p "/stats model"`                  -> "Usage left  75.0% (Resets in 1h 30m)" rows
  Codex       : ~/.codex/sessions/**/*.jsonl rate_limits (quota_probes.latest_codex_rate_limits), or ACP events
  Antigravity : fallback only — ali/agy_quota.py drives `agy` /usage in a pty (screen text), cached 10 min
Results are cached per member (10 min) so a probe never blocks; quota_probes reads them through ctx.cmd_json.
"""
from __future__ import annotations

import asyncio
import datetime
import json
import re
import shlex
import time
from typing import Optional

CACHE: dict = {}       # member name -> (at, result dict)
TTL = 600
ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07")


def clean(text: str) -> str:
    return ANSI.sub("", text or "").replace("\r", "")


_CLAUDE = re.compile(r"Current\s+(session|week)(?:\s*\(([^)]*)\))?\s*:\s*(\d+(?:\.\d+)?)%\s*used(?:\s*[·•|-]\s*resets\s+([^\n]+))?", re.I)


def parse_claude_usage(text: str) -> dict:
    """Remaining % for the 5-hour session and the all-models week from Claude Code's /usage report."""
    out = {"pct": None, "reset": "", "week": None, "week_reset": ""}
    for kind, scope, used, reset in _CLAUDE.findall(clean(text)):
        left = round(max(0.0, 100.0 - float(used)), 1)
        reset = reset.strip().rstrip(".")
        if kind.lower() == "session":
            out["pct"], out["reset"] = left, reset
        elif not scope or "all" in scope.lower():
            out["week"], out["week_reset"] = left, reset
    return out


_GEMINI = re.compile(r"^\s*[│|]?\s*([\w.\-]+)\s+.*?(\d+(?:\.\d+)?)%\s*\(Resets in ([^)]+)\)", re.M)


def _in_to_iso(span: str, now: Optional[float] = None) -> str:
    secs = 0
    for n, u in re.findall(r"(\d+)\s*([dhms])", span):
        secs += int(n) * {"d": 86400, "h": 3600, "m": 60, "s": 1}[u]
    if not secs:
        return ""
    t = datetime.datetime.fromtimestamp((time.time() if now is None else now) + secs, datetime.timezone.utc)
    return t.isoformat(timespec="seconds")


def parse_gemini_stats(text: str, now: Optional[float] = None, model: str = "") -> dict:
    """'Usage left' per model from Gemini CLI /stats model; picks the member's model, else the lowest remaining."""
    rows = [(m, float(p), r) for m, p, r in _GEMINI.findall(clean(text))]
    if not rows:
        return {"pct": None, "reset": ""}
    pick = next((r for r in rows if model and r[0] == model), None) or min(rows, key=lambda r: r[1])
    return {"pct": round(pick[1], 1), "reset": _in_to_iso(pick[2], now), "model": pick[0]}


def which(member: dict) -> str:
    blob = (str(member.get("cli") or "") + " " + str(member.get("cmd") or "") + " " + str(member.get("model") or "")).lower()
    for k in ("claude", "gemini", "agy", "codex"):
        if k in blob:
            return "agy" if k == "agy" or "antigravity" in blob else k
    return ""


async def _run(cmd: str, timeout: float) -> str:
    p = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    try:
        out, _ = await asyncio.wait_for(p.communicate(), timeout)
    except asyncio.TimeoutError:
        p.kill()
        await p.wait()
        return ""
    return out.decode(errors="replace")


async def refresh(member: dict, run=_run) -> Optional[dict]:
    """Read one CLI member's subscription window through its own CLI; cached TTL seconds."""
    name = member.get("name", "")
    hit = CACHE.get(name)
    if hit and time.time() - hit[0] < TTL:
        return hit[1]
    kind, res = which(member), None
    q = member.get("quota") or {}
    if kind == "claude":
        exe = q.get("exe") or "claude"
        raw = await run(f"{shlex.quote(exe)} -p /usage --output-format json", 60)
        try:
            raw = json.loads(raw).get("result", raw)
        except (ValueError, AttributeError):
            pass
        r = parse_claude_usage(raw)
        res = r if r["pct"] is not None or r["week"] is not None else None
    elif kind == "gemini":
        exe = q.get("exe") or "gemini"
        r = parse_gemini_stats(await run(f"{shlex.quote(exe)} -p '/stats model'", 90), model=member.get("model", ""))
        res = {"pct": r["pct"], "reset": r["reset"]} if r["pct"] is not None else None
    elif kind == "agy" and q.get("cmd"):
        try:
            o = json.loads(await run(q["cmd"], 120) or "{}")
            res = {k: o.get(k) for k in ("pct", "reset", "week", "week_reset")} if o.get("pct") is not None or o.get("week") is not None else None
        except ValueError:
            res = None
    CACHE[name] = (time.time(), res)
    return res


def cached(member: dict) -> Optional[dict]:
    hit = CACHE.get(member.get("name", ""))
    return hit[1] if hit else None
