"""工位 (cloud computer) — NOT in this release. Abstract interface only, so a provider can be plugged in later.

No vendor is chosen and nothing here provisions resources. Callers must check `available()` first; the default
registry is empty, so every 工位 entry point stays hidden in the app and the server never offers it.
"""
from __future__ import annotations

import abc


class Workstation(abc.ABC):
    """One isolated machine a member can work on, with a live screen."""

    @abc.abstractmethod
    async def start(self, member: str, project: str) -> str:
        """Start (or resume) a machine; return its id."""

    @abc.abstractmethod
    async def run(self, ws_id: str, command: str, timeout: float) -> dict:
        """Run one command; return {"code", "stdout", "stderr"}. Goes through the same red-line gate as any tool."""

    @abc.abstractmethod
    async def screen_url(self, ws_id: str) -> str:
        """A short-lived URL for the live screen."""

    @abc.abstractmethod
    async def stop(self, ws_id: str) -> None:
        """Stop the machine; billing must stop with it."""


PROVIDERS: dict[str, type[Workstation]] = {}


def available() -> bool:
    return bool(PROVIDERS)
