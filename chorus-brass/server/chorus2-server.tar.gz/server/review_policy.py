"""
Chorus — review policy (task card N2).

Pure functions deciding *who* reviews a segment and *how* it is reviewed,
based on a risk score.  No I/O, no state mutation, no imports beyond the
standard library (aiohttp is not needed here — the module is pure).

Public API
----------
risk_score(seg, ctx) -> float
    Compute the risk of a segment in [0.0, 1.0].

pick_reviewer(lead, executor, pool, capable) -> str | None
    Choose the reviewer: the lead unless the lead is the executor, in which
    case the first capable member of the fallback pool that is not the
    executor is used.

review_plan(risk) -> dict
    Map a risk score to a review plan:
        risk >= 0.7            -> "dual"   (lead + fallback, independent votes)
        0.4 <= risk < 0.7      -> "required"
        risk < 0.4             -> "spot"   (existing spot-check policy)

The functions are intentionally defensive: they accept dicts, objects with
attributes, or plain scalars where reasonable, and never raise for missing
keys — they fall back to neutral defaults.
"""

from __future__ import annotations

from typing import Any, Callable, Iterable, Mapping, Optional

__all__ = [
    "risk_score",
    "pick_reviewer",
    "review_plan",
    "RISK_DUAL_THRESHOLD",
    "RISK_REQUIRED_THRESHOLD",
    "DIFF_LINES_CAP",
    "IRREVERSIBLE_WEIGHT",
    "DIFF_WEIGHT",
    "NEW_MEMBER_WEIGHT",
    "PASS_RATE_WEIGHT",
    "DIFFICULTY_WEIGHT",
    "PASS_RATE_THRESHOLD",
    "DIFFICULTY_THRESHOLD",
]

# --- scoring constants (from the proposal, section 3.3) --------------------
IRREVERSIBLE_WEIGHT = 0.4
DIFF_WEIGHT = 0.3          # min(0.3, diff_lines / 300)
DIFF_LINES_CAP = 300
NEW_MEMBER_WEIGHT = 0.2
PASS_RATE_WEIGHT = 0.2
DIFFICULTY_WEIGHT = 0.1

PASS_RATE_THRESHOLD = 0.7
DIFFICULTY_THRESHOLD = 4

# --- tier thresholds ------------------------------------------------------
RISK_DUAL_THRESHOLD = 0.7
RISK_REQUIRED_THRESHOLD = 0.4


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Fetch ``key`` from a mapping or an object, returning *default* if absent."""
    if obj is None:
        return default
    if isinstance(obj, Mapping):
        if key in obj:
            value = obj[key]
            return default if value is None else value
        return default
    value = getattr(obj, key, None)
    return default if value is None else value


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "y", "on"}:
            return True
        if lowered in {"0", "false", "no", "n", "off", ""}:
            return False
    return default


def _as_name(value: Any) -> Optional[str]:
    """Normalise a member reference (str / dict / object) to a name."""
    if value is None:
        return None
    if isinstance(value, str):
        name = value.strip()
        return name or None
    if isinstance(value, Mapping):
        for key in ("name", "id", "agent", "member"):
            if key in value and isinstance(value[key], str) and value[key].strip():
                return value[key].strip()
        return None
    for key in ("name", "id", "agent", "member"):
        attr = getattr(value, key, None)
        if isinstance(attr, str) and attr.strip():
            return attr.strip()
    return None


def _iter_pool(pool: Any) -> Iterable[Any]:
    if pool is None:
        return ()
    if isinstance(pool, (str, bytes)):
        return (pool,)
    if isinstance(pool, Mapping):
        # a single member given as a mapping
        return (pool,)
    if isinstance(pool, Iterable):
        return pool
    return (pool,)


# ---------------------------------------------------------------------------
# 1. risk score
# ---------------------------------------------------------------------------
def risk_score(seg: Any, ctx: Any = None) -> float:
    """
    Compute the risk of *seg* in the range [0.0, 1.0].

    Inputs are read from ``seg`` first and then from ``ctx`` (context), so a
    caller may put global facts (pass rate, difficulty, member novelty) in
    either place.  Recognised keys:

        irreversible / is_irreversible / destructive   -> bool
        diff_lines / diff / changed_lines / lines      -> int
        member_is_new / is_new / new_member / low_sample -> bool
        pass_rate / pass / success_rate                -> float in [0, 1]
        difficulty / diff_level / level                -> number

    Scoring (proposal 3.3)::

        risk  = 0.4 if irreversible else 0
        risk += min(0.3, diff_lines / 300)
        risk += 0.2 if member_is_new else 0
        risk += 0.2 if pass_rate < 0.7 else 0
        risk += 0.1 if difficulty >= 4 else 0

    The diff-lines term scales linearly from 0.0 at 0 lines up to the
    ``DIFF_WEIGHT`` cap at ``DIFF_LINES_CAP`` lines (e.g. 150 lines -> 0.15).
    """
    risk = 0.0

    # 0.4 — irreversible: publish / delete / pay / send externally
    irreversible = _as_bool(
        _first(seg, ctx, ("irreversible", "is_irreversible", "destructive", "is_destructive")),
        False,
    )
    if irreversible:
        risk += IRREVERSIBLE_WEIGHT

    # min(0.3, diff_lines / 300) — size of the change
    diff_lines = _as_float(
        _first(seg, ctx, ("diff_lines", "diff", "changed_lines", "lines", "size")),
        0.0,
    )
    if diff_lines < 0:
        diff_lines = 0.0
    # Linear scaling: 0 lines -> 0.0, DIFF_LINES_CAP lines -> DIFF_WEIGHT (0.3).
    # e.g. 150 lines -> 0.15.  The cap is applied to the *lines*, not to the
    # resulting weight, so the weight never exceeds DIFF_WEIGHT.
    risk += min(DIFF_WEIGHT, diff_lines / DIFF_LINES_CAP * DIFF_WEIGHT)

    # 0.2 — new member / low sample
    member_is_new = _as_bool(
        _first(seg, ctx, ("member_is_new", "is_new", "new_member", "low_sample", "is_low_sample")),
        False,
    )
    if member_is_new:
        risk += NEW_MEMBER_WEIGHT

    # 0.2 — pass rate below 0.7
    pass_rate_raw = _first(seg, ctx, ("pass_rate", "pass", "success_rate", "test_pass_rate"))
    if pass_rate_raw is not None:
        pass_rate = _as_float(pass_rate_raw, 1.0)
        if pass_rate < PASS_RATE_THRESHOLD:
            risk += PASS_RATE_WEIGHT

    # 0.1 — difficulty >= 4
    difficulty = _as_float(
        _first(seg, ctx, ("difficulty", "diff_level", "level", "complexity")),
        0.0,
    )
    if difficulty >= DIFFICULTY_THRESHOLD:
        risk += DIFFICULTY_WEIGHT

    # clamp into [0, 1] and round to avoid float noise (e.g. 0.30000000004)
    risk = max(0.0, min(1.0, risk))
    return round(risk, 6)


def _first(seg: Any, ctx: Any, keys: Iterable[str]) -> Any:
    """Return the first non-None value found in *seg* then *ctx*."""
    for source in (seg, ctx):
        for key in keys:
            value = _get(source, key, None)
            if value is not None:
                return value
    return None


# ---------------------------------------------------------------------------
# 2. reviewer selection
# ---------------------------------------------------------------------------
def pick_reviewer(
    lead: Any,
    executor: Any,
    pool: Any = None,
    capable: Any = None,
) -> Optional[str]:
    """
    Choose the reviewer for a segment.

    ``reviewer = lead if lead != executor else fallback_pool.first(capable, != executor)``

    * ``lead`` / ``executor`` — member name (str) or member object/dict.
    * ``pool`` — iterable of candidate members (the "second strongest model"
      fallback pool).  May also be a single member.
    * ``capable`` — either a set/list of names considered capable, or a
      predicate ``capable(member) -> bool``.  ``None`` means "everyone is
      capable".

    Returns the reviewer name (str) or ``None`` when no reviewer can be found
    (e.g. the lead is the executor and the pool has no other capable member).
    """
    lead_name = _as_name(lead)
    executor_name = _as_name(executor)

    # Normal case: the lead reviews the executor's work.
    if lead_name is not None and lead_name != executor_name:
        return lead_name

    # Lead is the executor (or unknown) -> fall back to the pool.
    candidates = list(_iter_pool(pool))

    # A callable predicate, or a container of capable names.
    predicate: Optional[Callable[[Any], bool]] = None
    capable_names: Optional[set] = None
    if callable(capable):
        predicate = capable
    elif capable is not None:
        capable_names = {
            name for name in (_as_name(item) for item in _iter_pool(capable)) if name is not None
        }

    for candidate in candidates:
        name = _as_name(candidate)
        if name is None:
            continue
        if executor_name is not None and name == executor_name:
            continue
        if predicate is not None:
            try:
                if not predicate(candidate):
                    continue
            except Exception:
                continue
        elif capable_names is not None and name not in capable_names:
            continue
        return name

    # Nothing suitable in the pool.  If the lead is a distinct (unknown) name
    # we already returned it above; here the lead *is* the executor, so there
    # is genuinely no reviewer.
    return None


# ---------------------------------------------------------------------------
# 3. review plan
# ---------------------------------------------------------------------------
def review_plan(risk: Any) -> dict:
    """
    Map a risk score to a review plan.

    Returns a dict::

        {
            "tier":       "dual" | "required" | "spot",
            "risk":       float,
            "reviewers":  ["lead", "fallback"] | ["lead"] | [],
            "dual":       bool,
            "required":   bool,
            "spot_check": bool,
            "votes_required": 2 | 1 | 0,
            "fix_on_any_fix": True for dual, else False,
            "description": str,
        }

    Thresholds:
        risk >= 0.7            -> dual     (lead + fallback, independent votes,
                                            any FIX vote sends the work back)
        0.4 <= risk < 0.7      -> required (single mandatory review)
        risk < 0.4             -> spot     (existing spot-check policy)
    """
    value = _as_float(risk, 0.0)
    value = max(0.0, min(1.0, value))

    if value >= RISK_DUAL_THRESHOLD:
        tier = "dual"
        reviewers = ["lead", "fallback"]
        votes_required = 2
        description = (
            "dual review: lead + fallback reviewer vote independently; "
            "any FIX verdict returns the segment for rework"
        )
    elif value >= RISK_REQUIRED_THRESHOLD:
        tier = "required"
        reviewers = ["lead"]
        votes_required = 1
        description = "mandatory single review by the selected reviewer"
    else:
        tier = "spot"
        reviewers = []
        votes_required = 0
        description = "low risk: follow the existing spot-check policy"

    return {
        "tier": tier,
        "risk": value,
        "reviewers": reviewers,
        "dual": tier == "dual",
        "required": tier == "required",
        "spot_check": tier == "spot",
        "votes_required": votes_required,
        "fix_on_any_fix": tier == "dual",
        "description": description,
    }
