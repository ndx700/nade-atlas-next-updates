"""Unified member adapter protocol (SPEC §互通).

Every member — official API, OpenAI-compatible relay, or a CLI agent (Claude Code / Codex / Gemini CLI) — is driven
through one contract:  run(packet, emit, approve) -> Result.
  * packet: server-built handoff (task, relevant files, prior artifacts, review notes, shared asset digests); never a
    chat replay.
  * emit(Step): progress observed by the server (stream deltas, tool calls, file edits, test runs). The server is the
    source of truth for progress; an AI's own "%" is never trusted.
  * approve(tool, input) -> bool: every tool request passes red lines + the member's permission policy here, the
    same for every connection type. CLI self-approval flags are stripped (chorus2.cli_guard).
Usage is accounted by the server from token counts × price (relays included), never from the member's claims.
No cookies, no console scraping: subscriptions only through their official CLIs.
"""
from __future__ import annotations

import abc
import asyncio
import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Optional

from aiohttp import ClientSession, ClientTimeout


@dataclass
class Step:
    member: str
    kind: str            # start|thinking|text|tokens|tool|command|edit|test|permission|artifact|done|error
    text: str = ""
    at: float = field(default_factory=time.time)
    data: dict = field(default_factory=dict)


@dataclass
class Result:
    ok: bool
    text: str = ""
    artifacts: list = field(default_factory=list)
    usage: dict = field(default_factory=dict)   # {"in","out","cached"}
    error: str = ""
    status: Optional[int] = None


Emit = Callable[[Step], None]
LIMITS: dict = {}   # member name -> {"at", "rate_limits"} last seen from an ACP agent (Codex)
Approve = Callable[[str, dict], Awaitable[bool]]


class Adapter(abc.ABC):
    kind = "base"

    def __init__(self, member: dict):
        self.member = member
        self.name = member["name"]

    @abc.abstractmethod
    async def run(self, packet: str, emit: Emit, approve: Approve, cwd: str = "", system: str = "") -> Result:
        ...


# ---------------------------------------------------------------- OpenAI-compatible (official API and relays)
class ApiAdapter(Adapter):
    """Streams /chat/completions; emits thinking/text/tokens steps as deltas arrive. Relays use the same path; their
    balance is self-accounted by the server from usage × configured price."""
    kind = "api"

    def __init__(self, member: dict, provider: dict, session: Optional[ClientSession] = None, timeout: float = 600):
        super().__init__(member)
        self.provider = provider
        self.session = session
        self.timeout = timeout

    async def run(self, packet, emit, approve, cwd="", system=""):
        base = (self.provider.get("base") or "").rstrip("/")
        body = {"model": self.member.get("model", ""), "stream": True, "stream_options": {"include_usage": True},
                "messages": ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": packet}]}
        headers = {"Authorization": "Bearer " + (self.provider.get("key") or ""), "Content-Type": "application/json"}
        own = self.session is None
        s = self.session or ClientSession(timeout=ClientTimeout(total=self.timeout))
        emit(Step(self.name, "start", "开始"))
        text, usage, last_beat = [], {}, 0.0
        try:
            async with s.post(base + "/chat/completions", json=body, headers=headers) as r:
                if r.status >= 400:
                    err = (await r.text())[:400]
                    emit(Step(self.name, "error", f"HTTP {r.status}", data={"status": r.status}))
                    return Result(False, error=err, status=r.status)
                async for raw in r.content:
                    line = raw.decode(errors="replace").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        o = json.loads(payload)
                    except ValueError:
                        continue
                    if o.get("usage"):
                        u = o["usage"]
                        usage = {"in": u.get("prompt_tokens", 0), "out": u.get("completion_tokens", 0),
                                 "cached": (u.get("prompt_tokens_details") or {}).get("cached_tokens", 0) or u.get("prompt_cache_hit_tokens", 0)}
                    for ch in o.get("choices") or []:
                        d = ch.get("delta") or {}
                        if d.get("reasoning_content"):
                            if time.time() - last_beat > 0.5:
                                emit(Step(self.name, "thinking", "在想"))
                                last_beat = time.time()
                        if d.get("content"):
                            text.append(d["content"])
                            if time.time() - last_beat > 0.5:
                                emit(Step(self.name, "tokens", f"{sum(map(len, text))} 字"))
                                last_beat = time.time()
        except asyncio.TimeoutError:
            emit(Step(self.name, "error", "超时"))
            return Result(False, error="timeout")
        finally:
            if own:
                await s.close()
        out = "".join(text)
        emit(Step(self.name, "done", "交付"))
        return Result(True, out, artifacts=artifacts_in(out), usage=usage)


# ---------------------------------------------------------------- CLI agents
_EDIT_TOOLS = {"edit", "write", "multiedit", "apply_patch", "str_replace_editor", "replace", "write_file"}
_TEST_RE = re.compile(r"\b(pytest|go test|cargo test|npm (run )?test|gradle\w* .*test|jest|vitest|unittest)\b")


def parse_cli_line(line: str, member: str) -> Optional[Step]:
    """One stdout line of a CLI agent -> a Step. Understands Claude Code stream-json, Codex exec --json and Gemini
    CLI json events; plain text becomes a 'text' step."""
    line = line.strip()
    if not line:
        return None
    try:
        o = json.loads(line)
    except ValueError:
        return Step(member, "text", line[:200])
    if not isinstance(o, dict):
        return Step(member, "text", line[:200])
    t = o.get("type", "")
    # Claude Code stream-json: {"type":"assistant","message":{"content":[{"type":"tool_use","name":"Bash","input":{...}}]}}
    if t == "assistant" and isinstance(o.get("message"), dict):
        for c in o["message"].get("content") or []:
            if c.get("type") == "tool_use":
                return tool_step(member, c.get("name", ""), c.get("input") or {})
            if c.get("type") == "thinking":
                return Step(member, "thinking", "在想")
            if c.get("type") == "text":
                return Step(member, "text", (c.get("text") or "")[:200])
    # Codex exec --json: {"type":"item.started","item":{"type":"command_execution","command":"..."}} / file_change
    if t.startswith("item.") and isinstance(o.get("item"), dict):
        it = o["item"]
        if it.get("type") == "command_execution":
            return tool_step(member, "Bash", {"command": it.get("command", "")})
        if it.get("type") == "file_change":
            return Step(member, "edit", ", ".join(c.get("path", "") for c in it.get("changes") or [])[:200])
        if it.get("type") in ("reasoning",):
            return Step(member, "thinking", "在想")
        if it.get("type") == "agent_message":
            return Step(member, "text", (it.get("text") or "")[:200])
    # Gemini CLI / generic: {"type":"tool_call","name":..,"args":..}
    if t in ("tool_call", "tool_use"):
        return tool_step(member, o.get("name", ""), o.get("args") or o.get("input") or {})
    if t == "permission":
        return Step(member, "permission", o.get("tool", ""), data=o)
    if t == "result":
        return Step(member, "done", "交付", data={"usage": o.get("usage") or {}})
    if t in ("thinking", "reasoning"):
        return Step(member, "thinking", "在想")
    return Step(member, "text", (o.get("text") or o.get("message") or "")[:200] if isinstance(o.get("text") or o.get("message"), str) else "")


def tool_step(member, name, inp) -> Step:
    n = (name or "").lower()
    if n in _EDIT_TOOLS:
        return Step(member, "edit", str(inp.get("file_path") or inp.get("path") or "")[:200], data={"tool": name, "input": inp})
    if n in ("bash", "shell", "run_shell_command", "exec"):
        cmd = str(inp.get("command") or inp.get("cmd") or "")
        return Step(member, "test" if _TEST_RE.search(cmd) else "command", cmd[:200], data={"tool": name, "input": inp})
    return Step(member, "tool", name, data={"tool": name, "input": inp})


class CliAdapter(Adapter):
    """Fallback for CLIs without ACP: packet on stdin (then EOF), stdout events parsed into Steps. Tool permissions
    arrive through the approve MCP hook the server injects (CHORUS_APPROVE_URL), which calls the same gate."""
    kind = "cli"

    def __init__(self, member: dict, guard: Callable[[str], tuple], timeout: float = 3600, env: Optional[dict] = None):
        super().__init__(member)
        self.guard = guard
        self.timeout = timeout
        self.env = env or {}

    async def run(self, packet, emit, approve, cwd="", system=""):
        cmd, stripped = self.guard(self.member.get("cmd", ""))
        if not cmd.strip():
            return Result(False, error="这个成员没有填命令")
        if stripped:
            emit(Step(self.name, "text", "已去掉跳过审批的参数"))
        emit(Step(self.name, "start", "开始"))
        proc = await asyncio.create_subprocess_shell(
            cmd, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            cwd=cwd or None, env={**os.environ, **self.env}, start_new_session=True)
        proc.stdin.write((((system + "\n\n") if system else "") + packet).encode())
        await proc.stdin.drain()
        proc.stdin.close()
        text, usage = [], {}

        async def pump():
            async for raw in proc.stdout:
                st = parse_cli_line(raw.decode(errors="replace"), self.name)
                if st is None:
                    continue
                if st.kind == "done":
                    usage.update({k: int(v) for k, v in (st.data.get("usage") or {}).items() if k in ("in", "out", "cached")})
                if st.kind == "text" and st.text:
                    text.append(st.text)
                emit(st)
        try:
            await asyncio.wait_for(pump(), self.timeout)
            err = (await proc.stderr.read()).decode(errors="replace")[-400:]
            code = await proc.wait()
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            emit(Step(self.name, "error", "超时"))
            return Result(False, error="timeout")
        out = "\n".join(text)
        if code != 0:
            emit(Step(self.name, "error", f"退出码 {code}"))
            return Result(False, out, error=err or f"exit {code}")
        emit(Step(self.name, "done", "交付"))
        return Result(True, out, artifacts=artifacts_in(out), usage=usage)


# ---------------------------------------------------------------- ACP (Agent Client Protocol, JSON-RPC 2.0 over stdio)
_ACP_KIND = {"read": "tool", "edit": "edit", "delete": "edit", "move": "edit", "search": "tool", "execute": "command",
             "think": "thinking", "fetch": "tool", "other": "tool"}


class AcpAdapter(Adapter):
    """Drives an ACP agent (codex-acp, claude-code-acp, gemini --experimental-acp …): initialize → session/new →
    session/prompt; session/update notifications become Steps; session/request_permission becomes a gated consent
    decision (allow_once / reject_once only — 'always' is decided by the member's policy on our side, never by the agent);
    token usage from update/_meta is accounted by the server."""
    kind = "acp"

    def __init__(self, member: dict, guard: Callable[[str], tuple], timeout: float = 3600, env: Optional[dict] = None):
        super().__init__(member)
        self.guard, self.timeout, self.env = guard, timeout, env or {}
        self._id = 0

    def _next(self):
        self._id += 1
        return self._id

    async def run(self, packet, emit, approve, cwd="", system=""):
        cmd, stripped = self.guard(self.member.get("cmd", ""))
        if not cmd.strip():
            return Result(False, error="这个成员没有填命令")
        proc = await asyncio.create_subprocess_shell(
            cmd, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            cwd=cwd or None, env={**os.environ, **self.env}, start_new_session=True, limit=8 * 1024 * 1024)
        pending: dict = {}
        text, usage = [], {"in": 0, "out": 0, "cached": 0}
        emit(Step(self.name, "start", "开始"))

        async def send(o):
            proc.stdin.write((json.dumps(o, ensure_ascii=False) + "\n").encode())
            await proc.stdin.drain()

        async def call(method, params):
            i = self._next()
            fut = asyncio.get_running_loop().create_future()
            pending[i] = fut
            await send({"jsonrpc": "2.0", "id": i, "method": method, "params": params})
            return await fut

        def on_update(u):
            k = u.get("sessionUpdate", "")
            if k == "agent_message_chunk":
                c = u.get("content") or {}
                if c.get("type") == "text":
                    text.append(c.get("text", ""))
                    emit(Step(self.name, "tokens", f"{sum(map(len, text))} 字"))
            elif k == "agent_thought_chunk":
                emit(Step(self.name, "thinking", "在想"))
            elif k in ("tool_call", "tool_call_update"):
                raw = u.get("rawInput") or {}
                kind = _ACP_KIND.get(u.get("kind", "other"), "tool")
                title = u.get("title") or ""
                if kind == "command" and _TEST_RE.search(str(raw.get("command", "")) + " " + title):
                    kind = "test"
                if k == "tool_call" or u.get("status") in ("completed", "failed"):
                    emit(Step(self.name, kind, title[:200], data={"status": u.get("status", ""), "input": raw}))
            elif k == "plan":
                es = u.get("entries") or []
                done = sum(1 for e in es if e.get("status") == "completed")
                emit(Step(self.name, "plan", f"{done}/{len(es)}", data={"entries": es}))
            m_ = u.get("_meta") or {}
            rl = m_.get("rate_limits") or m_.get("rateLimits") or u.get("rate_limits") or u.get("rateLimits")
            if isinstance(rl, dict):   # Codex token/limit events over ACP: fresher than ~/.codex/sessions
                LIMITS[self.name] = {"at": time.time(), "rate_limits": rl}
                emit(Step(self.name, "limits", "", data={"rate_limits": rl}))
            meta = m_.get("usage") or u.get("usage")
            if isinstance(meta, dict):
                usage["in"] = int(meta.get("inputTokens", meta.get("in", usage["in"])) or 0)
                usage["out"] = int(meta.get("outputTokens", meta.get("out", usage["out"])) or 0)
                usage["cached"] = int(meta.get("cachedReadTokens", meta.get("cached", usage["cached"])) or 0)

        async def answer_permission(i, params):
            tc = params.get("toolCall") or {}
            raw = tc.get("rawInput") or {}
            tool = {"execute": "Bash", "edit": "Write", "delete": "Write", "move": "Write", "fetch": "WebFetch"}.get(tc.get("kind", ""), tc.get("title") or "tool")
            ok = await approve(tool, raw)
            opts = params.get("options") or []
            want = "allow_once" if ok else "reject_once"
            pick = next((o for o in opts if o.get("kind") == want), None) or next(
                (o for o in opts if o.get("kind", "").startswith("allow" if ok else "reject")), None)
            outcome = {"outcome": "selected", "optionId": pick["optionId"]} if pick else {"outcome": "cancelled"}
            emit(Step(self.name, "permission", ("同意 " if ok else "拒绝 ") + tool, data={"allow": ok, "input": raw}))
            await send({"jsonrpc": "2.0", "id": i, "result": {"outcome": outcome}})

        async def reader():
            while True:
                raw = await proc.stdout.readline()
                if not raw:
                    for f in pending.values():
                        if not f.done():
                            f.set_exception(RuntimeError("ACP agent 退出了"))
                    return
                try:
                    o = json.loads(raw)
                except ValueError:
                    continue
                if "method" in o and "id" in o:            # agent -> client request
                    if o["method"] == "session/request_permission":
                        asyncio.ensure_future(answer_permission(o["id"], o.get("params") or {}))
                    else:
                        await send({"jsonrpc": "2.0", "id": o["id"], "error": {"code": -32601, "message": "not supported"}})
                elif "method" in o:                         # notification
                    if o["method"] == "session/update":
                        on_update((o.get("params") or {}).get("update") or {})
                elif o.get("id") in pending:                # response
                    f = pending.pop(o["id"])
                    if "error" in o:
                        f.set_exception(RuntimeError(str(o["error"].get("message", "error"))))
                    else:
                        f.set_result(o.get("result") or {})

        rd = asyncio.ensure_future(reader())
        try:
            async def flow():
                await call("initialize", {"protocolVersion": 1, "clientCapabilities": {"fs": {"readTextFile": False, "writeTextFile": False}, "terminal": False}})
                sess = await call("session/new", {"cwd": cwd or os.getcwd(), "mcpServers": []})
                prompt = [{"type": "text", "text": ((system + "\n\n") if system else "") + packet}]
                return await call("session/prompt", {"sessionId": sess["sessionId"], "prompt": prompt})
            res = await asyncio.wait_for(flow(), self.timeout)
        except asyncio.TimeoutError:
            proc.kill()
            emit(Step(self.name, "error", "超时"))
            return Result(False, error="timeout")
        except RuntimeError as e:
            emit(Step(self.name, "error", str(e)[:120]))
            return Result(False, error=str(e))
        finally:
            if proc.returncode is None:
                proc.stdin.close()
                try:
                    await asyncio.wait_for(proc.wait(), 5)
                except asyncio.TimeoutError:
                    proc.kill()
            rd.cancel()
        out = "".join(text)
        stop = res.get("stopReason", "end_turn")
        if stop not in ("end_turn", "max_tokens"):
            emit(Step(self.name, "error", f"停止：{stop}"))
            return Result(False, out, error=stop, usage=usage)
        emit(Step(self.name, "done", "交付"))
        return Result(True, out, artifacts=artifacts_in(out), usage=usage)


def artifacts_in(text: str) -> list:
    """[产物]…[/产物] blocks, one artifact per non-empty line (paths or links)."""
    out = []
    for blk in re.findall(r"\[产物\](.*?)\[/产物\]", text or "", re.S):
        out += [ln.strip() for ln in blk.splitlines() if ln.strip()]
    return out


# ---------------------------------------------------------------- capability registry
_VISION = re.compile(r"(vision|vl\b|-vl|4o|gpt-4\.1|gpt-5|claude|gemini|qwen.*vl|glm-4v|mimo.*(vl|omni)|omni)", re.I)
_LONG = re.compile(r"(claude|gemini|kimi|moonshot|long|128k|200k|1m|qwen-long|deepseek)", re.I)


def capabilities(member: dict, price: Optional[dict] = None, stats: Optional[dict] = None) -> dict:
    """What a member can do; explicit member["caps"] wins over inference from kind/model name."""
    model = str(member.get("model", "")) + " " + str(member.get("cmd", ""))
    kind = member.get("kind", "api")
    c = {
        "code_exec": kind in ("cli", "dsh"),
        "vision": bool(_VISION.search(model)),
        "video": "gemini" in model.lower() or "omni" in model.lower(),
        "long_ctx": bool(_LONG.search(model)),
        "web": kind in ("cli",) or "search" in model.lower(),
        "price_out": (price or {}).get("out"),
        "pass_rate": (stats or {}).get("pass", 0.8),
    }
    c.update({k: v for k, v in (member.get("caps") or {}).items() if k in c})
    return c


def pick(members: list, need: set, price_of: Callable[[dict], Optional[dict]], stats: dict, exclude=()) -> Optional[dict]:
    """Cheapest member having every needed capability, ties by pass rate. Deterministic, no LLM."""
    best = None
    for m in members:
        if m["name"] in exclude:
            continue
        caps = capabilities(m, price_of(m), stats.get(m["name"]))
        if not all(caps.get(n) for n in need):
            continue
        key = (caps["price_out"] if caps["price_out"] is not None else 1e9, -caps["pass_rate"], m["name"])
        if best is None or key < best[0]:
            best = (key, m)
    return best[1] if best else None
