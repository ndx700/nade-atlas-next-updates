"""server/wakegraph.py — 唤醒/协作护栏 + 流转日志（纯标准库）。

群聊（乐章）里，用户或任一 AI 都可以用 @名字 唤醒另一个 AI；AI 之间互相唤醒
用于 接棒 / 求助 / 送审 / 派单 等。本模块做三件事：

1. 护栏：跳数、来回次数、重复内容、频率、预算、休息状态；
2. 流转日志：记录唤醒边（edge）与每个 AI 的当前步骤（step）；
3. 展示辅助：把边渲染成一行中文系统消息，并把连续的系统消息折叠成一组。
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

__all__ = [
    "REASONS",
    "STEPS",
    "REASON_LABELS",
    "WakeVerdict",
    "Graph",
]

REASONS = ("mention", "handoff", "help", "review", "dispatch", "lead_plan", "retry")
STEPS = ("planning", "working", "selfcheck", "review", "waiting", "idle", "resting")

REASON_LABELS = {
    "mention": "点名",
    "handoff": "接棒",
    "help": "求助",
    "review": "送审",
    "dispatch": "派单",
    "lead_plan": "谱稿",
    "retry": "重试",
}

#: 这些唤醒者被当成“人”（用户），绕过跳数/来回/频率/去重护栏。
USER_SENDERS = frozenset({"user", "ali"})

#: 最多保留多少条边（持久化也一样）。
MAX_EDGES = 500

#: 频率护栏的统计窗口（秒）。
RATE_WINDOW = 60.0

#: 去重表最多存多少个 key（超过后按时间剪枝）。
_SEEN_SOFT_CAP = 4096


def _minutes(seconds: float) -> str:
    """120.0 -> '2'，90.0 -> '1.5'（用于中文提示）。"""
    return f"{float(seconds) / 60.0:g}"


@dataclass
class WakeVerdict:
    """一次唤醒尝试的结论。ok=False 时 why 是给用户看的中文原因。"""

    ok: bool
    why: str = ""

    def __bool__(self) -> bool:  # 方便 if verdict:
        return bool(self.ok)


class Graph:
    """唤醒护栏 + 流转图。线程安全不在本模块职责内，由调用方加锁。"""

    _CFG_KEYS = ("max_hops", "pingpong_limit", "dedupe_window", "rate_per_min")

    def __init__(
        self,
        max_hops: int = 6,
        pingpong_limit: int = 3,
        dedupe_window: float = 120.0,
        rate_per_min: int = 6,
        now: Callable[[], float] = time.time,
    ) -> None:
        self.max_hops = int(max_hops)
        self.pingpong_limit = int(pingpong_limit)
        self.dedupe_window = float(dedupe_window)
        self.rate_per_min = int(rate_per_min)
        self._now: Callable[[], float] = now or time.time

        self._edges: list[dict] = []
        self._hops: dict[str, int] = {}
        self._steps: dict[str, dict[str, dict]] = {}
        self._seen: dict[str, float] = {}
        self._seq = 0

    # ------------------------------------------------------------------ guard
    def can_wake(
        self,
        root: str,
        src: str,
        dst: str,
        reason: str,
        text: str,
        budget_left: Optional[float] = None,
        dst_state: str = "idle",
    ) -> WakeVerdict:
        """判断 src 能否唤醒 dst。通过时会把去重指纹记下来。"""
        src = (src or "").strip()
        dst = (dst or "").strip()
        root = (root or "").strip()

        if not dst or src == dst:
            return WakeVerdict(False, "不能自己唤醒自己")
        if (dst_state or "").strip() == "resting":
            return WakeVerdict(False, "对方在休息")
        if budget_left is not None and float(budget_left) <= 0:
            return WakeVerdict(False, "预算用完")

        now = float(self._now())

        # 用户直接点名：绕过 跳数 / 来回 / 去重 / 频率，只保留上面的硬限制。
        if self._is_user(src):
            return WakeVerdict(True)

        if self._hops.get(root, 0) >= self.max_hops:
            return WakeVerdict(False, f"超过 {self.max_hops} 跳")

        if self._pingpong(root, src, dst) >= self.pingpong_limit:
            return WakeVerdict(False, f"互相来回 {self.pingpong_limit} 次已停")

        key = self._dedupe_key(src, dst, text)
        if key is not None:
            last = self._seen.get(key)
            if last is not None and (now - last) < self.dedupe_window:
                return WakeVerdict(
                    False, f"同一内容 {_minutes(self.dedupe_window)} 分钟内重复"
                )

        if self._recent_dst_count(dst, now) >= self.rate_per_min:
            return WakeVerdict(False, "频率过高")

        if key is not None:
            self._seen[key] = now
            self._prune_seen(now)
        return WakeVerdict(True)

    # ----------------------------------------------------------------- record
    def record(
        self,
        root: str,
        pid: str,
        src: str,
        dst: str,
        reason: str,
        seg: str = "",
        note: str = "",
    ) -> dict:
        """记录一条唤醒边，hop 按 root 单独递增。返回边的副本。"""
        now = float(self._now())
        self._seq += 1
        hop = self._hops.get(root, 0) + 1
        self._hops[root] = hop
        edge = {
            "id": f"e{self._seq}",
            "at": now,
            "root": root,
            "pid": pid,
            "src": src,
            "dst": dst,
            "reason": reason,
            "seg": seg or "",
            "note": note or "",
            "hop": hop,
        }
        self._edges.append(edge)
        if len(self._edges) > MAX_EDGES:
            del self._edges[: len(self._edges) - MAX_EDGES]
        return dict(edge)

    # ------------------------------------------------------------------ steps
    def set_step(
        self,
        pid: str,
        member: str,
        step: str,
        seg: str = "",
        detail: str = "",
    ) -> None:
        """设置某 AI 在某乐章里的当前步骤。"""
        if step not in STEPS:
            raise ValueError(f"unknown step: {step!r}")
        slot = self._steps.setdefault(str(pid), {})
        slot[str(member)] = {
            "step": step,
            "seg": seg or "",
            "detail": detail or "",
            "since": float(self._now()),
        }

    def steps(self, pid: str) -> dict[str, dict]:
        """member -> {step, seg, detail, since}（深拷贝）。"""
        members = self._steps.get(str(pid), {})
        return {m: dict(rec) for m, rec in members.items()}

    # ------------------------------------------------------------------- flow
    def flow(self, pid: str, limit: int = 50) -> dict:
        """乐章 pid 的最近边、成员步骤、各 root 已走跳数。"""
        mine = [e for e in self._edges if e.get("pid") == pid]
        if limit is not None and int(limit) > 0:
            mine = mine[-int(limit):]
        roots: dict[str, int] = {}
        for e in mine:
            root = e.get("root", "")
            hop = int(e.get("hop") or 0)
            roots[root] = roots.get(root, 0) + 1  # wakes in this 乐章 per root
        return {
            "edges": [dict(e) for e in mine],
            "steps": self.steps(pid),
            "roots": roots,
        }

    # ------------------------------------------------------------- rendering
    def system_line(self, edge: dict) -> str:
        """一行紧凑中文系统消息：'大肥鱼 → 小克 · 接棒 s3'。"""
        reason = str(edge.get("reason") or "")
        label = REASON_LABELS.get(reason, reason)
        src = str(edge.get("src") or "?")
        dst = str(edge.get("dst") or "?")
        line = f"{src} → {dst} · {label}"
        seg = str(edge.get("seg") or "")
        if seg:
            line += f" {seg}"
        return line

    def collapse(self, lines: list[dict], window: float = 30.0) -> list[dict]:
        """把同一 pid、间隔不超过 window 的连续系统消息折叠成一组。"""
        groups: list[dict] = []
        for raw in lines or []:
            if not isinstance(raw, dict):
                continue
            at = float(raw.get("at") or 0.0)
            pid = str(raw.get("pid") or "")
            if groups and groups[-1]["pid"] == pid and (at - groups[-1]["last"]) <= window:
                groups[-1]["items"].append(raw)
                groups[-1]["last"] = at
            else:
                groups.append({"pid": pid, "at": at, "last": at, "items": [raw]})

        out: list[dict] = []
        for grp in groups:
            items = grp["items"]
            out.append(
                {
                    "at": grp["at"],
                    "pid": grp["pid"],
                    "summary": self._summary(items),
                    "items": items,
                }
            )
        return out

    # ------------------------------------------------------------ persistence
    def to_json(self) -> dict:
        return {
            "version": 1,
            "config": {
                "max_hops": self.max_hops,
                "pingpong_limit": self.pingpong_limit,
                "dedupe_window": self.dedupe_window,
                "rate_per_min": self.rate_per_min,
            },
            "seq": self._seq,
            "hops": dict(self._hops),
            "edges": [dict(e) for e in self._edges[-MAX_EDGES:]],
            "steps": {
                pid: {m: dict(rec) for m, rec in members.items()}
                for pid, members in self._steps.items()
            },
        }

    @classmethod
    def from_json(cls, d: Any, **kw: Any) -> "Graph":
        if not isinstance(d, dict):
            raise ValueError("graph json 必须是对象")

        cfg: dict[str, Any] = {}
        raw_cfg = d.get("config")
        if isinstance(raw_cfg, dict):
            for k in cls._CFG_KEYS:
                if k in raw_cfg:
                    cfg[k] = raw_cfg[k]
        for k in cls._CFG_KEYS:
            if k in kw:
                cfg[k] = kw[k]
        if kw.get("now") is not None:
            cfg["now"] = kw["now"]
        g = cls(**cfg)

        edges: list[dict] = []
        raw_edges = d.get("edges")
        if isinstance(raw_edges, list):
            for raw in raw_edges:
                if not isinstance(raw, dict):
                    continue
                try:
                    hops = int(raw.get("hop") or 0)
                except (TypeError, ValueError):
                    hops = 0
                try:
                    at = float(raw.get("at") or 0.0)
                except (TypeError, ValueError):
                    at = 0.0
                edges.append(
                    {
                        "id": str(raw.get("id") or ""),
                        "at": at,
                        "root": str(raw.get("root") or ""),
                        "pid": str(raw.get("pid") or ""),
                        "src": str(raw.get("src") or ""),
                        "dst": str(raw.get("dst") or ""),
                        "reason": str(raw.get("reason") or ""),
                        "seg": str(raw.get("seg") or ""),
                        "note": str(raw.get("note") or ""),
                        "hop": hops,
                    }
                )
        g._edges = edges[-MAX_EDGES:]

        hops_by_root: dict[str, int] = {}
        raw_hops = d.get("hops")
        if isinstance(raw_hops, dict):
            for root, n in raw_hops.items():
                try:
                    hops_by_root[str(root)] = int(n)
                except (TypeError, ValueError):
                    continue
        for e in g._edges:
            root = e["root"]
            if e["hop"] > hops_by_root.get(root, 0):
                hops_by_root[root] = e["hop"]
        g._hops = hops_by_root

        seq = 0
        try:
            seq = int(d.get("seq") or 0)
        except (TypeError, ValueError):
            seq = 0
        for e in g._edges:
            eid = e["id"]
            if eid.startswith("e"):
                try:
                    seq = max(seq, int(eid[1:]))
                except ValueError:
                    continue
        g._seq = seq

        raw_steps = d.get("steps")
        if isinstance(raw_steps, dict):
            for pid, members in raw_steps.items():
                if not isinstance(members, dict):
                    continue
                slot = g._steps.setdefault(str(pid), {})
                for member, rec in members.items():
                    if not isinstance(rec, dict):
                        continue
                    try:
                        since = float(rec.get("since") or 0.0)
                    except (TypeError, ValueError):
                        since = 0.0
                    slot[str(member)] = {
                        "step": str(rec.get("step") or "idle"),
                        "seg": str(rec.get("seg") or ""),
                        "detail": str(rec.get("detail") or ""),
                        "since": since,
                    }
        return g

    # --------------------------------------------------------------- helpers
    @staticmethod
    def _is_user(src: str) -> bool:
        return (src or "").strip().lower() in USER_SENDERS

    def _pingpong(self, root: str, src: str, dst: str) -> int:
        """root 内末尾连续“只在这两人之间来回”的次数。"""
        pair = {src, dst}
        count = 0
        for e in reversed(self._edges):
            if e.get("root") != root:
                continue  # 别的 root 不打断本 root 的连续计数
            es, ed = e.get("src"), e.get("dst")
            if not es or not ed or es == ed:
                continue
            if {es, ed} == pair:
                count += 1
            else:
                break
        return count

    def _recent_dst_count(self, dst: str, now: float) -> int:
        start = now - RATE_WINDOW
        return sum(
            1
            for e in self._edges
            if e.get("dst") == dst and float(e.get("at") or 0.0) >= start
        )

    def _dedupe_key(self, src: str, dst: str, text: str) -> Optional[str]:
        norm = " ".join((text or "").split()).lower()
        if not norm:
            return None
        digest = hashlib.sha1(norm.encode("utf-8")).hexdigest()[:16]
        return f"{src}\x00{dst}\x00{digest}"

    def _prune_seen(self, now: float) -> None:
        if len(self._seen) <= _SEEN_SOFT_CAP:
            return
        horizon = now - max(self.dedupe_window, 1.0) * 2.0
        self._seen = {k: v for k, v in self._seen.items() if v >= horizon}

    def _summary(self, items: list[dict]) -> str:
        n = len(items)
        if n == 1:
            it = items[0]
            return str(it.get("text") or self.system_line(it))

        chain: list[str] = []
        connected = True
        for it in items:
            s = it.get("src")
            d = it.get("dst")
            if not s or not d:
                connected = False
                break
            s, d = str(s), str(d)
            if not chain:
                chain.append(s)
            elif chain[-1] != s:
                connected = False
                break
            chain.append(d)

        if connected and len(chain) >= 2:
            return f"{n} 次交接 · " + " → ".join(chain)

        joined = " / ".join(str(it.get("text") or self.system_line(it)) for it in items)
        return f"{n} 次交接 · {joined}"
