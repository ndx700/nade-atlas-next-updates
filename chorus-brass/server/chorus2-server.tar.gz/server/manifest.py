"""Artifact manifest registry for Chorus multi-agent handoff.

Design goals (task card N4):
- ``register_artifact``: register a produced artifact with id, segment,
  producer, path, sha256, mime, bytes, checks, refs, created_at.
- ``verify_artifact``: recompute sha256 of the file at ``path`` and detect
  tampering.
- ``resolve_inputs``: given a list of artifact ids, assemble a minimal
  context (signature + acceptance status + content digest) for downstream
  task cards. When a manifest is missing, fall back to the legacy path
  resolution and record a warning instead of failing hard.

Only stdlib + aiohttp are used. The registry is JSON-file backed so it can
be shared between processes and survives restarts; all file IO is guarded
by an ``asyncio.Lock`` per registry path to keep concurrent writes safe.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import mimetypes
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

__all__ = [
    "ArtifactManifest",
    "ManifestError",
    "ManifestNotFoundError",
    "ManifestIntegrityError",
    "ManifestRegistry",
    "default_registry",
    "register_artifact",
    "verify_artifact",
    "resolve_inputs",
    "sha256_file",
    "sha256_bytes",
    "guess_mime",
]

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ManifestError(Exception):
    """Base class for manifest related errors."""


class ManifestNotFoundError(ManifestError):
    """Raised when an artifact id cannot be located in the registry."""


class ManifestIntegrityError(ManifestError):
    """Raised when the on-disk content no longer matches the manifest."""

    def __init__(self, artifact_id: str, expected: str, actual: str) -> None:
        super().__init__(
            f"artifact {artifact_id!r} sha256 mismatch: expected {expected}, got {actual}"
        )
        self.artifact_id = artifact_id
        self.expected = expected
        self.actual = actual


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class ArtifactManifest:
    """Immutable-ish record describing one produced artifact."""

    id: str
    seg: str
    producer: str
    path: str
    sha256: str
    mime: str
    bytes: int
    checks: dict[str, Any] = field(default_factory=dict)
    refs: list[str] = field(default_factory=list)
    created_at: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ArtifactManifest":
        try:
            return cls(
                id=str(data["id"]),
                seg=str(data.get("seg", "")),
                producer=str(data.get("producer", "")),
                path=str(data["path"]),
                sha256=str(data["sha256"]),
                mime=str(data.get("mime", "application/octet-stream")),
                bytes=int(data.get("bytes", 0)),
                checks=dict(data.get("checks") or {}),
                refs=[str(r) for r in (data.get("refs") or [])],
                created_at=int(data.get("created_at", 0)),
            )
        except (KeyError, TypeError, ValueError) as exc:  # pragma: no cover
            raise ManifestError(f"invalid manifest payload: {exc}") from exc

    # -- convenience accessors -------------------------------------------
    @property
    def passed(self) -> bool:
        return bool(self.checks.get("passed", False))

    @property
    def checked_at(self) -> int | None:
        value = self.checks.get("at")
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def signature(self) -> dict[str, Any]:
        """Compact signature used in downstream minimal context."""
        return {
            "id": self.id,
            "seg": self.seg,
            "producer": self.producer,
            "sha256": self.sha256,
            "mime": self.mime,
            "bytes": self.bytes,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | os.PathLike[str], chunk_size: int = 1 << 20) -> str:
    """Stream a file through sha256; raises FileNotFoundError if missing."""
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def guess_mime(path: str | os.PathLike[str]) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    return mime or "application/octet-stream"


def _now() -> int:
    return int(time.time())


def _new_artifact_id() -> str:
    return f"art_{uuid.uuid4().hex[:16]}"


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class ManifestRegistry:
    """JSON-file backed registry of :class:`ArtifactManifest` records.

    The on-disk layout is::

        {
          "version": 1,
          "artifacts": { "art_xxx": {...}, ... }
        }

    All public coroutines are safe to call concurrently; writes are serialized
    through a per-instance ``asyncio.Lock`` and flushed atomically via a
    temporary file + ``os.replace``.
    """

    SCHEMA_VERSION = 1

    def __init__(self, store_path: str | os.PathLike[str]) -> None:
        self._path = Path(store_path)
        self._lock = asyncio.Lock()
        self._cache: dict[str, ArtifactManifest] | None = None

    # -- persistence -----------------------------------------------------
    @property
    def path(self) -> Path:
        return self._path

    def _load_sync(self) -> dict[str, ArtifactManifest]:
        if not self._path.exists():
            return {}
        try:
            raw = json.loads(self._path.read_text("utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        artifacts_raw = raw.get("artifacts") if isinstance(raw, dict) else None
        if not isinstance(artifacts_raw, dict):
            return {}
        out: dict[str, ArtifactManifest] = {}
        for key, value in artifacts_raw.items():
            if not isinstance(value, Mapping):
                continue
            try:
                out[str(key)] = ArtifactManifest.from_dict(value)
            except ManifestError:
                continue
        return out

    def _save_sync(self, artifacts: Mapping[str, ArtifactManifest]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": self.SCHEMA_VERSION,
            "artifacts": {k: v.to_dict() for k, v in artifacts.items()},
        }
        tmp = self._path.with_suffix(self._path.suffix + f".tmp{os.getpid()}")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), "utf-8")
        os.replace(tmp, self._path)

    async def _ensure_loaded(self) -> dict[str, ArtifactManifest]:
        if self._cache is None:
            self._cache = await asyncio.to_thread(self._load_sync)
        return self._cache

    # -- public API ------------------------------------------------------
    async def register(
        self,
        *,
        path: str | os.PathLike[str],
        seg: str,
        producer: str,
        mime: str | None = None,
        checks: Mapping[str, Any] | None = None,
        refs: Sequence[str] | None = None,
        artifact_id: str | None = None,
        created_at: int | None = None,
    ) -> ArtifactManifest:
        """Register (or re-register) an artifact produced at ``path``.

        The file must exist; its sha256 and byte size are computed here so the
        manifest is authoritative. Re-registering the same ``artifact_id``
        replaces the previous record (useful when a segment is re-run).
        """
        file_path = Path(path)
        if not file_path.is_file():
            raise FileNotFoundError(f"artifact file not found: {file_path}")

        digest, size = await asyncio.to_thread(self._hash_and_size, file_path)
        manifest = ArtifactManifest(
            id=artifact_id or _new_artifact_id(),
            seg=str(seg),
            producer=str(producer),
            path=str(file_path),
            sha256=digest,
            mime=mime or guess_mime(file_path),
            bytes=size,
            checks=dict(checks or {}),
            refs=[str(r) for r in (refs or [])],
            created_at=int(created_at if created_at is not None else _now()),
        )

        async with self._lock:
            artifacts = await self._ensure_loaded()
            artifacts[manifest.id] = manifest
            await asyncio.to_thread(self._save_sync, artifacts)
        return manifest

    async def get(self, artifact_id: str) -> ArtifactManifest:
        async with self._lock:
            artifacts = await self._ensure_loaded()
            manifest = artifacts.get(artifact_id)
        if manifest is None:
            raise ManifestNotFoundError(f"unknown artifact id: {artifact_id}")
        return manifest

    async def list(self) -> list[ArtifactManifest]:
        async with self._lock:
            artifacts = await self._ensure_loaded()
            return sorted(artifacts.values(), key=lambda m: m.created_at)

    async def verify(self, artifact_id: str) -> ArtifactManifest:
        """Recompute sha256 of the artifact file and compare with the manifest.

        Raises :class:`ManifestIntegrityError` on mismatch and
        :class:`ManifestNotFoundError` when the id is unknown.
        """
        manifest = await self.get(artifact_id)
        file_path = Path(manifest.path)
        if not file_path.is_file():
            raise FileNotFoundError(f"artifact file missing: {file_path}")
        actual = await asyncio.to_thread(sha256_file, file_path)
        if actual != manifest.sha256:
            raise ManifestIntegrityError(manifest.id, manifest.sha256, actual)
        return manifest

    async def resolve(
        self,
        input_artifacts: Iterable[str],
        *,
        legacy_paths: Mapping[str, str | os.PathLike[str]] | None = None,
    ) -> dict[str, Any]:
        """Assemble minimal downstream context for ``input_artifacts``.

        Returns::

            {
              "artifacts": [ {signature..., "checks": {...}, "path": "..."} ],
              "warnings": [ "...", ... ],
            }

        Missing manifests fall back to ``legacy_paths`` (id -> path) and are
        reported in ``warnings``; unknown ids without a legacy path are also
        reported as warnings so downstream tasks can proceed with whatever is
        available instead of crashing.
        """
        legacy_paths = dict(legacy_paths or {})
        artifacts: list[dict[str, Any]] = []
        warnings: list[str] = []

        for artifact_id in input_artifacts:
            try:
                manifest = await self.get(artifact_id)
            except ManifestNotFoundError:
                legacy = legacy_paths.get(artifact_id)
                if legacy is None:
                    warnings.append(
                        f"no manifest for artifact {artifact_id!r} and no legacy path provided"
                    )
                    continue
                entry = await self._legacy_entry(artifact_id, legacy)
                warnings.append(
                    f"manifest missing for artifact {artifact_id!r}; fell back to legacy path {entry['path']}"
                )
                artifacts.append(entry)
                continue

            entry = manifest.signature()
            entry["checks"] = dict(manifest.checks)
            entry["path"] = manifest.path
            entry["refs"] = list(manifest.refs)
            artifacts.append(entry)

        return {"artifacts": artifacts, "warnings": warnings}

    # -- internals -------------------------------------------------------
    @staticmethod
    def _hash_and_size(file_path: Path) -> tuple[str, int]:
        digest = hashlib.sha256()
        size = 0
        with open(file_path, "rb") as fh:
            while True:
                chunk = fh.read(1 << 20)
                if not chunk:
                    break
                size += len(chunk)
                digest.update(chunk)
        return digest.hexdigest(), size

    async def _legacy_entry(
        self, artifact_id: str, legacy_path: str | os.PathLike[str]
    ) -> dict[str, Any]:
        file_path = Path(legacy_path)
        if not file_path.is_file():
            raise FileNotFoundError(f"legacy artifact file not found: {file_path}")
        digest, size = await asyncio.to_thread(self._hash_and_size, file_path)
        return {
            "id": artifact_id,
            "seg": "",
            "producer": "",
            "sha256": digest,
            "mime": guess_mime(file_path),
            "bytes": size,
            "created_at": 0,
            "checks": {},
            "path": str(file_path),
            "refs": [],
            "legacy": True,
        }


# ---------------------------------------------------------------------------
# Module-level convenience API (uses a process-wide default registry)
# ---------------------------------------------------------------------------

_DEFAULT_REGISTRY: ManifestRegistry | None = None
_DEFAULT_LOCK = asyncio.Lock()


def default_registry(store_path: str | os.PathLike[str] | None = None) -> ManifestRegistry:
    """Return the shared registry, optionally (re)pointing it at ``store_path``."""
    global _DEFAULT_REGISTRY
    if store_path is not None:
        _DEFAULT_REGISTRY = ManifestRegistry(store_path)
    if _DEFAULT_REGISTRY is None:
        _DEFAULT_REGISTRY = ManifestRegistry(
            os.environ.get("CHORUS_MANIFEST_PATH", "work/manifest.json")
        )
    return _DEFAULT_REGISTRY


async def register_artifact(
    *,
    path: str | os.PathLike[str],
    seg: str,
    producer: str,
    mime: str | None = None,
    checks: Mapping[str, Any] | None = None,
    refs: Sequence[str] | None = None,
    artifact_id: str | None = None,
    created_at: int | None = None,
    registry: ManifestRegistry | None = None,
) -> ArtifactManifest:
    reg = registry or default_registry()
    return await reg.register(
        path=path,
        seg=seg,
        producer=producer,
        mime=mime,
        checks=checks,
        refs=refs,
        artifact_id=artifact_id,
        created_at=created_at,
    )


async def verify_artifact(
    artifact_id: str,
    *,
    registry: ManifestRegistry | None = None,
) -> ArtifactManifest:
    reg = registry or default_registry()
    return await reg.verify(artifact_id)


async def resolve_inputs(
    input_artifacts: Iterable[str],
    *,
    legacy_paths: Mapping[str, str | os.PathLike[str]] | None = None,
    registry: ManifestRegistry | None = None,
) -> dict[str, Any]:
    reg = registry or default_registry()
    return await reg.resolve(input_artifacts, legacy_paths=legacy_paths)
