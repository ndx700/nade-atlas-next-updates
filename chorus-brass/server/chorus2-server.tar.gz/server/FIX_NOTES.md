# N3 / N6 修复记录

依据：`tools/cards/n/N3.md`、`tools/cards/n/N6.md`。初次在 server/ 运行指定命令：12 failed, 54 passed。

## 原始失败逐项归因

| 用例 | 判断与修复 |
| --- | --- |
| TestVerdictRules.test_merge_when_cost_high_and_gain_low | 实现错。N3 要求 expected_gain = 并行度 × 关键路径缩短比例，原实现多加了 1。两段默认收益应为 1，而非 3；修正公式后成本超限且收益不足，merge。 |
| TestVerdictRules.test_thresholds_are_configurable | 实现公式错误，同时测试夹具也错。修正公式后默认两段收益恰为 1，gain_floor=1 时不满足严格小于，不能期待 merge。显式设并行度 2、缩短比例 0.4，收益 0.8，保留严格配置 merge、宽松配置 split 的精确断言。 |
| TestReplay.test_replay_with_custom_thresholds | 实现错，与收益公式相同；保留 merge 断言。 |
| TestIrreversiblePolicy.test_publish_asks | 实现错。publish 工具本身就应 ask，不应额外要求参数命中生产环境正则。 |
| TestIrreversiblePolicy.test_payment_asks | 实现错。同上，payment 无需生产环境参数也应 ask。 |
| TestIrreversiblePolicy.test_send_email_asks | 实现错。同上，对外发送应 ask。 |
| TestIrreversiblePolicy.test_keyword_in_command_asks | 实现错。命中发布语义的 bash 参数也应 ask，不应被不可逆工具名单排除。 |
| TestIrreversiblePolicy.test_ask_request_is_structured | 上述匹配错误导致未生成 AskRequest；保留字段断言，修正匹配后通过。 |
| TestIrreversiblePolicy.test_ask_request_resolvable_by_relay | 同一匹配错误导致 ask 为空；保留请求查询及 approve 解析断言。 |
| TestIrreversiblePolicy.test_ask_request_deny_resolution | 同一匹配错误；保留 deny 解析断言。 |
| TestIrreversiblePolicy.test_ask_request_serializable_roundtrip | 同一匹配错误；保留序列化往返断言。 |
| TestHookEngine.test_deny_takes_precedence_over_ask | 实现错。危险命令策略限定 shell 工具名，漏掉 publish 参数中的 rm -rf /。移除危险命令工具名限制，保留 deny 优先于 ask 的断言。 |

## 相关修正与回归

- ROI 去掉空计划、单段计划的特殊豁免，统一执行 N3 的两个严格条件；旧代码将 split 解释为“不拆分”，语义矛盾。空计划默认成本超限且收益为零，测试精确期望 merge；单段默认收益断言改为零。
- 显式收益测试改为 4 × 0.5 = 2，上限测试按乘法公式收紧为 3 × 0.9。
- 新增成本恰等于 1.5 倍、收益恰等于阈值的边界测试，确保不能将 > / < 偷换为 >= / <=。
- 十条回放增加逐条 verdict 精确对照；这些是原测试已有的合成样本，未将其冒称为真实历史数据。
- Matcher 增加显式 tool_or_args 模式，仅不可逆策略启用；事件条件始终必须满足，其它策略维持各维度同时匹配。
- 不可逆工具名单补齐 delete_project，并新增删除项目 ask、非 before_tool 事件不误触发、无关工具及参数 allow 的回归测试。
- 所有项目内导入保持扁平（hooks / split_roi），无 server.xxx 导入。没有跳过用例或删除失败断言。

## 验证与范围

最终在 server/ 运行：

```sh
python3 -m pytest -q test_split_roi.py test_hooks.py
```

结果：**71 passed**（新增 5 个回归用例）。

仅修改四个指定 Python 文件并新增本说明文件。未改 orchestra.py 或其它文件；未执行 git commit/push。工作区原有 tools/mimo_pool.log 修改保留不动。未读取或打印密钥。
