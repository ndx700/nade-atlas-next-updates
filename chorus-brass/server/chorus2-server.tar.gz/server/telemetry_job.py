"""Daily opt-in reporting. No endpoint means a local sanitized report only."""
import asyncio
import datetime

from aiohttp import ClientSession, ClientTimeout

from telemetry import build_daily_report, sanitize


async def run_daily(server, now=None):
    """At most one attempt per configured calendar day, including after restart."""
    collab = server.CFG.get("collab")
    if not isinstance(collab, dict) or collab.get("telemetry") is not True:
        return "disabled"
    now = datetime.datetime.now(datetime.timezone.utc).timestamp() if now is None else now
    zone = datetime.timezone(datetime.timedelta(hours=server.CFG.get("tz", 8)))
    date = datetime.datetime.fromtimestamp(now, zone).date().isoformat()
    state_path = server.DATA / "telemetry_job.json"
    state = server.load(state_path, {})
    if state.get("last_attempt_date") == date:
        return "already_attempted"
    # RESULTS is the existing bounded completion history; never forward identities/text.
    events = []
    for result in server.RESULTS:
        at = result.get("at")
        if not isinstance(at, (int, float)) or datetime.datetime.fromtimestamp(at, zone).date().isoformat() != date:
            continue
        member = server.member(result.get("member")) or {}
        events.append({"model": member.get("model", "unknown"), "task_type": "reply",
                       "outcome": "pass" if result.get("ok") else None})
    report, _ = sanitize(build_daily_report(events, str(getattr(server, "VERSION", "brass")),
                                          report_date=date, now=now))
    server.DATA.mkdir(parents=True, exist_ok=True)
    server.save(server.DATA / "telemetry_out.json", report)
    # Persist before awaiting network: concurrent ticks/restarts cannot duplicate attempts.
    server.save(state_path, {"last_attempt_date": date})
    url = server.CFG.get("telemetry_url")
    if not isinstance(url, str) or not url.strip():
        return "local_only"
    try:
        async with ClientSession(timeout=ClientTimeout(total=30), trust_env=True) as session:
            async with session.put(url.strip(), json=report, allow_redirects=False) as response:
                if not 200 <= response.status < 300:
                    return "send_failed"
    except Exception:
        # Do not expose endpoint, response body, or credentials in logs.
        return "send_failed"
    return "sent"


async def telemetry_job(server):
    while True:
        try:
            await run_daily(server)
        except Exception as exc:
            print("telemetry_job", type(exc).__name__)
        await asyncio.sleep(60)


async def context(app):
    import server
    task = asyncio.create_task(telemetry_job(server))
    try:
        yield
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
