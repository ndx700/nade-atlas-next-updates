# Round 3 服务端验收记录

分支：`codex/round3`。改动仅在 `server/`，未提交。测试使用 `TemporaryDirectory` / `/tmp/round3-*`，未访问 `/var/lib/chorus`；未修改 `app/`（工作区中其他人的 app 改动保留）。

## B / N19

新增 `dm_notify.py`，调用方式：`await notify_user(member, reason, text, link)`。`make_app()` 绑定服务实例；单独调用可用 `bind(server)`。member 支持声部名或成员字典，link 支持字符串或带 `pid` / `project` 的字典。

- 按 `CFG.tz` 的自然日，每个声部跨项目最多三条主动通知，定音卡也占额度。
- 当日同文字合并并递增 count，不额外占额度；风险级别变化时单独创建定音卡，不能合并到普通文字来绕过。标记随聊天落盘，重载仍可限额、去重。
- 尊重 `CFG.dm_prefs[声部名].muted`，静音不消耗额度。
- 复用 `add_msg` 的 dm 字段；无指定项目时选该声部的活动项目，必要时创建私信项目。
- hooks BEFORE_TOOL / AFTER_TOOL 审计，记录发送、合并、静音、限额和定音等结果。
- reason、text、link 一起检查 redline 和花钱/外发语义；命中后只创建 pending 定音卡，通过现有 `/api/approve/{id}` 决定，超时自动拒绝。`approve_all` 不绕过；批准通知卡不会执行付款或外发动作。

## D / 导入验证与修复

演示脚本实际位置是 `tools/seed_demo.py`，不是 `server/tools/seed_demo.py`。

真实 HTTP 测试已写入 `server/test_import_live.py`：临时演示数据、本地 mock 模型、真实 server 子进程，覆盖两个导入接口、聊天 commit 和落盘。**本沙箱不能完成监听启动**：`socket.socket(AF_INET, SOCK_STREAM)` 直接报 `PermissionError: [Errno 1] Operation not permitted`。该测试在此环境明确 skip；不能据此宣称 HTTP 实测通过。

另用同一 seed 的临时数据运行 `test_import_handlers.py`，直接验证真实处理器与持久化：

| 场景 | 结果 |
| --- | --- |
| memory/import 粘贴三行（其中两行重复） | 只新增两条 |
| 重复导入相同记忆 | added=0 |
| memory/import 上传 ZIP 内 memories.txt | 新增并落盘 |
| import 粘贴 JSON / 上传文件 | 解析出两条对话 |
| import/commit | 创建项目，聊天文件包含原始两条消息 |
| 空请求、非文本 text、损坏 ZIP | 返回 400 |

处理器测试将整理助手设为离线，验证已有逐行回退路径。由于沙箱也阻断线程完成后的事件循环唤醒，测试中仅将 executor 调度替换为同线程执行，解析器本身保持真实实现；该验证不覆盖网络或线程调度。

修复：

1. `file_bytes` 校验输入，空请求/非文本 text 返回 400，避免 KeyError/AttributeError 导致 500。
2. 两个导入入口捕获损坏/加密等不可读 ZIP，返回可操作的 400。
3. 记忆导入每次新增后更新去重集合；`added` 返回实际新增数，修复同一批次重复插入及重复导入虚报。

## 检查结果与复现

```sh
PYTHONPATH=server python -m pytest server/test_dm_notify.py server/test_import_handlers.py server/test_import_live.py server/test_hooks.py server/test_redline.py server/test_skills_consent.py -q
# 213 passed, 1 skipped（真实 HTTP 测试因 socket 限制跳过）

PYTHONPATH=server python -m unittest discover -s server -p test_dm_notify.py -q
PYTHONPATH=server python -m unittest discover -s server -p 'test_import*.py' -q
PYTHONPATH=server python -m unittest discover -s server -p test_hooks.py -q
PYTHONPATH=server python -m unittest discover -s server -p test_redline.py -q
```

全量 `pytest server tests` 已尝试，无法全绿：首个失败为已有的 `test_backup.py::BackupTests::test_api_auth_boundaries_and_real_http_flow`，同样是本地 socket 被沙箱拒绝（在此之前 43 项通过）；未为此修改已有测试。完整运行还会受线程唤醒限制阻塞，设置了外部 timeout。

小克在允许监听本地端口的环境可直接运行以下命令完成尚未完成的 HTTP 验收；测试自行生成并清理临时数据、停止子进程，无需真实 key：

```sh
PYTHONPATH=server python -m unittest discover -s server -p test_import_live.py -v
```
