"""拆分 ROI 闸门 (Task card N3).

谱稿完成后计算拆分成本/收益，决定"该拆 / 不该拆"。

纯函数 ``split_decision(plan, prices, thresholds)`` 返回::

    {
        "serial_cost":   float,
        "parallel_cost": float,
        "expected_gain": float,
        "verdict":       "split" | "merge",
        "reason":        str,
    }

只依赖标准库，可离线单测。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

__all__ = [
    "DEFAULT_THRESHOLDS",
    "DEFAULT_PRICES",
    "SplitThresholds",
    "SplitPrices",
    "split_decision",
    "replay",
]


# ---------------------------------------------------------------------------
# 默认阈值 / 价格（可配置）
# ---------------------------------------------------------------------------

DEFAULT_THRESHOLDS: dict[str, float] = {
    # parallel_cost > serial_cost * cost_ratio 且 expected_gain < gain_floor 时降级
    "cost_ratio": 1.5,
    "gain_floor": 1.3,
    # 单 agent 上下文重复成本系数（相对 Σ seg.est_tokens）
    "context_repeat_factor": 0.15,
    # handoff / 审核开销：每个额外段落的固定 token 开销
    "handoff_tokens_per_segment": 200.0,
    # handoff / 审核开销折算系数（相对 member_price）
    "handoff_overhead_factor": 0.10,
    # orchestrator_tokens 缺省值（plan 未提供时）
    "default_orchestrator_tokens": 800.0,
    # 并行度上限（用于 expected_gain）
    "max_parallelism": 8.0,
    # 关键路径缩短比例上限
    "max_critical_path_reduction": 0.9,
}

DEFAULT_PRICES: dict[str, float] = {
    "lead_price": 1.0,
    "member_price": 0.6,
}


@dataclass(frozen=True)
class SplitThresholds:
    """可配置阈值集合。"""

    cost_ratio: float = 1.5
    gain_floor: float = 1.3
    context_repeat_factor: float = 0.15
    handoff_tokens_per_segment: float = 200.0
    handoff_overhead_factor: float = 0.10
    default_orchestrator_tokens: float = 800.0
    max_parallelism: float = 8.0
    max_critical_path_reduction: float = 0.9

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "SplitThresholds":
        base = dict(DEFAULT_THRESHOLDS)
        if data:
            for key, value in data.items():
                if key in base:
                    base[key] = float(value)
        return cls(**base)  # type: ignore[arg-type]

    def to_dict(self) -> dict[str, float]:
        return {
            "cost_ratio": self.cost_ratio,
            "gain_floor": self.gain_floor,
            "context_repeat_factor": self.context_repeat_factor,
            "handoff_tokens_per_segment": self.handoff_tokens_per_segment,
            "handoff_overhead_factor": self.handoff_overhead_factor,
            "default_orchestrator_tokens": self.default_orchestrator_tokens,
            "max_parallelism": self.max_parallelism,
            "max_critical_path_reduction": self.max_critical_path_reduction,
        }


@dataclass(frozen=True)
class SplitPrices:
    """token 单价（可配置）。"""

    lead_price: float = 1.0
    member_price: float = 0.6

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "SplitPrices":
        base = dict(DEFAULT_PRICES)
        if data:
            for key, value in data.items():
                if key in base:
                    base[key] = float(value)
        return cls(**base)  # type: ignore[arg-type]

    def to_dict(self) -> dict[str, float]:
        return {"lead_price": self.lead_price, "member_price": self.member_price}


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _iter_segments(plan: Any) -> list[Mapping[str, Any]]:
    """从 plan 中提取段落列表，兼容多种常见结构。"""
    if plan is None:
        return []
    if isinstance(plan, Mapping):
        for key in ("segments", "segs", "paragraphs", "sections", "plan"):
            if key in plan:
                inner = plan[key]
                if isinstance(inner, Mapping):
                    return _iter_segments(inner)
                if isinstance(inner, Sequence) and not isinstance(inner, (str, bytes)):
                    return [s for s in inner if isinstance(s, Mapping)]
        return []
    if isinstance(plan, Sequence) and not isinstance(plan, (str, bytes)):
        return [s for s in plan if isinstance(s, Mapping)]
    return []


def _seg_tokens(seg: Mapping[str, Any]) -> float:
    for key in ("est_tokens", "tokens", "estimated_tokens", "est_token"):
        if key in seg:
            return max(0.0, _as_float(seg[key]))
    return 0.0


def _seg_member_price(seg: Mapping[str, Any], prices: SplitPrices) -> float:
    for key in ("member_price", "price", "unit_price"):
        if key in seg:
            return max(0.0, _as_float(seg[key], prices.member_price))
    return prices.member_price


def _plan_orchestrator_tokens(plan: Any, thresholds: SplitThresholds) -> float:
    if isinstance(plan, Mapping):
        for key in ("orchestrator_tokens", "orchestrator_est_tokens", "lead_tokens"):
            if key in plan:
                return max(0.0, _as_float(plan[key], thresholds.default_orchestrator_tokens))
    return thresholds.default_orchestrator_tokens


def _plan_parallelism(plan: Any, seg_count: int, thresholds: SplitThresholds) -> float:
    if isinstance(plan, Mapping):
        for key in ("parallelism", "parallel_degree", "concurrency"):
            if key in plan:
                value = _as_float(plan[key], 0.0)
                if value > 0:
                    return min(value, thresholds.max_parallelism)
    if seg_count <= 1:
        return 1.0
    return min(float(seg_count), thresholds.max_parallelism)


def _plan_critical_path_reduction(plan: Any, seg_count: int, thresholds: SplitThresholds) -> float:
    if isinstance(plan, Mapping):
        for key in ("critical_path_reduction", "speedup_ratio", "path_reduction"):
            if key in plan:
                value = _as_float(plan[key], -1.0)
                if value >= 0:
                    return min(value, thresholds.max_critical_path_reduction)
    if seg_count <= 1:
        return 0.0
    # 默认：1 - 1/并行度，再受上限约束
    parallelism = _plan_parallelism(plan, seg_count, thresholds)
    if parallelism <= 1:
        return 0.0
    return min(1.0 - 1.0 / parallelism, thresholds.max_critical_path_reduction)


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------


def split_decision(
    plan: Any,
    prices: Mapping[str, Any] | SplitPrices | None = None,
    thresholds: Mapping[str, Any] | SplitThresholds | None = None,
) -> dict[str, Any]:
    """计算拆分 ROI 并给出 verdict。

    参数
    ----
    plan:
        谱稿/计划，可以是 dict（含 ``segments``）或段落 list。每个段落可含
        ``est_tokens``、``member_price`` 等字段。
    prices:
        ``{"lead_price": float, "member_price": float}`` 或 :class:`SplitPrices`。
    thresholds:
        阈值映射或 :class:`SplitThresholds`，可覆盖默认值。

    返回
    ----
    dict: ``serial_cost`` / ``parallel_cost`` / ``expected_gain`` / ``verdict`` / ``reason``
    """
    price_obj = prices if isinstance(prices, SplitPrices) else SplitPrices.from_mapping(prices)
    thr_obj = (
        thresholds
        if isinstance(thresholds, SplitThresholds)
        else SplitThresholds.from_mapping(thresholds)
    )

    segments = _iter_segments(plan)
    seg_count = len(segments)

    # --- serial_cost ---
    seg_tokens_total = sum(_seg_tokens(s) for s in segments)
    context_repeat_cost = seg_tokens_total * thr_obj.context_repeat_factor
    serial_cost = seg_tokens_total * price_obj.lead_price + context_repeat_cost

    # --- parallel_cost ---
    orchestrator_tokens = _plan_orchestrator_tokens(plan, thr_obj)
    orchestrator_cost = orchestrator_tokens * price_obj.lead_price

    member_cost = 0.0
    for seg in segments:
        member_cost += _seg_tokens(seg) * _seg_member_price(seg, price_obj)

    extra_segments = max(0, seg_count - 1)
    handoff_tokens = extra_segments * thr_obj.handoff_tokens_per_segment
    handoff_cost = handoff_tokens * price_obj.member_price * thr_obj.handoff_overhead_factor

    parallel_cost = orchestrator_cost + member_cost + handoff_cost

    # --- expected_gain ---
    parallelism = _plan_parallelism(plan, seg_count, thr_obj)
    path_reduction = _plan_critical_path_reduction(plan, seg_count, thr_obj)
    expected_gain = parallelism * path_reduction

    # --- verdict ---
    cost_exceeded = parallel_cost > serial_cost * thr_obj.cost_ratio
    gain_low = expected_gain < thr_obj.gain_floor

    if cost_exceeded and gain_low:
        verdict = "merge"
        reason = (
            f"parallel_cost={parallel_cost:.2f} > serial_cost×{thr_obj.cost_ratio}="
            f"{serial_cost * thr_obj.cost_ratio:.2f} 且 expected_gain={expected_gain:.2f} "
            f"< {thr_obj.gain_floor}，降级：合并段落 / 转为独奏"
        )
    elif cost_exceeded:
        verdict = "split"
        reason = (
            f"parallel_cost={parallel_cost:.2f} 超过 serial_cost×{thr_obj.cost_ratio}="
            f"{serial_cost * thr_obj.cost_ratio:.2f}，但 expected_gain={expected_gain:.2f} "
            f">= {thr_obj.gain_floor}，收益覆盖成本，保留拆分"
        )
    elif gain_low:
        verdict = "split"
        reason = (
            f"expected_gain={expected_gain:.2f} 低于 {thr_obj.gain_floor}，"
            f"但 parallel_cost={parallel_cost:.2f} 未超过 "
            f"serial_cost×{thr_obj.cost_ratio}={serial_cost * thr_obj.cost_ratio:.2f}，"
            f"成本可控，保留拆分"
        )
    else:
        verdict = "split"
        reason = (
            f"parallel_cost={parallel_cost:.2f} <= serial_cost×{thr_obj.cost_ratio}="
            f"{serial_cost * thr_obj.cost_ratio:.2f} 且 expected_gain={expected_gain:.2f} "
            f">= {thr_obj.gain_floor}，该拆"
        )

    return {
        "serial_cost": round(serial_cost, 4),
        "parallel_cost": round(parallel_cost, 4),
        "expected_gain": round(expected_gain, 4),
        "verdict": verdict,
        "reason": reason,
    }


def replay(
    plans: Iterable[Any],
    prices: Mapping[str, Any] | SplitPrices | None = None,
    thresholds: Mapping[str, Any] | SplitThresholds | None = None,
) -> list[dict[str, Any]]:
    """对多个历史需求回放，返回每条的决策结果（DoD：10 个历史需求回放）。"""
    results: list[dict[str, Any]] = []
    for idx, plan in enumerate(plans):
        decision = split_decision(plan, prices=prices, thresholds=thresholds)
        results.append({"index": idx, **decision})
    return results
