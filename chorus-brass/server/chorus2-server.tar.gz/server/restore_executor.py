#!/usr/bin/env python3
"""Run on the systemd host or Docker host, never inside the serving process.

One-shot: python restore_executor.py --data ... --mode systemd --target chorus.service
Docker: --mode docker --target container-name (DATA is the mounted volume path).
Use a host timer to poll. No Docker socket or service privileges enter the app.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request
import urllib.parse

from backup import (BackupError, STATE_ROOTS, digest, private_dir, read_json,
                    sync_dir, verify_stage, write_json, writer_lock)


class Service:
    def __init__(self, mode, target, health_url, data):
        self.mode, self.target, self.health_url = mode, target, health_url
        self.data = Path(data)
        url = urllib.parse.urlsplit(health_url)
        if (url.scheme not in ("http", "https") or url.hostname not in ("127.0.0.1", "::1", "localhost") or
                url.path != "/api/hello" or url.query or url.fragment or url.username or url.password):
            raise BackupError("健康检查必须使用本机 /api/hello 地址")
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        self.http = urllib.request.build_opener(NoRedirect)

    def command(self, verb):
        args = (["systemctl", verb, self.target] if self.mode == "systemd"
                else ["docker", verb, self.target])
        subprocess.run(args, check=True, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=120)

    def stop(self):
        self.command("stop")
        if self.mode == "systemd":
            status = subprocess.run(["systemctl", "show", "--property=ActiveState", "--value", self.target],
                                    check=True, capture_output=True, text=True, timeout=10).stdout.strip()
            if status not in ("inactive", "failed"):
                raise BackupError("服务没有完全停止")
        else:
            status = subprocess.run(["docker", "inspect", "--format", "{{.State.Running}}", self.target],
                                    check=True, capture_output=True, text=True, timeout=10).stdout.strip()
            if status != "false":
                raise BackupError("容器没有完全停止")

    def start(self):
        self.command("start")

    def healthy(self):
        for _ in range(30):
            try:
                with self.http.open(self.health_url, timeout=2) as response:
                    obj = json.load(response)
                    if response.status != 200 or obj.get("app") != "aichat":
                        continue
                # setup() persists any environment password override. Read only
                # after startup; never put this token on argv or in logs.
                cfg = read_json(self.data / "config.json")
                token = hashlib.sha256(cfg["password"].strip().encode()).hexdigest()[:32]
                url = self.health_url.rsplit("/api/hello", 1)[0] + "/api/index?v=-1"
                req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token})
                with self.http.open(req, timeout=2) as response:
                    view = json.load(response)
                    if response.status == 200 and isinstance(view.get("projects"), list):
                        return True
            except (OSError, ValueError, KeyError, TypeError):
                pass
            time.sleep(1)
        return False


def move_roots(data, stage, previous, journal):
    """Each rename is within the same mount, including a Docker volume.

    Journal and previous/ remain after success. If the host crashes mid-switch,
    the server startup guard refuses to start; rerun the executor to roll back.
    Recovery inspects path presence, covering crashes between rename and journal.
    """
    previous.mkdir(mode=0o700)
    original = [name for name in STATE_ROOTS if (data / name).exists()]
    if any((data / name).is_symlink() for name in STATE_ROOTS):
        raise BackupError("目标持久目录包含符号链接")
    write_json(journal, {"state": "switching", "original": original})
    for name in STATE_ROOTS:
        if name in original:
            (data / name).rename(previous / name)
            sync_dir(previous)
            sync_dir(data)
        if (stage / name).exists():
            (stage / name).rename(data / name)
            sync_dir(stage)
            sync_dir(data)
    write_json(journal, {"state": "switched", "original": original})


def rollback(data, previous, journal):
    saved = read_json(journal)
    if saved["state"] == "rolled-back":
        return
    for name in reversed(STATE_ROOTS):
        current, old = data / name, previous / name
        if old.exists():
            if current.is_dir():
                shutil.rmtree(current)
            elif current.exists() or current.is_symlink():
                current.unlink()
            old.rename(current)
        elif name not in saved["original"]:
            if current.is_dir():
                shutil.rmtree(current)
            elif current.exists():
                current.unlink()
    sync_dir(data)
    write_json(journal, {**saved, "state": "rolled-back"})


def apply(data, plan_path, service):
    data = Path(data)
    root = private_dir(data / "backups")
    plan = read_json(plan_path)
    ident = plan["id"]
    from backup import ID
    if not isinstance(ident, str) or not ID.fullmatch(ident):
        raise BackupError("计划编号无效")
    stage, previous = root / ("stage-" + ident), root / ("pre-restore-" + ident)
    journal = root / ("journal-" + ident + ".json")
    guard = root / "restore-active.json"
    if plan["state"] not in ("queued", "applying", "rollback_failed"):
        raise BackupError("恢复计划未提交或已经执行")
    recovering = plan["state"] in ("applying", "rollback_failed")
    if not recovering:
        if plan["expires_at"] < time.time():
            plan["state"] = "expired"
            write_json(plan_path, plan)
            shutil.rmtree(stage, ignore_errors=True)
            raise BackupError("恢复计划已过期")
        archive = root / (plan["backup_id"] + ".chorus")
        if digest(archive) != plan["archive_sha256"]:
            raise BackupError("备份校验失败")
        verify_stage(stage, plan["manifest"])
    stopped = False
    try:
        # Persist a startup interlock before stopping; the serving process must
        # refuse setup() while this guard is in switching/recovering state.
        if guard.exists() and read_json(guard).get("id") != ident:
            raise BackupError("另一恢复任务持有启动锁")
        plan["state"] = "applying"
        write_json(plan_path, plan)
        write_json(guard, {"id": ident, "state": "switching"})
        service.stop()
        stopped = True
        with writer_lock(data):
            if recovering and journal.exists():
                rollback(data, previous, journal)
                plan.update(state="rolled_back", error="中断的恢复已回退")
            elif recovering:
                plan.update(state="failed", error="恢复在切换前中断，数据未改动")
            else:
                verify_stage(stage, plan["manifest"])
                move_roots(data, stage, previous, journal)
            # Allow the server to acquire its lifetime lock only after switch.
            write_json(guard, {"id": ident, "state": "checking"})
        service.start()
        if not service.healthy():
            raise BackupError("恢复后健康检查失败")
        plan["state"] = plan["state"] if recovering else "completed"
        write_json(plan_path, plan)
        guard.unlink(missing_ok=True)
        sync_dir(root)
    except Exception:
        if stopped:
            write_json(guard, {"id": ident, "state": "recovering"})
            service.stop()
            with writer_lock(data):
                if journal.exists():
                    rollback(data, previous, journal)
                    plan.update(state="rolled_back", error="恢复失败，已恢复原数据")
                else:
                    plan.update(state="failed", error="恢复失败，数据未切换")
                write_json(guard, {"id": ident, "state": "checking"})
            service.start()
            if not service.healthy():
                write_json(plan_path, {**plan, "state": "rollback_failed", "error": "原数据已回退，服务仍需检查"})
                # Keep the guard and journal so the outcome is not reported as success.
                raise BackupError("回退后服务未通过健康检查") from None
            write_json(plan_path, plan)
            guard.unlink(missing_ok=True)
        else:
            # Stop failure leaves the startup interlock in place for manual
            # recovery; no filesystem switch was attempted.
            write_json(plan_path, {**plan, "state": "applying", "error": "停止服务失败，数据未切换"})
        raise BackupError("恢复未完成，请查看恢复任务状态") from None
    finally:
        if plan.get("state") in ("completed", "rolled_back", "failed"):
            shutil.rmtree(stage, ignore_errors=True)
    return {"id": ident, "state": plan["state"]}


def startup_guard(data):
    path = Path(data) / "backups" / "restore-active.json"
    if path.exists() and read_json(path).get("state") != "checking":
        raise BackupError("恢复切换未完成，请运行进程外恢复执行器处理")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", required=True, type=Path)
    p.add_argument("--mode", required=True, choices=("systemd", "docker"))
    p.add_argument("--target", required=True)
    p.add_argument("--health-url", default="http://127.0.0.1:8790/api/hello")
    args = p.parse_args()
    root = private_dir(args.data / "backups")
    # Multiple host timers cannot apply the same one-shot plan concurrently.
    with (root / ".executor.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        plans = sorted(root.glob("plan-*.json"))
        for path in plans:
            if read_json(path)["state"] in ("queued", "applying", "rollback_failed"):
                result = apply(args.data, path, Service(args.mode, args.target, args.health_url, args.data))
                print(json.dumps(result))
                return


if __name__ == "__main__":
    try:
        main()
    except (BackupError, OSError, subprocess.SubprocessError):
        raise SystemExit("恢复执行失败；请查看备份目录中的任务状态，未输出任何凭据")
