"""Optional heavy add-ons, installed from 设置 → 插件. Nothing heavy is imported or downloaded until installed.

Each entry says what it costs (download size, RAM, money) and what the server needs. `fits()` checks the real host
(CPU cores, RAM, GPU, free disk) so a 2C/1G server is only offered what it can run: on-device Android TTS, online
voices, or paid cloud. Voice chat UI is shown only when a TTS engine and an ASR engine are installed (features()).
"""
from __future__ import annotations

import asyncio
import os
import shutil
import time

import api_errors as errors

CATALOG = [
    # ---- speech synthesis
    {"id": "tts_android", "kind": "tts", "title": "手机自带朗读（Android TTS）", "where": "device", "size_mb": 0, "ram_mb": 0,
     "cost": "免费", "license": "系统", "note": "在手机上合成，不占服务器；音质看手机厂商的语音包", "official": True},
    {"id": "tts_edge", "kind": "tts", "title": "Edge 在线神经语音（晓晓/云希…）", "where": "server", "size_mb": 1, "ram_mb": 30,
     "cost": "免费", "license": "非官方接口", "pip": ["edge-tts"], "official": False,
     "note": "调用微软 Edge 朗读的非公开接口，可能随时失效或限流"},
    {"id": "tts_melo", "kind": "tts", "title": "MeloTTS 中英（本地 CPU，sherpa-onnx）", "where": "server", "size_mb": 170, "ram_mb": 450,
     "cores": 2, "cost": "免费", "license": "MIT", "pip": ["sherpa-onnx", "soundfile"], "official": True,
     "model": "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-melo-tts-zh_en.tar.bz2"},
    {"id": "tts_kokoro", "kind": "tts", "title": "Kokoro 多语种 v1.1（本地 CPU，sherpa-onnx）", "where": "server", "size_mb": 360, "ram_mb": 900,
     "cores": 2, "cost": "免费", "license": "Apache-2.0", "pip": ["sherpa-onnx", "soundfile"], "official": True,
     "model": "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_1.tar.bz2"},
    {"id": "tts_cosyvoice", "kind": "tts", "title": "CosyVoice 2/3（本地 GPU，最像真人，流式约 150ms）", "where": "server", "size_mb": 6000,
     "ram_mb": 8000, "gpu_gb": 6, "cost": "免费", "license": "Apache-2.0", "official": True,
     "note": "需要 6GB 以上显存的 GPU；这里只做接入，不在小服务器上提供"},
    {"id": "tts_mimo", "kind": "tts", "title": "小米 MiMo-V2.5-TTS（云端，冰糖/茉莉/苏打/白桦…，可用语气指令）", "where": "cloud",
     "size_mb": 0, "ram_mb": 0, "cost": "Token Plan 内计 token（一句约 260 token）", "license": "商用", "provider": "mimo", "official": True},
    {"id": "tts_minimax", "kind": "tts", "title": "MiniMax 语音 speech-2.8-turbo（云端）", "where": "cloud", "size_mb": 0, "ram_mb": 0,
     "cost": "$60 / 百万字符", "license": "商用", "provider": "minimax", "official": True},
    {"id": "tts_openai", "kind": "tts", "title": "OpenAI 兼容 /audio/speech（gpt-4o-mini-tts 或中转）", "where": "cloud", "size_mb": 0,
     "ram_mb": 0, "cost": "约 $0.015 / 分钟（官方，2027-01-06 停用）", "license": "商用", "provider": "openai", "official": True},
    # ---- speech recognition
    {"id": "asr_android", "kind": "asr", "title": "手机自带语音识别", "where": "device", "size_mb": 0, "ram_mb": 0, "cost": "免费",
     "license": "系统", "official": True},
    {"id": "asr_sensevoice", "kind": "asr", "title": "SenseVoice 小模型（本地 CPU，中英粤日韩）", "where": "server", "size_mb": 230,
     "ram_mb": 700, "cores": 2, "cost": "免费", "license": "FunASR 模型协议", "pip": ["sherpa-onnx"], "official": True,
     "model": "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09.tar.bz2"},
    {"id": "asr_cloud", "kind": "asr", "title": "OpenAI 兼容 /audio/transcriptions（whisper / 中转 SenseVoice）", "where": "cloud",
     "size_mb": 0, "ram_mb": 0, "cost": "按接口计费", "license": "商用", "provider": "any", "official": True},
    # ---- other heavy add-ons
    {"id": "media_ffmpeg", "kind": "media", "title": "视频缩略图、音频波形、关键帧（ffmpeg）", "where": "server", "size_mb": 80, "ram_mb": 150,
     "cost": "免费", "license": "LGPL", "binary": "ffmpeg", "official": True},
    {"id": "web_reader", "kind": "web", "title": "网页正文提取（共享给不能上网的成员）", "where": "server", "size_mb": 5, "ram_mb": 40,
     "cost": "免费", "license": "MIT", "pip": ["readability-lxml"], "official": True},
]
BY_ID = {p["id"]: p for p in CATALOG}


def host() -> dict:
    """Real host resources: cores, total/free RAM, GPUs (nvidia-smi), free disk in the data dir."""
    cores = os.cpu_count() or 1
    mem = avail = 0
    try:
        with open("/proc/meminfo") as f:
            info = {ln.split(":")[0]: int(ln.split()[1]) for ln in f if ":" in ln}
        mem, avail = info.get("MemTotal", 0) // 1024, info.get("MemAvailable", 0) // 1024
    except OSError:
        pass
    gpu = 0.0
    if shutil.which("nvidia-smi"):
        try:
            import subprocess
            out = subprocess.run(["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout
            gpu = max((float(x) / 1024 for x in out.split()), default=0.0)
        except Exception:  # noqa: BLE001
            gpu = 0.0
    return {"cores": cores, "ram_mb": mem, "ram_free_mb": avail, "gpu_gb": round(gpu, 1)}


def fits(p: dict, h: dict, disk_free_mb: float) -> tuple[bool, str]:
    if p["where"] != "server":
        return True, ""
    if p.get("gpu_gb") and h["gpu_gb"] < p["gpu_gb"]:
        return False, f"需要 {p['gpu_gb']}GB 显存的 GPU"
    if p.get("cores") and h["cores"] < p["cores"]:
        return False, f"需要 {p['cores']} 核 CPU"
    # leave ~350 MB for the core server + OS on small boxes
    if p.get("ram_mb", 0) and h["ram_mb"] - 350 < p["ram_mb"]:
        return False, f"需要约 {p['ram_mb']}MB 内存，这台只有 {h['ram_mb']}MB"
    if p.get("size_mb", 0) * 2.2 > disk_free_mb:
        return False, f"磁盘不够（需要约 {int(p['size_mb'] * 2.2)}MB）"
    return True, ""


def disk_free_mb(path) -> float:
    import pathlib
    p = pathlib.Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free / 2**20


class Plugins:
    def __init__(self, S, runner=None, hostinfo=None):
        self.S, self.hostinfo = S, hostinfo or host
        self.runner = runner or self._run
        self.jobs: dict[str, asyncio.Task] = {}

    def state(self):
        return self.S.CFG.setdefault("plugins", {})

    def dir(self, pid):
        return self.S.DATA / "plugins" / pid

    def view(self):
        h = self.hostinfo()
        free = disk_free_mb(self.S.DATA)
        rows = []
        for p in CATALOG:
            ok, why = fits(p, h, free)
            st = self.state().get(p["id"], {})
            rows.append({**{k: v for k, v in p.items() if k not in ("pip", "model")}, "fits": ok, "why": why,
                         "state": st.get("state", "available"), "progress": st.get("progress", 0),
                         **(errors.payload(st["error"], st["fix"]) if st.get("error") and st.get("fix") in errors.FIXES
                            else errors.upstream(st["error"]) if st.get("error") else errors.payload(""))})
        return {"host": h, "disk_free_mb": int(free), "plugins": rows, "features": self.features()}

    def installed(self, kind=None):
        return [i for i, st in self.state().items() if st.get("state") == "installed" and (not kind or BY_ID.get(i, {}).get("kind") == kind)]

    def features(self):
        return {"voice": bool(self.installed("tts")) and bool(self.installed("asr")), "tts": self.installed("tts"),
                "asr": self.installed("asr"), "media": "media_ffmpeg" in self.installed() or bool(shutil.which("ffmpeg"))}

    def install(self, pid):
        p = BY_ID.get(pid)
        if not p:
            raise KeyError(pid)
        ok, why = fits(p, self.hostinfo(), disk_free_mb(self.S.DATA))
        if not ok:
            raise ValueError(why)
        if pid in self.jobs and not self.jobs[pid].done():
            return self.state()[pid]
        if p["where"] == "cloud" and not self.S.provider(p.get("provider") or "") and p.get("provider") != "any":
            raise ValueError("请先在 设置 → 接口 里添加这个服务的密钥")
        st = self.state()[pid] = {"state": "installing", "progress": 0, "at": time.time()}
        self.S.save_cfg()
        self.jobs[pid] = asyncio.ensure_future(self._install(p, st))
        return st

    async def _install(self, p, st):
        try:
            steps = []
            if p.get("pip"):
                steps.append(["pip", *p["pip"]])
            if p.get("model"):
                steps.append(["model", p["model"]])
            if p.get("binary"):
                steps.append(["binary", p["binary"]])
            for n, step in enumerate(steps):
                await self.runner(step, self.dir(p["id"]))
                st["progress"] = round(100 * (n + 1) / len(steps))
            st.update(state="installed", progress=100, error="", fix="none")
        except Exception as e:  # noqa: BLE001 - a failed install is reported, never crashes the server
            st.update(state="failed", **errors.upstream(e))
        finally:
            self.S.save_cfg()
            self.S.bump()

    async def _run(self, step, dest):
        import sys
        dest.mkdir(parents=True, exist_ok=True)
        if step[0] == "pip":
            cmd = [sys.executable, "-m", "pip", "install", "-q", *step[1:]]
        elif step[0] == "model":
            arc = dest / step[1].rsplit("/", 1)[-1]
            cmd = ["sh", "-c", f'curl -fsSL -o "{arc}" "{step[1]}" && tar xjf "{arc}" -C "{dest}" && rm -f "{arc}"']
        else:
            if shutil.which(step[1]):
                return
            raise RuntimeError(f"请让管理员安装 {step[1]}（apt install {step[1]}）")
        p = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        _, err = await p.communicate()
        if p.returncode:
            raise RuntimeError(err.decode(errors="replace")[-200:] or f"{step[0]} 失败")

    def uninstall(self, pid):
        if pid not in BY_ID:
            raise KeyError(pid)
        t = self.jobs.pop(pid, None)
        if t and not t.done():
            t.cancel()
        shutil.rmtree(self.dir(pid), ignore_errors=True)   # pip packages stay (shared); model files are removed
        self.state().pop(pid, None)
        self.S.save_cfg()
        self.S.bump()
