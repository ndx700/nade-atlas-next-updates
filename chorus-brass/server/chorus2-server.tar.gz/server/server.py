#!/usr/bin/env python3
"""AI 协作 server: projects, group and private chats with AI members, live replies, files, web videos, quotas, skills.

One process, one data folder (DATA, default ./data):
  config.json      password, providers (API keys), members, settings. Edited from the app or by hand.
  projects.json    the project list.
  chats/<pid>.jsonl one finished message per line (edits and recalls rewrite the file).
  files/           uploads and fetched videos, served at /files/<name> with Range.
  skills/<name>/   installed skills (SKILL.md and whatever came with it).

The app talks to /api/* with "Authorization: Bearer <token>" (or ?t=<token>), token = sha256(password)[:32].
Reads long-poll: the server answers as soon as something changed after the version the app already has, or after
25 s with 304. Members are OpenAI-compatible / Anthropic APIs, or any CLI (prompt on stdin, reply on stdout).
"""
import asyncio
import datetime
import errno
import hashlib
import io
import math
import json
import os
import pathlib
import re
import secrets
import signal
import subprocess
import shlex
import shutil
import sys
import time
import zipfile
import tempfile

import backup
import workspace_tools
import api_workspace
import dm_index
import api_errors as errors
from restore_executor import startup_guard

import context
import importers
import task_cards
import member_avatars
import chorus2
import orchestra
import redline

from aiohttp import ClientConnectionError, ClientSession, ClientTimeout, WSMsgType, web

DATA = pathlib.Path(os.environ.get("AICHAT_DATA", "data")).resolve()
PORT = int(os.environ.get("AICHAT_PORT", "8791"))  # chorus2: never collide with the legacy 8790 instance
POLL = 25
WEB_APP = pathlib.Path(__file__).resolve().parent.parent / "tools" / "aichat" / "web" / "app.html"

# ---------------------------------------------------------------- storage


def load(p, default):
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return default


def save(p, o):
    backup.write_json(p, o)


DEFAULT_CONFIG = {
    "password": "",
    "name": "AI 协作",
    "tz": 8,
    "max_upload_mb": 2048,
    "context_messages": 40,
    "design_autopick_s": 20,
    "providers": [],
    "members": [],
}

CFG = {}
PROJECTS = []
CHATS = {}  # pid -> list of message dicts
STATUS = {}  # member name -> {"state", "what", "since", "pid", "note", "queue"}
QUOTA = {}  # member name -> quota dict for the app
QUOTA_AT = ""
APP_SEEN = {}
JOBS = {}  # job id -> dict
EPOCH = secrets.token_hex(16)  # identifies this process, independent of version counters
VER = 0
CHANGED = asyncio.Event()
PVER = {}  # pid -> last version that touched it
DIRTY = set()  # pids with live text not yet announced


def cfg_path():
    return DATA / "config.json"


def save_cfg():
    save(cfg_path(), CFG)


def token():
    return hashlib.sha256(CFG["password"].strip().encode()).hexdigest()[:32]


def now_at():
    t = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=CFG.get("tz", 8))))
    return t.strftime("%m-%d %H:%M")


def bump(pid=None):
    """Something changed: wake every waiting poll."""
    global VER, CHANGED
    VER += 1
    if pid:
        PVER[pid] = VER
    else:
        for p in PROJECTS:
            PVER[p["id"]] = VER
    ev, CHANGED = CHANGED, asyncio.Event()
    ev.set()
    return VER


def chat_file(pid):
    return DATA / "chats" / f"{pid}.jsonl"


def load_chat(pid):
    out = []
    try:
        for line in chat_file(pid).read_text().splitlines():
            if line.strip():
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    except OSError:
        pass
    for m in out:
        m["rev"] = 0
    return out


def persist(pid, m=None):
    """Append one finished message, or (m None) rewrite the whole chat."""
    f = chat_file(pid)
    keep = lambda x: {k: v for k, v in x.items() if k not in ("rev", "live", "note")}
    tmp = f.with_suffix(".tmp")
    try:
        with tmp.open("w") as fh:
            if m is not None:
                # Preserve append order while publishing the new file atomically.
                if f.exists():
                    with f.open() as old:
                        shutil.copyfileobj(old, fh)
                fh.write(json.dumps(keep(m), ensure_ascii=False) + "\n")
            else:
                for x in CHATS[pid]:
                    if not x.get("live"):
                        fh.write(json.dumps(keep(x), ensure_ascii=False) + "\n")
        tmp.replace(f)
    finally:
        tmp.unlink(missing_ok=True)


def add_msg(pid, who, text, dm="", live=False, **extra):
    msgs = CHATS.setdefault(pid, [])
    m = {"seq": (msgs[-1]["seq"] + 1) if msgs else 1, "who": who, "at": now_at(), "text": text, "dm": dm, "ts": time.time(), **extra}
    if live:
        m["live"] = True
        m["note"] = ""
    msgs.append(m)
    if not live:
        try:
            persist(pid, m)
        except OSError:
            msgs.remove(m)
            raise
    m["rev"] = bump(pid)
    return m


# 同意卡片 (Ali 10-26: 她让我选择同意安装的弹窗我看不到): a CLI member's permission request becomes a card in the chat;
# the CLI waits until Ali taps 同意 or 拒绝 (or ten minutes pass, which counts as 拒绝).
APPROVE_KEY = secrets.token_hex(16)
APPROVALS = {}  # id -> {"pid", "msg", "future"}


def approval_summary(tool, inp):
    if not isinstance(inp, dict):
        return str(inp)[:400]
    for k in ("command", "file_path", "url", "pattern", "path", "query"):
        if inp.get(k):
            return str(inp[k])[:400]
    return json.dumps(inp, ensure_ascii=False)[:400]


WEB_TOOLS = {"WebFetch", "WebSearch"}


def approve_all_for(who):
    """完全同意 per member (Ali 10-26: 每个 AI 身上加个开关，只同意小克): a member's own approve_all wins over the server-wide one."""
    m = member(who) if who else None
    return bool(m["approve_all"] if m and "approve_all" in m else CFG.get("approve_all"))


def auto_allowed(tool, inp, who=None):
    """完全同意: everything. 完全访问: reading any website (the web tools, or a plain curl / wget with nothing chained)."""
    if approve_all_for(who):
        return True
    if not CFG.get("full_access"):
        return False
    if tool in WEB_TOOLS:
        return True
    cmd = str((inp or {}).get("command", "")).strip() if tool == "Bash" else ""
    return read_only_fetch(cmd)


# 完全访问 only covers reading a public page to stdout. Anything else (writing files, uploading, local addresses,
# unknown flags) falls back to asking, so the lists below can stay strict.
FETCH_FLAGS = {
    "curl": ({"-s", "-S", "-L", "-I", "-i", "-f", "--silent", "--show-error", "--location", "--head", "--include",
              "--fail", "--compressed"},
             {"-H", "-A", "-m", "-e", "--header", "--user-agent", "--max-time", "--connect-timeout", "--referer",
              "--retry", "--max-redirs"}, "sSLIif"),
    "wget": ({"-q", "-S", "--quiet", "--server-response", "--spider", "-nv", "--no-verbose"},
             {"-T", "-U", "-t", "--timeout", "--user-agent", "--header", "--tries", "--max-redirect"}, "qS"),
}


def public_url(u):
    import ipaddress
    import urllib.parse
    if "://" not in u:
        u = "http://" + u
    try:
        r = urllib.parse.urlsplit(u)
        host = (r.hostname or "").rstrip(".").lower()
    except ValueError:
        return False
    if r.scheme not in ("http", "https") or not host or host == "localhost" or host.endswith(".localhost"):
        return False
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:  # a name, unless it is a number in disguise (2130706433, 0x7f.1, 0177.0.0.1)
        return not re.fullmatch(r"[0-9a-fx.]+", host) or not re.search(r"[0-9]", host)
    return ip.is_global


def read_only_fetch(cmd):
    """A plain curl / wget that only prints public pages: no chaining, no expansion, no output files, no uploads."""
    if re.search(r"[;&|`$<>(){}*!~\\]|\n", cmd):
        return False
    try:
        args = shlex.split(cmd)
    except ValueError:
        return False
    if not args or args[0] not in FETCH_FLAGS:
        return False
    flags, valued, short = FETCH_FLAGS[args[0]]
    urls, out_ok, i = [], args[0] == "curl", 1
    while i < len(args):
        a = args[i]
        if args[0] == "wget" and a in ("-O", "-qO", "--output-document") and i + 1 < len(args) and args[i + 1] == "-":
            out_ok, i = True, i + 2
            continue
        if args[0] == "wget" and a in ("-O-", "-qO-", "--output-document=-"):
            out_ok = True
        elif args[0] == "wget" and a == "--spider":
            out_ok = True
        elif a in flags:
            pass
        elif a in valued:
            i += 1
            if i >= len(args):
                return False
        elif a.startswith("--") and "=" in a and a.split("=", 1)[0] in valued:
            pass
        elif a.startswith("-") and not a.startswith("--") and len(a) > 1 and all(c in short for c in a[1:]):
            pass
        elif a.startswith("-"):
            return False
        else:
            urls.append(a)
        i += 1
    return out_ok and bool(urls) and all(public_url(u) for u in urls)


async def h_approve_ask(request):
    if request.remote not in ("127.0.0.1", "::1") or not secrets.compare_digest(request.headers.get("X-Key", ""), APPROVE_KEY):
        raise errors.http_error(web.HTTPForbidden, fix="settings")
    b = await errors.json_object(request)
    pid, who, tool, inp = b.get("pid", ""), b.get("who", "AI"), b.get("tool", ""), b.get("input") or {}
    if pid not in CHATS:
        return web.json_response({"allow": False, "why": "没有对应的聊天"})
    action, verdict = chorus2.gate(tool, inp, who, pid)
    if action == "deny":
        chorus2.log(pid, who, f"已拦下：{verdict.why}")
        return web.json_response({"allow": False, "why": verdict.why or "这一步不允许"})
    if action == "allow":
        # chorus2 autonomy: everything off the red line runs without asking (SPEC 红线与自治);
        # a red line reaches here only when the member's own policy says 自动同意 (logged in 场记).
        return web.json_response({"allow": True, "why": ""})
    # action == "ask": one consent card for this one action; approve_all can never skip it.
    aid = secrets.token_hex(6)
    consent = redline.card(tool, inp, verdict)
    m = add_msg(pid, who, f"请求同意：{consent.get('title') or tool}", b.get("dm", ""),
                approval={"id": aid, "tool": tool, "summary": redline.scrub(approval_summary(tool, inp)), "state": "pending",
                          "line": verdict.line, "why": consent.get("why", ""), "impact": consent.get("impact", ""), "cost": consent.get("cost", ""),
                          "deadline": time.time() + CFG.get("consent_timeout", 600), "who": who})
    fut = asyncio.get_running_loop().create_future()
    APPROVALS[aid] = {"pid": pid, "msg": m, "future": fut, "who": who, "line": verdict.line}
    try:
        allow = await asyncio.wait_for(fut, CFG.get("consent_timeout", 600))
    except asyncio.TimeoutError:
        allow = False
        m["approval"]["state"] = "timeout"; m["rev"] = bump(pid); persist(pid)
    finally:
        APPROVALS.pop(aid, None)
    return web.json_response({"allow": bool(allow), "why": "" if allow else f"{owner()} 没有同意"})


async def h_approve(request):
    a = APPROVALS.get(request.match_info["id"])
    if not a:
        raise errors.http_error(web.HTTPGone, "这个请求已经结束了", fix="retry")
    if request.method == "GET":
        return web.json_response(a["msg"]["approval"])
    b = await errors.json_object(request)
    allow = bool(b.get("allow"))
    if allow and b.get("scope") == "project" and a.get("line") and a["line"] != "illegal":
        chorus2.grant(a["pid"], a["who"], a["line"])  # 这个乐章里这位成员的这一类以后都同意
    m = a["msg"]
    m["approval"]["state"] = "allow" if allow else "deny"
    m["rev"] = bump(a["pid"]); persist(a["pid"])
    if not a["future"].done():
        a["future"].set_result(allow)
    return web.json_response({"ok": True})


# 进度卡片 (Ali 10-25): a member doing several steps writes a checklist block; the app shows it as a card.
TODO_BLOCK = re.compile(r"\[进度\](.*?)(?:\[/进度\]|$)", re.S)


def todo_of(text):
    """The last checklist in a reply: [{"t": step, "s": done|doing|todo}]."""
    blocks = TODO_BLOCK.findall(text or "")
    if not blocks:
        return []
    out = []
    for ln in blocks[-1].splitlines():
        ln = ln.strip()
        if ln[:1] in ("✓", "✔", "✅", "✱", "*", "○", "◯", "-") and len(ln) > 1:
            st = "done" if ln[0] in "✓✔✅" else "doing" if ln[0] in "✱*" else "todo"
            out.append({"t": ln[1:].strip(" ：:"), "s": st})
    return out[:12]


def strip_todo(text):
    return TODO_BLOCK.sub("", text or "").strip()


def finish_msg(pid, m):
    m.pop("live", None)
    m.pop("note", None)
    m["rev"] = bump(pid)
    if m.get("text", "").strip():
        persist(pid, m)
    else:
        m["gone"] = True


def project(pid):
    return next((p for p in PROJECTS if p["id"] == pid), None)


def member(name):
    return next((m for m in CFG["members"] if m["name"] == name), None)


def cards():
    return task_cards.TaskCards(sys.modules[__name__])


def provider(pid):
    return next((p for p in CFG["providers"] if p["id"] == pid), None)


# ---------------------------------------------------------------- views for the app


NOT_CHAT = re.compile(r"embed|rerank|seedream|seedance|tts|asr|whisper|dall-e|image|video|moderation|audio|speech", re.I)


def member_view(m):
    # Every model it can switch to (Ali 10-25: 有能换的模型都要可以换): its own list, then whatever its provider offers.
    models = [x if isinstance(x, list) else [x, x] for x in m.get("models") or []]
    if m.get("kind", "api") == "api":
        pr = provider(m.get("provider")) or {}
        have = {x[0] for x in models}
        models += [x for x in (x if isinstance(x, list) else [x, x] for x in pr.get("models") or []) if x[0] not in have and not NOT_CHAT.search(x[0])]
    if m.get("model") and not any(x[0] == m["model"] for x in models):
        models.insert(0, [m["model"], m["model"]])
    efforts = m.get("efforts")
    if efforts is None:
        efforts = [["low", "低"], ["medium", "中"], ["high", "高"]]
    return {
        "name": m["name"], "model": m.get("model", ""), "auto": m.get("auto", True), "kind": m.get("kind", "api"),
        "priority": m.get("priority", "normal"),
        "pricing_warning": pricing_warning(m, m.get("model", "")),
        "price": price(m, m.get("model", "")), "wallet": (provider(m.get("provider")) or {}).get("wallet"),
        **member_avatars.view(DATA, m), "effort": m.get("effort", ""), "role": m.get("role", ""),
        "owns": m.get("owns", []), "avoid": m.get("avoid", []), "style": m.get("style", ""),
        "options": {"models": models, "efforts": efforts},
    }


def status_view(names, pid=None):
    import connect
    out = {}
    for name in names:
        if reason := connect.remote_status(name):
            out[name] = {"state": "resting", "label": "离席", "what": reason, "reason": reason, "queue": QUEUED.get(name, 0), "tasks": []}
            continue
        recent = TASK_STATUS.get(name, {})
        for tid in list(recent):
            if recent[tid]["outcome"] != "running" and time.time() - recent[tid].get("todo_end", 0) >= 8:
                del recent[tid]
        tasks = {tid: st for tid, st in recent.items() if pid is None or st.get("pid") == pid}
        active = [st for st in tasks.values() if st["outcome"] == "running"]
        visible = active or list(tasks.values())[-1:]
        state = visible[-1] if visible else STATUS.get(name, {})
        if not state or pid is not None and state.get("pid") != pid:
            continue
        working = bool(active) if recent else state.get("state") == "working"
        o = {"state": "working" if working else "idle", "what": state.get("what", ""), "queue": QUEUED.get(name, 0),
             "task_id": state.get("task_id", ""), "outcome": state.get("outcome", "unknown")}
        def progress(st):
            return {"seconds": max(0, int(time.time() - st.get("since", time.time()))), "asked": st.get("asked", ""), "note": st.get("note", "")}
        if working:
            o["progress"] = progress(state)
        if state.get("todo") and (working or time.time() - state.get("todo_end", 0) < 8):
            o.update(todo=state["todo"], todo_pid=state.get("todo_pid", ""))
        o["tasks"] = [{"task_id": tid, "outcome": st["outcome"], "pid": st["pid"], "progress": progress(st),
                        "todo": st.get("todo", []), "todo_pid": st.get("todo_pid", ""), "error_code": st.get("error_code", "")} for tid, st in tasks.items()]
        out[name] = o
    return out


def msg_view(m):
    o = {k: v for k, v in m.items() if k not in ("rev", "request_hash", "client_ops")}
    if "[进度]" in o.get("text", ""):
        o["text"] = strip_todo(o["text"])
    return o


def index_view():
    ps = []
    for p in PROJECTS:
        if p.get("archived"):
            continue
        msgs = [m for m in CHATS.get(p["id"], []) if not m.get("gone") and not m.get("recalled") and not m.get("dm")]
        last = msgs[-1] if msgs else None
        ai = [m for m in msgs if m["who"] not in ("Ali", "系统") and not m.get("live")]
        last_ai = ai[-1]["seq"] if ai else 0
        working = [n for n in p["members"] if any(st["outcome"] == "running" and st.get("pid") == p["id"] for st in TASK_STATUS.get(n, {}).values())]
        ps.append({
            "id": p["id"], "name": p["name"], "brief": p.get("brief", ""), "file": p["id"], "members": p["members"],
            "last_ai_seq": last_ai, "ai_count": len(ai), "pinned": bool(p.get("pinned")), "muted": bool(p.get("muted")),
            "read_at": p.get("read_at", 0), "manual_unread": bool(p.get("manual_unread")), "working": working, "last": {"seq": last["seq"], "who": last["who"], "text": last["text"][:200], "at": last["at"]} if last else None,
        })
    import connect
    quotas = connect.quota_view(QUOTA, (m["name"] for m in CFG.get("members", [])))
    return {"epoch": EPOCH, "v": VER, "name": CFG.get("name", ""), "owner": owner(), "projects": ps, "features": PLUGINS.features(), "results": RESULTS[-256:], "quota": quotas, "quota_at": QUOTA_AT}


def chat_view(pid, since):
    import connect
    p = project(pid)
    msgs = CHATS.get(pid, [])
    full = since <= 0
    changed = [msg_view(m) for m in msgs if full or m["rev"] > since]
    if full:
        changed = [m for m in changed if not m.get("gone")]
    jobs = [j for j in JOBS.values() if j["project"] == pid and (j["state"] != "done" or time.time() - j["t"] < 120)]
    names = p["members"] if p else []
    return {
        "epoch": EPOCH, "v": PVER.get(pid, VER), "full": full, "updated": now_at(), "owner": owner(), "messages": changed,
        "members": [member_view(m) for n in names if (m := member(n))],
        "status": status_view(names, pid), "quota": connect.quota_view({n: QUOTA[n] for n in names if n in QUOTA}, names),
        "jobs": [{k: v for k, v in j.items() if k not in ("t", "proc", "error")}
                 | (errors.upstream(j["error"]) if j.get("error") else errors.payload("")) for j in jobs],
        "project": {"id": pid, "name": p["name"], "brief": p.get("brief", ""), "lead": p.get("lead", "")} if p else None,
    }


# ---------------------------------------------------------------- auth and polls


@web.middleware
async def auth(request, handler):
    path = request.path
    public = path in ("/", "/api/hello", "/api/invite/redeem") or path.startswith("/api/connect/pub/") or path.startswith("/files/") and not CFG.get("private_files", True)
    if not public and (path.startswith("/api/") or path.startswith("/files/")):
        t = request.headers.get("Authorization", "").removeprefix("Bearer ").strip() or request.query.get("t", "")
        try:
            authenticated = bool(CFG.get("password")) and secrets.compare_digest(t.encode(), token().encode())
        except UnicodeEncodeError:
            authenticated = False
        if not authenticated:
            return errors.response("密码不对或登录已失效，请重新登录", "relogin", status=401, hint="用 app 配对得到的 token")
        b = request.headers.get("X-Chorus-Build", "")
        if b.isdigit() and int(b) != APP_SEEN.get("build"):
            APP_SEEN.update(build=int(b), at=now_at())  # which build the phones run (shown by the quota workflow)
            print("app build", b)
    try:
        return await handler(request)
    except web.HTTPException as exc:
        return errors.from_http(exc)
    except (ValueError, TypeError, KeyError):
        return errors.response("请求内容不对，请检查填写的内容后重试", "none", status=400)
    except Exception as exc:  # noqa: BLE001 - classify without echoing exception text or credentials
        return web.json_response(errors.upstream(exc, fallback=errors.payload("服务器暂时没能完成，请稍后重试", "retry")), status=500)


async def wait_change(seen, get):
    """Return once get() is newer than seen, or None after POLL seconds."""
    end = time.monotonic() + POLL
    while get() <= seen:
        left = end - time.monotonic()
        if left <= 0:
            return False
        try:
            await asyncio.wait_for(CHANGED.wait(), left)
        except asyncio.TimeoutError:
            return False
    return True


async def h_hello(request):
    return web.json_response({"app": "aichat", "name": CFG.get("name", ""), "version": 1})


async def h_index(request):
    v = int(request.query.get("v", "0") or 0)
    if request.query.get("epoch", EPOCH) == EPOCH and v >= 0 and not await wait_change(v, lambda: VER):
        return web.Response(status=304)
    return web.json_response(index_view())


async def h_dms(request):
    return await dm_index.handle(request, sys.modules[__name__])


async def h_boot(request):
    """Immediate, local-only cold-start snapshot; `seen` has the /api/dms format.

    Cache with epoch/v and ETag. The content hash also detects changes to views
    that do not bump VER (settings, cached quotas, installed skills, avatars).
    """
    seen = dm_index.read_cursors(request.query.get("seen", "{}"))
    snapshot = {
        "epoch": EPOCH, "v": VER, "index": index_view(),
        "dms": dm_index.cards(sys.modules[__name__], seen),
        "read_state_supplied": "seen" in request.query,
        "config": config_view(), "members": [member_view(m) for m in CFG["members"]],
        "features": PLUGINS.features(),
        "quota": {"members": chorus2.QUOTA2, "quota": QUOTA, "quota_at": QUOTA_AT},
    }
    body = json.dumps(snapshot, ensure_ascii=False, sort_keys=True).encode()
    etag = '"' + hashlib.sha256(body).hexdigest() + '"'
    headers = {"ETag": etag, "Cache-Control": "private, no-cache", "Vary": "Authorization"}
    matches = [tag.strip().removeprefix("W/") for tag in request.headers.get("If-None-Match", "").split(",")]
    if etag in matches or "*" in matches:
        return web.Response(status=304, headers=headers)
    return web.Response(body=body, content_type="application/json", headers=headers)


def chat_cursor(request, key):
    try:
        value = int(request.query.get(key, "0") or 0)
        if value < 0:
            raise ValueError
        return value
    except ValueError:
        raise errors.http_error(web.HTTPBadRequest, "消息进度必须是非负整数，请刷新后重试", "retry") from None


async def h_chat(request):
    pid = request.match_info["pid"]
    if not project(pid):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    v = chat_cursor(request, "v")
    if "since" in request.query:
        # A sequence cursor is an immediate append delta. Also send `v` to merge
        # edits/recalls of older messages; keep using v alone for legacy polling.
        since = chat_cursor(request, "since")
        seq = max((m["seq"] for m in CHATS.get(pid, [])), default=0)
        reset = since == 0 or since > seq or v > VER or request.query.get("epoch", EPOCH) != EPOCH
        result = chat_view(pid, 0 if reset else v or VER or 1)
        if not reset:
            result["messages"] = [msg_view(m) for m in CHATS.get(pid, [])
                                  if m["seq"] > since or "v" in request.query and m.get("rev", 0) > v]
        result["seq"] = seq
        return web.json_response(result)
    if request.query.get("epoch", EPOCH) != EPOCH:
        v = 0
    if v > 0 and not await wait_change(v, lambda: PVER.get(pid, 0)):
        return web.Response(status=304)
    return web.json_response(chat_view(pid, v))


async def h_quota_refresh(request):
    """额度详情的「刷新」: read every quota now; the phones get it through the index poll (refresh_quota bumps VER)."""
    await refresh_quota()
    return web.json_response({"quota_at": QUOTA_AT})


async def h_older(request):
    """Messages before a seq (the app loads the newest 400 first)."""
    pid = request.match_info["pid"]
    before = int(request.query.get("before", "0"))
    msgs = [msg_view(m) for m in CHATS.get(pid, []) if m["seq"] < before and not m.get("gone")]
    return web.json_response({"messages": msgs[-400:]})


# ---------------------------------------------------------------- sending, dispatch


MENTION = re.compile(r"@([^\s@，。,.!?！？:：]+)")


def targets(p, text, dm):
    if dm:
        return [dm] if dm in p["members"] or member(dm) else []
    found = MENTION.findall(text)
    if any(x in ("全体", "所有人", "all", "everyone") for x in found):
        return [n for n in p["members"] if (member(n) or {}).get("auto", True)]
    out = []
    for f in found:
        # "@龙娘你看下" has no space: take the longest member name the mention starts with.
        hit = max((n for n in p["members"] if f.startswith(n)), key=len, default=None)
        if hit and hit not in out:
            out.append(hit)
    return out


def default_reply(p):
    """A message with no @ still gets an answer: the lead, else the project's default member, else the only member,
    else the first auto member. Only members that still exist on this server count."""
    names = [n for n in p.get("members", []) if member(n)]
    for n in (p.get("lead"), p.get("default")):
        if n and n in names:
            return [n]
    if len(names) == 1:
        return names
    auto = [n for n in names if (member(n) or {}).get("auto", True)]
    return auto[:1]


LOCKS = {}
TASKS = {}
QUEUED = {}
TASK_STATUS = {}  # member -> task ID -> independent running/terminal state


async def h_say(request):
    b = await errors.json_object(request)
    pid = b.get("project", "")
    p = project(pid)
    if not p:
        raise errors.http_error(web.HTTPNotFound, "没有这个项目", fix="retry")
    client_id = send_client_id(b)
    if (b.get("text") is not None and not isinstance(b["text"], str)
            or b.get("to") is not None and not isinstance(b["to"], str)
            or b.get("files") is not None and (not isinstance(b["files"], list)
                or any(not isinstance(f, dict) or any(not isinstance(f.get(k, ""), str) for k in ("name", "url")) for f in b["files"]))):
        raise errors.http_error(web.HTTPBadRequest, "消息文字、收件人或附件不对，请检查后重新发送", "none")
    text = (b.get("text") or "").strip()
    for f in b.get("files") or []:
        text += f"\n📎 [{f.get('name', 'file')}]({f.get('url', '')})"
    dm = b.get("to") or ""
    extra = {}
    if b.get("reply_to"):
        extra["reply_to"] = int(b["reply_to"])
    if b.get("priority") == "now":
        extra["priority"] = "now"
    opts = {"model": b.get("model") or "", "effort": b.get("effort") or "", "priority": b.get("priority") or "queue"}
    # Persist the original request identity: editing/recalling the message must not
    # change which send is acknowledged when a client retries after a lost reply.
    payload = {"text": text.strip(), "to": dm, "reply_to": extra.get("reply_to"), **opts,
               "files": [{"name": f.get("name", "file"), "url": f.get("url", "")} for f in b.get("files") or []]}
    request_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    # No await between lookup and persist: atomic within the single server event loop.
    if client_id:
        original = next((m for m in CHATS.get(pid, []) if m.get("client_id") == client_id and m["who"] == "Ali"), None)
        if original:
            if original.get("request_hash"):
                matches = secrets.compare_digest(original["request_hash"], request_hash)
            else:
                # Pre-upgrade messages did not retain model/effort or initial text.
                # Compare the fields available; never silently reuse an edited ID.
                matches = (not original.get("edited") and not original.get("recalled")
                           and original["text"] == text.strip() and original.get("dm", "") == dm
                           and original.get("reply_to") == extra.get("reply_to")
                           and original.get("priority", "queue") == opts["priority"])
            if not matches:
                return errors.response("这条发送编号已用于其他内容，请重新发送", "none", status=409, code="client_id_conflict", seq=original["seq"])
            return web.json_response(say_receipt(original))
    who = targets(p, text, dm)
    if not who and not dm:
        who = default_reply(p)
    who = [n for n in who if member(n)]  # explicit @ and private messages wake manual members; @all filters auto in targets()
    intent = bool(dm and CONCIERGE.claims(pid, dm, text))
    m = add_msg(pid, "Ali", text.strip(), dm, **extra,
                **({"accepted_intent": True} if intent else {}),
                **({"client_id": client_id, "accepted_to": [dm] if intent else who, "request_hash": request_hash} if client_id else {}))
    if intent:   # 「我想做 X」: clarify -> plan card, instead of a plain reply
        asyncio.ensure_future(CONCIERGE.on_user(pid, dm, text.strip()))
        return web.json_response(say_receipt(m, [dm]))
    asyncio.ensure_future(run_chain(pid, who, m, opts))
    return web.json_response(say_receipt(m, who))


def send_client_id(body):
    value = body.get("client_id", "")
    if not isinstance(value, str) or len(value) > 200:
        raise errors.http_error(web.HTTPBadRequest, "发送编号无效，请重新发送", "none")
    return value


def say_receipt(message, targets=None):
    return {"seq": message["seq"], "to": message.get("accepted_to", targets or []), "v": VER, "epoch": EPOCH,
            "message": msg_view(message), **({"intent": True} if message.get("accepted_intent") else {})}


async def run_chain(pid, names, trigger, opts):
    """One shared budget for the entire tree, including parallel branches."""
    opts = {**opts}
    opts.setdefault("root_id", trigger.get("client_id") or f"{pid}:{trigger.get('seq', 0)}")
    opts.setdefault("_budget", {"used": 0, "limit": _room_max_hops(pid), "notified": False, "t0": time.time()})
    await asyncio.gather(*(run_member(pid, n, trigger, opts) for n in names))


def publish_status(name):
    tasks = TASK_STATUS.get(name, {})
    active = [st for st in tasks.values() if st["outcome"] == "running"]
    visible = active or list(tasks.values())[-1:]
    if visible:
        STATUS[name] = {**visible[-1], "state": "working" if active else "idle", "queue": QUEUED.get(name, 0)}


def _room_max_hops(pid):
    """Per-room override first (config room_overrides.{pid}.max_hops), then global; an explicit 0 means no cap."""
    room = (CFG.get("room_overrides") or {}).get(pid) or {}
    if "max_hops" in room:
        return int(room["max_hops"] or 0)
    v = CFG.get("max_hops", HOPS)
    return int(HOPS if v is None else v)


ROOTS = {}  # root_id -> {"pid", "budget", "tasks": {task: name}, "started": {task: ts}}
STOPPED_ROOTS = {}  # root_id -> stop time; bounded, oldest dropped first
STOP_AT = {}  # pid -> time of a whole-room stop; rounds that began before it may not call again
STOP_KEEP = 200


def reserve_call(pid, opts):
    budget = opts.get("_budget")
    if budget is None:
        return True
    # Also catches the hand-off gap, when the next member is queued but not yet registered in ROOTS.
    rid, t0, stop_at = opts.get("root_id") or "", budget.get("t0"), STOP_AT.get(pid)
    if budget.get("stopped") or (rid and rid in STOPPED_ROOTS) or (t0 is not None and stop_at is not None and t0 <= stop_at):
        return False
    if budget["limit"] and budget["used"] >= budget["limit"]:
        if not budget["notified"]:
            budget["notified"] = True
            add_msg(pid, "系统", f"本轮已达到 {budget['limit']} 次 AI 调用上限，已停止自动交接。", root_id=opts.get("root_id", ""))
        return False
    budget["used"] += 1  # no await between check and reservation
    return True


async def run_member(pid, name, trigger, opts):
    lock = LOCKS.setdefault(name, asyncio.Lock())
    now = opts.get("priority") == "now"
    task = asyncio.current_task()
    TASKS.setdefault(name, set()).add(task)
    root = opts.get("root_id") or f"noid:{id(task)}"
    ent = ROOTS.setdefault(root, {"pid": pid, "budget": opts.get("_budget") or {}, "tasks": {}, "started": {}})
    ent["tasks"][task] = name
    acquired = False
    queued = False
    try:
        if not now:
            QUEUED[name] = QUEUED.get(name, 0) + 1
            queued = True
            STATUS.setdefault(name, {"state": "idle"})["queue"] = QUEUED[name]
            bump()
            await lock.acquire()
            acquired = True
            QUEUED[name] -= 1
            queued = False
        if not reserve_call(pid, opts):
            return
        ent["started"][task] = time.time()  # waiting for the lock does not count as stuck
        ent.setdefault("timeout_watch", {})[task] = {
            "since": time.monotonic(), "dm": trigger.get("dm", ""), "notified": False,
        }
        await answer(pid, name, trigger, opts)
    finally:
        TASKS[name].discard(task)
        ent["tasks"].pop(task, None)
        ent["started"].pop(task, None)
        ent.get("timeout_watch", {}).pop(task, None)
        if not ent["tasks"] and ROOTS.get(root) is ent:
            ROOTS.pop(root, None)
        if queued:
            QUEUED[name] -= 1
        if acquired:
            lock.release()
        publish_status(name)
        STATUS.setdefault(name, {"state": "idle"})["queue"] = QUEUED.get(name, 0)
        bump()


MEMBER_TIMEOUT_DEFAULT_MS = 0  # disabled unless explicitly enabled in config


def member_timeout_ms():
    value = CFG.get("member_timeout_ms", MEMBER_TIMEOUT_DEFAULT_MS)
    # A malformed hand-edited config must not break the background scanner.
    return value if type(value) is int and value >= 0 else MEMBER_TIMEOUT_DEFAULT_MS


def scan_member_timeouts():
    """Warn once per execution, without cancelling it or dispatching an AI call."""
    now = time.monotonic()
    limit = member_timeout_ms()
    if limit == 0:
        return
    for rid, ent in list(ROOTS.items()):
        for task, watch in list(ent.get("timeout_watch", {}).items()):
            name = ent["tasks"].get(task)
            if not name or task.done() or watch["notified"]:
                continue
            elapsed = max(0, int((now - watch["since"]) * 1000))
            if elapsed < limit:
                continue
            add_msg(ent["pid"], "系统",
                    f"@{owner()} 成员 {name} 本次回答已持续 {elapsed // 1000} 秒，"
                    "尚未结束，请检查是否卡住；任务仍在运行，可手动叫停。",
                    dm=watch["dm"], root_id=rid, level="warn", type="member_timeout",
                    member=name, elapsed_ms=elapsed)
            watch["notified"] = True


async def member_timeout_loop():
    while True:
        await asyncio.sleep(5)
        try:
            scan_member_timeouts()
        except Exception as exc:  # one failed notification must not stop future scans
            print("member_timeout", type(exc).__name__)


async def member_timeout_context(app):
    task = asyncio.create_task(member_timeout_loop())
    try:
        yield
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


def skills_list():
    out = []
    root = DATA / "skills"
    state = load(root / "state.json", {})
    for d in sorted(root.iterdir() if root.exists() else []):
        f = d / "SKILL.md"
        if not f.exists():
            continue
        meta = frontmatter(f.read_text(errors="replace"))
        name = meta.get("name") or d.name
        out.append({"name": name, "dir": d.name, "description": meta.get("description", ""), "on": state.get(d.name, {}).get("on", True),
                    "source": state.get(d.name, {}).get("source", "")})
    return out


def frontmatter(s):
    m = re.match(r"^---\s*\n(.*?)\n---", s, re.S)
    out = {}
    for line in (m.group(1).splitlines() if m else []):
        k, _, v = line.partition(":")
        if v:
            out[k.strip()] = v.strip().strip("\"'")
    return out


def invoked_skills(text):
    on = {s["name"]: s for s in skills_list() if s["on"]}
    names = re.findall(r"(?:^|\s)/([\w\-.]+)", text)
    return [on[n] for n in dict.fromkeys(names) if n in on]


def scope_key(pid, dm):
    return pid + ("~" + dm if dm else "")


def summary(pid, dm):
    return load(DATA / "summaries" / f"{SAFE.sub('_', scope_key(pid, dm))}.json", {"upto": 0, "text": ""})


def scope_msgs(pid, dm):
    """The messages a member sees in this chat: finished, not recalled, from the current topic on."""
    p = project(pid) or {}
    start = (p.get("topics") or {}).get(dm or "", 0)
    return [x for x in CHATS.get(pid, []) if not x.get("gone") and not x.get("recalled") and not x.get("live")
            and x["seq"] >= start and (x.get("dm", "") == dm if dm else not x.get("dm"))]


def owner():
    """What the AIs call the person who runs this server. Messages store them as "Ali" (the protocol's name for the
    owner); a friend's server sets its own name (AICHAT_OWNER), so the AIs do not call everyone Ali."""
    return CFG.get("owner") or "Ali"


def who_name(who):
    return owner() if who == "Ali" else who


def msg_line(pid, local):
    def line(x, short):
        t = strip_todo(x["text"])
        t = context.prune(t) if short else t
        if local:
            t = re.sub(r"\]\(/files/([^)\s]+)\)", lambda mm: f"]({DATA / 'files' / mm.group(1)})", t)
        q = ""
        if x.get("reply_to"):
            r = next((y for y in CHATS[pid] if y["seq"] == x["reply_to"]), None)
            if r:
                q = f"（回复 {who_name(r['who'])}：{r['text'][:80]}）"
        return f"[{x['at']}] {who_name(x['who'])}：{q}{'📌 ' if x.get('pinned') else ''}{t}"
    return line


def budget_for(m):
    v = m.get("context") or CFG.get("context", "standard")
    return int(v) if str(v).isdigit() else context.BUDGETS.get(v, context.BUDGETS["standard"])


def build_prompt(pid, name, trigger, local, since=0):
    """System part (stable, so providers can cache it) and the conversation. since > 0: a CLI member that keeps its
    own session gets only what came after the last message it saw."""
    p = project(pid)
    m = member(name) or {}
    others = [n for n in p["members"] if n != name]
    dm = trigger.get("dm", "")
    sysp = [f"你是「{name}」。" + (m.get("persona") or "").strip()]
    role = lambda n: task_cards.role_description(member(n) or {})
    if role(name):
        sysp.append(f"你在群里的分工：{role(name)}。")
    lead = p.get("lead") if p.get("lead") in p["members"] else ""
    sysp.append("要分几步做的事（查资料、改代码、写方案等），在回复最开头先写进度清单，之后每做完一步就把清单再写一遍更新状态，格式：\n"
                "[进度]\n✓ 已完成的步骤\n✱ 正在做的步骤\n○ 还没开始的步骤\n[/进度]\n每步一行、写短；简单的问答不要写清单。清单不会显示在聊天里，只显示成进度卡片。")
    if dm:
        sysp.append(f"这是 {owner()} 和你的私聊，项目「{p['name']}」。")
        sysp.append(f"所有成员都适用：只有 {owner()} 在这条私聊里点名让你叫某个群成员时，才单独起一行写「@名字 具体要做什么」，"
                    f"这一行会发到群里叫醒对方；{owner()} 没点名的成员 @ 了也不会转发，不能自行叫醒别人。其他行里的 @ 不会转发。")
    else:
        sysp.append(f"你在 AI 协作群「{p['name']}」里，群主是 {owner()}，其他成员：" + ("、".join(n + (f"（{role(n)}）" if role(n) else "") for n in others) or "无") + "。"
                    "只说你自己的话，不替别人说话，开头不要写自己的名字。要找别的成员时 @ 对方。")
        if lead == name:
            sysp.append(f"你是这个群的主 AI，负责调度：{owner()} 没有 @ 人的消息都先到你这里。能自己答的直接答；需要别人做的，"
                        "按各自的分工拆成小任务，用「@名字 具体要做什么」分派（你 @ 谁，谁就会接着回复）。成员做完会 @ 你汇报，"
                        f"你汇总后给 {owner()} 一个结论。不要无事 @ 人。")
        elif lead:
            sysp.append(f"这个群的主 AI 是「{lead}」，由它分派任务；你做完后 @{lead} 汇报结果。")
    if p.get("brief"):
        sysp.append("项目简介：" + p["brief"])
    if not dm:
        try:
            task_prompt = cards().prompt(pid)
            if task_prompt:
                sysp.append(task_prompt)
        except (OSError, ValueError):
            print("task prompt unavailable", pid)
    mem = [e["text"] for sc in ("all", "m-" + name, "p-" + pid) for e in memory(sc)]
    if mem:
        sysp.append("\n# 你记得的事\n" + "\n".join("- " + t for t in mem))
    sm = summary(pid, dm)
    if sm["text"]:
        sysp.append("\n# 前情提要（更早的消息）\n" + sm["text"])
    if dm:
        g = summary(pid, "")["text"]
        if g:
            sysp.append("\n# 群里在聊的（提要节选）\n" + g[:800])
    for s in invoked_skills(trigger["text"]):
        d = DATA / "skills" / s["dir"]
        sysp.append(f"\n# {owner()} 调用了 skill「{s['name']}」\n" + (f"（skill 文件在本机 {d}）\n" if local else "") + (d / "SKILL.md").read_text(errors="replace"))
    line = msg_line(pid, local)
    msgs = scope_msgs(pid, dm)
    if since:
        new = [x for x in msgs if x["seq"] > since]
        convo = "\n\n".join(line(x, False) for x in new)
        fallen, used = [], context.tokens(convo)
    else:
        kept, fallen, used = context.window(msgs, budget_for(m), line)
        convo = "\n\n".join(line(x, short) for x, short in kept)
        fallen = [x for x in fallen if x["seq"] > sm["upto"]]
    src = trigger.get("who") or "Ali"
    if src == "Ali":  # the owner's own message: messages store them as "Ali"
        said = f"{owner()} 刚才{'私聊你' if dm else '@ 了你'}"
    else:  # a hand-off: say who, so nobody reads it as the owner speaking
        said = f"{src} 刚才在消息里提到了你（这不是 {owner()} 的新消息）"
    ask = f"\n\n---\n以上是{'之后的新消息' if since else '最近的消息'}。{said}，现在请你（{name}）直接回复。"
    system = "\n".join(sysp)
    return system, convo + ask, {"fallen": fallen, "tokens": context.tokens(system) + used, "budget": budget_for(m)}


SUMMARIZING = set()


async def update_summary(pid, dm, fallen, opts=None):
    """Fold messages that no longer fit into the 前情提要, with the cheapest member."""
    key = scope_key(pid, dm)
    if key in SUMMARIZING or not fallen:
        return
    if opts is not None and not reserve_call(pid, opts):
        return
    SUMMARIZING.add(key)
    try:
        sm = summary(pid, dm)
        text = await complete(context.SUMMARY_SYSTEM, context.summary_prompt(sm["text"], fallen, msg_line(pid, False)), cheap=True)
        if text.strip():
            save(DATA / "summaries" / f"{SAFE.sub('_', key)}.json", {"upto": fallen[-1]["seq"], "text": text.strip(), "at": now_at()})
            bump(pid)
    except Exception as e:  # noqa: BLE001 - the old summary stays; tried again next time
        print("summary", key, type(e).__name__)
    finally:
        SUMMARIZING.discard(key)


# ---------------------------------------------------------------- spending

PRICES = {}  # filled from config "prices": {model prefix: [in, out, cached] per 1M tokens, currency}


def price(m, model):
    """Per-1M-token prices: the member's own, else the provider's, else config prices by model prefix."""
    pr = provider(m.get("provider")) or {}
    own_model = m.get("price_model", m.get("model"))
    own_provider = m.get("price_provider", m.get("provider"))
    for src in ((pr.get("prices") or {}).get(model),
                (m.get("prices") or {}).get(model) if own_provider == m.get("provider") else None,
                m.get("price") if model == own_model and own_provider == m.get("provider") else None,
                pr.get("price") if model == pr.get("model") else None):
        if src and src.get("provider", m.get("provider")) == m.get("provider"):
            return src
    for k, v in sorted((CFG.get("prices") or {}).items(), key=lambda kv: -len(kv[0])):
        if (model or "").startswith(k):
            return v
    if m.get("kind", "api") == "api" and model in CATALOG_PRICES:
        return {**CATALOG_PRICES[model], "source": "catalog", "estimated": True}
    return None


def pricing_warning(m, model):
    if m.get("kind", "api") == "api" and price(m, model) is None:
        return "此 API 声部缺少价格，当前仅统计用量，预算无法准确扣费；请粘贴或填写该模型的输入、输出单价。"
    return ""


def spend_file():
    return DATA / "spend.json"


def today():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=CFG.get("tz", 8)))).strftime("%Y-%m-%d")


def in_period(pr):
    """Time-of-day prices (DeepSeek's off-peak hours and the like): the period the clock is in now, else the base price."""
    now = datetime.datetime.now(tz()).strftime("%H:%M")
    for p in pr.get("periods") or []:
        a, b = p.get("from", ""), p.get("to", "")
        if a and b and (a <= now < b if a < b else now >= a or now < b):
            return {**pr, **{k: v for k, v in p.items() if k in ("in", "out", "cached")}}
    return pr


def record_usage(m, model, u, pid=None):
    """Adds one reply's tokens (and cost, when the price is known) to the member's day."""
    pr = price(m, model)
    pr = in_period(pr) if pr else pr
    cost = None
    if not pr:
        u["pricing_warning"] = pricing_warning(m, model)
    if pr:
        cached = u.get("cached", 0)
        cost = ((u.get("in", 0) - cached) * pr.get("in", 0) + cached * pr.get("cached", pr.get("in", 0)) + u.get("out", 0) * pr.get("out", 0)) / 1e6
        u["cost"] = round(cost, 5)
        u["cur"] = pr.get("cur", "¥")
    sp = load(spend_file(), {})
    d = sp.setdefault(m["name"], {}).setdefault(today(), {"in": 0, "out": 0, "cached": 0, "cost": 0.0, "n": 0})
    for k in ("in", "out", "cached"):
        d[k] += u.get(k, 0)
    bp = None
    if pid:
        bp = d.setdefault("by_project", {}).setdefault(pid, {"in": 0, "out": 0, "cached": 0, "n": 0, "cost_by_currency": {}})
        for k in ("in", "out", "cached"):
            bp[k] += u.get(k, 0)
        bp["n"] += 1
    if cost is not None:
        cur = u["cur"]
        costs = d.setdefault("cost_by_currency", {})
        costs[cur] = round(costs.get(cur, 0) + cost, 5)
        if bp is not None:
            bp["cost_by_currency"][cur] = round(bp["cost_by_currency"].get(cur, 0) + cost, 5)
        entries = d.setdefault("by_model", {})
        key = json.dumps([m.get("provider", ""), model, cur], ensure_ascii=False)
        entries[key] = round(entries.get(key, 0) + cost, 5)
        # Existing numeric field stays readable; it represents only the cap's currency.
        d["cost"] = costs.get(m.get("daily_cap_cur", (price(m, m.get("model")) or {}).get("cur", "¥")), 0)
    d["n"] += 1
    save(spend_file(), sp)


def over_cap(m):
    """The member's daily cap (cost, or tokens when no price is set): reached → it does not answer."""
    d = load(spend_file(), {}).get(m["name"], {}).get(today())
    if not d:
        return None
    if m.get("daily_cap") and d["cost"] >= float(m["daily_cap"]):
        return f"今天的花费上限 {m['daily_cap']} 到了"
    if m.get("daily_tokens") and d["in"] + d["out"] >= int(m["daily_tokens"]):
        return f"今天的 token 上限 {m['daily_tokens']} 到了"
    return None


def spent_total(pr_id, cur="¥"):
    """Everything the members on this provider have cost, all days (one account: Ali 10-25 三个 AI 用一个 API 一起算)."""
    names = {m["name"] for m in CFG["members"] if m.get("provider") == pr_id}
    return sum(d.get("cost_by_currency", {}).get(cur, 0) for n, days in load(spend_file(), {}).items() if n in names for d in days.values())


def balance_value(amount, cur):
    value = float(amount)
    if not math.isfinite(value):
        raise ValueError("余额数值无效")
    return {"accounts": [{"amount": value, "cur": cur}]}


def wallet_quota(pr, api_balance=None):
    """Never combine currencies or recover an amount by stripping punctuation."""
    w = pr.get("wallet")
    cur = (w or {}).get("cur", "¥")
    if w and w.get("ledger") != 2:
        # Balances Ali set before the per-currency ledger: each provider bills in one currency, so the old
        # spend baseline holds; keep them instead of asking him to type them again.
        names = {m["name"] for m in CFG["members"] if m.get("provider") == pr["id"]}
        old_total = sum(d.get("cost", 0) for n, days in load(spend_file(), {}).items() if n in names for d in days.values())
        w.update(amount=float(w["amount"]) - (old_total - float(w.get("spent0", 0))), spent0=spent_total(pr["id"], cur), ledger=2)
        save_cfg()
    if w:
        left = float(w["amount"]) - (spent_total(pr["id"], cur) - float(w.get("spent0", 0)))
        source = "estimate"
    elif api_balance:
        if isinstance(api_balance, str):  # compatibility with old quota adapters
            accounts = []
            for part in api_balance.split(" + "):
                hit = re.fullmatch(r"\s*([$¥])\s*(-?\d+(?:\.\d+)?)\s*", part)
                if not hit:
                    return None
                accounts.append({"cur": hit[1], "amount": float(hit[2])})
        else:
            accounts = api_balance.get("accounts", [])
        if not accounts or any(not math.isfinite(float(a["amount"])) or not a.get("cur") for a in accounts):
            return None
        # DeepSeek lists an empty USD account beside the CNY one: an empty account is not a second balance.
        accounts = [a for a in accounts if float(a["amount"]) != 0] or accounts[:1]
        text = " + ".join(f"{a['cur']}{a['amount']:.2f}" for a in accounts)
        if len(accounts) != 1:
            return {"balance": text, "short": text, "accounts": accounts, "fill": None,
                    "unset": False, "source": "api", "checked_at": time.time()}
        left, cur = accounts[0]["amount"], accounts[0]["cur"]
        # The ring's full mark is the balance right after the last top-up (Ali 10-26: 每次充值算重置，重置后为100):
        # a balance higher than last time means money went in, so the ring starts again at 100%.
        peaks, last = pr.setdefault("peaks", {}), pr.setdefault("last_balance", {})
        # No last balance yet (first run of this rule) also starts at 100%: Ali 10-26 现在就按当前余额算满圆.
        if cur not in last or left > float(last[cur]) + .005:
            peaks[cur] = max(left, .01)
        if last.get(cur) != left:
            last[cur] = left
            save_cfg()  # survives a restart, which would otherwise read the current balance as a fresh top-up
        w = {"amount": peaks[cur]}
        source = "api"
    else:
        return None
    top = max(float(w["amount"]), .01)
    text = f"{cur}{left:.2f}"
    return {"pct": None, "reset": "", "week": None, "week_reset": "", "balance": text, "short": text,
            "amount": left, "cur": cur, "source": source, "checked_at": time.time(),
            "accounts": [{"amount": left, "cur": cur}],
            "fill": round(max(0., min(100., left / top * 100)), 1)}


def money_number(value):
    n = float(value)
    if not math.isfinite(n) or n < 0 or n > 1e9:
        raise errors.http_error(web.HTTPBadRequest, "金额或单价无效", fix="settings")
    return n


async def h_wallet(request):
    """Set the account balance (and the member's prices) from the app: PUT {member, amount, price_in, price_out}."""
    b = await errors.json_object(request)
    m = member(b.get("member", ""))
    pr = provider((m or {}).get("provider"))
    if not m or not pr:
        raise errors.http_error(web.HTTPNotFound, "这个成员没有接口账户", fix="settings")
    model = b.get("model") or m.get("model", "")
    old_price = price(m, model) or {}
    cur = b.get("cur") or old_price.get("cur") or (pr.get("wallet") or {}).get("cur", "¥")
    if cur not in ("¥", "$"):
        raise errors.http_error(web.HTTPBadRequest, "请选择 ¥ 或 $，不同币种分开记账", fix="none")
    amount = money_number(b["amount"]) if b.get("amount") not in (None, "") else None
    patched = {**old_price}
    for field, key in (("price_in", "in"), ("price_out", "out")):
        if b.get(field) not in (None, ""):
            patched[key] = money_number(b[field])
    if old_price and cur != old_price.get("cur", "¥") and any(b.get(k) in (None, "") for k in ("price_in", "price_out")):
        raise errors.http_error(web.HTTPBadRequest, "切换单价币种时请同时填写输入和输出价", fix="settings")
    if amount is not None:
        pr["wallet"] = {"amount": amount, "spent0": spent_total(pr["id"], cur), "cur": cur, "at": now_at(), "ledger": 2}
    if any(b.get(k) not in (None, "") for k in ("price_in", "price_out")):
        patched["cur"] = cur
        patched["provider"] = pr["id"]
        pr.setdefault("prices", {})[model] = patched
        m.setdefault("prices", {})[model] = patched
        if model == m.get("model"):
            m["price"] = patched
            m.update(price_model=model, price_provider=pr["id"])
    save_cfg()
    await refresh_quota([x["name"] for x in CFG["members"] if x.get("provider") == pr["id"]])
    return web.json_response({"ok": True})


PRICE_ASK = """查一下「{vendor}」接口上模型 {models} 现在的官方 API 单价（按每百万 token），以官网价格页为准，不要凭记忆。
如果有分时段价格（比如夜间优惠），把每个时段都写出来，时间用北京时间。
只回复一段 JSON，不要别的文字，格式：
{{"models": {{"<模型名>": {{"cur": "¥", "in": 输入单价, "out": 输出单价, "cached": 缓存命中输入单价或null,
  "periods": [{{"from": "00:30", "to": "08:30", "in": 0, "out": 0, "cached": 0}}]}}}}, "source": "价格页网址"}}"""


PRICE_JOBS = {}
# Official price pages by API host, used when a provider has no price_url of its own.
PRICE_PAGES = {"api.deepseek.com": "https://api-docs.deepseek.com/zh-cn/quick_start/pricing",
               "api.moonshot.cn": "https://platform.moonshot.cn/docs/pricing/chat",
               "open.bigmodel.cn": "https://open.bigmodel.cn/pricing"}


def price_job_view(job):
    result = {k: v for k, v in job.items() if k not in ("task", "provider", "created")}
    if result.get("error"):
        result.update(errors.upstream(result["error"]))
    return result


async def lookup_prices(job, m, pr):
    try:
        async with asyncio.timeout(120):
            # A configured official page is the evidence. A plain chat model only extracts it.
            # Ali 10-25 wants it one tap: without a configured page, the known vendors' pages; failing those, the
            # helper's own answer, labelled unverified, still shown for Ali to check before it is applied.
            url = pr.get("price_url", "") or next((u for h, u in PRICE_PAGES.items() if h in pr.get("base", "")), "")
            page = ""
            if url.startswith("https://"):
                try:
                    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as session:
                        async with session.get(url) as response:
                            response.raise_for_status()
                            raw = await response.content.read(512 * 1024 + 1)
                    page = raw[:512 * 1024].decode("utf-8", errors="replace")
                    page = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", "", page, flags=re.S | re.I)
                    page = re.sub(r"<[^>]+>", " ", page)
                except Exception as e:  # noqa: BLE001 - fall back to the helper's own knowledge
                    print("price page", type(e).__name__)
                    page = ""
            h = member(CFG.get("price_helper", "")) or cheapest()
            if not h:
                raise ValueError("没有可提取价格的成员")
            models = sorted({x.get("model") for x in CFG["members"] if x.get("provider") == pr["id"] and x.get("model")})
            ask = PRICE_ASK.format(vendor=pr.get("name", pr["id"]), models="、".join(models))
            if page:
                ask += f"\n只从以下网页内容提取；缺项就省略模型，不准猜。来源：{url}\n" + page[:100000]
            else:
                url = "AI 查询（未核验，请核对）"
            r = {"who": h["name"], "text": "", "note": ""}
            if h.get("kind") in ("cli", "dsh"):
                await call_cli(None, {**h, "timeout": 95}, r, "", ask, h.get("model", ""), h.get("effort", ""))
            else:
                await call_api(None, h, r, "", ask, h.get("model", ""), "")
            hit = re.search(r"\{.*\}", r["text"], re.S)
            result = json.loads(hit[0]) if hit else {}
            got = {}
            for model, value in (result.get("models") or {}).items():
                if model not in models or (page and model.lower() not in page.lower()) or not isinstance(value, dict):
                    continue
                cur = value.get("cur")
                if cur not in ("¥", "$") or any(value.get(k) is None for k in ("in", "out")):
                    continue
                candidate = {**value, "in": money_number(value["in"]), "out": money_number(value["out"]),
                             "source": url, "at": now_at()}
                if value.get("cached") is not None:
                    candidate["cached"] = money_number(value["cached"])
                candidate["periods"] = [{**period, **{k: money_number(period[k]) for k in ("in", "out", "cached") if period.get(k) is not None}}
                                        for period in value.get("periods") or [] if isinstance(period, dict) and period.get("from") and period.get("to")]
                got[model] = candidate
            if not got:
                raise ValueError("来源页中未提取到匹配模型和完整单价；未应用任何价格")
            job.update(state="review", ok=True, source=url, models=got,
                       prices={x["name"]: got[x["model"]] for x in CFG["members"] if x.get("provider") == pr["id"] and x.get("model") in got},
                       evidence="已获取配置的来源页；请核对币种、模型、单位及优惠条件后应用")
    except asyncio.CancelledError:
        job.update(state="cancelled", ok=False, error="查价已取消，未应用价格")
        raise
    except Exception as exc:
        job.update(state="failed", ok=False, error=str(exc)[:400])


async def h_price_lookup(request):
    b = dict(request.query) if request.method == "GET" else await errors.json_object(request)
    if b.get("id"):
        job = PRICE_JOBS.get(b["id"])
        if not job:
            raise errors.http_error(web.HTTPNotFound, "查价任务不存在，请重新查询", fix="retry")
        if b.get("op") == "cancel":
            job["task"].cancel()
            await asyncio.gather(job["task"], return_exceptions=True)
        if b.get("op") == "apply" and job["state"] == "review":
            account = provider(job["provider"])
            if not account:
                raise errors.http_error(web.HTTPNotFound, "原接口已删除，价格未应用", fix="retry")
            account.setdefault("prices", {}).update(job["models"])
            names = []
            for m in CFG["members"]:
                if m.get("provider") == job["provider"] and m.get("model") in job["models"]:
                    m.setdefault("prices", {}).update(job["models"])
                    m["price"] = job["models"][m["model"]]
                    m.update(price_model=m["model"], price_provider=job["provider"])
                    names.append(m["name"])
            save_cfg(); bump()
            job.update(state="applied", members=names)
        return web.json_response(price_job_view(job))
    m = member(b.get("member", ""))
    pr = provider((m or {}).get("provider"))
    if not m or not pr:
        raise errors.http_error(web.HTTPNotFound, "这个成员没有接口账户", fix="settings")
    existing = next((j for j in PRICE_JOBS.values() if j["provider"] == pr["id"] and j["state"] in ("running", "review")), None)
    if existing:
        return web.json_response(price_job_view(existing))
    for jid, previous in list(PRICE_JOBS.items()):
        if previous["state"] not in ("running", "review") and time.time() - previous["created"] > 600:
            del PRICE_JOBS[jid]
    jid = secrets.token_hex(12)
    job = {"id": jid, "state": "running", "ok": True, "provider": pr["id"], "created": time.time()}
    PRICE_JOBS[jid] = job
    job["task"] = asyncio.create_task(lookup_prices(job, m, pr))
    return web.json_response(price_job_view(job))


def spent_today(name):
    d = load(spend_file(), {}).get(name, {}).get(today()) or {}
    amounts = d.get("cost_by_currency", {})
    return "今日 " + (" + ".join(f"{cur}{amount:.2f}" for cur, amount in amounts.items()) or "花费未知")


def spend_view():
    sp = load(spend_file(), {})
    t = today()
    month = t[:7]
    out = {}
    for name, days in sp.items():
        td = days.get(t, {})
        mo = [v for k, v in days.items() if k.startswith(month)]
        out[name] = {"today": {k: td.get(k, 0) for k in ("in", "out", "cost", "n")},
                     "month": {k: round(sum(v.get(k, 0) for v in mo), 5) for k in ("in", "out", "cost", "n")},
                     "cost_by_currency": {"today": td.get("cost_by_currency", {}),
                                          "month": {cur: round(sum(v.get("cost_by_currency", {}).get(cur, 0) for v in mo), 5)
                                                    for cur in {cur for v in mo for cur in v.get("cost_by_currency", {})}}}}
    return out


async def h_spend(request):
    return web.json_response({"spend": spend_view(), "today": today()})


# ---------------------------------------------------------------- CLI sessions


def sessions():
    return load(DATA / "sessions.json", {})


class AIError(RuntimeError):
    def __init__(self, code, detail):
        super().__init__(detail)
        self.code = code


def api_error(status, detail):
    evidence = detail.lower()
    quota = any(x in evidence for x in ("insufficient_quota", "insufficient_balance", "credit balance", "余额不足", "quota_exceeded", "billing_hard_limit", "usage_limit_reached", "out of credits", "you've hit your limit", "usage limit exceeded"))
    code = "quota_exhausted" if status == 402 or quota else "provider_auth" if status in (401, 403) else "rate_limit" if status == 429 else "provider_error"
    return AIError(code, f"HTTP {status} {detail[:300]}")


LAST_RESULT = {}
RESULTS = []  # bounded execution event feed, independent of delivery ACKs


async def answer(pid, name, trigger, opts):
    m = member(name)
    if not m:
        return
    kind = m.get("kind", "api")
    model = opts.get("model") if trigger.get("dm") and opts.get("model") else m.get("model", "")
    effort = opts.get("effort") if trigger.get("dm") and opts.get("effort") else m.get("effort", "")
    task_id = secrets.token_hex(12)
    st = {"task_id": task_id, "outcome": "running"}
    TASK_STATUS.setdefault(name, {})[task_id] = st
    st.update({"state": "working", "since": time.time(), "pid": pid, "asked": trigger["text"][:80], "note": "", "what": "", "todo": [], "todo_end": 0})
    publish_status(name)
    reply = add_msg(pid, name, "", trigger.get("dm", ""), live=True, task_id=task_id, root_id=opts.get("root_id", ""), reply_to=trigger["seq"] if trigger.get("priority") else None)
    if reply.get("reply_to") is None:
        reply.pop("reply_to")
    dm = trigger.get("dm", "")
    skey = f"{name}|{scope_key(pid, dm)}"
    try:
        cap = over_cap(m)
        if cap:
            reply["text"] = f"（{cap}，明天再找我，或者在成员设置里调高上限）"
            reply["failed"] = True
            reply["error_code"] = "quota_exhausted"
            return
        local = kind in ("cli", "dsh")
        sess = sessions().get(skey) if local and m.get("resume_cmd") else None
        system, prompt, info = build_prompt(pid, name, trigger, local, since=sess["upto"] if sess else 0)
        reply["ctx"] = {"tokens": info["tokens"], "budget": info["budget"]}
        if info["fallen"]:
            # Way behind (first time, or a long burst): wait for the summary, else let it catch up in the background.
            if summary(pid, dm)["text"] == "" and sum(context.tokens(x["text"]) for x in info["fallen"]) > 3 * context.SUMMARY_BATCH \
                    or sum(context.tokens(x["text"]) for x in info["fallen"]) > 6 * context.SUMMARY_BATCH:
                live(pid, reply, note="正在整理前情提要…")
                await update_summary(pid, dm, info["fallen"], opts)
                system, prompt, info = build_prompt(pid, name, trigger, local)
            elif sum(context.tokens(x["text"]) for x in info["fallen"]) > context.SUMMARY_BATCH:
                asyncio.ensure_future(update_summary(pid, dm, info["fallen"], opts))
        if local:
            await call_cli(pid, m, reply, system, prompt, model, effort, sess, skey)
        else:
            await call_api(pid, m, reply, system, prompt, model, effort, opts)
        if not reply["text"].strip():
            reply["text"] = "（没有回复内容）"
            reply["failed"] = True
            reply["error_code"] = "provider_error"
    except asyncio.CancelledError:
        reply["text"] = (reply["text"] + "\n\n" if reply["text"] else "") + f"（{owner()} 让停下了）"
        reply["stopped"] = True
        raise
    except Exception as e:  # noqa: BLE001 - shown in the chat
        reply["text"] = (reply["text"] + "\n\n" if reply["text"] else "") + f"⚠️ 出错了：{e}"
        reply["failed"] = True
        reply["error_code"] = getattr(e, "code", "provider_unreachable" if isinstance(e, (ClientConnectionError, asyncio.TimeoutError)) else api_error(int(hit[1]) if (hit := re.search(r"HTTP\s+(\d{3})", str(e))) else 0, str(e)).code)
    finally:
        reply["provider"] = m.get("provider", "")
        if not reply.get("stopped"):
            LAST_RESULT[name] = {"ok": not reply.get("failed"), "code": reply.get("error_code", ""), "at": time.time(), "root_id": opts.get("root_id", "")}
            RESULTS.append({**LAST_RESULT[name], "id": bump(pid), "member": name, "provider": m.get("provider", ""), "project": pid})
            del RESULTS[:-256]
        if reply.get("usage"):
            record_usage(m, model, reply["usage"], pid)
        if st.get("todo") and st.get("todo_pid") == pid:
            st["todo"] = [{**x, "s": "done"} for x in todo_of(reply["text"]) or st["todo"]] if not reply.get("failed") and not reply.get("stopped") else st["todo"]
            st["todo_end"] = time.time()
        st.update({"state": "idle", "note": "", "asked": "", "outcome": "cancelled" if reply.get("stopped") else "failed" if reply.get("failed") else "succeeded", "todo_end": time.time(), "error_code": reply.get("error_code", "")})
        publish_status(name)
        finish_msg(pid, reply)
        if not dm and not reply.get("failed") and not reply.get("stopped"):
            try:
                cards().propose(pid, reply)
            except Exception as e:  # a candidate must never break the reply or hand-off
                print("task candidate:", type(e).__name__)
        asyncio.ensure_future(refresh_quota([name]))
        if not dm and not reply.get("failed") and not reply.get("stopped"):
            dispatch(pid, name, reply, opts)
        if dm and not reply.get("failed") and not reply.get("stopped"):
            dm_relay(pid, name, trigger, reply, opts)


HOPS = 0  # default cap on foreground AI calls per root request; 0 = no cap (Ali 10-26), config "max_hops" overrides


def dispatch(pid, name, reply, opts):
    """主 AI (Ali 10-25): whom the lead @s answers next; a member that @s the lead hands back to it."""
    p = project(pid)
    lead = p.get("lead") if p and p.get("lead") in p["members"] and (member(p["lead"]) or {}).get("auto", True) else ""
    if not lead:
        return
    who = targets(p, reply["text"], "")
    who = [n for n in who if n != name] if name == lead else [n for n in who if n == lead]
    if who:
        asyncio.ensure_future(run_chain(pid, who, reply, {**opts, "priority": "queue"}))


def dm_relay(pid, name, trigger, reply, opts):
    """Any member may relay @ lines, restricted to members named in the owner's current DM."""
    p = project(pid)
    if not p or name not in p["members"] or trigger.get("dm") != name or trigger.get("who") != "Ali":
        return
    asked = [n for n in p["members"] if n != name and n in trigger["text"]]
    lines = [ln.strip() for ln in reply["text"].splitlines() if ln.strip().startswith("@")]
    lines = [ln for ln in lines if any(n in asked for n in targets(p, ln, ""))]
    who = [n for n in targets(p, "\n".join(lines), "") if n in asked]
    if not who:
        return
    m = add_msg(pid, name, f"（{owner()} 私聊里让我叫的）\n" + "\n".join(lines), relayed_from=reply["seq"])
    asyncio.ensure_future(run_chain(pid, who, m, {**opts, "priority": "queue"}))


def live(pid, reply, text=None, note=None):
    if text is not None:
        reply["text"] = text
        if "[进度]" in text:
            t = todo_of(text)
            st = TASK_STATUS.get(reply["who"], {}).get(reply.get("task_id"))
            if t and st is not None and t != st.get("todo"):
                st.update(todo=t, todo_pid=pid or "")
                bump(pid)
    if note is not None:
        reply["note"] = note[-400:]
        TASK_STATUS.get(reply["who"], {}).get(reply.get("task_id"), {})["note"] = reply["note"]
        publish_status(reply["who"])
    if pid is None:
        return
    DIRTY.add((pid, id(reply)))
    LIVE_REF[(pid, id(reply))] = reply


LIVE_REF = {}


async def flusher():
    """Live text goes out at most every 90 ms: enough to look like typing, without a poll per token."""
    while True:
        await asyncio.sleep(0.09)
        if DIRTY:
            items = list(DIRTY)
            DIRTY.clear()
            for pid, k in items:
                r = LIVE_REF.pop((pid, k), None)
                if r is not None:
                    r["rev"] = bump(pid)


async def call_api(pid, m, reply, system, prompt, model, effort, opts=None):
    pr = provider(m.get("provider"))
    if not pr:
        raise RuntimeError("这个成员没有选接口")
    base = pr["base"].rstrip("/")
    to = ClientTimeout(total=None, sock_read=600, sock_connect=20)
    text, note = "", ""
    async with ClientSession(trust_env=True, timeout=to) as s:
        if pid is not None and (m.get("workspace_tools") or {}).get("enabled"):
            await asyncio.wait_for(api_workspace.run(sys.modules[__name__], s, pid, m, reply,
                                   system, prompt, model, effort, opts or {}), timeout=m.get("timeout", 3600))
            return
        if pr.get("kind") == "anthropic":
            # The system part (persona, memory, 前情提要) changes rarely: marked for prompt caching.
            body = {"model": model, "max_tokens": m.get("max_tokens", 8000), "stream": True,
                    "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
                    "messages": [{"role": "user", "content": prompt}]}
            if effort in ("medium", "high"):
                body["thinking"] = {"type": "enabled", "budget_tokens": 4000 if effort == "medium" else 16000}
                body["max_tokens"] = max(body["max_tokens"], body["thinking"]["budget_tokens"] + 4000)
            # Relays for Claude often want the key as a Bearer token; the official API takes x-api-key.
            h = {"x-api-key": pr.get("key", ""), "Authorization": "Bearer " + pr.get("key", ""), "anthropic-version": "2023-06-01"}
            async with s.post(re.sub(r"/v1$", "", base) + "/v1/messages", json=body, headers=h, proxy=pr.get("proxy") or None) as r:
                if r.status >= 400:
                    raise api_error(r.status, await r.text())
                usage = {}
                async for ev in sse(r):
                    if ev.get("error") or ev.get("type") == "error":
                        raise api_error(500, json.dumps(ev.get("error") or ev, ensure_ascii=False))
                    u = ev.get("usage") or (ev.get("message") or {}).get("usage")
                    if u:
                        usage["in"] = max(usage.get("in", 0), u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0) + u.get("cache_creation_input_tokens", 0))
                        usage["cached"] = max(usage.get("cached", 0), u.get("cache_read_input_tokens", 0))
                        usage["out"] = max(usage.get("out", 0), u.get("output_tokens", 0))
                        reply["usage"] = usage
                    d = ev.get("delta") or {}
                    if d.get("type") == "text_delta":
                        text += d.get("text", "")
                        live(pid, reply, text=text)
                    elif d.get("type") == "thinking_delta":
                        note += d.get("thinking", "")
                        live(pid, reply, note=note)
            return
        body = {"model": model, "stream": True, "stream_options": {"include_usage": True},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]}
        if effort and m.get("send_effort", True):
            body["reasoning_effort"] = effort
        body.update(m.get("extra_body") or {})
        h = {"Authorization": "Bearer " + pr.get("key", "")}
        for attempt in range(3):
            async with s.post(base + "/chat/completions", json=body, headers=h, proxy=pr.get("proxy") or None) as r:
                if r.status == 400 and attempt < 2 and ("reasoning_effort" in body or "stream_options" in body):
                    # Models (or relays) without the setting refuse it: drop the optional fields one at a time.
                    body.pop("reasoning_effort" if "reasoning_effort" in body else "stream_options")
                    continue
                if r.status >= 400:
                    raise api_error(r.status, await r.text())
                async for ev in sse(r):
                    if ev.get("error") or ev.get("type") == "error":
                        raise api_error(500, json.dumps(ev.get("error") or ev, ensure_ascii=False))
                    u = ev.get("usage")
                    if u:
                        cached = u.get("prompt_cache_hit_tokens") or (u.get("prompt_tokens_details") or {}).get("cached_tokens") or 0
                        reply["usage"] = {"in": u.get("prompt_tokens", 0), "out": u.get("completion_tokens", 0), "cached": cached}
                    for c in ev.get("choices") or []:
                        d = c.get("delta") or c.get("message") or {}
                        if d.get("reasoning_content") or d.get("reasoning"):
                            note += d.get("reasoning_content") or d.get("reasoning") or ""
                            live(pid, reply, note=note)
                        if d.get("content"):
                            text += d["content"]
                            live(pid, reply, text=text)
                return


async def sse(r):
    buf = b""
    plain = bytearray()
    event_seen = False
    async for chunk in r.content.iter_any():
        buf += chunk
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line = line.strip()
            if line.startswith(b"data:"):
                event_seen = True
                d = line[5:].strip()
                if d == b"[DONE]":
                    return
                try:
                    yield json.loads(d)
                except ValueError:
                    pass
            elif not event_seen and len(plain) < 65536:
                plain.extend(line + b"\n")
    if not event_seen:
        # Some relays return HTTP 200 with an ordinary JSON error instead of SSE.
        try:
            data = json.loads(bytes(plain) + buf)
        except ValueError:
            return
        if isinstance(data, dict):
            yield data


def dsh_cmd(m):
    """DeepSeek Harness (Ali 10-25: 要可以直接连接 dsh): its headless profile prints only the answer on stdout."""
    return m.get("cmd") or "dsh --profile headless \"$(cat)\""


async def call_cli(pid, m, reply, system, prompt, model, effort, sess=None, skey=""):
    """A CLI member: cmd is a shell template with {model} {effort} {out} {cwd}. The prompt goes in on stdin. With {out},
    the reply is the file the CLI writes there (codex -o) and stdout is progress; without it stdout is the reply.
    A member with resume_cmd (same template plus {session}) and session_re (a regex whose group 1 finds the session id
    in what the CLI prints) keeps one session per chat and is sent only the new messages."""
    if m.get("kind") == "dsh":
        m = {**m, "cmd": dsh_cmd(m), "cwd": m.get("cwd") or str(DATA / "work" / pid)}
        pathlib.Path(m["cwd"]).mkdir(parents=True, exist_ok=True)
        if m.get("provider") and (pr := provider(m["provider"])) and pr.get("key"):
            m["env"] = {"DEEPSEEK_API_KEY": pr["key"], **(m.get("env") or {})}
    template = m["resume_cmd"] if sess and m.get("resume_cmd") else m.get("cmd", "")
    out = DATA / "tmp" / f"{secrets.token_hex(6)}.txt"
    out.parent.mkdir(exist_ok=True)
    q = shlex.quote
    cmd = template.replace("{model}", q(model or "")).replace("{effort}", q(effort or "")).replace("{out}", q(str(out))) \
        .replace("{cwd}", q(m.get("cwd") or str(DATA))).replace("{session}", q((sess or {}).get("id", "")))
    if not cmd.strip():
        raise RuntimeError("这个成员没有填命令")
    # Codex runs in a read-only sandbox without network. 完全访问 opens the network (and its work folder);
    # 完全同意 lifts the sandbox altogether.
    approve_all = approve_all_for(m.get("name"))
    if " -s read-only" in cmd and (approve_all or CFG.get("full_access")):
        cmd = cmd.replace(" -s read-only", " -s danger-full-access" if approve_all
                          else " -s workspace-write -c sandbox_workspace_write.network_access=true")
        if not m.get("cwd"):  # its writable folder is the project's work folder, never the server's data
            m = {**m, "cwd": str(DATA / "work" / (pid or "dm"))}
            pathlib.Path(m["cwd"]).mkdir(parents=True, exist_ok=True)
    cmd, stripped = chorus2.cli_guard(cmd)
    if stripped:
        chorus2.log(pid, reply["who"], "已去掉跳过审批的参数：所有工具请求走同意卡/权限设置")
    to_file = "{out}" in template
    env = {**os.environ, **{k: str(v) for k, v in (m.get("env") or {}).items()},
           # Where a CLI's permission requests go (approve_mcp.py): a card in this chat for Ali to answer.
           "CHORUS_APPROVE_URL": f"http://127.0.0.1:{PORT}/approve/ask", "CHORUS_APPROVE_KEY": APPROVE_KEY,
           "CHORUS_PID": pid or "", "CHORUS_WHO": reply["who"], "CHORUS_DM": reply.get("dm") or ""}
    proc = await asyncio.create_subprocess_shell(cmd, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                                                 stderr=asyncio.subprocess.PIPE, cwd=m.get("cwd") or None, env=env, start_new_session=True)
    RUNNING.setdefault(reply["who"], set()).add(proc)
    text, note = "", ""

    async def read_out():
        nonlocal text, note
        async for raw in proc.stdout:
            s = raw.decode(errors="replace")
            if to_file:
                note = (note + s)[-2000:]
                live(pid, reply, note=note)
            else:
                text += s
                live(pid, reply, text=text)

    async def read_err():
        nonlocal note
        async for raw in proc.stderr:
            note = (note + raw.decode(errors="replace"))[-2000:]
            live(pid, reply, note=note)
    try:
        try:
            proc.stdin.write((prompt if sess else system + "\n\n" + prompt).encode())
            await proc.stdin.drain()
        except (BrokenPipeError, ConnectionResetError):
            pass  # an early CLI rejection still has useful stderr and an exit code
        finally:
            proc.stdin.close()
        await asyncio.wait_for(asyncio.gather(read_out(), read_err(), proc.wait()), m.get("timeout", 3600))
    except asyncio.TimeoutError:
        raise RuntimeError("超时了")
    finally:
        await kill_process_group(proc)
        RUNNING.get(reply["who"], set()).discard(proc)
        if not to_file or proc.returncode:
            out.unlink(missing_ok=True)
    if to_file:
        text = out.read_text(errors="replace") if out.exists() else ""
        out.unlink(missing_ok=True)
    if proc.returncode:
        live(pid, reply, text=text.strip())
        if sess:
            # The CLI lost the session (cleared, expired): start a fresh one next time.
            ss = sessions(); ss.pop(skey, None); save(DATA / "sessions.json", ss)
        raise RuntimeError(f"命令退出码 {proc.returncode}：{note.strip()[-300:]}")
    if m.get("session_re") and skey:
        found = re.search(m["session_re"], note + "\n" + text)
        sid = found.group(1) if found else (sess or {}).get("id")
        if sid:
            ss = sessions(); ss[skey] = {"id": sid, "upto": reply["seq"]}; save(DATA / "sessions.json", ss)
    live(pid, reply, text=text.strip())


RUNNING = {}


async def kill_process_group(proc):
    # Kill descendants even when their shell leader already exited.
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    await proc.wait()


def _project_used(pid, cur):
    """Today's cost of one room across all members, from the by_project rows record_usage writes."""
    total = 0.0
    for days in load(spend_file(), {}).values():
        rec = days.get(today()) if isinstance(days, dict) else None
        row = ((rec or {}).get("by_project") or {}).get(pid) or {}
        total += float((row.get("cost_by_currency") or {}).get(cur, 0) or 0)
    return total


async def h_spend_summary(request):
    """Spend ring: only the server decides warn, so client and server never disagree on the threshold."""
    pid = request.query.get("pid", "")
    room = (CFG.get("room_overrides") or {}).get(pid) or {}
    cur = room.get("currency") or CFG.get("spend_currency", "¥")
    cap = float(room.get("budget") or 0) if pid else 0.0
    used = _project_used(pid, cur) if cap > 0 else 0.0
    ratio = used / cap if cap > 0 else 0.0
    return web.json_response({"used": round(used, 4), "budget": cap, "currency": cur, "ratio": round(ratio, 4),
                              "warn": bool(cap > 0 and ratio >= float(CFG.get("spend_warn_ratio", 0.8)))})


async def h_room_stop(request):
    """Stops a whole round (or every round in the room when no root_id is given), not just one member."""
    pid = request.match_info["pid"]
    rid = request.query.get("root_id") or ""
    hit, started = [], set()
    for r, e in list(ROOTS.items()):
        if e["pid"] != pid or (rid and r != rid):
            continue
        e["budget"]["stopped"] = True
        hit.extend(e["tasks"])
        started.update(n for t, n in e["tasks"].items() if t in e["started"])
    if rid:
        STOPPED_ROOTS[rid] = time.time()
        while len(STOPPED_ROOTS) > STOP_KEEP:
            STOPPED_ROOTS.pop(next(iter(STOPPED_ROOTS)))
    else:
        STOP_AT[pid] = time.time()
    for t in hit:
        t.cancel()
    # Only members already answering in this round: a queued member's RUNNING entry may belong to another room.
    await asyncio.gather(*(kill_process_group(p) for n in started for p in list(RUNNING.get(n, ()))), return_exceptions=True)
    await asyncio.gather(*hit, return_exceptions=True)
    if hit:
        add_msg(pid, "系统", f"已叫停本轮，取消 {len(hit)} 个任务。发一条新消息即可开始新一轮", root_id=rid, level="warn")
    return web.json_response({"ok": True, "cancelled": len(hit)})


async def h_rhythm(request):
    pid = request.match_info["pid"]
    if request.method == "POST":
        v = (await errors.json_object(request)).get("max_hops")
        if not isinstance(v, int) or isinstance(v, bool) or not 0 <= v <= 1000:
            raise errors.http_error(web.HTTPBadRequest, "调用次数上限要填 0 到 1000 的整数，0 表示不限", fix="settings")
        CFG.setdefault("room_overrides", {}).setdefault(pid, {})["max_hops"] = v
        save_cfg()
    rounds = [e for e in ROOTS.values() if e["pid"] == pid]
    return web.json_response({"max_hops": _room_max_hops(pid), "used": max((e["budget"].get("used", 0) for e in rounds), default=0),
                              "stopped": any(e["budget"].get("stopped") for e in rounds),
                              "running": sorted({n for e in rounds for t, n in e["tasks"].items() if t in e["started"]})})


async def h_stop(request):
    """Ali stops a member mid-answer: what it wrote so far stays, marked as stopped."""
    name = request.match_info["name"]
    tasks = list(TASKS.get(name, ()))
    for t in tasks:
        t.cancel()
    await asyncio.gather(*(kill_process_group(p) for p in list(RUNNING.get(name, ()))), return_exceptions=True)
    await asyncio.gather(*tasks, return_exceptions=True)
    return web.json_response({"ok": True})


async def h_msg(request):
    """Edit or recall Ali's own message, or react to any message."""
    b = await errors.json_object(request)
    pid, seq, op = b["project"], int(b["seq"]), b["op"]
    client_id = send_client_id(b)
    if op not in ("edit", "recall", "pin", "react"):
        raise errors.http_error(web.HTTPBadRequest, "不支持这个消息操作，请刷新后重试", "retry")
    if op == "edit" and not isinstance(b.get("text"), str) or op == "react" and not isinstance(b.get("emoji"), str):
        raise errors.http_error(web.HTTPBadRequest, "请填写消息文字或表情后重试", "none")
    request_hash = hashlib.sha256(json.dumps({"seq": seq, "op": op,
        **({"text": b["text"]} if op == "edit" else {}),
        **({"emoji": b["emoji"]} if op == "react" else {})}, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    if client_id:
        receipt = next((x["client_ops"][client_id] for x in CHATS.get(pid, []) if client_id in x.get("client_ops", {})), None)
        if receipt:
            if not secrets.compare_digest(receipt["hash"], request_hash):
                return errors.response("这条操作编号已用于其他内容，请重新操作", "none", status=409, code="client_id_conflict")
            return web.json_response(receipt["response"])
    m = next((x for x in CHATS.get(pid, []) if x["seq"] == seq), None)
    if not m:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if op in ("edit", "recall") and m["who"] != "Ali":
        raise errors.http_error(web.HTTPForbidden, "只能改自己的消息", fix="none")
    previous = json.loads(json.dumps(m))
    if op == "edit":
        m["text"], m["edited"] = b["text"], True
    elif op == "recall":
        m["text"], m["recalled"] = "", True
    elif op == "pin":
        m["pinned"] = not m.get("pinned")
    elif op == "react":
        r = m.setdefault("reactions", {})
        who = r.setdefault(b["emoji"], [])
        if "Ali" in who:
            who.remove("Ali")
        else:
            who.append("Ali")
        if not who:
            r.pop(b["emoji"])
    # Copy nested reactions/cards so later operations cannot change a receipt.
    result = json.loads(json.dumps({"ok": True, "message": msg_view(m)}))
    if client_id:
        m.setdefault("client_ops", {})[client_id] = {"hash": request_hash, "response": result}
    try:
        persist(pid)
    except OSError:
        CHATS[pid][next(i for i, item in enumerate(CHATS[pid]) if item is m)] = previous
        raise
    m["rev"] = bump(pid)
    return web.json_response(result)


# ---------------------------------------------------------------- projects


def create_project(name, brief, members, mode, budget, lead=""):
    pid = datetime.datetime.now().strftime("%y%m%d") + "-" + secrets.token_hex(3)
    ms = [n for n in members or [] if member(n)]
    p = {"id": pid, "name": name, "brief": (brief or "").strip(), "members": ms, "created": time.time(),
         "mode": mode if mode in ("solo", "parallel", "concerto", "symphony") else "concerto",
         "budget": {"cap": float((budget or {}).get("cap") or 0), "cur": (budget or {}).get("cur", "¥")}, "segments": [],
         "lead": lead if lead in ms else ""}
    PROJECTS.append(p)
    save(DATA / "projects.json", PROJECTS)
    CHATS[pid] = []
    bump()
    return pid


async def h_new_project(request):
    b = await errors.json_object(request)
    name = (b.get("name") or "").strip()
    if not name:
        raise errors.http_error(web.HTTPBadRequest, "项目要有名字", fix="settings")
    pid = create_project(name, b.get("brief"), b.get("members"), b.get("mode"), {"cap": b.get("budget"), "cur": b.get("cur", "¥")})
    p = project(pid)
    if p["brief"] and p["members"] and p["mode"] in ("solo", "parallel"):
        trig = add_msg(pid, "Ali", f"@全体 新项目「{name}」\n\n{p['brief']}")
        asyncio.ensure_future(run_chain(pid, targets(p, trig["text"], ""), trig, {}))
    return web.json_response({"id": pid})


import concierge  # noqa: E402
import voice  # noqa: E402


async def _concierge_ask(name, brief):
    m = member(name)
    return await chorus2.ask_model(m, "你是项目顾问。用户想做一个东西。只输出 2-3 个最关键的澄清问题，每行一个，以问号结尾。", brief) if m else ""

import plugins as plugins_mod  # noqa: E402
PLUGINS = plugins_mod.Plugins(sys.modules[__name__])


async def h_plugins(request):
    pid = request.match_info.get("id")
    try:
        if request.method == "POST":
            PLUGINS.install(pid)
        elif request.method == "DELETE":
            PLUGINS.uninstall(pid)
    except KeyError:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    except ValueError as e:
        raise errors.http_error(web.HTTPBadRequest, str(e), fix="settings")
    return web.json_response(PLUGINS.view())

CONCIERGE = concierge.Concierge(sys.modules[__name__], chorus2, ask=_concierge_ask)


async def h_intent(request):
    iid, op = request.match_info["id"], request.match_info["op"]
    b = await errors.json_object(request) if request.can_read_body else {}
    if op == "confirm":
        pid = await CONCIERGE.confirm(iid, b.get("edits"))
        if not pid:
            raise errors.http_error(web.HTTPConflict, "这张卡已经处理过了", fix="retry")
        return web.json_response({"ok": True, "project": pid})
    if op == "cancel":
        return web.json_response({"ok": CONCIERGE.cancel(iid)})
    raise errors.http_error(web.HTTPNotFound, fix="retry")


async def voice_send_member(pid, name, trig, text):
    if CONCIERGE.claims(pid, name, text):
        await CONCIERGE.on_user(pid, name, text)
    else:
        await run_chain(pid, [name], trig, {"priority": "now"})


async def stop_member(name):
    for t in list(TASKS.get(name, ())):
        t.cancel()
    await asyncio.gather(*(kill_process_group(p) for p in list(RUNNING.get(name, ()))), return_exceptions=True)

voice_asr = voice.asr


async def h_voice(request):
    if not PLUGINS.features()["voice"]:
        raise errors.http_error(web.HTTPConflict, "先在 设置 → 插件 装一个朗读引擎和一个识别引擎", fix="settings")
    return await voice.handle(request, sys.modules[__name__], voice_send_member)


async def h_read_all(request):
    """全部标为已读 (optionally only the given pids)."""
    b = await errors.json_object(request) if request.can_read_body else {}
    ids = set(b.get("pids") or [])
    n = 0
    for p in PROJECTS:
        if (not ids or p["id"] in ids) and not p.get("archived"):
            p["read_at"], p["manual_unread"] = time.time(), False
            n += 1
    save(DATA / "projects.json", PROJECTS)
    bump()
    return web.json_response({"ok": True, "n": n})


async def h_edit_project(request):
    p = project(request.match_info["pid"])
    if not p:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if request.method == "DELETE":
        p["archived"] = True  # goes to 最近删除; only the user empties it
        p["deleted_at"] = time.time()
    else:
        b = await errors.json_object(request)
        for k in ("name", "brief"):
            if k in b:
                p[k] = b[k].strip()
        if "name" in b and not p["name"]:
            raise errors.http_error(web.HTTPBadRequest, "名字不能为空", fix="settings")
        for k in ("pinned", "muted"):   # long-press menu: 置顶 / 免打扰
            if k in b:
                p[k] = bool(b[k])
        if "unread" in b:               # 标为已读 / 标为未读
            p["read_at"] = 0 if b["unread"] else time.time()
            p["manual_unread"] = bool(b["unread"])
        if "members" in b:
            p["members"] = [n for n in b["members"] if member(n)]
        for n in b.get("add_members") or []:
            if member(n) and n not in p["members"]:
                p["members"].append(n)
        p["members"] = [n for n in p["members"] if n not in (b.get("remove_members") or [])]
        if b.get("mode") in ("solo", "parallel", "concerto", "symphony"):
            p["mode"] = b["mode"]
        if "budget" in b:
            p["budget"] = {"cap": float(b["budget"] or 0), "cur": b.get("cur", "¥")}
        if "lead" in b:
            lead = b["lead"]
            if lead and (lead not in p["members"] or not (member(lead) or {}).get("auto", True)):
                raise errors.http_error(web.HTTPBadRequest, "主 AI 必须在群内且开启自动回复", fix="settings")
            p["lead"] = lead
        if p.get("lead") not in p["members"]:
            p["lead"] = ""
    save(DATA / "projects.json", PROJECTS)
    bump()
    return web.json_response({"ok": True, "chat": chat_view(p["id"], 0), "index": index_view()})


# ---------------------------------------------------------------- files and videos


SAFE = re.compile(r"[^\w.\-一-鿿]+")


async def h_upload(request):
    name = SAFE.sub("_", request.match_info["name"])[-120:] or "file"
    stored = f"{secrets.token_hex(5)}-{name}"
    f = DATA / "files" / stored
    limit = CFG.get("max_upload_mb", 2048) << 20
    n = 0
    # Keep incomplete uploads outside files/, publish only after the final chunk.
    tmp = DATA / "tmp" / ("upload-" + secrets.token_hex(16))
    try:
        with tmp.open("xb") as fh:
            async for chunk in request.content.iter_chunked(1 << 16):
                n += len(chunk)
                if n > limit:
                    return errors.response(f"文件太大（最多 {CFG.get('max_upload_mb', 2048)} MB），请换一个小些的文件", "none", status=413)
                fh.write(chunk)
        tmp.replace(f)
    except OSError:
        return errors.response("文件暂时无法保存，请稍后重试", "retry", status=507)
    finally:
        tmp.unlink(missing_ok=True)
    return web.json_response({"url": f"/files/{stored}", "size": n})


async def h_file(request):
    f = (DATA / "files" / request.match_info["name"]).resolve()
    if f.parent != (DATA / "files").resolve() or not f.is_file():
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    r = web.FileResponse(f, headers={"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=31536000, immutable"})
    if request.query.get("dl"):
        r.headers["Content-Disposition"] = "attachment"
    return r   # aiohttp answers Range / If-Range with 206 + Content-Range: progressive play and seeking


def media_derived(f, kind):
    """Cached thumbnail (jpg, first frame ~1s) or waveform peaks (json, 200 buckets) made with ffmpeg."""
    out = f.parent / ".derived" / (f.name + (".jpg" if kind == "thumb" else ".peaks.json"))
    if out.exists() and out.stat().st_mtime >= f.stat().st_mtime:
        return out
    out.parent.mkdir(exist_ok=True)
    ff = shutil.which("ffmpeg")
    if not ff:
        return None
    if kind == "thumb":
        cmd = [ff, "-y", "-loglevel", "error", "-ss", "1", "-i", str(f), "-frames:v", "1", "-vf", "scale=480:-2", str(out)]
        ok = subprocess.run(cmd, timeout=30).returncode == 0 or subprocess.run(
            [ff, "-y", "-loglevel", "error", "-i", str(f), "-frames:v", "1", "-vf", "scale=480:-2", str(out)], timeout=30).returncode == 0
        return out if ok and out.exists() else None
    raw = subprocess.run([ff, "-loglevel", "error", "-i", str(f), "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
                         capture_output=True, timeout=60).stdout
    if not raw:
        return None
    import array
    a = array.array("h", raw[: len(raw) // 2 * 2])
    n = 200
    step = max(1, len(a) // n)
    peaks = [round(max((abs(x) for x in a[i:i + step]), default=0) / 32768, 3) for i in range(0, step * n, step)][:n]
    out.write_text(json.dumps({"peaks": peaks, "seconds": round(len(a) / 8000, 2)}))
    return out


async def h_file_derived(request):
    f = (DATA / "files" / request.match_info["name"]).resolve()
    if f.parent != (DATA / "files").resolve() or not f.is_file():
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    kind = request.match_info["kind"]
    if kind not in ("thumb", "peaks"):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    try:
        out = await asyncio.to_thread(media_derived, f, kind)
    except (subprocess.TimeoutExpired, OSError):
        out = None
    if not out:
        raise errors.http_error(web.HTTPNotFound, "无法生成", fix="retry")
    return web.FileResponse(out, headers={"Cache-Control": "private, max-age=86400"})


async def h_files(request):
    """Every file sent in a project (the files page)."""
    pid = request.match_info["pid"]
    out = []
    for m in CHATS.get(pid, []):
        for name, url in re.findall(r"📎 \[([^\]]+)\]\(([^)\s]+)\)", m.get("text", "")):
            f = DATA / "files" / url.rsplit("/", 1)[-1]
            out.append({"name": name, "url": url, "who": m["who"], "at": m["at"], "seq": m["seq"], "dm": m.get("dm", ""),
                        "size": f.stat().st_size if f.exists() else 0})
    return web.json_response({"files": out[::-1]})


async def h_video(request):
    b = await errors.json_object(request)
    pid = b["project"]
    if not project(pid):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    jid = b.get("id") or secrets.token_hex(5)
    JOBS[jid] = {"id": jid, "project": pid, "url": b["url"], "dm": b.get("to") or "", "title": "", "progress": 0.0, "state": "queued",
                 "file": "", "error": "", "t": time.time()}
    bump(pid)
    asyncio.ensure_future(fetch_video(JOBS[jid]))
    return web.json_response({"id": jid})


async def fetch_video(j):
    with tempfile.TemporaryDirectory(dir=DATA / "tmp", prefix="video-") as tmp:
        await _fetch_video(j, pathlib.Path(tmp))


async def _fetch_video(j, staging):
    pid = j["project"]
    stem = secrets.token_hex(5)
    fmt = "bv*+ba/b" if shutil.which("ffmpeg") else "b"
    cmd = [sys.executable, "-m", "yt_dlp", "--no-playlist", "--newline", "--no-simulate", "-f", fmt, "--merge-output-format", "mp4",
           "-S", "vcodec:h264,res:1080,acodec:m4a", "--progress-template", "download:PROG %(progress._percent_str)s",
           "--print", "before_dl:TITLE %(title)s", "--print", "after_move:FILE %(filepath)s",
           "-o", str(staging / f"{stem}.%(ext)s"), j["url"]]
    proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        path, err, parts = "", "", 0
        j["state"] = "downloading"

        async def read_err():
            nonlocal err
            async for raw in proc.stderr:
                line = raw.decode(errors="replace").strip()
                if "ERROR" in line:
                    err = line.split("ERROR:", 1)[-1].strip()[:200]
        t = asyncio.ensure_future(read_err())
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith("PROG"):
                try:
                    v = float(line.split()[-1].rstrip("%")) / 100
                except ValueError:
                    continue
                # Video and audio come down one after the other: the bar fills to 90% on the first, then on to 100%.
                if v < j.get("_last", 0) - 0.5:
                    parts += 1
                j["_last"] = v
                j["progress"] = min(0.99, v * 0.9 if parts == 0 and fmt != "b" else 0.9 + v * 0.1 if parts else v)
                bump(pid)
            elif line.startswith("TITLE "):
                j["title"] = line[6:]
                bump(pid)
            elif line.startswith("FILE "):
                path = line[5:]
            elif "Merger" in line:
                j["state"] = "merging"
                bump(pid)
        await proc.wait()
        await t
        j.pop("_last", None)
        if proc.returncode or not path or not os.path.exists(path):
            j.update(state="failed", error=err or "这个网页没有可播放的视频")
        else:
            name = os.path.basename(path)
            pathlib.Path(path).replace(DATA / "files" / name)
            title = (j["title"] or "视频")[:80] + os.path.splitext(name)[1]
            j.update(state="done", progress=1.0, file=f"/files/{name}")
            add_msg(pid, "视频", f"📎 [{title}](/files/{name})\n{j['url']}", j["dm"])
        j["t"] = time.time()
        bump(pid)
    finally:
        if proc.returncode is None:
            proc.kill()
            await proc.wait()
        if "t" in locals():
            t.cancel()
            await asyncio.gather(t, return_exceptions=True)



# ---------------------------------------------------------------- quotas


def tz():
    return datetime.timezone(datetime.timedelta(hours=CFG.get("tz", 8)))


def when(ts):
    at = datetime.datetime.fromtimestamp(ts, tz())
    return at.strftime("%H:%M 刷新" if at.date() == datetime.datetime.now(tz()).date() else "%m-%d %H:%M 刷新")


def find_rate_limits(o):
    if isinstance(o, dict):
        if isinstance(o.get("rate_limits"), dict):
            return o["rate_limits"]
        o = list(o.values())
    if isinstance(o, list):
        for v in o:
            r = find_rate_limits(v)
            if r:
                return r
    return None


def codex_quota(home):
    logs = sorted(pathlib.Path(os.path.expanduser(home or "~/.codex")).glob("sessions/**/*.jsonl"), key=lambda p: p.stat().st_mtime)
    for f in reversed(logs[-5:]):
        for line in reversed(f.read_text(errors="replace").splitlines()):
            if "rate_limits" not in line:
                continue
            try:
                r = find_rate_limits(json.loads(line)) or {}
            except ValueError:
                continue
            q = {"pct": None, "reset": "", "week": None, "week_reset": "", "balance": "", "short": ""}
            for w in (r.get("primary") or {}, r.get("secondary") or {}):
                if w.get("used_percent") is None:
                    continue
                left = max(0, 100 - round(w["used_percent"]))
                reset = w.get("resets_at") or (f.stat().st_mtime + w["resets_in_seconds"] if w.get("resets_in_seconds") else None)
                mins = w.get("window_minutes") or 0
                if mins >= 7 * 1440 - 60:
                    q["week"], q["week_reset"] = left, when(reset) if reset else ""
                else:
                    q["pct"], q["reset"] = left, when(reset) if reset else ""
            q["short"] = f"{q['pct'] if q['pct'] is not None else q['week']}%"
            return q
    return None


async def volc_balance(ak, sk):
    """火山引擎 account balance (Ali 10-25): the billing OpenAPI QueryBalanceAcct, signed with the account's AccessKey;
    the 方舟 API key cannot read it. A pasted key often carries a stray newline, and some consoles show the secret
    base64-encoded: the signature is tried with the key as given, then decoded."""
    import base64, binascii
    ak, sk = ak.strip(), sk.strip()
    try:
        return await _volc_balance(ak, sk)
    except RuntimeError as e:
        if "SignatureDoesNotMatch" not in str(e):
            raise
        try:
            raw = base64.b64decode(sk, validate=True).decode()
        except (binascii.Error, UnicodeDecodeError):
            raise e from None
        return await _volc_balance(ak, raw)


async def _volc_balance(ak, sk):
    import hashlib, hmac
    host, region, service, body = "billing.volcengineapi.com", "cn-north-1", "billing", b"{}"  # the region the official SDK signs billing with
    query = "Action=QueryBalanceAcct&Version=2022-01-01"
    now = datetime.datetime.now(datetime.timezone.utc)
    xdate, day = now.strftime("%Y%m%dT%H%M%SZ"), now.strftime("%Y%m%d")
    payload = hashlib.sha256(body).hexdigest()
    signed = "content-type;host;x-content-sha256;x-date"
    canon = "\n".join(["POST", "/", query, f"content-type:application/json\nhost:{host}\nx-content-sha256:{payload}\nx-date:{xdate}\n", signed, payload])
    scope = f"{day}/{region}/{service}/request"
    to_sign = "\n".join(["HMAC-SHA256", xdate, scope, hashlib.sha256(canon.encode()).hexdigest()])
    k = sk.encode()
    for part in (day, region, service, "request"):
        k = hmac.new(k, part.encode(), hashlib.sha256).digest()
    sig = hmac.new(k, to_sign.encode(), hashlib.sha256).hexdigest()
    h = {"Content-Type": "application/json", "Host": host, "X-Date": xdate, "X-Content-Sha256": payload,
         "Authorization": f"HMAC-SHA256 Credential={ak}/{scope}, SignedHeaders={signed}, Signature={sig}"}
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        async with s.post(f"https://{host}/?{query}", data=body, headers=h) as r:
            j = await r.json(content_type=None)
    res = (j or {}).get("Result") or {}
    if "AvailableBalance" not in res:
        raise RuntimeError(f"火山余额没读到：{json.dumps((j or {}).get('ResponseMetadata', {}).get('Error') or j, ensure_ascii=False)[:200]}")
    return balance_value(res["AvailableBalance"], "¥")


async def balance(pr):
    """Account balance for providers that publish it (DeepSeek, Moonshot/Kimi, SiliconFlow, OpenRouter, 火山 with AK/SK)."""
    base = pr["base"].rstrip("/")
    if pr.get("volc_ak") and pr.get("volc_sk"):
        return await volc_balance(pr["volc_ak"], pr["volc_sk"])
    h = {"Authorization": "Bearer " + pr.get("key", "")}
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        if "deepseek.com" in base:
            async with s.get("https://api.deepseek.com/user/balance", headers=h) as r:
                j = await r.json()
            infos = j.get("balance_infos") or []
            sign = {"CNY": "¥", "USD": "$"}
            return {"accounts": [{"cur": sign.get(b.get("currency"), b.get("currency", "")), "amount": float(b["total_balance"])} for b in infos if "total_balance" in b]}
        if "moonshot" in base:
            async with s.get(base + "/users/me/balance", headers=h) as r:
                j = await r.json()
            return balance_value((j.get("data") or {})["available_balance"], "¥" if ".cn" in base else "$")
        if "siliconflow" in base:
            async with s.get(base + "/user/info", headers=h) as r:
                j = await r.json()
            return balance_value((j.get("data") or {})["totalBalance"], "¥")
        if "openrouter.ai" in base:
            async with s.get(base + "/credits", headers=h) as r:
                d = (await r.json()).get("data") or {}
            return balance_value(float(d["total_credits"]) - float(d["total_usage"]), "$")
        if pr.get("kind", "openai") == "openai":
            # API relays (one-api, new-api and their forks) answer the old OpenAI billing endpoints for the key itself.
            root = re.sub(r"/v\d+[a-z]*$", "", base)
            try:
                async with s.get(root + "/v1/dashboard/billing/subscription", headers=h, proxy=pr.get("proxy") or None) as r:
                    sub = await r.json(content_type=None) if r.status == 200 else None
                if not isinstance(sub, dict) or "hard_limit_usd" not in sub:
                    return None
                async with s.get(root + "/v1/dashboard/billing/usage", headers=h, proxy=pr.get("proxy") or None) as r:
                    use = await r.json(content_type=None) if r.status == 200 else {}
                total = float(sub.get("hard_limit_usd") or 0)
                if total >= 1e8:  # "unlimited" keys
                    return None
                left = total - float((use or {}).get("total_usage") or 0) / 100
                return balance_value(left, "$")
            except (ValueError, OSError):
                return None
    return None


async def refresh_quota(names=None):
    """Each member's quota: "quota" in its config says where it comes from: codex (session logs), cmd (prints JSON
    {pct, reset, week, week_reset, balance}), or, for API members, the provider's balance when it has one."""
    global QUOTA_AT
    providers = {m.get("provider") for m in CFG["members"] if names and m["name"] in names and m.get("provider")}
    if names:
        names = set(names) | {m["name"] for m in CFG["members"] if m.get("provider") in providers}
    cache = {}
    for m in list(CFG["members"]):
        if names and m["name"] not in names:
            continue
        qc = m.get("quota") or {}
        q = None
        try:
            if qc.get("type") == "codex":
                q = codex_quota(qc.get("home"))
            elif qc.get("type") == "cmd" and qc.get("cmd"):
                p = await asyncio.create_subprocess_shell(qc["cmd"], stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
                o, _ = await asyncio.wait_for(p.communicate(), 90)
                j = json.loads(o.decode() or "{}")
                q = {"pct": j.get("pct"), "reset": j.get("reset", ""), "week": j.get("week"), "week_reset": j.get("week_reset", ""),
                     "balance": j.get("balance", ""), "short": j.get("short", "")}
            elif m.get("kind", "api") == "api" and qc.get("type") != "none":
                pr = provider(m.get("provider"))
                if pr and pr["id"] in cache:
                    q = cache[pr["id"]]
                    QUOTA[m["name"]] = q
                    continue
                b = None
                if pr and (not pr.get("wallet") or pr.get("volc_ak")):
                    try:
                        b = await balance(pr)
                    except Exception as e:  # noqa: BLE001 - a failed balance API must not hide the hand-set wallet (Ali 10-26)
                        print("balance", pr["id"], type(e).__name__)
                if b and pr.get("wallet"):
                    pr.pop("wallet")
                q = wallet_quota(pr, b) if pr else None
                if not q:
                    # No balance known yet (火山方舟 has no balance API): today's cost, and the ring asks to be set.
                    t = spent_today(m["name"])
                    q = {"pct": None, "reset": "", "week": None, "week_reset": "", "balance": t, "short": t, "fill": None, "unset": True}
        except Exception as e:  # noqa: BLE001
            print("quota", m["name"], type(e).__name__)
        if not q:
            q = {"unset": True, "balance": "额度未知", "short": "额度未知"}
        q["checked_at"] = time.time()
        if m.get("kind", "api") == "api" and m.get("provider"):
            cache[m["provider"]] = q
        if q:
            QUOTA[m["name"]] = q
    QUOTA_AT = now_at()[6:]
    bump()


async def quota_loop():
    while True:
        await refresh_quota()
        await asyncio.sleep(CFG.get("quota_every", 300))


# ---------------------------------------------------------------- settings


def provider_view(p):
    k = p.get("key", "")
    return {"id": p["id"], "name": p.get("name", ""), "kind": p.get("kind", "openai"), "base": p["base"], "key": ("…" + k[-4:]) if k else "",
            "price_url": p.get("price_url", ""), "proxy": p.get("proxy", ""), "models": p.get("models") or [], "models_at": p.get("models_at", "")}


def config_view():
    return {
        "name": CFG.get("name", ""), "providers": [provider_view(p) for p in CFG["providers"]],
        "members": [{k: v for k, v in m.items() if k != "env"} | {"env": sorted((m.get("env") or {}).keys())}
                    | member_avatars.view(DATA, m) for m in CFG["members"]],
        "skills": skills_list(),
        "settings": {k: CFG.get(k, d) for k, d in SETTING_KEYS.items()},
    }


async def h_config(request):
    return web.json_response(config_view())


# 高级模式 (Ali 10-25): the server-wide choices, edited from the app.
SETTING_KEYS = {"name": "AI 协作", "context": "standard", "helper": "", "summary_helper": "", "price_helper": "", "update_every": 300,
                # 权限 (Ali 10-26: 弄个设置 完全访问和完全同意，每次都让我点一堆同意): off by default, the owner turns them on.
                "full_access": False, "approve_all": False,
                "member_timeout_ms": MEMBER_TIMEOUT_DEFAULT_MS,
                "backups": {"interval_hours": 0, "keep": 7}}


async def h_settings(request):
    b = await errors.json_object(request)
    if "member_timeout_ms" in b and (type(b["member_timeout_ms"]) is not int or b["member_timeout_ms"] < 0):
        raise errors.http_error(web.HTTPBadRequest, "成员等待时间必须是非负整数（毫秒），填 0 可关闭", fix="settings")
    if "backups" in b:
        try:
            b["backups"] = backup.validate_options(b["backups"])
        except backup.BackupError as e:
            return errors.response(str(e), "settings", status=400)
    for k in SETTING_KEYS:
        if k in b:
            CFG[k] = b[k]
    save_cfg()
    bump()
    return web.json_response({k: CFG.get(k, d) for k, d in SETTING_KEYS.items()})


async def fetch_models(pr):
    """Every model the interface offers. Works for the vendors and for API relays (中转站, one-api/new-api and the
    like): a base typed without /v1 is found by trying again with it, and then kept that way."""
    base = pr["base"].rstrip("/")
    if pr.get("kind") == "anthropic" and base.endswith("/v1"):
        base = pr["base"] = base[:-3]  # /v1/messages is added when calling
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=30)) as s:
        if pr.get("kind") == "anthropic":
            h = {"x-api-key": pr.get("key", ""), "Authorization": "Bearer " + pr.get("key", ""), "anthropic-version": "2023-06-01"}
            tries = [(base, base + "/v1/models?limit=1000")]
        else:
            h = {"Authorization": "Bearer " + pr.get("key", "")}
            tries = [(base, base + "/models")]
            if not re.search(r"/v\d+[a-z]*$", base):
                tries.append((base + "/v1", base + "/v1/models"))
        err = ""
        for b, url in tries:
            async with s.get(url, headers=h, proxy=pr.get("proxy") or None) as r:
                body = await r.text()
                if r.status >= 400:
                    err = err or f"拉模型列表失败 HTTP {r.status}：{body[:200]}"
                    continue
                try:
                    j = json.loads(body)
                except ValueError:
                    err = err or "这个地址返回的不是接口数据，检查一下地址（中转站一般以 /v1 结尾）"
                    continue
            items = j.get("data") if isinstance(j, dict) else j
            if not isinstance(items, list):
                err = err or "这个地址返回的不是模型列表"
                continue
            pr["base"] = b
            break
        else:
            raise RuntimeError(err)
    ids = sorted({(x.get("id") if isinstance(x, dict) else str(x)) for x in items or [] if x})
    pr["models"] = [[i, i] for i in ids]
    pr["models_at"] = now_at()
    save_cfg()
    return pr["models"]


async def h_provider(request):
    if request.method == "DELETE":
        CFG["providers"] = [p for p in CFG["providers"] if p["id"] != request.match_info["id"]]
        save_cfg()
        bump()
        return web.json_response({"ok": True})
    b = await errors.json_object(request)
    pr = provider(b.get("id")) if b.get("id") else None
    if not pr:
        pr = {"id": secrets.token_hex(4)}
        CFG["providers"].append(pr)
    for k in ("name", "kind", "base", "proxy", "price_url"):
        if b.get(k) is not None:
            pr[k] = b[k].strip()
    if b.get("key"):
        pr["key"] = b["key"].strip()
    if not pr.get("base"):
        CFG["providers"].remove(pr)
        raise errors.http_error(web.HTTPBadRequest, "请填写接口地址后重试", fix="edit_base")
    save_cfg()
    err = {"error": "", "fix": "none"}
    try:
        await fetch_models(pr)
    except Exception as e:  # noqa: BLE001 - kept, the app shows why the list is empty
        err = errors.upstream(e)
    bump()
    return web.json_response(provider_view(pr) | err)


async def h_models(request):
    pr = provider(request.match_info["id"])
    if not pr:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    try:
        return web.json_response({"models": await fetch_models(pr)})
    except Exception as exc:
        raise errors.upstream_http(web.HTTPBadGateway, exc) from None


MEMBER_KEYS = ("name", "role", "kind", "provider", "model", "models", "efforts", "effort", "persona", "auto", "cmd", "cwd", "priority", "skills", "tier",
               "quota", "models_cmd", "timeout", "send_effort", "extra_body", "max_tokens", "voice", "resume_cmd", "session_re", "context",
               "price", "prices", "daily_cap", "daily_cap_cur", "daily_tokens", "owns", "avoid", "style", "workspace_tools", "approve_all")


async def h_member(request):
    if request.method == "DELETE":
        n = request.match_info["name"]
        old_avatars = [m.get("avatar") for m in CFG["members"] if m["name"] == n]
        CFG["members"] = [m for m in CFG["members"] if m["name"] != n]
        for p in PROJECTS:
            p["members"] = [x for x in p["members"] if x != n]
        save_cfg()
        save(DATA / "projects.json", PROJECTS)
        for value in old_avatars:
            member_avatars.clean_unused(sys.modules[__name__], value)
        bump()
        chorus2.retry_unavailable()
        return web.json_response({"ok": True})
    b = await errors.json_object(request)
    role_update = task_cards.role_fields(b)
    if "workspace_tools" in b:
        try:
            role_update["workspace_tools"] = workspace_tools.settings(b["workspace_tools"])
        except workspace_tools.ToolError as exc:
            raise errors.http_error(web.HTTPBadRequest, "成员的副本工具设置不对，请检查目录和权限", fix="settings") from None
    old = b.get("old_name") or b.get("name")
    m = member(old)
    if not m:
        if member(b.get("name", "")):
            raise errors.http_error(web.HTTPConflict, "已经有这个名字了", fix="settings")
        m = {"name": b["name"]}
        CFG["members"].append(m)
    if m.get("price") or m.get("prices"):
        m.setdefault("price_model", m.get("model"))
        m.setdefault("price_provider", m.get("provider"))
    for k in MEMBER_KEYS:
        if k in b:
            m[k] = role_update[k] if k in role_update else b[k]
    if "price" in b or "prices" in b:
        m.update(price_model=m.get("model"), price_provider=m.get("provider"))
    if "env" in b:  # values only replace what is sent; an empty value removes the variable
        env = m.setdefault("env", {})
        for k, v in b["env"].items():
            if v:
                env[k] = v
            else:
                env.pop(k, None)
    if old != m["name"]:
        for p in PROJECTS:
            p["members"] = [m["name"] if x == old else x for x in p["members"]]
        save(DATA / "projects.json", PROJECTS)
    for p in PROJECTS:
        if p.get("lead") == old:
            p["lead"] = m["name"] if m.get("auto", True) and m["name"] in p["members"] else ""
    save(DATA / "projects.json", PROJECTS)
    save_cfg()
    bump()
    chorus2.retry_unavailable()
    asyncio.ensure_future(refresh_quota([m["name"]]))
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- skills


def gh_zip(url):
    """A GitHub URL as (zip URL, folder inside the repo or "")."""
    m = re.match(r"https?://github\.com/([^/]+)/([^/#?]+?)(?:\.git)?(?:/(?:tree|blob)/([^/]+)(?:/(.*))?)?/?$", url)
    if not m:
        return None
    owner, repo, ref, sub = m.groups()
    sub = (sub or "").removesuffix("/SKILL.md")
    return f"https://codeload.github.com/{owner}/{repo}/zip/{ref or 'HEAD'}", sub


async def h_skill_install(request):
    url = (await errors.json_object(request))["url"].strip()
    root = DATA / "skills"
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=120)) as s:
        g = gh_zip(url)
        src, sub = (g if g else (url, ""))
        if not g and "github.com" in url and "/blob/" in url:
            src = url.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/")
        async with s.get(src) as r:
            if r.status >= 400:
                raise errors.http_error(web.HTTPBadRequest, "下载失败，请检查下载地址后重试", fix="edit_base")
            data = await r.read()
    installed = []
    state = load(root / "state.json", {})
    if data[:2] == b"PK":
        z = zipfile.ZipFile(io.BytesIO(data))
        names = z.namelist()
        top = names[0].split("/")[0] + "/" if g else ""
        base = top + (sub + "/" if sub else "")
        dirs = sorted({n[:-len("SKILL.md")] for n in names if n.startswith(base) and n.endswith("SKILL.md")})
        # A repo of many skills installs them all; a folder with nested SKILL.md files keeps only the outermost.
        dirs = [d for d in dirs if not any(d != o and d.startswith(o) for o in dirs)]
        for d in dirs:
            meta = frontmatter(z.read(d + "SKILL.md").decode(errors="replace"))
            name = SAFE.sub("-", meta.get("name") or d.rstrip("/").split("/")[-1] or "skill")
            dest = root / name
            shutil.rmtree(dest, ignore_errors=True)
            for n in names:
                if n.startswith(d) and not n.endswith("/"):
                    p = (dest / n[len(d):]).resolve()
                    if dest.resolve() in p.parents:
                        p.parent.mkdir(parents=True, exist_ok=True)
                        p.write_bytes(z.read(n))
            installed.append(name)
    else:
        text = data.decode(errors="replace")
        meta = frontmatter(text)
        if not meta.get("name") and not text.lstrip().startswith("#"):
            raise errors.http_error(web.HTTPBadRequest, "这个地址里没有找到 SKILL.md", fix="none")
        name = SAFE.sub("-", meta.get("name") or url.rstrip("/").split("/")[-2])
        (root / name).mkdir(parents=True, exist_ok=True)
        (root / name / "SKILL.md").write_text(text)
        installed.append(name)
    if not installed:
        raise errors.http_error(web.HTTPBadRequest, "这个地址里没有找到 SKILL.md", fix="none")
    for n in installed:
        state[n] = {"on": True, "source": url}
    save(root / "state.json", state)
    bump()
    return web.json_response({"installed": installed, "skills": skills_list()})


async def h_skill(request):
    root = DATA / "skills"
    d = request.match_info["dir"]
    state = load(root / "state.json", {})
    if request.method == "DELETE":
        shutil.rmtree(root / SAFE.sub("-", d), ignore_errors=True)
        state.pop(d, None)
    else:
        state.setdefault(d, {})["on"] = bool((await errors.json_object(request)).get("on", True))
    save(root / "state.json", state)
    bump()
    return web.json_response({"skills": skills_list()})


async def h_skills(request):
    return web.json_response({"skills": skills_list()})


# ---------------------------------------------------------------- memory and imports


def mem_file(scope):
    return DATA / "memory" / (SAFE.sub("_", scope) + ".json")


def memory(scope):
    return load(mem_file(scope), [])


def save_memory(scope, items):
    save(mem_file(scope), items)
    bump()


async def h_memory(request):
    """Memories: "all" (everyone), "m-<member>" or "p-<project>". They go into every prompt of that scope."""
    if request.method == "GET":
        sc = request.query.get("scope")
        if sc:
            return web.json_response({"scope": sc, "items": memory(sc)})
        scopes = ["all"] + ["m-" + m["name"] for m in CFG["members"]] + ["p-" + p["id"] for p in PROJECTS if not p.get("archived")]
        return web.json_response({"scopes": [{"scope": x, "count": len(memory(x))} for x in scopes]})
    if request.method == "DELETE":
        sc, i = request.match_info["scope"], request.match_info["id"]
        save_memory(sc, [e for e in memory(sc) if e["id"] != i])
        return web.json_response({"ok": True})
    b = await errors.json_object(request)
    sc = b["scope"]
    items = memory(sc)
    e = next((x for x in items if x["id"] == b.get("id")), None)
    if e:
        e["text"] = b["text"].strip()
    else:
        items.append({"id": secrets.token_hex(4), "text": b["text"].strip(), "source": b.get("source", "Ali"), "at": now_at()})
    save_memory(sc, items)
    return web.json_response({"items": items})


def helper():
    """The member that tidies imports: config "helper", else the first API member."""
    return member(CFG.get("helper", "")) or next((m for m in CFG["members"] if m.get("kind", "api") == "api" and m.get("provider")), None)


def cheapest():
    """For 前情提要: config "summary_helper", else an API member on a small/cheap model, else the usual helper."""
    hit = member(CFG.get("summary_helper", ""))
    if hit:
        return hit
    small = re.compile(r"flash|mini|lite|haiku|nano|small|turbo|air|chat", re.I)
    return next((m for m in CFG["members"] if m.get("kind", "api") == "api" and m.get("provider") and small.search(m.get("model", ""))), None) or helper()


async def complete(system, prompt, cheap=False):
    h = cheapest() if cheap else helper()
    if not h:
        raise RuntimeError("没有可以用来整理的 API 成员（设置里选一个「整理助手」）")
    r = {"who": h["name"], "text": "", "note": ""}
    await call_api(None, h, r, system, prompt, h.get("model", ""), "")
    return r["text"]


async def file_bytes(b):
    if b.get("text"):
        return b["text"].encode(), b.get("name") or "粘贴.txt"
    f = (DATA / "files" / b["url"].rsplit("/", 1)[-1]).resolve()
    if f.parent != (DATA / "files").resolve() or not f.is_file():
        raise errors.http_error(web.HTTPNotFound, "找不到这个文件", fix="retry")
    return f.read_bytes(), b.get("name") or f.name.split("-", 1)[-1]


async def h_memory_import(request):
    """Another app's memories (an export file or pasted text) into one scope, tidied into short entries."""
    b = await errors.json_object(request)
    data, name = await file_bytes(b)
    text = data.decode("utf-8-sig", errors="replace")
    if data[:2] == b"PK":
        z = zipfile.ZipFile(io.BytesIO(data))
        text = "\n\n".join(z.read(n).decode(errors="replace") for n in z.namelist() if re.search(r"memor|记忆|saved", n, re.I))
    source = b.get("source") or importers.source_of_text(name + " " + text[:2000])
    sc = b.get("scope") or ("m-" + (importers.guess_member(source, CFG["members"], CFG["providers"]) or "") if source else "all")
    if sc == "m-":
        sc = "all"
    entries = []
    try:
        out = await complete("把下面这些 AI 记忆整理成一条条独立、简短的事实，每条一行，以「- 」开头。保留原意，不要编造，不要加别的话。",
                             text[:60000])
        entries = [x.strip()[2:].strip() for x in out.splitlines() if x.strip().startswith("- ")]
    except Exception as e:  # noqa: BLE001 - without a helper the text is split by lines
        print("memory import:", type(e).__name__)
    if not entries:
        entries = [x.strip(" -•*\t") for x in re.split(r"\n+", text) if len(x.strip(" -•*\t")) > 1][:500]
    items = memory(sc)
    have = {e["text"] for e in items}
    for t in entries:
        if t not in have:
            items.append({"id": secrets.token_hex(4), "text": t, "source": source or name, "at": now_at()})
    save_memory(sc, items)
    return web.json_response({"scope": sc, "added": len(entries), "items": items})


PARSED = {}  # token -> conversations found in an upload, until Ali picks which to bring in


async def h_import(request):
    """Step 1: read a chat export and list what is in it. Unknown formats are converted by the helper model."""
    b = await errors.json_object(request)
    data, name = await file_bytes(b)
    convs = await asyncio.get_running_loop().run_in_executor(None, importers.parse, data, name)
    if not convs and data[:2] != b"PK":
        try:
            out = await complete(
                "下面是一段聊天记录。把它转成 JSON 数组，每条消息一个对象 {\"role\": \"user\" 或 \"assistant\", \"text\": \"…\"}。"
                "user 是提问的人。只输出 JSON。", data.decode(errors="replace")[:80000])
            j = json.loads(out[out.find("["):out.rfind("]") + 1])
            convs = [{"title": re.sub(r"\.\w+$", "", name), "source": "ai", "messages": [m for m in j if m.get("text")]}]
        except Exception as e:  # noqa: BLE001
            print("import via helper:", type(e).__name__)
    convs = [c for c in convs if c["messages"]]
    if not convs:
        raise errors.http_error(web.HTTPBadRequest, "没认出这个文件里的对话", fix="none")
    tok = secrets.token_hex(6)
    PARSED[tok] = convs
    return web.json_response({"token": tok, "conversations": [{
        "i": i, "title": c["title"], "source": c["source"], "count": len(c["messages"]),
        "at": datetime.datetime.fromtimestamp(c["messages"][0]["ts"], tz()).strftime("%Y-%m-%d") if c["messages"][0].get("ts") else "",
        "member": importers.guess_member(c["source"], CFG["members"], CFG["providers"])} for i, c in enumerate(convs)]})


async def h_import_commit(request):
    """Step 2: the picked conversations become projects (one each, or all in one), or go into a member's private chat."""
    b = await errors.json_object(request)
    convs = PARSED.get(b["token"])
    if convs is None:
        raise errors.http_error(web.HTTPGone, "导入已过期，请重新选文件", fix="retry")
    picks = [convs[i] for i in b.get("picks", range(len(convs)))]
    mode = b.get("mode", "projects")  # projects | one | dm
    made = []

    def add(pid, c, who, dm):
        msgs = CHATS.setdefault(pid, [])
        for x in c["messages"]:
            ts = x.get("ts") or time.time()
            at = datetime.datetime.fromtimestamp(ts, tz()).strftime("%m-%d %H:%M")
            speaker = "Ali" if x["role"] == "user" else (x.get("who") if c["source"] == "text" and x.get("who") else who)
            m = {"seq": (msgs[-1]["seq"] + 1) if msgs else 1, "who": speaker, "at": at, "text": x["text"].strip(), "dm": dm, "ts": ts,
                 "imported": c["source"], "rev": 0}
            msgs.append(m)
        persist(pid)

    for c in picks:
        who = b.get("member") or importers.guess_member(c["source"], CFG["members"], CFG["providers"]) or {
            "chatgpt": "ChatGPT", "claude": "Claude", "gemini": "Gemini", "deepseek": "DeepSeek", "codex": "Codex",
            "claude-code": "Claude Code"}.get(c["source"], "AI")
        if mode == "dm":
            pid = b["project"]
            add_msg(pid, "导入", f"—— 导入「{c['title']}」{len(c['messages'])} 条 ——", who)
            add(pid, c, who, who)
            made.append(pid)
            continue
        if mode == "one" and made:
            pid = made[0]
            add_msg(pid, "导入", f"—— {c['title']} ——")
        else:
            pid = datetime.datetime.now().strftime("%y%m%d") + "-" + secrets.token_hex(3)
            PROJECTS.append({"id": pid, "name": b.get("name") if mode == "one" and b.get("name") else c["title"][:40],
                             "brief": f"从 {c['source']} 导入", "members": [who] if member(who) else [], "created": time.time()})
            CHATS[pid] = []
            made.append(pid)
        add(pid, c, who, "")
    save(DATA / "projects.json", PROJECTS)
    PARSED.pop(b["token"], None)
    bump()
    return web.json_response({"projects": list(dict.fromkeys(made))})


# ---------------------------------------------------------------- voices


DOUBAO_TTS = "https://openspeech.bytedance.com/api/v3/tts/unidirectional"


def speakable(text):
    """What is read aloud: no code, links or markdown marks."""
    t = re.sub(r"```.*?```", "（代码略）", text, flags=re.S)
    t = re.sub(r"📎 \[([^\]]+)\]\([^)]+\)", r"文件 \1", t)
    t = re.sub(r"https?://\S+", "链接", t)
    return re.sub(r"[*`#>_|]", "", t).strip()[:1500]


async def doubao_tts(key, text, v):
    """Doubao speech 2.0 (seed-tts-2.0; voices cloned in the console, S_…, through seed-icl-2.0). Never the 1.0 API:
    it repeats sentence endings."""
    voice = v.get("voice") or "zh_female_vv_uranus_bigtts"
    h = {"X-Api-Resource-Id": "seed-icl-2.0" if voice.startswith("S_") else "seed-tts-2.0", "X-Api-Request-Id": secrets.token_hex(16)}
    if ":" in key:
        app, tok = key.split(":", 1)
        h.update({"X-Api-App-Id": app, "X-Api-Access-Key": tok})
    else:
        h["X-Api-Key"] = key
    audio = {"format": "mp3", "sample_rate": 24000, "speech_rate": max(-50, min(100, round((float(v.get("speed", 1)) - 1) * 100)))}
    add = {"model_type": 4} if voice.startswith("S_") else {}
    if v.get("style"):
        add["context_texts"] = [v["style"]]
    if v.get("pitch"):
        add["post_process"] = {"pitch": int(v["pitch"])}
    out = bytearray()
    for attempt in range(2):
        params = {"text": text, "speaker": voice, "audio_params": audio}
        if add:
            params["additions"] = json.dumps(add, ensure_ascii=False)
        async with ClientSession(trust_env=True, timeout=ClientTimeout(total=120)) as s:
            async with s.post(DOUBAO_TTS, json={"user": {"uid": "chorus"}, "req_params": params}, headers=h) as r:
                if r.status >= 400:
                    raise RuntimeError(f"豆包语音 HTTP {r.status} {(await r.text())[:200]}")
                err = ""
                async for line in r.content:
                    line = line.strip()
                    if not line:
                        continue
                    msg = json.loads(line)
                    code = msg.get("code", 0)
                    if code == 0 and msg.get("data"):
                        import base64
                        out += base64.b64decode(msg["data"])
                    elif code not in (0, 20000000):
                        err = f"{code} {msg.get('message', '')}"
                        break
        if out:
            return bytes(out), "mp3"
        if attempt == 0 and add.keys() - {"model_type"}:
            add = {k: v2 for k, v2 in add.items() if k == "model_type"}  # a voice that refuses style or pitch still speaks
            continue
        raise RuntimeError("豆包语音：" + (err or "没有声音"))


async def mimo_tts(pr, text, v):
    """MiMo-V2.5-TTS: chat/completions with the text as the assistant message; style hint as the user message."""
    msgs = ([{"role": "user", "content": v["style"]}] if v.get("style") else []) + [{"role": "assistant", "content": text}]
    body = {"model": v.get("model") or "mimo-v2.5-tts", "messages": msgs, "audio": {"format": "wav", "voice": v.get("voice") or "冰糖"}}
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=120)) as s:
        async with s.post(pr["base"].rstrip("/") + "/chat/completions", json=body, headers={"api-key": pr.get("key", "")},
                          proxy=pr.get("proxy") or None) as r:
            if r.status >= 400:
                raise RuntimeError(f"语音 HTTP {r.status} {(await r.text())[:200]}")
            j = await r.json(content_type=None)
    import base64
    return base64.b64decode(j["choices"][0]["message"]["audio"]["data"]), "wav"


async def openai_tts(pr, text, v):
    body = {"model": v.get("model") or "gpt-4o-mini-tts", "voice": v.get("voice") or "alloy", "input": text,
            "speed": float(v.get("speed", 1)), "response_format": "mp3"}
    if v.get("style"):
        body["instructions"] = v["style"]
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=120)) as s:
        async with s.post(pr["base"].rstrip("/") + "/audio/speech", json=body, headers={"Authorization": "Bearer " + pr.get("key", "")},
                          proxy=pr.get("proxy") or None) as r:
            if r.status >= 400:
                raise RuntimeError(f"语音 HTTP {r.status} {(await r.text())[:200]}")
            return await r.read(), "mp3"


async def h_tts(request):
    """A message (or, for the voice settings' preview, any text) read in the member's own voice. Cached by content."""
    b = await errors.json_object(request)
    if b.get("seq"):
        m = next((x for x in CHATS.get(b["project"], []) if x["seq"] == int(b["seq"])), None)
        if not m:
            raise errors.http_error(web.HTTPNotFound, fix="retry")
        who, text = m["who"], m["text"]
    else:
        who, text = b["member"], b.get("text") or "你好，我是" + b["member"] + "。"
    try:
        return web.json_response({"url": await tts_file(who, text, b.get("voice") or {})})
    except ValueError as e:
        raise errors.upstream_http(web.HTTPBadRequest, e) from None


async def tts_file(who, text, voice=None):
    """Text in the member's own voice -> /files URL (content-cached). ValueError when there is nothing to read or no engine."""
    mm = member(who) or {}
    v = {**(mm.get("voice") or {}), **(voice or {})}
    text = speakable(text)
    if not text:
        raise ValueError("没有可以读的文字")
    tag = hashlib.sha1(json.dumps([text, v], sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    for ext in ("mp3", "wav"):
        if (DATA / "files" / f"tts-{tag}.{ext}").exists():
            return f"/files/tts-{tag}.{ext}"
    tts = CFG.get("tts") or {}
    engine = v.get("engine") or ("doubao" if tts.get("doubao_key") else "openai")
    if engine == "doubao":
        if not tts.get("doubao_key"):
            raise ValueError("还没填豆包语音的 key（设置 → 语音）")
        data, ext = await doubao_tts(tts["doubao_key"], text, v)
    elif engine == "mimo":
        pr = provider(v.get("provider") or tts.get("provider") or "mimo")
        if not pr or not pr.get("key"):
            raise ValueError("还没设置 MiMo 的接口（设置 → 语音）")
        data, ext = await mimo_tts(pr, text, v)
    else:
        pr = provider(v.get("provider") or tts.get("provider") or "openai")
        if not pr or not pr.get("key"):
            raise ValueError("还没设置朗读用的接口（设置 → 语音）")
        data, ext = await openai_tts(pr, text, v)
    tmp = DATA / "tmp" / ("tts-" + secrets.token_hex(16))
    try:
        tmp.write_bytes(data)
        tmp.replace(DATA / "files" / f"tts-{tag}.{ext}")
    finally:
        tmp.unlink(missing_ok=True)
    return f"/files/tts-{tag}.{ext}"


VOICES = {
    "doubao": [["zh_female_vv_uranus_bigtts", "薇薇（温柔女声）"], ["zh_female_xiaohe_uranus_bigtts", "小何（自然女声）"],
               ["zh_male_m191_uranus_bigtts", "云舟（沉稳男声）"], ["zh_male_taocheng_uranus_bigtts", "小天（少年音）"],
               ["saturn_zh_female_cancan_tob", "灿灿（活泼）"]],
    "openai": [[x, x] for x in ("alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse")],
}


async def h_voices(request):
    tts = CFG.get("tts") or {}
    return web.json_response({"voices": VOICES, "doubao": bool(tts.get("doubao_key")), "provider": tts.get("provider", ""),
                              "doubao_key": ("…" + tts["doubao_key"][-4:]) if tts.get("doubao_key") else ""})


async def h_tts_config(request):
    b = await errors.json_object(request)
    tts = CFG.setdefault("tts", {})
    if b.get("doubao_key") is not None:
        tts["doubao_key"] = b["doubao_key"].strip()
    if b.get("provider") is not None:
        tts["provider"] = b["provider"]
    save_cfg()
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- start


# A new server starts with the common providers (keys empty, filled in from the app) and one member per model,
# named after the model; people rename them as they like.
# Vendors the app offers in 简洁模式「加一个 AI」: pick one, paste a key. Nothing is installed until the user does
# (Ali 10-25: 不给模型带任何东西; a new server starts with no members, no personas, no keys).
# Local catalog estimates per million tokens; explicit/pasted prices take precedence.
CATALOG_PRICES = {
    "gpt-5": {"in": 1.25, "out": 10, "cached": .125, "cur": "$"},
    "claude-sonnet-4-5": {"in": 3, "out": 15, "cur": "$"},
    "gemini-2.5-flash": {"in": .3, "out": 2.5, "cur": "$"},
    "deepseek-chat": {"in": 2, "out": 3, "cached": .2, "cur": "¥"},
    "grok-4": {"in": 3, "out": 15, "cur": "$"},
    "kimi-k2-turbo-preview": {"in": 16, "out": 64, "cur": "¥"},
    "doubao-seed-1-6-250615": {"in": .8, "out": 8, "cur": "¥"},
    "glm-4.6": {"in": 2, "out": 8, "cur": "¥"},
}
CATALOG = [
    # name, provider id, provider name, kind, base, model
    ("GPT", "openai", "OpenAI", "openai", "https://api.openai.com/v1", "gpt-5"),
    ("Claude", "anthropic", "Anthropic", "anthropic", "https://api.anthropic.com", "claude-sonnet-4-5"),
    ("Gemini", "gemini", "Google Gemini", "openai", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash"),
    ("DeepSeek", "deepseek", "DeepSeek", "openai", "https://api.deepseek.com", "deepseek-chat"),
    ("Grok", "xai", "xAI", "openai", "https://api.x.ai/v1", "grok-4"),
    ("Kimi", "moonshot", "Moonshot（Kimi）", "openai", "https://api.moonshot.cn/v1", "kimi-k2-turbo-preview"),
    ("豆包", "ark", "火山方舟（豆包）", "openai", "https://ark.cn-beijing.volces.com/api/v3", "doubao-seed-1-6-250615"),
    ("GLM", "zhipu", "智谱（GLM）", "openai", "https://open.bigmodel.cn/api/paas/v4", "glm-4.6"),
]


async def h_catalog(request):
    return web.json_response({"vendors": [{"id": i, "name": pn, "member": n, "kind": k, "base": b, "model": m, "price": {**CATALOG_PRICES[m], "source": "catalog", "estimated": True}} for n, i, pn, k, b, m in CATALOG]})


async def h_quick_add(request):
    """简洁模式: a vendor and a key become a provider plus one member named after the model (renamable later)."""
    b = await errors.json_object(request)
    v = next((x for x in CATALOG if x[1] == b.get("vendor")), None)
    if not v or not (b.get("key") or "").strip():
        raise errors.http_error(web.HTTPBadRequest, "请先选择厂商并粘贴接口密钥", fix="repaste")
    n, vid, pn, kind, base, model = v
    pr = {"id": vid if not provider(vid) else f"{vid}-{secrets.token_hex(2)}", "name": pn, "kind": kind, "base": b.get("base") or base,
          "key": b["key"].strip()}
    try:
        await fetch_models(pr)
    except Exception as e:  # noqa: BLE001
        raise errors.upstream_http(web.HTTPBadRequest, e) from None
    CFG["providers"].append(pr)
    name = (b.get("name") or n).strip()
    while member(name):
        name += "2"
    ids = [x[0] for x in pr.get("models") or []]
    CFG["members"].append({"name": name, "kind": "api", "provider": pr["id"], "auto": True,
                           "model": model if model in ids or not ids else ids[0]})
    for p in PROJECTS:
        if b.get("join_all", True) and name not in p["members"]:
            p["members"].append(name)
    save(DATA / "projects.json", PROJECTS)
    save_cfg()
    bump()
    return web.json_response({"name": name, "provider": provider_view(pr)})


async def h_topic(request):
    """新话题: the member starts afresh from here; what came before is left to the 前情提要."""
    b = await errors.json_object(request)
    p = project(b.get("project"))
    if not p:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    msgs = CHATS.get(p["id"], [])
    dm = b.get("to") or ""
    p.setdefault("topics", {})[dm] = (msgs[-1]["seq"] + 1) if msgs else 0
    save(DATA / "projects.json", PROJECTS)
    add_msg(p["id"], "Ali", "—— 新话题 ——", dm, divider=True)
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- 体检 (Ali 10-25: how do we know a setup worked)


def _num(s):
    try:
        return float(s)
    except ValueError:
        return None


async def run_checks():
    """Every part a working server needs, each ok or not with what to do. Free: model lists, not completions."""
    out = [{"id": "server", "label": "服务器", "ok": True, "detail": f"在运行，端口 {PORT}"}]
    out.append({"id": "password", "label": "密码", "ok": bool(CFG.get("password")) and len(CFG["password"]) >= 6,
                "detail": "已设置" if len(CFG.get("password", "")) >= 6 else "太短，至少 6 位"})
    for pr in CFG["providers"]:
        if not pr.get("key"):
            out.append({"id": "p-" + pr["id"], "label": pr.get("name") or pr["base"], "ok": False, "detail": "没有填 key"})
            continue
        try:
            ms = await asyncio.wait_for(fetch_models(pr), 25)
            out.append({"id": "p-" + pr["id"], "label": pr.get("name") or pr["base"], "ok": True, "detail": f"模型列表可读（{len(ms)} 个），不代表聊天额度充足"})
        except Exception as e:  # noqa: BLE001
            detail = errors.upstream(e)
            out.append({"id": "p-" + pr["id"], "label": pr.get("name") or pr["base"], "ok": False,
                        "detail": detail["error"], **detail})
    for m in CFG["members"]:
        k = m.get("kind", "api")
        if k == "api":
            pr = provider(m.get("provider"))
            ok = bool(pr and pr.get("key"))
            out.append({"id": "m-" + m["name"], "label": m["name"], "ok": False, "state": "unknown" if ok else "failed", "detail": "接口已配置；聊天能力尚未验证" if ok else "接口没配好"})
        else:
            cmd = dsh_cmd(m) if k == "dsh" else m.get("cmd", "")
            exe = shlex.split(cmd)[0] if cmd.strip() else ""
            found = bool(exe) and (shutil.which(exe) or os.path.exists(exe))
            out.append({"id": "m-" + m["name"], "label": m["name"], "ok": bool(found),
                        "detail": f"命令 {exe} 可用" if found else (f"找不到命令 {exe}" if exe else "没有填命令")})
    for m in CFG["members"]:
        name = m["name"]
        last = LAST_RESULT.get(name)
        item = next((i for i in out if i["id"] == "m-" + name), None)
        if last and item:
            fresh = time.time() - last["at"] < 300
            item.update(ok=last["ok"] and fresh, state=("ok" if last["ok"] else "failed") if fresh else "unknown",
                        code=last["code"], checked_at=last["at"], member=name,
                        detail=("最近聊天成功" if last["ok"] else "最近聊天失败：" + last["code"]) if fresh else "上次聊天结果已过期，当前未知")
        q = QUOTA.get(name) or {}
        low = None
        if q.get("pct") is not None and q["pct"] <= 0:
            low = "5 小时额度用完了"
        elif q.get("week") is not None and q["week"] <= 0:
            low = "本周额度用完了"
        elif q.get("accounts") and all(a["amount"] <= 0 for a in q["accounts"]):
            low = f"没钱了（余额 {q.get('balance')}）"
        elif q.get("amount") is not None and q["amount"] <= 0:
            low = f"没钱了（余额 {q.get('balance')}）"
        known = not q.get("unset") and (q.get("pct") is not None or q.get("week") is not None or q.get("accounts") or q.get("amount") is not None)
        fresh = time.time() - q.get("checked_at", 0) < 300
        state = "unknown" if q.get("source") == "estimate" or len(q.get("accounts") or []) > 1 else "failed" if low and fresh else "ok" if known and fresh else "unknown"
        out.append({"id": "q-" + name, "label": name + " 的额度", "member": name, "ok": state == "ok", "state": state,
                    "code": "quota_exhausted" if low else "", "checked_at": q.get("checked_at", 0),
                    "detail": "多币种余额：" + q.get("balance", "") + "；当前模型使用的币种未确认" if len(q.get("accounts") or []) > 1 else low if low and fresh and q.get("source") != "estimate" else "手填余额的本地估算，未与官方账单核对" if q.get("source") == "estimate" else (q.get("short") or q.get("balance")) if known and fresh else "额度未知或已过期，模型列表可读不能证明有额度"})
    for item in out:
        item.setdefault("state", "ok" if item["ok"] else "failed")
        item.setdefault("checked_at", time.time())
    yt = shutil.which("yt-dlp")
    out.append({"id": "yt-dlp", "label": "网页视频（yt-dlp）", "ok": bool(yt), "detail": "可用" if yt else "没装：pip install yt-dlp", "optional": True})
    ff = shutil.which("ffmpeg")
    out.append({"id": "ffmpeg", "label": "视频合成（ffmpeg）", "ok": bool(ff), "detail": "可用" if ff else "没装：apt install ffmpeg", "optional": True})
    if not CFG["members"]:
        out.append({"id": "members", "label": "成员", "ok": False, "detail": "还没有成员：在 app 里加一个 AI"})
    return out


async def h_check(request):
    items = await run_checks()
    return web.json_response({"ok": all(i["ok"] for i in items if not i.get("optional")), "items": items})


def doctor():
    """python server.py doctor: the same checks, for the install script and for an AI doing the setup."""
    setup()
    items = asyncio.run(run_checks())
    for i in items:
        print(("✅" if i["ok"] else ("⚠️ " if i.get("optional") else "❌")), i["label"], "—", i["detail"])
    bad = [i for i in items if not i["ok"] and not i.get("optional")]
    print("\n全部通过" if not bad else f"\n还有 {len(bad)} 项没通过")
    return 0 if not bad else 1


def setup():
    global CFG, PROJECTS
    for d in ("chats", "files", "skills", "tmp", "memory", "summaries", "work"):
        (DATA / d).mkdir(parents=True, exist_ok=True)
    CFG = {**DEFAULT_CONFIG, **(load(cfg_path(), None) or {})}
    if os.environ.get("AICHAT_PASSWORD"):
        CFG["password"] = os.environ["AICHAT_PASSWORD"]
    if os.environ.get("AICHAT_OWNER"):
        CFG["owner"] = os.environ["AICHAT_OWNER"]
    if not CFG["password"]:
        CFG["password"] = secrets.token_urlsafe(9)
        print(f"没有设置密码，已生成并保存到配置文件：{cfg_path().resolve()}")
    for m in CFG["members"]:
        if m.get("price") or m.get("prices"):
            m.setdefault("price_model", m.get("model"))
            m.setdefault("price_provider", m.get("provider"))
    save_cfg()
    PROJECTS = load(DATA / "projects.json", [])
    for p in PROJECTS:
        CHATS[p["id"]] = load_chat(p["id"])


# ---------------------------------------------------------------- 在线更新 (Ali 10-25)
# The app asks its own server for the newest build; servers pull new builds from an upstream mirror (default Ali's
# relay, reachable in China) and keep them in DATA/app, so friends' phones update without a store or a VPN.

# The public channel: builds with nothing baked in. Ali's own channel (latest.json) carries his login, so only his
# server (setup_ali.py) follows it.
UPSTREAM = os.environ.get("CHORUS_UPDATE_FROM", "")


def app_latest():
    return load(DATA / "app" / "latest.json", None)


async def h_app_latest(request):
    j = app_latest()
    return web.json_response({**j, "url": "/api/app/apk"} if j else {"code": 0})


async def h_app_apk(request):
    j = app_latest()
    f = DATA / "app" / j["file"] if j else None
    if not f or not f.exists():
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    r = web.FileResponse(f)
    r.content_type = "application/vnd.android.package-archive"
    return r


def publish_apk(path, notes="", code=None, name=""):
    """Puts a build where phones find it: python server.py publish app.apk "更新说明" [versionCode] [versionName]."""
    src = pathlib.Path(path)
    data = src.read_bytes()
    (DATA / "app").mkdir(parents=True, exist_ok=True)
    m = re.search(r"(\d+)", src.stem)
    code = int(code or (m.group(1) if m else 0) or 0)
    file = f"chorus-{code}.apk"
    (DATA / "app" / file).write_bytes(data)
    for old in (DATA / "app").glob("chorus-*.apk"):
        if old.name != file:
            old.unlink()
    j = {"code": code, "name": name or f"1.0.{code}", "notes": notes, "file": file, "size": len(data), "sha256": hashlib.sha256(data).hexdigest(),
         "at": now_at()}
    save(DATA / "app" / "latest.json", j)
    return j


async def update_loop():
    """Every few hours: is there a newer build upstream? Fetch it once, check its hash, offer it to the phones."""
    while True:
        src = CFG.get("update_from", UPSTREAM)
        if src:
            try:
                async with ClientSession(trust_env=True, timeout=ClientTimeout(total=600)) as s:
                    async with s.get(src) as r:
                        j = await r.json(content_type=None) if r.status == 200 else None
                    cur = app_latest() or {"code": 0}
                    if j and int(j.get("code", 0)) > int(cur.get("code", 0)):
                        url = j.get("url") or j["file"]
                        if not url.startswith("http"):
                            url = src.rsplit("/", 1)[0] + "/" + url.lstrip("/")
                        async with s.get(url) as r:
                            data = await r.read() if r.status == 200 else b""
                        if data and hashlib.sha256(data).hexdigest() == j.get("sha256"):
                            tmp = DATA / "tmp" / "update.apk"
                            tmp.write_bytes(data)
                            publish_apk(tmp, j.get("notes", ""), j["code"], j.get("name", ""))
                            tmp.unlink(missing_ok=True)
                            bump()
            except Exception as e:  # noqa: BLE001 - tried again next round
                print("update", type(e).__name__)
        await asyncio.sleep(CFG.get("update_every", 6 * 3600))


async def refresh_models():
    """Model lists: providers that have none yet ask their API; a CLI member with models_cmd (lines "id<TAB>label",
    e.g. `agy models`) runs it. Failures keep the old list."""
    for pr in CFG["providers"]:
        if not pr.get("models") and pr.get("key"):
            try:
                await fetch_models(pr)
            except Exception as e:  # noqa: BLE001
                print("models", pr.get("id"), type(e).__name__)
    for m in CFG["members"]:
        if not m.get("models_cmd"):
            continue
        try:
            p = await asyncio.create_subprocess_shell(m["models_cmd"], stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            o, _ = await asyncio.wait_for(p.communicate(), 120)
            got = [ln.split("\t", 1) for ln in o.decode(errors="replace").splitlines() if ln.strip() and not ln.lower().startswith("fetching")]
            got = [[a.strip(), (b[0] if b else a).strip()] for a, *b in got if a.strip() and " " not in a.strip()]
            if got:
                m["models"] = got
                if m.get("model") and not any(x[0] == m["model"] for x in got):
                    m["model"] = got[0][0]
        except Exception as e:  # noqa: BLE001
            print("models", m["name"], type(e).__name__)
    save_cfg()
    bump()


async def models_loop():
    while True:
        await refresh_models()
        await asyncio.sleep(CFG.get("models_every", 6 * 3600))


async def on_start(app):
    asyncio.ensure_future(models_loop())
    asyncio.ensure_future(update_loop())
    asyncio.ensure_future(flusher())
    asyncio.ensure_future(quota_loop())


async def h_web(request):
    # Serve only the fixed application entry, alongside its API. The relay's
    # /chorus/ proxy preserves the shared origin; no CORS or directory exposure.
    if WEB_APP.is_file():
        return web.FileResponse(WEB_APP, headers={"Cache-Control": "no-cache"})
    return web.Response(text="AI 协作服务器在运行。用 app 连接这个地址。")



# ---------------------------------------------------------------- live push (chorus2): one WebSocket replaces the long-polls
async def h_ws(request):
    """Push instead of poll: the app opens one socket and gets the index, its open chat and the 乐章 progress the moment
    anything changes. Client → {"sub": pid|null, "v": chat version}; server → {"type": "index"|"chat"|"orchestra"|"quota", ...}."""
    ws = web.WebSocketResponse(heartbeat=20, compress=True)
    await ws.prepare(request)
    state = {"pid": None, "cv": 0, "iv": -1, "orch": {}, "design": {}}

    async def reader():
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    b = json.loads(msg.data)
                except ValueError:
                    continue
                if "sub" in b:
                    state.update(pid=b.get("sub"), cv=int(b.get("v") or 0))
                    wake.set()
    wake = asyncio.Event()
    rt = asyncio.ensure_future(reader())
    try:
        while not ws.closed:
            if state["iv"] != VER:
                state["iv"] = VER
                await ws.send_json({"type": "index", "data": index_view()})
            pid = state["pid"]
            if pid and project(pid) and PVER.get(pid, 0) > state["cv"]:
                cv = state["cv"]
                state["cv"] = PVER.get(pid, 0)
                await ws.send_json({"type": "chat", "pid": pid, "data": chat_view(pid, cv)})
            if pid and project(pid) and orchestra_view:
                snap = orchestra_view(pid)
                prev = state["orch"].get(pid)
                if snap != prev:
                    d = orchestra.diff(prev or {}, snap) if prev else snap
                    state["orch"][pid] = snap
                    await ws.send_json({"type": "orchestra", "pid": pid, "full": prev is None, "data": d})
            designs = globals().get("design_options")
            if pid and project(pid) and designs:
                sessions = designs.for_project(pid)
                if sessions != state["design"].get(pid):
                    state["design"][pid] = sessions
                    await ws.send_json({"type": "design", "pid": pid, "data": {"sessions": sessions}})
            ev = CHANGED
            wake.clear()
            waits = [asyncio.ensure_future(ev.wait()), asyncio.ensure_future(wake.wait())]
            await asyncio.wait(waits, timeout=POLL, return_when=asyncio.FIRST_COMPLETED)
            for w in waits:
                w.cancel()
    finally:
        rt.cancel()
    return ws


orchestra_view = None  # set once orchestra is wired (pid -> snapshot dict)


def make_app():
    app = web.Application(middlewares=[auth], client_max_size=1 << 40)
    r = app.router
    r.add_get("/", h_web)
    r.add_get("/api/hello", h_hello)
    r.add_get("/api/index", h_index)
    r.add_get("/api/boot", h_boot)
    r.add_get("/api/ws", h_ws)
    r.add_get("/api/dms", h_dms)
    r.add_put("/api/dms/{name}", lambda q: dm_index.prefs(q, sys.modules[__name__]))
    r.add_get("/api/chat/{pid}", h_chat)
    r.add_get("/api/chat/{pid}/older", h_older)
    r.add_post("/api/quota/refresh", h_quota_refresh)
    r.add_get("/api/chat/{pid}/files", h_files)
    r.add_post("/api/say", h_say)
    r.add_post("/api/msg", h_msg)
    r.add_post("/api/stop/{name}", h_stop)
    r.add_post("/api/room/{pid}/stop", h_room_stop)
    r.add_get("/api/room/{pid}/rhythm", h_rhythm)
    r.add_post("/api/room/{pid}/rhythm", h_rhythm)
    r.add_post("/approve/ask", h_approve_ask)
    r.add_post("/api/approval/{id}", h_approve)
    r.add_get("/api/approval/{id}", h_approve)
    r.add_post("/api/projects", h_new_project)
    r.add_post("/api/projects/read_all", h_read_all)
    r.add_post("/api/intent/{id}/{op}", h_intent)
    r.add_get("/api/voice/ws", h_voice)
    r.add_get("/api/plugins", h_plugins)
    r.add_post("/api/plugins/{id}", h_plugins)
    r.add_delete("/api/plugins/{id}", h_plugins)
    r.add_patch("/api/projects/{pid}", h_edit_project)
    r.add_delete("/api/projects/{pid}", h_edit_project)
    r.add_post("/api/video", h_video)
    r.add_put("/api/upload/{name}", h_upload)
    r.add_get("/files/{name}", h_file)
    r.add_get("/files/{name}/{kind}", h_file_derived)
    r.add_get("/api/config", h_config)
    r.add_put("/api/settings", h_settings)
    r.add_put("/api/providers", h_provider)
    r.add_delete("/api/providers/{id}", h_provider)
    r.add_get("/api/providers/{id}/models", h_models)
    r.add_put("/api/members", h_member)
    r.add_delete("/api/members/{name}", h_member)
    r.add_get("/api/tasks/{pid}", cards().handle)
    r.add_post("/api/tasks/{pid}", cards().handle)
    r.add_patch("/api/tasks/{pid}/{id}", cards().handle)
    r.add_delete("/api/tasks/{pid}/{id}", cards().handle)
    r.add_get("/api/skills", h_skills)
    r.add_post("/api/skills/install", h_skill_install)
    r.add_post("/api/skills/{dir}", h_skill)
    r.add_delete("/api/skills/{dir}", h_skill)
    r.add_get("/api/memory", h_memory)
    r.add_put("/api/memory", h_memory)
    r.add_delete("/api/memory/{scope}/{id}", h_memory)
    r.add_post("/api/memory/import", h_memory_import)
    r.add_post("/api/import", h_import)
    r.add_post("/api/import/commit", h_import_commit)
    r.add_post("/api/tts", h_tts)
    r.add_get("/api/voices", h_voices)
    r.add_put("/api/voices", h_tts_config)
    r.add_get("/api/spend", h_spend)
    r.add_get("/api/spend/summary", h_spend_summary)
    r.add_put("/api/wallet", h_wallet)
    r.add_post("/api/price_lookup", h_price_lookup)
    r.add_get("/api/price_lookup", h_price_lookup)
    r.add_get("/api/check", h_check)
    r.add_get("/api/catalog", h_catalog)
    r.add_post("/api/quick_add", h_quick_add)
    r.add_post("/api/topic", h_topic)
    r.add_get("/api/app/latest", h_app_latest)
    r.add_get("/api/app/apk", h_app_apk)
    member_avatars.register(app, sys.modules[__name__])
    chorus2.register(app, sys.modules[__name__])
    import connect
    connect.register(app, sys.modules[__name__], chorus2)
    backup.register(app, DATA, lambda: CFG)
    app.on_startup.append(on_start)
    app.cleanup_ctx.append(member_timeout_context)
    return app


def run_http():
    try:
        web.run_app(make_app(), port=PORT, access_log=None)
    except OSError as exc:
        if exc.errno != errno.EADDRINUSE:
            raise
        print(f"端口 {PORT} 被占用，换 AICHAT_PORT={PORT + 1}", file=sys.stderr)
        raise SystemExit(1) from None


def run_server():
    DATA.mkdir(parents=True, exist_ok=True)
    try:
        with backup.writer_lock(DATA, startup=True):
            startup_guard(DATA)
            setup()
            print(f"AI 协作服务器：http://0.0.0.0:{PORT}  数据：{DATA}")
            run_http()
    except backup.BackupError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    if sys.argv[1:2] == ["doctor"]:
        sys.exit(doctor())
    if sys.argv[1:2] == ["publish"]:
        setup()
        print(json.dumps(publish_apk(*sys.argv[2:6]), ensure_ascii=False))
        sys.exit(0)
    run_server()
