"""Reading other apps' chat exports into conversations: [{"title", "source", "messages": [{"role", "text", "ts"}]}].

role is "user" (Ali) or "assistant". Known formats: ChatGPT and DeepSeek (conversations.json, a "mapping" tree),
Claude (conversations.json with chat_messages), Gemini (Google Takeout "My Activity" JSON or HTML), Claude Code and
Codex session logs (.jsonl), plain lists of {role, content}, and text transcripts ("who: text" lines). Zips are opened
and every file inside is tried."""
import datetime
import html
import io
import json
import re
import zipfile


def ts_of(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return v / 1000 if v > 1e12 else float(v)
    try:
        return datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def text_of(c):
    """Text out of the many shapes message content comes in."""
    if c is None:
        return ""
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return "\n".join(t for t in (text_of(x) for x in c) if t)
    if isinstance(c, dict):
        if c.get("type") in ("tool_use", "tool_result", "function_call", "thinking", "reasoning", "image", "image_url"):
            return ""
        for k in ("parts", "text", "content", "result"):
            if k in c:
                return text_of(c[k])
    return ""


def role_of(r):
    r = (r or "").lower()
    if r in ("user", "human", "request", "me", "prompt"):
        return "user"
    if r in ("assistant", "model", "bot", "ai", "response", "gpt", "claude", "gemini"):
        return "assistant"
    return ""


def from_mapping(conv, source):
    """ChatGPT / DeepSeek: a tree of nodes; the conversation is the path from the root to current_node."""
    mp = conv["mapping"]
    node = conv.get("current_node") or next((k for k, v in mp.items() if not v.get("children")), None)
    path = []
    while node and node in mp:
        path.append(mp[node])
        node = mp[node].get("parent")
    out = []
    for n in reversed(path):
        m = n.get("message") or {}
        if m.get("fragments"):  # DeepSeek: REQUEST / THINK / RESPONSE fragments
            for f in m["fragments"]:
                r = {"REQUEST": "user", "RESPONSE": "assistant"}.get(f.get("type"))
                if r and f.get("content"):
                    out.append({"role": r, "text": f["content"], "ts": ts_of(m.get("inserted_at") or n.get("inserted_at"))})
            continue
        r = role_of((m.get("author") or {}).get("role"))
        t = text_of(m.get("content"))
        if r and t.strip() and not (m.get("metadata") or {}).get("is_visually_hidden_from_conversation"):
            out.append({"role": r, "text": t, "ts": ts_of(m.get("create_time"))})
    return {"title": conv.get("title") or "对话", "source": source, "messages": out}


def from_claude(conv):
    out = []
    for m in conv.get("chat_messages") or []:
        t = text_of(m.get("content")) or m.get("text") or ""
        r = role_of(m.get("sender"))
        if r and t.strip():
            out.append({"role": r, "text": t, "ts": ts_of(m.get("created_at"))})
    return {"title": conv.get("name") or "Claude 对话", "source": "claude", "messages": out}


def from_gemini_activity(items):
    """Takeout's Gemini Apps activity: each item is one prompt ("Prompted …") with the answer as HTML."""
    out = []
    for it in sorted(items, key=lambda x: x.get("time", "")):
        title = it.get("title", "")
        if not title.startswith(("Prompted", "已提问", "提问")):
            continue
        q = re.sub(r"^(Prompted|已提问|提问)\s*", "", title)
        ts = ts_of(it.get("time"))
        out.append({"role": "user", "text": q, "ts": ts})
        a = "\n".join(strip_html(h.get("html", "")) for h in it.get("safeHtmlItem") or [])
        if a.strip():
            out.append({"role": "assistant", "text": a, "ts": ts})
    return [{"title": "Gemini 对话", "source": "gemini", "messages": out}] if out else []


def strip_html(s):
    s = re.sub(r"<br\s*/?>|</p>|</li>|</h\d>", "\n", s)
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


def from_jsonl(lines, name):
    """Claude Code (~/.claude/projects/*.jsonl) and Codex (~/.codex/sessions/*.jsonl) logs."""
    out, source = [], "jsonl"
    for line in lines:
        try:
            o = json.loads(line)
        except ValueError:
            continue
        if not isinstance(o, dict):
            continue
        p = o.get("payload") if isinstance(o.get("payload"), dict) else None
        if p is not None:  # Codex
            source = "codex"
            if p.get("type") == "message" and role_of(p.get("role")):
                t = text_of(p.get("content"))
                if t.strip() and not t.lstrip().startswith(("<environment_context>", "<user_instructions>", "# AGENTS.md")):
                    out.append({"role": role_of(p["role"]), "text": t, "ts": ts_of(o.get("timestamp"))})
            continue
        m = o.get("message")
        if isinstance(m, dict) and o.get("type") in ("user", "assistant"):  # Claude Code
            source = "claude-code"
            if o.get("isMeta") or o.get("isSidechain"):
                continue
            t = text_of(m.get("content"))
            if t.strip() and not t.lstrip().startswith(("<command-", "<local-command", "<system-reminder>")):
                out.append({"role": o["type"], "text": t, "ts": ts_of(o.get("timestamp"))})
            continue
        r = role_of(o.get("role") or o.get("sender") or o.get("author"))
        if r:
            out.append({"role": r, "text": text_of(o.get("content") or o.get("text")), "ts": ts_of(o.get("timestamp") or o.get("time"))})
    # Consecutive pieces of one answer (Claude Code logs each block) are joined.
    merged = []
    for m in out:
        if merged and merged[-1]["role"] == m["role"] == "assistant":
            merged[-1]["text"] += "\n\n" + m["text"]
        else:
            merged.append(m)
    return [{"title": name, "source": source, "messages": merged}] if merged else []


LINE = re.compile(r"^\s*(?:\*\*)?(?:\[([^\]]{4,25})\]\s*)?(?:#{1,4}\s*)?([^\s:：\[\]*#]{1,16})(?:\*\*)?\s*[:：]\s?(.*)$")
USERS = ("我", "user", "you", "用户", "ali", "human", "me", "问")


def from_text(s, name):
    """Transcripts written as "who: text" (or "[time] who：text", or our own "**who** (time):" headers)."""
    out, cur = [], None
    for line in s.splitlines():
        m = LINE.match(line)
        if m and len(m.group(2)) <= 16 and not m.group(2).startswith("http"):
            who = m.group(2)
            cur = {"who": who, "role": "user" if who.lower() in USERS else "assistant", "text": m.group(3), "ts": ts_of(m.group(1))}
            out.append(cur)
        elif cur is not None:
            cur["text"] += "\n" + line
    if len(out) < 2:
        return []
    for m in out:
        m["text"] = m["text"].strip()
    return [{"title": name, "source": "text", "messages": out}]


def from_json(o, name):
    if isinstance(o, dict):
        for k in ("conversations", "data", "items", "chats"):
            if isinstance(o.get(k), list):
                return from_json(o[k], name)
        if "mapping" in o:
            return [from_mapping(o, "chatgpt")]
        if "chat_messages" in o:
            return [from_claude(o)]
        if isinstance(o.get("messages"), list):
            return from_json(o["messages"], o.get("title") or o.get("name") or name)
        return []
    if not isinstance(o, list) or not o:
        return []
    first = o[0] if isinstance(o[0], dict) else {}
    if "mapping" in first:
        src = "deepseek" if any("fragments" in json.dumps(v)[:4000] for v in list(first["mapping"].values())[:3]) else "chatgpt"
        return [from_mapping(c, src) for c in o if isinstance(c, dict) and "mapping" in c]
    if "chat_messages" in first:
        return [from_claude(c) for c in o if isinstance(c, dict)]
    if "header" in first and "title" in first and ("Gemini" in first.get("header", "") or "Bard" in first.get("header", "")):
        return from_gemini_activity(o)
    msgs = []
    for x in o:
        if isinstance(x, dict):
            r = role_of(x.get("role") or x.get("sender") or x.get("author") or x.get("from"))
            t = text_of(x.get("content") or x.get("text") or x.get("message"))
            if r and t.strip():
                msgs.append({"role": r, "text": t, "ts": ts_of(x.get("timestamp") or x.get("time") or x.get("created_at"))})
    return [{"title": name, "source": "json", "messages": msgs}] if msgs else []


def parse(data: bytes, name: str):
    """Every conversation found in one file."""
    if data[:2] == b"PK":
        z = zipfile.ZipFile(io.BytesIO(data))
        out = []
        for n in z.namelist():
            if n.endswith("/") or "/." in n or n.startswith("__MACOSX"):
                continue
            if re.search(r"\.(json|jsonl|txt|md|html)$", n, re.I):
                try:
                    out += parse(z.read(n), n.rsplit("/", 1)[-1])
                except Exception:  # noqa: BLE001 - one odd file does not stop the rest
                    pass
        return out
    s = data.decode("utf-8-sig", errors="replace")
    base = re.sub(r"\.\w+$", "", name)
    st = s.lstrip()
    if st.startswith(("[", "{")):
        try:
            return [c for c in from_json(json.loads(s), base) if c["messages"]]
        except ValueError:
            pass
        lines = s.splitlines()
        if len(lines) > 1:
            return from_jsonl(lines, base)
    if st.startswith("<") and "Gemini" in s[:20000]:
        # Takeout HTML: each "outer-cell" holds a prompt and its answer.
        cells = re.findall(r'class="outer-cell.*?(?=class="outer-cell|\Z)', s, re.S)
        items = []
        for c in cells:
            parts = re.findall(r'class="content-cell[^"]*"[^>]*>(.*?)</div>', c, re.S)
            if parts:
                txt = strip_html(parts[0])
                q = re.sub(r"^(Prompted|已提问|提问)\s*", "", txt.split("\n", 1)[0])
                items.append({"role": "user", "text": q, "ts": None})
                rest = txt.split("\n", 1)[1] if "\n" in txt else ""
                if rest.strip():
                    items.append({"role": "assistant", "text": rest.strip(), "ts": None})
        return [{"title": "Gemini 对话", "source": "gemini", "messages": items}] if items else []
    return from_text(s, base)


# Which member an export's assistant most likely is, from words in the member's name, model and provider.
SOURCE_HINTS = {
    "chatgpt": ("gpt", "openai", "codex", "龙娘", "o3", "o4"), "codex": ("codex", "gpt", "龙娘"),
    "claude": ("claude", "小克", "anthropic", "sonnet", "opus"), "claude-code": ("claude", "小克", "sonnet", "opus"),
    "gemini": ("gemini", "猫猫", "agy", "antigravity"), "deepseek": ("deepseek", "大肥鱼"),
    "kimi": ("kimi", "moonshot"), "doubao": ("doubao", "豆包", "ark"), "glm": ("glm", "zhipu", "bigmodel"), "grok": ("grok", "大小姐", "x.ai"),
}


def guess_member(source, members, providers):
    hints = SOURCE_HINTS.get(source, ())
    for m in members:
        pr = next((p for p in providers if p["id"] == m.get("provider")), {})
        hay = " ".join([m["name"], m.get("model", ""), m.get("cmd", ""), pr.get("name", ""), pr.get("base", "")]).lower()
        if any(h in hay for h in hints):
            return m["name"]
    return ""


def source_of_text(s):
    """For pasted memories: which app they came from, if it says."""
    low = s.lower()
    for k, words in (("chatgpt", ("chatgpt", "openai")), ("claude", ("claude",)), ("gemini", ("gemini",)), ("grok", ("grok",)),
                     ("deepseek", ("deepseek",)), ("kimi", ("kimi",)), ("doubao", ("豆包", "doubao"))):
        if any(w in low for w in words):
            return k
    return ""
