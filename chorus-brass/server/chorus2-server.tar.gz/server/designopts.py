"""Cheap, parallel UI directions; only a picked direction gets an expanded render.

The wire format is data, never HTML or executable code. All timings are monotonic
seconds from session creation. Model calls and server notifications are injected.
"""
from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import math
import re
import secrets
import time
import unicodedata
from collections import OrderedDict
from pathlib import Path

from aiohttp import web


BLOCK_TYPES = ["header", "list", "card", "hero", "tabs", "form", "chart", "image"]
SPEC_SCHEMA = {
    "type": "object", "required": ["screens", "palette", "type"], "additionalProperties": False,
    "properties": {
        "screens": {"type": "array", "minItems": 1, "maxItems": 12, "items": {
            "type": "object", "required": ["name", "blocks"], "additionalProperties": False,
            "properties": {"name": {"type": "string", "minLength": 1, "maxLength": 100},
                           "blocks": {"type": "array", "minItems": 1, "maxItems": 60, "items": {
                               "type": "object", "required": ["type", "props"], "additionalProperties": False,
                               "properties": {"type": {"enum": BLOCK_TYPES}, "props": {"type": "object"}}}}}}},
        "palette": {"type": "array", "minItems": 3, "maxItems": 8,
                    "items": {"type": "string", "pattern": r"^#[0-9a-fA-F]{6}$"}},
        "type": {"type": "object", "required": ["heading", "body"], "additionalProperties": False,
                 "properties": {k: {"type": "string", "minLength": 1, "maxLength": 80} for k in ("heading", "body")}},
    },
}


def _validate(value, schema, path="spec"):
    types = {"object": dict, "array": list, "string": str}
    if "type" in schema and not isinstance(value, types[schema["type"]]):
        raise ValueError(f"{path}: expected {schema['type']}")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path}: unsupported block type")
    if isinstance(value, dict):
        if any(k not in value for k in schema.get("required", [])):
            raise ValueError(f"{path}: missing required field")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False and set(value) - props.keys():
            raise ValueError(f"{path}: unknown field")
        for k, sub in props.items():
            if k in value:
                _validate(value[k], sub, f"{path}.{k}")
    if isinstance(value, (str, list)):
        low, high = ("minLength", "maxLength") if isinstance(value, str) else ("minItems", "maxItems")
        if len(value) < schema.get(low, 0) or len(value) > schema.get(high, math.inf):
            raise ValueError(f"{path}: invalid length")
    if isinstance(value, str) and "pattern" in schema and not re.fullmatch(schema["pattern"], value):
        raise ValueError(f"{path}: invalid color")
    if isinstance(value, list) and "items" in schema:
        for i, item in enumerate(value):
            _validate(item, schema["items"], f"{path}[{i}]")


def validate_spec(value):
    """Enforce the published schema, JSON-only props, and a bounded payload."""
    try:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
        if len(encoded.encode()) > 200_000:
            raise ValueError("spec: payload too large")
        _validate(value, SPEC_SCHEMA)
        return json.loads(encoded)
    except (TypeError, RecursionError, OverflowError) as e:
        raise ValueError("spec: invalid JSON") from e


def parse_spec(raw):
    if isinstance(raw, str):
        raw = raw.strip()
        if raw.startswith("```json\n") or raw.startswith("```\n"):
            raw = raw[raw.index("\n") + 1:]
            if raw.endswith("```"):
                raw = raw[:-3]
        if len(raw.encode()) > 200_000:
            raise ValueError("spec: payload too large")
        try:
            raw = json.loads(raw)
        except (ValueError, RecursionError) as e:
            raise ValueError("spec: invalid JSON") from e
    return validate_spec(raw)


def normalize(brief):
    return " ".join(unicodedata.normalize("NFKC", brief).casefold().split())


def cache_key(brief, n):
    return hashlib.sha256(json.dumps([normalize(brief), n], ensure_ascii=False).encode()).hexdigest()


def _library():
    styles = [
        ("brass", "Brass programme", ["#F4ECDD", "#28251F", "#A47D43"], "Georgia", "Arial", ["editorial", "sidebar"]),
        ("paper", "Quiet paper", ["#FAF9F6", "#242424", "#536D64"], "Georgia", "Verdana", ["reading", "single-column"]),
        ("midnight", "Midnight console", ["#141B29", "#EEF2FF", "#8BA4FF"], "Arial", "Courier New", ["dashboard", "grid"]),
        ("citrus", "Citrus studio", ["#FFFBEA", "#253025", "#B4C844"], "Trebuchet MS", "Arial", ["hero", "cards"]),
        ("cobalt", "Cobalt atlas", ["#F0F5FF", "#132B50", "#3267D6"], "Verdana", "Arial", ["navigation", "list"]),
        ("rose", "Rose journal", ["#FFF1F0", "#4C2934", "#BD6379"], "Georgia", "Trebuchet MS", ["editorial", "cards"]),
        ("mono", "Mono index", ["#FFFFFF", "#171717", "#727272"], "Arial", "Courier New", ["table", "compact"]),
        ("ocean", "Ocean workspace", ["#EFF9F8", "#183B43", "#248A94"], "Trebuchet MS", "Verdana", ["tabs", "dashboard"]),
    ]
    out = []
    for sid, name, colors, heading, body, tags in styles:
        bg, ink, accent = colors
        # Fixed geometry and trusted local colors: no random IDs or external assets.
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="240" height="150" viewBox="0 0 240 150">'
               f'<rect width="240" height="150" fill="{bg}"/><rect x="12" y="12" width="40" height="126" rx="4" fill="{ink}"/>'
               f'<rect x="64" y="14" width="132" height="12" rx="3" fill="{ink}"/>'
               f'<rect x="64" y="38" width="164" height="44" rx="5" fill="{accent}"/>'
               f'<path d="M64 96h164M64 113h164M64 130h110" stroke="{ink}" stroke-width="5" opacity=".35"/></svg>')
        out.append({"id": sid, "name": name, "palette": colors, "type": {"heading": heading, "body": body},
                    "layout_tags": tags, "thumbnail": svg})
    return out


LIBRARY = _library()
LIBRARY_JSON = json.dumps({"styles": LIBRARY, "schema": SPEC_SCHEMA}, ensure_ascii=False).encode()
UI_BRIEF = re.compile(r"界面|设计|前端|网页|网站|小程序|应用|\b(ui|ux|app|website|dashboard|landing|interface|design)\b", re.I)


class NoMemberError(Exception):
    """No eligible design member remains in the pool."""


class DesignOptions:
    def __init__(self, data: Path, *, ask, members, price_of, healthy=lambda name: True,
                 notify=lambda pid: None, config=None, cache_size=64):
        self.ask, self.members, self.price_of, self.healthy = ask, members, price_of, healthy
        self.notify, self.config = notify, config if config is not None else {}
        self.sessions = {}
        self.cache = OrderedDict()
        self.cache_size = cache_size
        self.path = Path(data) / "design-options.json"
        self.disk_lock = asyncio.Lock()
        self.tasks = set()
        try:
            saved = json.loads(self.path.read_text())
            if isinstance(saved, dict):
                for key, specs in list(saved.items())[-cache_size:]:
                    try:
                        if not re.fullmatch(r"[0-9a-f]{64}", key) or not isinstance(specs, list) or not 1 <= len(specs) <= 8:
                            continue
                        self.cache[key] = [validate_spec(x) for x in specs]
                    except ValueError:
                        continue
        except (OSError, ValueError, RecursionError):
            pass  # Missing/corrupt cache is a miss, never a startup failure.

    def spawn(self, coro):
        task = asyncio.create_task(coro)
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return task

    def snapshot(self, sid):
        s = self.sessions[sid]
        return copy.deepcopy({k: v for k, v in s.items() if not k.startswith("_")})

    def for_project(self, pid):
        return [self.snapshot(sid) for sid, s in self.sessions.items() if s["pid"] == pid]

    def _pool(self):
        return [m for m in self.members() if m.get("auto", True) and self.healthy(m["name"])
                and (m.get("caps") or {}).get("design", True)]

    def _price(self, member):
        p = self.price_of(member) or {}
        return sum(float(p.get(k, 0) or 0) for k in ("in", "out")) if p else math.inf

    def start(self, pid, brief, n=3, mode="concerto"):
        if not isinstance(pid, str) or not pid or not isinstance(brief, str) or not brief.strip() or len(brief) > 20_000:
            raise ValueError("pid and a nonempty brief (up to 20000 characters) are required")
        if type(n) is not int or not 1 <= n <= 8:
            raise ValueError("n must be an integer from 1 to 8")
        key = cache_key(brief, n)
        sid = secrets.token_hex(12)
        cached = self.cache.get(key)
        if cached is not None and len(cached) != n:
            self.cache.pop(key)
            cached = None
        if cached is not None:
            self.cache.move_to_end(key)
        s = self.sessions[sid] = {
            "sid": sid, "pid": pid, "brief": brief.strip(), "n": n, "mode": mode,
            "cache_hit": cached is not None, "picked": None, "picked_by": None,
            "render": {"state": "idle"}, "revision": 0,
            "options": [{"id": i, "state": "ready" if cached else "pending",
                         **({"spec": copy.deepcopy(cached[i]), "cost_estimate": 0.0} if cached else {})} for i in range(n)],
            "metrics": {"time_to_first_option": 0.0 if cached else None,
                        "time_to_all": 0.0 if cached else None, "cancelled": 0},
            "_key": key, "_started": time.monotonic(), "_workers": [], "_changed": asyncio.Event(),
        }
        if not cached:
            pool = self._pool()
            cheap = min(pool, key=lambda m: (self._price(m), m["name"])) if pool else None
            s["_cheap"] = cheap
            s["_workers"] = [self.spawn(self._generate(s, slot, cheap)) for slot in s["options"]]
        self.set_mode(sid, mode)
        self.changed(s)
        return self.snapshot(sid)

    def set_mode(self, sid, mode):
        s = self.sessions[sid]
        s["mode"] = mode
        old = s.get("_auto")
        if old:
            old.cancel()
        if mode == "symphony" and s["picked"] is None:
            s["_auto"] = self.spawn(self._autopick(s))

    def attach(self, sid, pid, mode):
        s = self.sessions[sid]
        previous = s["pid"]
        s["pid"] = pid
        self.set_mode(sid, mode)
        self.notify(previous)
        self.changed(s)

    def changed(self, s):
        s["_changed"].set()
        self.notify(s["pid"])

    def _finish_metrics(self, s):
        if all(x["state"] != "pending" for x in s["options"]) and s["metrics"]["time_to_all"] is None:
            s["metrics"]["time_to_all"] = time.monotonic() - s["_started"]

    async def _call(self, member, system, prompt, pid):
        if member is None:
            raise NoMemberError("No capable member available")
        return await asyncio.wait_for(self.ask(member, system, prompt, pid), self.config.get("design_timeout_s", 30))

    async def _generate(self, s, slot, member):
        try:
            style = LIBRARY[slot["id"] % len(LIBRARY)]
            prompt = json.dumps({"brief": s["brief"], "option": slot["id"], "style": style["id"],
                                 "palette": style["palette"], "type": style["type"],
                                 "instruction": "Draft a distinct, compact wireframe direction (1-3 screens)."}, ensure_ascii=False)
            raw = await self._call(member, "Return only JSON matching this schema: " + json.dumps(SPEC_SCHEMA), prompt, s["pid"])
            spec = parse_spec(raw)
            if slot["state"] != "pending":
                return
            price = self.price_of(member) or {}
            cost = (len(prompt) / 4 * float(price.get("in", 0) or 0)
                    + len(json.dumps(spec)) / 4 * float(price.get("out", 0) or 0)) / 1e6
            slot.update(state="ready", spec=spec, member=member["name"], cost_estimate=round(cost, 8))
            if s["metrics"]["time_to_first_option"] is None:
                s["metrics"]["time_to_first_option"] = time.monotonic() - s["_started"]
        except asyncio.CancelledError:
            if slot["state"] == "pending":
                slot["state"] = "cancelled"
                s["metrics"]["cancelled"] += 1
            raise
        except Exception as e:  # member output/errors are untrusted; never expose provider bodies or keys
            if slot["state"] == "pending":
                slot.update(state="failed", error="schema_rejected" if isinstance(e, ValueError)
                            else "no_member" if isinstance(e, NoMemberError)
                            else "timeout" if isinstance(e, asyncio.TimeoutError) else "member_failed")
        finally:
            self._finish_metrics(s)
            self.changed(s)
        if all(x["state"] == "ready" for x in s["options"]):
            self.cache[s["_key"]] = [copy.deepcopy(x["spec"]) for x in s["options"]]
            self.cache.move_to_end(s["_key"])
            while len(self.cache) > self.cache_size:
                self.cache.popitem(last=False)
            await self._persist()

    async def _persist(self):
        async with self.disk_lock:
            payload = json.dumps(self.cache, ensure_ascii=False)

            def write():
                self.path.parent.mkdir(parents=True, exist_ok=True)
                # A cancelled await cannot stop a disk thread. Unique temporary
                # files keep a later writer independent of that finishing write.
                tmp = self.path.with_name(f".{self.path.name}.{secrets.token_hex(6)}.tmp")
                try:
                    tmp.write_text(payload)
                    tmp.replace(self.path)
                finally:
                    tmp.unlink(missing_ok=True)
            try:
                await asyncio.to_thread(write)
            except OSError:
                pass  # The memory cache still works when DATA is read-only/full.

    @staticmethod
    def score(brief, slot):
        try:
            validate_spec(slot["spec"])
        except (KeyError, ValueError):
            return (0, 0, -math.inf, -slot["id"])
        # Word tokens plus Han characters make overlap meaningful in both UI languages.
        words = lambda text: set(re.findall(r"[a-z0-9_]+|[\u3400-\u9fff]", normalize(text)))
        overlap = len(words(brief) & words(json.dumps(slot["spec"], ensure_ascii=False)))
        return (1, overlap, -slot.get("cost_estimate", 0), -slot["id"])

    async def _autopick(self, s):
        deadline = s["_started"] + max(0, float(self.config.get("design_autopick_s", 20)))
        await asyncio.sleep(max(0, deadline - time.monotonic()))
        while s["picked"] is None:
            s["_changed"].clear()
            ready = [x for x in s["options"] if x["state"] == "ready"]
            if ready:
                choice = max(ready, key=lambda x: self.score(s["brief"], x))
                await self.pick(s["sid"], choice["id"], by="auto")
                return
            if all(x["state"] != "pending" for x in s["options"]):
                return
            await s["_changed"].wait()

    def cancel(self, sid):
        s = self.sessions[sid]
        for task in [*s["_workers"], s.get("_auto"), s.get("_render")]:
            if task and task is not asyncio.current_task():
                task.cancel()
        for slot in s["options"]:
            if slot["state"] == "pending":
                slot["state"] = "cancelled"
                s["metrics"]["cancelled"] += 1
        s["revision"] += 1
        if s["render"]["state"] == "pending":
            s["render"] = {"state": "cancelled"}
            s["metrics"]["cancelled"] += 1
        self._finish_metrics(s)
        self.changed(s)

    async def pick(self, sid, option, by="user"):
        s = self.sessions[sid]
        if type(option) is not int or not 0 <= option < s["n"]:
            raise ValueError("option must be a slot id")
        if s["options"][option]["state"] != "ready":
            raise ValueError("option is not ready")
        self.cancel(sid)
        revision = s["revision"]
        s.update(picked=option, picked_by=by, render={"state": "pending", "option": option})
        # Start the expensive call only once cancellation of the drafts has settled.
        s["_render"] = self.spawn(self._expand(s, option, revision, list(s["_workers"])))
        self.changed(s)
        return self.snapshot(sid)

    async def _expand(self, s, option, revision, workers):
        try:
            await asyncio.gather(*workers, return_exceptions=True)
            pool = self._pool()
            cheap_name = (s.get("_cheap") or {}).get("name")
            stronger = [m for m in pool if m["name"] != cheap_name]
            member = max(stronger or pool, key=lambda m: (self._price(m) if math.isfinite(self._price(m)) else -1, m["name"])) if pool else None
            prompt = json.dumps({"brief": s["brief"], "chosen": s["options"][option]["spec"],
                                 "instruction": "Expand only this direction into a high-fidelity spec. Include complete copy, "
                                 "spacing, responsive layout, interactions and accessible labels in block props."}, ensure_ascii=False)
            raw = await self._call(member, "Return only JSON matching this schema: " + json.dumps(SPEC_SCHEMA), prompt, s["pid"])
            spec = parse_spec(raw)
            if s["revision"] == revision:
                s["render"] = {"state": "ready", "option": option, "spec": spec, "member": member["name"]}
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if s["revision"] == revision:
                s["render"] = {"state": "failed", "option": option,
                               "error": "schema_rejected" if isinstance(e, ValueError)
                               else "no_member" if isinstance(e, NoMemberError) else "render_failed"}
        finally:
            self.changed(s)

    async def close(self):
        for s in self.sessions.values():
            self.cancel(s["sid"])
        tasks = list(self.tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


def register(app, server, chorus):
    async def ask(member, system, prompt, pid):
        token = chorus.ROLE.set("design")
        try:
            if member.get("kind", "api") == "api":
                return await chorus.ask_model(member, system, prompt, pid)
            import adapters as A
            why = chorus.account_block()
            if why:
                raise RuntimeError(why)
            adapter = A.AcpAdapter(member, chorus.cli_guard)

            async def deny(tool, inp):
                return False  # wireframe generation needs no tools or side effects
            result = await adapter.run(prompt, lambda step: None, deny, cwd=str(server.DATA / "work"), system=system)
            usage = result.usage
            # ACP uses zero counters even when the agent reports no usage.
            # Estimate tokens here; record_usage applies the configured prices.
            if not usage or not any(usage.get(k, 0) for k in ("in", "out", "cached")):
                usage = {"in": math.ceil((len(system) + len(prompt)) / 4),
                         "out": math.ceil(len(result.text or "") / 4), "cached": 0,
                         "estimated": True}
            server.record_usage(member, member.get("model", ""), usage, pid)
            if not result.ok or not result.text or not result.text.strip():
                raise RuntimeError("Design member failed")
            return result.text
        finally:
            chorus.ROLE.reset(token)

    # A plain CLI's approval/cancellation protocol cannot isolate concurrent
    # drafts. API and ACP members have cancellable, structured reply contracts.
    capable = lambda: [m for m in chorus.members() if m.get("kind", "api") == "api"
                       or (m.get("kind") == "cli" and m.get("protocol") == "acp")]
    service = DesignOptions(server.DATA, ask=ask, members=capable, price_of=chorus.price_of,
                            healthy=chorus.healthy, notify=server.bump, config=server.CFG)
    server.design_options = service

    async def library(request):
        return web.Response(body=LIBRARY_JSON, content_type="application/json")

    async def start(request):
        b = await body(request)
        pid = b.get("pid")
        if not isinstance(pid, str):
            raise web.HTTPBadRequest(text="pid is required")
        p = server.project(pid)
        if not p:
            raise web.HTTPNotFound()
        try:
            result = service.start(pid, b.get("brief"), b.get("n", 3), p.get("mode", "concerto"))
        except ValueError as e:
            return web.json_response({"error": str(e)}, status=400)
        p["design_sid"] = result["sid"]
        chorus.save_projects()
        return web.json_response(result)

    def session(request):
        sid = request.match_info["sid"]
        if sid not in service.sessions or not server.project(service.sessions[sid]["pid"]):
            raise web.HTTPNotFound()
        return sid

    async def get(request):
        return web.json_response(service.snapshot(session(request)))

    async def pick(request):
        sid = session(request)
        b = await body(request)
        try:
            result = await service.pick(sid, b.get("option"))
        except ValueError as e:
            return web.json_response({"error": str(e)}, status=400)
        return web.json_response(result)

    async def body(request):
        try:
            b = await request.json()
        except (ValueError, UnicodeError):
            raise web.HTTPBadRequest(text="Expected a JSON object") from None
        if not isinstance(b, dict):
            raise web.HTTPBadRequest(text="Expected a JSON object")
        return b

    app.router.add_get("/api/design/library", library)
    app.router.add_post("/api/design/start", start)
    app.router.add_get("/api/design/{sid}", get)
    app.router.add_post("/api/design/{sid}/pick", pick)

    async def cleanup(app_):
        await service.close()
    app.on_cleanup.append(cleanup)
    return service


def speculate(server, pid, brief, mode="concerto"):
    """Synchronous first step: publish skeletons before awaiting any clarifications."""
    service = getattr(server, "design_options", None)
    if service is None or not UI_BRIEF.search(brief or ""):
        return None
    p = server.project(pid)
    if not p:
        return None
    old = service.sessions.get(p.get("design_sid"))
    if (old and normalize(brief).startswith(normalize(old["brief"]))
            and any(x["state"] in ("pending", "ready") for x in old["options"])):
        if old["mode"] != mode:
            service.set_mode(old["sid"], mode)
            service.changed(old)
        return service.snapshot(old["sid"])
    result = service.start(pid, brief, mode=mode)
    p["design_sid"] = result["sid"]
    return result
