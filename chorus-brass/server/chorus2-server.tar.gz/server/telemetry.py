"""
N15 匿名统计回传（仅客户端部分，不联网）。

设计要点：
- 随机安装 id（首次生成后持久化到 DATA 目录，可关闭）。
- build_daily_report(events, version) 只产出聚合统计，不含原始文本。
- sanitize(report) 白名单字段 + 泄露形态检测，返回 (clean_report, dropped)。
- pending_payload() 读取待上传原文（供设置里「查看待上传」）。
- opt_in 状态默认 None（首启询问），False 时 send 直接返回。
- send_daily(sender, now) 每天最多一次，失败不重试风暴。

所有行为带开关，默认关闭（enabled=False）。
纯标准库，无网络，上传由外部注入 sender 回调。
"""

from __future__ import annotations

import json
import math
import os
import random
import re
import string
import time
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "Telemetry",
    "build_daily_report",
    "sanitize",
    "default_data_dir",
    "SENSITIVE_PATTERNS",
    "WHITELIST_FIELDS",
]

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# 白名单字段（顶层）
WHITELIST_FIELDS = frozenset(
    {
        "install_id",
        "report_date",
        "server_version",
        "generated_at",
        "stats",
        "error_types",
        "issue_codes",
    }
)

# stats 内部白名单
WHITELIST_STATS_FIELDS = frozenset(
    {
        "model",
        "task_type",
        "passed",
        "rework",
        "redo",
        "token_quantiles",
        "latency_quantiles",
    }
)

# 数值型分位字段
WHITELIST_QUANTILE_FIELDS = frozenset({"p50", "p90", "p99"})

# 泄露形态检测（任一命中即丢弃该字符串值）
SENSITIVE_PATTERNS: List[Tuple[str, "re.Pattern[str]"]] = [
    ("path", re.compile(r"(?:[A-Za-z]:\\|/(?:home|Users|var|etc|tmp|opt|root|mnt|srv)/|\.\.?/|~\/)")),
    ("windows_path", re.compile(r"[A-Za-z]:\\(?:[^\\\s]+\\)*[^\\\s]*")),
    ("url", re.compile(r"(?:https?|ftp|file)://|www\.", re.IGNORECASE)),
    ("email", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("sk_key", re.compile(r"\bsk-[A-Za-z0-9_\-]{8,}")),
    ("aws_key", re.compile(r"\bAKIA[0-9A-Z]{12,}\b")),
    ("long_token", re.compile(r"\b[A-Za-z0-9_\-]{32,}\b")),
    ("ip", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("long_chinese", re.compile(r"[\u4e00-\u9fff]{21,}")),
]

# 中文长句阈值
LONG_CHINESE_THRESHOLD = 20

# 允许的标识符形态（install_id 等）
_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")

# 任务类型 / 模型名允许字符（保守）
_SAFE_NAME_RE = re.compile(r"^[A-Za-z0-9_\-.]{1,64}$")

# 毛病类别码（如 E01、W12）
_ISSUE_CODE_RE = re.compile(r"^[A-Z]{1,3}\d{1,4}$")

# 报错类型（如 TimeoutError、ValueError）
_ERROR_TYPE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------

def default_data_dir() -> str:
    """默认 DATA 目录（可用 TELEMETRY_DATA_DIR 覆盖）。"""
    env = os.environ.get("TELEMETRY_DATA_DIR")
    if env:
        return env
    return os.path.join(os.getcwd(), "DATA")


def _quantile(sorted_values: Sequence[float], q: float) -> Optional[float]:
    """线性插值分位数（纯标准库）。"""
    if not sorted_values:
        return None
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    pos = (len(sorted_values) - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return float(sorted_values[int(pos)])
    return float(sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (pos - lo))


def _quantiles(values: Iterable[float]) -> Dict[str, Optional[float]]:
    vals = sorted(float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool))
    return {
        "p50": _quantile(vals, 0.50),
        "p90": _quantile(vals, 0.90),
        "p99": _quantile(vals, 0.99),
    }


def _is_sensitive(text: str) -> Optional[str]:
    """返回命中的泄露形态名，未命中返回 None。"""
    if not isinstance(text, str):
        return None
    for name, pat in SENSITIVE_PATTERNS:
        if pat.search(text):
            return name
    return None


# ---------------------------------------------------------------------------
# build_daily_report
# ---------------------------------------------------------------------------

def build_daily_report(
    events: Sequence[Dict[str, Any]],
    version: str,
    *,
    install_id: Optional[str] = None,
    report_date: Optional[str] = None,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """
    聚合事件为日报。只产出聚合统计，不含原始文本。

    事件字段（可选）：
      - model: str
      - task_type: str
      - outcome: "pass" | "rework" | "redo"
      - tokens: int/float
      - latency_ms: int/float
      - issue_code: str（毛病类别码，如 E01）
      - error_type: str（报错类型，如 TimeoutError）
    """
    events = list(events or [])
    ts = now if now is not None else time.time()
    date_str = report_date or time.strftime("%Y-%m-%d", time.localtime(ts))

    # (model, task_type) -> 聚合
    buckets: Dict[Tuple[str, str], Dict[str, Any]] = {}
    issue_codes: Dict[str, int] = {}
    error_types: Dict[str, int] = {}

    for ev in events:
        if not isinstance(ev, dict):
            continue
        model = ev.get("model") or "unknown"
        task_type = ev.get("task_type") or "unknown"
        if not isinstance(model, str):
            model = "unknown"
        if not isinstance(task_type, str):
            task_type = "unknown"

        key = (model, task_type)
        bucket = buckets.setdefault(
            key,
            {
                "model": model,
                "task_type": task_type,
                "passed": 0,
                "rework": 0,
                "redo": 0,
                "_tokens": [],
                "_latency": [],
            },
        )

        outcome = ev.get("outcome")
        if outcome == "pass":
            bucket["passed"] += 1
        elif outcome == "rework":
            bucket["rework"] += 1
        elif outcome == "redo":
            bucket["redo"] += 1

        tok = ev.get("tokens")
        if isinstance(tok, (int, float)) and not isinstance(tok, bool) and tok >= 0:
            bucket["_tokens"].append(float(tok))

        lat = ev.get("latency_ms")
        if isinstance(lat, (int, float)) and not isinstance(lat, bool) and lat >= 0:
            bucket["_latency"].append(float(lat))

        ic = ev.get("issue_code")
        if isinstance(ic, str) and ic:
            issue_codes[ic] = issue_codes.get(ic, 0) + 1

        et = ev.get("error_type")
        if isinstance(et, str) and et:
            error_types[et] = error_types.get(et, 0) + 1

    stats: List[Dict[str, Any]] = []
    for (model, task_type), bucket in buckets.items():
        stats.append(
            {
                "model": model,
                "task_type": task_type,
                "passed": bucket["passed"],
                "rework": bucket["rework"],
                "redo": bucket["redo"],
                "token_quantiles": _quantiles(bucket["_tokens"]),
                "latency_quantiles": _quantiles(bucket["_latency"]),
            }
        )

    # 稳定排序，便于测试
    stats.sort(key=lambda s: (s["model"], s["task_type"]))

    report: Dict[str, Any] = {
        "install_id": install_id,
        "report_date": date_str,
        "server_version": version if isinstance(version, str) else str(version),
        "generated_at": ts,
        "stats": stats,
        "issue_codes": dict(sorted(issue_codes.items())),
        "error_types": dict(sorted(error_types.items())),
    }
    return report


# ---------------------------------------------------------------------------
# sanitize
# ---------------------------------------------------------------------------

def _sanitize_scalar(value: Any, field: str, dropped: List[Dict[str, Any]]) -> Any:
    """清洗标量值；泄露则丢弃并记录。"""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        reason = _is_sensitive(value)
        if reason is not None:
            dropped.append({"field": field, "reason": reason, "value": value})
            return None
        return value
    dropped.append({"field": field, "reason": "unsupported_type", "value": repr(value)})
    return None


def _sanitize_stats(stats: Any, dropped: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not isinstance(stats, list):
        return []
    out: List[Dict[str, Any]] = []
    for idx, item in enumerate(stats):
        if not isinstance(item, dict):
            dropped.append({"field": f"stats[{idx}]", "reason": "not_dict", "value": repr(item)})
            continue
        clean: Dict[str, Any] = {}
        for key in WHITELIST_STATS_FIELDS:
            if key not in item:
                continue
            val = item[key]
            path = f"stats[{idx}].{key}"
            if key in ("model", "task_type"):
                sv = _sanitize_scalar(val, path, dropped)
                if sv is None:
                    continue
                if not isinstance(sv, str) or not _SAFE_NAME_RE.match(sv):
                    dropped.append({"field": path, "reason": "bad_name", "value": val})
                    continue
                clean[key] = sv
            elif key in ("passed", "rework", "redo"):
                if isinstance(val, bool) or not isinstance(val, int):
                    dropped.append({"field": path, "reason": "bad_count", "value": val})
                    continue
                clean[key] = val
            elif key in ("token_quantiles", "latency_quantiles"):
                if not isinstance(val, dict):
                    dropped.append({"field": path, "reason": "bad_quantiles", "value": repr(val)})
                    continue
                q: Dict[str, Any] = {}
                for qk, qv in val.items():
                    if qk not in WHITELIST_QUANTILE_FIELDS:
                        dropped.append({"field": f"{path}.{qk}", "reason": "not_whitelisted", "value": qk})
                        continue
                    if qv is None:
                        q[qk] = None
                    elif isinstance(qv, bool) or not isinstance(qv, (int, float)):
                        dropped.append({"field": f"{path}.{qk}", "reason": "bad_number", "value": qv})
                        continue
                    else:
                        q[qk] = float(qv)
                clean[key] = q
        # 未在白名单的字段直接丢弃
        for key in item:
            if key not in WHITELIST_STATS_FIELDS:
                dropped.append({"field": f"stats[{idx}].{key}", "reason": "not_whitelisted", "value": item[key]})
        out.append(clean)
    return out


def _sanitize_counter_dict(
    data: Any,
    field: str,
    dropped: List[Dict[str, Any]],
    key_pattern: "re.Pattern[str]",
    key_reason: str,
) -> Dict[str, int]:
    if not isinstance(data, dict):
        return {}
    out: Dict[str, int] = {}
    for k, v in data.items():
        path = f"{field}.{k}"
        if not isinstance(k, str):
            dropped.append({"field": path, "reason": "bad_key_type", "value": repr(k)})
            continue
        reason = _is_sensitive(k)
        if reason is not None:
            dropped.append({"field": path, "reason": reason, "value": k})
            continue
        if not key_pattern.match(k):
            dropped.append({"field": path, "reason": key_reason, "value": k})
            continue
        if isinstance(v, bool) or not isinstance(v, int):
            dropped.append({"field": path, "reason": "bad_count", "value": v})
            continue
        out[k] = v
    return dict(sorted(out.items()))


def sanitize(report: Any) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    白名单字段清洗。返回 (clean_report, dropped_records)。

    任何字符串值若含 路径/URL/邮箱/key 形态(sk-、AKIA、长 token)/IP/中文长句(>20字)
    一律丢弃，并记录到 dropped。
    """
    dropped: List[Dict[str, Any]] = []
    if not isinstance(report, dict):
        dropped.append({"field": "<root>", "reason": "not_dict", "value": repr(report)})
        return {}, dropped

    clean: Dict[str, Any] = {}

    # install_id
    if "install_id" in report:
        iid = report["install_id"]
        if iid is None:
            clean["install_id"] = None
        else:
            # 本地生成的 UUID hex 固定为 32 位；仅此字段允许该形态。
            if isinstance(iid, str) and re.fullmatch(r"[0-9a-f]{32}", iid):
                sv = iid
            else:
                sv = _sanitize_scalar(iid, "install_id", dropped)
            if sv is not None:
                if isinstance(sv, str) and _SAFE_ID_RE.match(sv):
                    clean["install_id"] = sv
                else:
                    dropped.append({"field": "install_id", "reason": "bad_id", "value": iid})

    # report_date
    if "report_date" in report:
        rd = report["report_date"]
        sv = _sanitize_scalar(rd, "report_date", dropped)
        if sv is not None:
            if isinstance(sv, str) and re.match(r"^\d{4}-\d{2}-\d{2}$", sv):
                clean["report_date"] = sv
            else:
                dropped.append({"field": "report_date", "reason": "bad_date", "value": rd})

    # server_version
    if "server_version" in report:
        sv = _sanitize_scalar(report["server_version"], "server_version", dropped)
        if sv is not None:
            if isinstance(sv, str) and _SAFE_NAME_RE.match(sv):
                clean["server_version"] = sv
            else:
                dropped.append({"field": "server_version", "reason": "bad_version", "value": report["server_version"]})

    # generated_at
    if "generated_at" in report:
        ga = report["generated_at"]
        if isinstance(ga, bool) or not isinstance(ga, (int, float)):
            dropped.append({"field": "generated_at", "reason": "bad_number", "value": ga})
        else:
            clean["generated_at"] = float(ga)

    # stats
    if "stats" in report:
        clean["stats"] = _sanitize_stats(report["stats"], dropped)

    # issue_codes
    if "issue_codes" in report:
        clean["issue_codes"] = _sanitize_counter_dict(
            report["issue_codes"], "issue_codes", dropped, _ISSUE_CODE_RE, "bad_issue_code"
        )

    # error_types
    if "error_types" in report:
        clean["error_types"] = _sanitize_counter_dict(
            report["error_types"], "error_types", dropped, _ERROR_TYPE_RE, "bad_error_type"
        )

    # 未在白名单的顶层字段直接丢弃
    for key in report:
        if key not in WHITELIST_FIELDS:
            dropped.append({"field": str(key), "reason": "not_whitelisted", "value": report[key]})

    return clean, dropped


# ---------------------------------------------------------------------------
# Telemetry
# ---------------------------------------------------------------------------

class Telemetry:
    """
    匿名统计回传客户端。

    所有行为带开关，默认关闭（enabled=False）。
    opt_in: None（首启询问）/ True / False。
    """

    def __init__(
        self,
        *,
        enabled: bool = False,
        data_dir: Optional[str] = None,
        install_id: Optional[str] = None,
        opt_in: Optional[bool] = None,
        now: Optional[float] = None,
    ) -> None:
        self.enabled = bool(enabled)
        self.data_dir = data_dir if data_dir is not None else default_data_dir()
        self._now_fn: Callable[[], float] = (lambda: now) if now is not None else time.time
        self.opt_in: Optional[bool] = opt_in  # None = 首启询问

        self._install_id_file = os.path.join(self.data_dir, "telemetry_install_id")
        self._state_file = os.path.join(self.data_dir, "telemetry_state.json")
        self._pending_file = os.path.join(self.data_dir, "telemetry_pending.json")

        self._install_id: str = install_id if install_id else self._load_or_create_install_id()
        self._state: Dict[str, Any] = self._load_state()

        # 若外部传入 opt_in，覆盖状态
        if opt_in is not None:
            self._state["opt_in"] = opt_in

    # -- 持久化 ---------------------------------------------------------

    def _ensure_dir(self) -> None:
        try:
            os.makedirs(self.data_dir, exist_ok=True)
        except OSError:
            pass

    def _load_or_create_install_id(self) -> str:
        self._ensure_dir()
        try:
            with open(self._install_id_file, "r", encoding="utf-8") as f:
                existing = f.read().strip()
            if existing and _SAFE_ID_RE.match(existing):
                return existing
        except OSError:
            pass
        new_id = uuid.uuid4().hex
        try:
            with open(self._install_id_file, "w", encoding="utf-8") as f:
                f.write(new_id)
        except OSError:
            pass
        return new_id

    def _load_state(self) -> Dict[str, Any]:
        try:
            with open(self._state_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
        return {"opt_in": None, "last_send_date": None, "last_send_ok": None}

    def _save_state(self) -> None:
        self._ensure_dir()
        try:
            with open(self._state_file, "w", encoding="utf-8") as f:
                json.dump(self._state, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    # -- 公开属性 -------------------------------------------------------

    @property
    def install_id(self) -> str:
        return self._install_id

    @property
    def current_opt_in(self) -> Optional[bool]:
        """当前 opt_in 状态（None = 首启询问）。"""
        if self.opt_in is not None:
            return self.opt_in
        return self._state.get("opt_in")

    def set_opt_in(self, value: Optional[bool]) -> None:
        """设置 opt_in 状态。None 表示回到「首启询问」。"""
        self.opt_in = value
        self._state["opt_in"] = value
        self._save_state()

    # -- pending payload ------------------------------------------------

    def store_pending(self, report: Dict[str, Any]) -> str:
        """保存待上传 payload（原文），返回文件路径。"""
        self._ensure_dir()
        payload = {
            "install_id": self._install_id,
            "stored_at": self._now_fn(),
            "report": report,
        }
        try:
            with open(self._pending_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except OSError:
            pass
        return self._pending_file

    def pending_payload(self) -> Optional[Dict[str, Any]]:
        """读取待上传原文（供设置里「查看待上传」）。"""
        try:
            with open(self._pending_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
        return None

    def clear_pending(self) -> None:
        try:
            os.remove(self._pending_file)
        except OSError:
            pass

    # -- 发送 -----------------------------------------------------------

    def _today(self, now: Optional[float] = None) -> str:
        ts = now if now is not None else self._now_fn()
        return time.strftime("%Y-%m-%d", time.localtime(ts))

    def send_daily(
        self,
        sender: Optional[Callable[[Dict[str, Any]], Any]],
        now: Optional[float] = None,
        *,
        events: Optional[Sequence[Dict[str, Any]]] = None,
        version: str = "0.0.0",
    ) -> Dict[str, Any]:
        """
        每天最多发送一次。失败不重试风暴（当天不再重试）。

        返回状态字典：
          {"sent": bool, "reason": str, "date": str, "dropped": [...]}
        """
        today = self._today(now)

        # 开关关闭
        if not self.enabled:
            return {"sent": False, "reason": "disabled", "date": today, "dropped": []}

        # opt_in False 直接返回；None（首启询问）也不发送
        if self.current_opt_in is not True:
            reason = "opt_out" if self.current_opt_in is False else "opt_in_unset"
            return {"sent": False, "reason": reason, "date": today, "dropped": []}

        # 每天最多一次
        last = self._state.get("last_send_date")
        if last == today:
            return {"sent": False, "reason": "already_sent_today", "date": today, "dropped": []}

        # 失败不重试风暴：若今天已尝试过（无论成败），不再重试
        last_attempt = self._state.get("last_attempt_date")
        if last_attempt == today:
            return {"sent": False, "reason": "already_attempted_today", "date": today, "dropped": []}

        if sender is None:
            return {"sent": False, "reason": "no_sender", "date": today, "dropped": []}

        # 构建 + 清洗
        report = build_daily_report(
            events or [],
            version,
            install_id=self._install_id,
            report_date=today,
            now=now if now is not None else self._now_fn(),
        )
        clean, dropped = sanitize(report)

        # 保存待上传 payload（原文，供「查看待上传」）
        self.store_pending(report)

        # 标记今天已尝试（失败也不重试）
        self._state["last_attempt_date"] = today
        self._save_state()

        try:
            sender(clean)
        except Exception as exc:  # noqa: BLE001 - 失败不重试风暴
            self._state["last_send_ok"] = False
            self._state["last_send_error"] = type(exc).__name__
            self._save_state()
            return {"sent": False, "reason": "send_failed", "date": today, "dropped": dropped}

        self._state["last_send_date"] = today
        self._state["last_send_ok"] = True
        self._save_state()
        self.clear_pending()
        return {"sent": True, "reason": "ok", "date": today, "dropped": dropped}
