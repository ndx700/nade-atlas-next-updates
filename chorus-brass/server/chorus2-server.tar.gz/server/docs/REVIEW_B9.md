# B9 — Rerun #10–#13

范围：仅对应 `DOGFOOD_rerun.md` 文末 Rerun 表 #10–#13；未修改 #1–#9。未读取或输出运行数据中的密钥。

| 项目 | 修复与验证 |
|---|---|
| #10 启动锁提示 | 持锁期间写入当前 pid；第二个服务启动时打印「这个数据目录已有服务在跑（pid N）」并退出，不再使用恢复提示或输出 traceback。恢复工具仍保留恢复场景用语。测试覆盖锁竞争、实际启动入口及释放后重新获取。 |
| #11 指挥澄清 | 每个 questions 条目独立成卡，各自保存选项、默认值和答案。提示词要求一卡一问。支持 choice 或文本 answer；同批问题全部回答后，自动创建服务端规划任务，将各题及答案附入 API/CLI 指挥上下文，保留原 start 选项。重复提交已答卡不会重复规划。 |
| #12 费用与预算 | 显式价格（包括粘贴识别后保存的 price/prices）优先；缺少显式价格时，精确模型匹配使用本地目录默认估价。目录接口和成员视图带出价格；默认价标记 source=catalog、estimated=true。真实 record_usage 的费用进入 cost_split，budget.spent 按预算币种累计各阶段费用，达到上限后阻止后续段落派发。未知模型通过成员视图、usage 和项目待处理卡给出中文缺价提示，不虚构免费价格。 |
| #13 私密文件 | server.save 与备份 JSON 写入共用安全实现：同目录 mkstemp 唯一临时文件，在写入任何内容前即为 0600；写入、flush/fsync 后原子 replace，再同步目录。已有 0644 配置保存后收紧为 0600；失败保留旧文件并清理临时文件，忽略可预测 .tmp 符号链接。 |

新增测试：`server/test_review_b9.py`，最初 4 项；含下文 account_cap 返工新增 2 项，当前共 6 项，全部通过。覆盖写入期间/完成后的权限、原子替换失败、临时路径攻击、启动 pid 提示、两题独立回答和自动重规划、重复回答幂等、真实记账 hook、目录价格、显式价格覆盖、缺价提示、预算增长及封顶拦截。

验证结果：

- `PYTHONPATH=server python3 -m unittest test_review_b9 test_dogfood_fixes test_orchestra -q`：93 项通过。
- `test_review_fixes` 中不依赖 socket 的 18 项：全部通过。完整模块共 19 项，其中 HTTP 测试因沙箱 `socket.socket` 报 `PermissionError: [Errno 1] Operation not permitted`，无法完成。
- `test_chorus2`：40 项中 1 项通过，39 项因同一 socket 权限限制在 HTTP 测试初始化时出错，不能标记通过。
- `test_backup.BackupTests.test_lifetime_lock_rejects_second_writer`：通过。加密往返测试在 20 秒限时内未完成；完整备份测试组在 50 秒限时内未完成，不标记通过。
- 修改的 5 个 Python 文件通过 `py_compile`；`git diff --check` 通过。
- 全目录 `compileall` 另发现已有 `server/ali/setup_ali.py:63` 语法错误；该文件不在 B9 修改范围。

边界：目录价格是本地估价，不是实时官方报价；未知型号需要填写价格。多币种账本不自动兑换，预算只累计同币种费用；遇到币种不一致会给中文提示，要求统一预算币种。并行中已发出的请求不会因之后达到预算上限而追溯取消。旧版本持锁文件若没有 pid，只能显示 pid 未知；新版本持锁记录实际 pid。

## 合并 main（B7/B8）后的 account_cap 回归返工

根因：B9 #12 将 `orchestra.budget_state()` 的费用来源补为真实 `cost_split`（覆盖规划、执行、审核等阶段）。原来的 `run_segment()` 在没有项目预算时，仍把默认 cap=0 传给 `autopilot.budget_mode()`；该策略函数明确约定 `spent>0, cap<=0` 返回 `stop`。因此 `on_usage(... cost=1.5 ...)` 后，项目实际花费由原来的 0 变成 1.5，派发入口先走「预算用完」分支并返回，根本没有到后面的 `account_block()` 和 `account_cap` 建卡逻辑。项目最初没有 `pending` 字段，原断言因此报 `KeyError: pending`。这也会让没有设置任何上限的项目在首次付费后无法继续派发。

这是 B9 记账补全与已有零上限策略之间的语义冲突。对照合并后的 main（`c62d407`）：B7 在相关文件中修改的是重试 sleep、规划异常日志和谱稿 ID 去重；B8 修改的是 ensemble 的 breaker busy 与恢复用量。它们没有修改上述预算分支或账户封顶建卡逻辑，不应通过撤销 B7/B8 或更改原测试期望规避此问题。

修复：`run_segment()` 使用 `budget_state()` 返回的规范化预算，仅在项目 cap>0 时调用预算策略；未设置预算或 cap=0 时采用 normal 模式。这与 `budget_state()` 对未设上限的判断一致，保留真实费用统计、正预算封顶、账户小时/日封顶以及 `autopilot.budget_mode()` 自身的既有语义。

新增两个无 socket 回归测试（`test_review_b9.B9Runtime`）：

- `test_account_cap_card_after_usage_without_project_cap`：真实 `on_usage()` 累计 1.5 元、账户小时上限 1 元；分别验证未设项目预算、项目 cap=0、项目 cap=10 均不调用成员、段落 blocked，并且仅生成 `account_cap` 卡。
- `test_usage_without_project_cap_still_dispatches`：账户未封顶时，分别验证未设项目预算和 cap=0 在已有费用后仍正常完成段落。每个场景使用独立唤醒图，避免前一场景触发唤醒限流。

验证：修复前新增测试复现缺卡和零派发；修复后 `cd server && python3 -m unittest -q test_review_b9 test_dogfood_fixes test_orchestra test_autopilot test_review_b7 test_review_b8` 共 **160 项通过**，含原有 B9 正预算封顶与 B7/B8 回归测试；`git diff --check` 通过。未修改 `test_chorus2.py` 的任何期望。

本轮环境没有 `python` 命令，`python3 -m pytest` 提示未安装 pytest。改用 unittest 直接执行原 `test_chorus2.TestCliGuardAndCaps.test_account_cap_blocks_wakes_and_segments` 时，当前检出版本的 `Base.asyncSetUp()` 会调用 `TestClient(TestServer(...)).start_server()`，在 socket 初始化阶段报 `PermissionError: [Errno 1] Operation not permitted`；该原始 HTTP 用例未能跑到断言，不标记通过。上述新增回归测试直接调用相同的记账与派发路径，无需 socket。
