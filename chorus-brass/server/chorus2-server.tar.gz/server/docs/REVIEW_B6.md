# B6：MiMo designopts 审查核实

核查范围：`server/docs/R_B1_mimo.md` 的 #1、#3、#4。仅修复本卡要求的问题；未涉及 #2、#5、#6。

## #1：部分成立，已修复

原代码已经检查 `result.ok`，失败时也已抛出固定的 `RuntimeError("Design member failed")`，所以“失败正文直接进入 parse_spec”的描述不成立。`AcpAdapter` 的文本来自 `agent_message_chunk`；工具事件和错误字段也不是直接拼接到该文本中。

成立的问题是：成功结果的空文本未被拒绝，以及 usage 缺失时没有记账。此外，ACP 默认返回全零 usage 字典，该字典为真，原代码会记录零用量，同样无法反映未报告用量的调用。

修复后仅接受 `result.ok` 且文本非空、非纯空白的结果，否则抛出上述固定错误，不带结果正文或 error 字段。每个返回的 ACP 结果均先记账，包括失败或空文本结果：有非零 token 用量时使用报告值；usage 缺失或 token 计数全零时，按输入（system + prompt）和输出字符数各除以 4、向上取整估算 token，并传入 `estimated=True`。沿用 `server.record_usage` 按配置价格计算费用；`chorus.price_of` 同样读取该价格来源。估算不代表供应商实账，槽位的 `cost_estimate` 仍是原有的字符数估算值。无需工具的拒绝策略及 ROLE 恢复行为保持有效。

测试：`RouteTests.test_acp_requires_successful_nonempty_text_and_accounts_every_result` 覆盖成功、失败但正文为合法 spec、失败且含模拟私有正文、空文本、纯空白、报告 usage、空 usage、全零 usage；验证固定错误、逐次记账、估算量、项目/模型归属、工具拒绝及 ROLE 恢复。

## #3：成立，已修复

空成员池原本在草稿生成时映射为 `member_failed`，在展开时映射为 `render_failed`，无法区分无可用成员。新增 `NoMemberError`，在两个阶段均映射为 `state="failed", error="no_member"`，按本卡要求采用该错误码，而不是原审查建议的 `member_failed`。

测试：更新 `DesignTests.test_timeouts_no_members_and_failed_render` 的空池断言；新增 `test_no_eligible_member_during_expansion_retains_draft`，验证草稿完成后只剩不健康/不支持设计的成员时，展开返回 `no_member`、保留 ready 草稿，且没有额外模型调用。

## #4：部分成立，已修复

原审查所述“pick 后 cancel 把已选 ready 选项变为 cancelled”不成立：`cancel()` 仅将 pending 选项标为 cancelled，已选 ready 选项保持 ready。取消 pending 展开时，render 会变为 cancelled，而不是 failed。

但原 `design_context()` 确实没有检查取消状态，因此取消展开后仍会通过回退逻辑注入已选草稿。现在只要选中选项或 render 为 cancelled，就返回空上下文；即使仍残留 spec 也不会注入。正常展开失败但选中草稿仍有效时，继续保留原有草稿回退行为。

测试：`ConciergeTests.test_cancelled_expansion_or_option_does_not_inject_draft` 使用事件控制真实 pick → 展开 → cancel 流程，验证取消前有草稿、取消后无上下文；另覆盖 failed render 的有效草稿回退、选项被标 cancelled 时无草稿注入、残留 ready render spec 也不能绕过取消检查。已有测试继续验证 ready 展开规格可注入。

## 验证结果

在 `server/` 下执行：

- `/workspace/venv/bin/python -m pytest -q test_designopts.py`：**20 passed, 17 subtests passed**。
- 扩大回归：`/workspace/venv/bin/python -m pytest -q test_designopts.py test_chorus2.py test_task_cards.py test_review_b5.py --tb=short`：**59 passed, 40 failed, 43 subtests passed**。失败来自需要真实 TCP socket 的现有测试，沙箱创建 socket 抛出 `PermissionError: [Errno 1] Operation not permitted`。
- 全量回归首次运行遇到失败后停滞，已中断；再用 `timeout 30s /workspace/venv/bin/python -m pytest -q -x --tb=short` 定位首个失败：`BackupTests.test_api_auth_boundaries_and_real_http_flow` 在创建 TCP socket 时遇到同一权限限制，结果 **43 passed, 1 failed**。不能声称全量回归通过。
- `git diff --check`：通过。

未读取或输出真实密钥；测试使用本地替身，不调用供应商。
