# DOGFOOD.md — running our own work through chorus2 (协奏), local only

Setup: local chorus2 (`server.py`, data `/workspace/dogfood/data`, port 18791), members MiMo 2.6 Pro (API), DeepSeek V4.1 Flash (API),
Gemini 3.8 Flash (API, free tier → low priority), Codex gpt-6.1-sol high (CLI). Project 「狗粮·cardlint」, mode 协奏.

| # | Friction / bug | Severity | Fix |
|---|---|---|---|
| 1 | Port 8791 is already taken on the box by the sandbox tunnel → server dies with "address already in use", no hint | low | ran on 18791; server should print a plain-Chinese hint + suggest AICHAT_PORT |
| 2 | API token is sha256(password)[:32], not the password; a script using the password gets 「密码不对」 with no hint | low | docs + error text should say "用 app 配对或 token" |
| 3 | Creating a 协奏 project fires `@全体 新项目…` to every member (run_chain) before the 指挥 plans — 4 parallel paid replies for nothing | med | 协奏/交响 projects: only the 指挥 gets the brief |
| 4 | `POST /api/orchestra/{pid}/plan` runs the 指挥's planning inside the HTTP request; a client disconnect (app backgrounded, curl ^C) cancels the plan silently | high | plan must run as a server task; the route returns 202 + progress events |
| 5 | The worktree/checkpoint/breaker engine (`ensemble.py`) is not wired to the running 协奏 loop (`chorus2.conduct` uses run_member); fault isolation, per-card worktrees, checkpoints resume only exist in tests | high | wire ensemble into conduct for projects with a workspace repo |
| 6 | 指挥 split a ~150-line CLI tool into 12 段落 (README, examples, packaging each their own) — review + dispatch overhead ×12 | med | deterministic segment-count guardrail + merge trivial segments (B4) |
| 7 | Every 段落 ended `blocked: 没有能接手的声部`: the 指挥 writes free-text `skills` (「需求分析」「python」) and `orchestra.assign` hard-filters members that declare none → nobody qualifies | **high** (pipeline dead) | skills become a soft preference (B4) |
| 8 | Gemini free tier: 3.1-pro 429 (quota), 3.8-flash 503 once | med | member `priority: low` → light cards only, rate limit, 429/503 → backoff + reassign (B4); dispatch.py backs off 5/15/45 s on 5xx |
| 9 | Codex sandbox (workspace-write) cannot open sockets or write git metadata of a worktree → it cannot run the aiohttp test suite or commit | med | lead runs tests + commits; card text now says so |

## Rerun 2026-10-30 12:30 HKT (main 3054dda+, after B4)
Plan now 4 段 (was 12) and segments get assigned (B4 fixes for #6/#7 confirmed). New frictions:

| # | Friction / bug | Severity | Fix |
|---|---|---|---|
| 10 | Starting a 2nd server on the same data dir dies with 「服务仍在写入，不能恢复」 — restore wording at startup, and no hint which pid holds the lock | low | startup: 「这个数据目录已有服务在跑（pid N）」 |
| 11 | 指挥 clarify card packs two different questions into one card and gives each *answer* as an "option" — picking one loses the other; answering does not resume planning (needed a second POST /plan) | high | one question per card; answering a clarify card re-triggers plan with the answers appended |
| 12 | `cost_split` tokens counted (in/out per phase) but `cost` is `{}` and `budget.spent` stays ¥0 — API members have no price table → budget cap never trips | high | pricing from paste auto-detect / catalog default; warn when a paid member has no price |
| 13 | `data/config.json` (holds API keys) was rewritten with mode 0644 by the server | high (security) | atomic write with 0600 preserved |
