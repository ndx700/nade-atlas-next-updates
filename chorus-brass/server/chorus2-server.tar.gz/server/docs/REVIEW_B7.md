# B7 审查核实与修复

核实日期：2026-10-30。依据当前工作树逐条检查 `R_B4_mimo.md`（20 条）和 `R3_gemini.md`（7 条），不直接采纳原报告的严重级别或建议实现。未输出密钥值，也未为排查而转储环境或配置。

## A. MiMo 审 B4

| 编号 | 结论 | 代码依据及处理 |
| --- | --- | --- |
| #1 | 不成立 | `chorus2.plan` 先定义闭包，再给 `prompt` 赋值，最后才 `await lead_call`；实际调用不存在未赋值窗口。实际 plan 回归已覆盖此路径。 |
| #2 | 成立，已修复 | 异步 HTTP 模式没有调用方等待异常，done callback 只取走异常，原来没有 traceback。现在在 `work` 的异常分支记录 project ID 和 traceback，同时保留失败卡、持久化、重新抛出及 shield 行为。新增异步失败日志测试。 |
| #3 | 不成立 | `S.member` 与 `members()`/`candidates()` 都取 CFG 中的成员；`candidates` 过滤成员，不改写字典。`auto=False` 的成员不能自动接单是既有策略。低优先级的指定 assignee 还必须属于经过难度、额度和 low_wait 过滤的 pool。 |
| #4 | 不成立 | `tried` 是当前卡已失败成员集合；`tried.add(who)` 和临时传 `tried \| {who}` 在这些分支中都用于排除失败者，后者无害。没有漏排或错误改派的证据。 |
| #5 | 不成立，补回归 | 429/503 后允许 `assignee=""` 表示暂时无人接手，这是 waiting 状态的正确表示。GRAPH 的 record/set_step 均在 `if who` 内。新成员尚未尝试，不能提前加入失败集合；失败时才加入。新增断言：无替代成员时 waiting/retry_at 齐全，GRAPH 永不写空成员；有替代成员正常完成。 |
| #6 | 原指控不成立，但发现相邻真实问题并修复 | `compact_plan` 的唯一生产调用方是 `parse_plan`，先去重、去环再压缩，不会将同 ID 两段直接交给 merge。首段向相邻段合并后还会重写依赖并 `_drop_cycles`。但 ID 归一化的 while 循环有真实死循环：例如前段显式为 `s2`，第二段也为 `s2` 时，fallback 永远算出 `s2`。已改为递增 suffix 直到找到空 ID。新增显式/自动 ID 连续碰撞，以及压缩后依赖、token 总量测试。 |
| #7 | 不成立 | `parse_plan` 仅在 brief 非 None 时调用 compact；空字符串可合法得到目标 5。 |
| #8 | 成立，改判并修复 | 与主管初筛不同：本环境 aiohttp HeadersParser 对原始请求头值使用 UTF-8 + surrogateescape 解码，非法 UTF-8 字节确实可变为孤立 surrogate，随后 t.encode 抛 UnicodeEncodeError。现在捕获该编码失败并按无效 token 返回 401；不使用 surrogateescape 放宽鉴权。新增以原始非法字节经真实 HeadersParser 解码后调用 auth 的回归，验证不会调用 handler，中文密码及正确 token 既有测试仍通过。 |
| #9 | 不成立 | 已检查本环境 aiohttp `web.run_app` 源码：只吞 GracefulExit/KeyboardInterrupt，启动的 OSError 会传播给 `run_http`。提示明确要求修改 AICHAT_PORT，未承诺自动换端口。已有 EADDRINUSE 提示及 EACCES 继续抛出的测试。 |
| #10 | 不成立 | `[t, tick, *PLANNING.values(), *RUNNING.values()]` 在同一事件循环中同步构造列表，中途没有 await；任务的 finally 不会在展开期间插入运行。显式 list 包装不会增加保护。 |
| #11 | 不成立 | 测试 setUp 每次通过 patch 替换整个 CFG，cleanup 停止 patch，修改 password 不会泄漏至下个测试。 |
| #12 | 不成立 | 难度 1–2 的 need_tier 是 weak，rank 为 0，assign 的 `need_rank > 0` 与 execution_pool 的 `difficulty <= 2` 一致。已有难度 2 可接、3–5 拒绝的测试。 |
| #13 | 不成立 | 如 #3，低优先级的 explicit 必须在 pool，已经覆盖难度和 low_wait。 |
| #14 | 不成立 | h_plan 正运行在事件循环内，正常路径 create_task 不会因没有 running loop 失败。work 完成/失败都有 finally 清理；done callback 注册顺序也没有丢失异常或遗留 PLANNING 的证据。不为假设的内存耗尽建立额外状态机。 |
| #15 | 不成立 | 与 #1 重复，闭包在赋值后才执行。 |
| #16 | 不成立，补回归 | parse_plan 在压缩之前已 int 转换 est_tokens，非法字符串 fallback 为 4000，并限制非负。新增字符串 token 经实际 parse→compact 后仍为整数且总量守恒的测试。没有生产路径直接传未经归一化的段给 compact_plan。 |
| #17 | 不成立，补回归 | LowPriorityLimited 分支在覆盖 who 前把旧成员设为 resting；新 who 非空才 record/working，无成员就 waiting 返回。新增测试同时覆盖抛异常限流、HTTP 限流及有/无替代成员四种组合，明确断言旧/新成员身份。 |
| #18 | 成立，已修复 | `c.asyncio` 与其他模块引用的是同一 asyncio 模块，对其 sleep 的 patch 会污染全局。恢复阶梯等待现使用 `from asyncio import sleep` 的本模块引用，测试只 patch `c.sleep`；事件循环及其他模块的 sleep 保持正常。 |
| #19 | 不属于功能缺陷 | 下划线 helper 的跨模块使用是封装建议，没有导致错误的具体行为。为此创建公开 API 超出本卡修复需要。 |
| #20 | 不成立 | `PORT` 在导入时就从 AICHAT_PORT 读取，run_app 也用同一个 PORT；提示的 PORT+1 与当前监听配置一致。 |

## B. Gemini 审 ensemble.py / checkpoints.py

| 编号 | 结论 | 代码依据及处理 |
| --- | --- | --- |
| #1 | 所述路径遍历不成立 | `Path.resolve()` 默认就是 strict=False，可解析不存在的多级路径，同时规范化 `..` 并解析既有 symlink。比较前缀包含 `os.sep`，`tree_sibling` 不会匹配 `tree/`。根目录的 README 正常通过。新增实际文件测试覆盖新建深层路径、相对越界、绝对 sibling、symlink 指向外部及带 `..` 的路径；仅内部文件获准写入。没有为等价的 is_relative_to 改写安全检查。 |
| #2 | 部分成立，已修复 | 冷却过期后的第一次失败确实从 0 重新计数，不能立即重开。现在只要存在未被成功清除的 until，失败就重新设置完整冷却期；增加 probing/claim，保证冷却后的单次探测，正在探测的成员暂不可用。被 breaker 拦截的调用不当作新的服务失败。成功仍由 ok 清除失败计数与 until。报告所称“成功之间偶发失败永远累加”不成立：执行/审核成功原本就调用 ok；没有任何成功的失败序列应当累计。新增冷却后首次失败、成功重置、并发只允许一个探测测试。 |
| #3 | 部分成立，已修复 | failover 是无 await 的同步方法，在本引擎单事件循环中没有所称多核写竞态，不添加锁。真实问题是审核调用失败返回 FIX，导致作者返工并降低通过率；还可能反复选回失败 reviewer。review 现在在本轮排除已失败 reviewer，尝试其他非作者成员；无人完成审核时返回 None。卡保存执行结果并进入 waiting/retry_at，作者不扣分；后续 run 到期且有审核者时只续做审核，可经 checkpoint 恢复。实际 FIX 仍正常返工。新增故障后换审核者和等待→重启→审核通过且不重复执行的测试。 |
| #4 | 产物丢失成立，已修复；effect 命中时 double-merge 的说法不成立 | 原 resume 命中 effect 已直接 passed/done，不会再 merge，但仅恢复旧 cards 数据，会遗漏后来生成的 summary/artifacts。现在 merge 前保存交付字段，成功 effect 同时保存 by/summary/artifacts；resume 用 effect 回填交付、assignee 和 completed 状态，即使 cards 行不存在也能恢复。best_of 胜出同样记录父卡 effect。SQLite schema 和 done_effect JSON API 已能存这些字段，无需改 checkpoints.py。新增丢失 passed 写入、关闭/重开 SQLite、删除 cards 行、下游 packet 仍收到上游产物且只 merge 未完成卡的测试。 |
| #5 | 所述 watchdog 重复调度不成立；补充取消清理 | asyncio.wait 只把已经完成取消/清理的 Task 放进 fin；调度器只在此后移出 running 并恢复 todo，因此不需要再 gather 已完成的 t。新增延迟 finally 测试，确认旧任务清理期间不会启动第二次。另修复真实相邻清理问题：引擎整体取消后原 finally 只发 cancel 没有等待；现在 drain watchdog 和卡任务。git 包装器在创建或 communicate 期间取消时会 kill 并回收子进程，避免任务结束后 git 仍操作工作区；新增子进程回收测试。 |
| #6 | 成立，已修复 | errors 改为 deque(maxlen=1000)，原 append、遍历及真假检查接口保持兼容，丢弃最旧异常。新增超过容量后的长度和保留起点测试。 |
| #7 | 成立，已修复 | merge 仅移除赢家/尝试合并者的 worktree，未胜出者原来一直残留。新增 Workspace.discard，在 best_of 的 finally 中删除所有候选 worktree 和临时分支；覆盖成功、失败回退和取消路径。通过真实 git 测试验证成功/取消后候选目录、分支均不存在，胜出文件仍在 main。 |

## 验证及边界

针对性回归位于 `test_review_b7.py` 与 `test_dogfood_fixes.py`。同时运行既有 fault、orchestra、ensemble 纯单元、review_fixes、review_b5 套件。结果见下方最终记录。

- `git diff --check`：通过。
- 实际文件写入与真实 git worktree/merge/删除、SQLite 关闭重开均在本地临时目录验证，不依赖模型服务。
- 本环境禁止创建监听 socket。最初运行 `test_ensemble` 的四个混合集成测试，以及扩展回归中的 `test_real_http_and_stream_error_classification`，均在 TestServer 建 socket 时遭遇 `PermissionError: [Errno 1] Operation not permitted`，未进入业务断言。保留测试代码，没有通过改写生产行为绕过限制。
- 审核等待到期后需再次调用引擎 run 才能恢复；本引擎不新增永久驻留的重试循环。既有 FIX/执行失败的有限重试行为保持不变。
- git merge 与 SQLite effect 不是跨系统原子事务；本卡修复 effect 已记录、passed 尚未保存时的交付恢复，不宣称消除进程在 merge 成功与 effect 落盘之间硬退出的窗口。旧版本已经丢失且 effect 未记录的交付元数据无法凭空恢复。

最终验证：**163 项，162 通过，1 项因 socket 限制跳过，0 失败**。选择的套件为 `test_review_b7`、`test_faults`、`test_dogfood_fixes`、`test_orchestra`、`test_ensemble.TestPieces`、`test_review_fixes`、`test_review_b5`。仅在本次运行的 loader 中将 `ReviewFixes.test_real_http_and_stream_error_classification` 标记 skip，未修改该测试文件。失败规划测试按预期打印测试异常 `RuntimeError: bad` 的 traceback。

可在 `server/` 下重跑（具备监听权限时无需跳过）：

```bash
python3 -m unittest test_review_b7 test_faults test_dogfood_fixes test_orchestra test_ensemble.TestPieces test_review_fixes test_review_b5 -q
```
