# 低配服务器（2 核 / 1G）实测

用 `python bench/lowspec.py` 测：服务器绑在 2 个 CPU 上（taskset），数据目录全新。模拟 10 台手机，每台发 30 条消息，并且反复拉首页和聊天；同时开着 10 条 WebSocket。

| 指标 | 结果 |
|---|---|
| 空闲 RSS | 60 MB |
| 负载下 RSS | 61 MB |
| 900 次请求用的 CPU | 0.19 秒（2 核约 52%，持续 0.18 秒） |
| 发消息 p50 / p95 | 1.9 ms / 3.9 ms（目标 p95 < 150ms） |
| 启动后 import 的 RSS | 49 MB |

- 重的模块都是懒加载：ffmpeg 只在请求缩略图或波形时调用；sherpa-onnx、edge-tts 只在装了插件后才 import；asset 的关键帧提取按需调用。
- SQLite（断点续跑）开了 WAL，`synchronous=NORMAL`，所有连接共用一把锁。
- 插件安装器会先检测 CPU、内存、GPU、磁盘，只列出这台机器跑得动的引擎（见 plugins.fits，测试在 test_plugins.py）。2C/1G 只会看到：手机自带、Edge 在线（标“非官方”）、云端（MiMo、MiniMax、OpenAI）。
