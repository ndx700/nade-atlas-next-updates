# B8：核实 MiMo 审 B7 的 10 条意见

核实日期：2026-10-30。输入为 `server/docs/R_B7_mimo.md`，逐条核对当前代码、B7 报告及本地回归结果。修复 #2、#3，增强 #10 的测试；其余不按原报告建议改动，理由如下。未读取或打印密钥，也未转储环境变量或凭据配置。

| 编号 | 结论 | 核实依据与处理 |
| --- | --- | --- |
| #1 breaker probing 并发清除 | 不成立，补并发回归 | `claim()`、随后读取 `probe` 都是同步操作，中间没有 `await`。在引擎的单事件循环内，已存在 probe 时，后续调用在进入 try/finally 前就返回 BUSY，不会清除标记；更早开始的普通调用已保存 `probe=False`，结束时也不会清除新探测者。探测返回后，`run_card` 的 `hb.done`、`metric` 和 `breaker.fail/ok` 同样没有 await，失败重开之前不会插入另一次 claim。原 B7 测试实际也使用两个重叠的 Task，并非只有顺序场景。新增更强的交错测试：普通调用跨越开闸与冷却、第二个调用开始半开探测、普通调用先结束、连续十次并发请求均被拒绝，probe 仍保留，取消探测后才释放。无需引入 token/引用计数。 |
| #2 BREAKER_BUSY 处理 | 部分成立，已修复 | choose 与 call 之间有 worktree/share 等 await，成员可能在这期间被其他卡占用或熔断。原代码虽不增加 breaker 失败数，却增加 runs/fails、加入 tried 并可能最终 blocked。tried 只活在一次 run_card 内，“永久排除”表述过重，但误判失败真实存在。现在在 metric/account/失败处理前单独识别 BUSY；用本轮临时 busy 集合避免立刻重复选中，若还有可用成员就立即换人，否则保存 `_execute_pending`、retry_at 并进入 waiting。ready 到期按执行成员可用性判断，区别于审核等待；重启恢复后不受上一轮 busy 集合影响。测试覆盖选择后才被熔断、无执行/失败统计/计费、SQLite 恢复、到期门控、无需审核者即可重新派执行，以及有替代成员立即完成。 |
| #3 resume 结果缺 usage | 成立，已修复 | Result.usage 默认是空 dict，而不是 None；但默认值是哪一种都不能保留原用量。真正问题在于 `_review_pending` 未保存 usage，恢复后 `_candidate` 的 `_cost` 算成 0，可能影响成本排序。现与 text/artifacts 一起保存 usage，恢复的 Result 自动取得原值。执行计费仍只发生在实际执行分支，不重复计费。测试用 SQLite 恢复待审核候选，断言原 usage、成本 6、仅执行一次、仅计执行费一次。历史 pending 无 usage 仍按 Result 默认空 dict 兼容；已经丢失的历史用量不能凭空恢复。 |
| #4 failover 重选失败 reviewer | 不成立，补回归 | failover 可能把某个失败成员设为 lead，但下一次实际审核始终通过 `reviewer(author, tried)` 选取；lead 分支与 others 分支都排除 tried，同时排除作者。因此不存在重复调用失败 reviewer 的所述路径。新增三个审核者全部失败的测试，实际调用严格为 L、r1、r2 各一次，最终返回 None，不误判作者需要返工。 |
| #5 旧 effect 缺少交付字段 | 不成立，补兼容回归 | resume 已先 `c.update(old, state=...)`，old 就是 `ckpt.cards(pid)` 返回的 cards 行；然后只覆盖 effect 中实际存在的交付字段。旧 effect 只有 by 时，cards 行中保存的 summary/artifacts 原本就保留，无需重复回填。新增旧式 effect 与 review 状态 cards 行组合测试，验证产物、摘要、passed 恢复。若旧 effect 与 cards 两处均没有交付元数据，没有来源可以恢复；无依据伪造产物不能解决历史数据缺失。 |
| #6 finally 删除胜出 worktree/branch | 所述产物丢失原因不成立，补真实 git 故障注入 | merge 成功后，胜出提交已被 main 的 merge commit 引用，删除临时分支不会删除 main 上的提交和文件；worktree 本来也已由 merge 移除。新增 done_effect 写入抛异常的测试，确认 finally 清掉所有候选目录和分支后，胜出文件仍能从 main 的工作区及 `git show main:<file>` 读取。失败合并的候选允许清理并重新执行；正常成功、取消、失败回退的清理仍由 B7 测试覆盖。不采用“永久保留赢家”建议，避免候选泄漏。边界：git merge 与 SQLite effect 非原子事务，写 effect 失败时不能保证自动恢复时不重复执行；这在 B7 报告中已明确，不把“main 保留产物”表述为跨系统 exactly-once 保证。仅跳过 discard 或保留分支也不会使 resume 自动识别未落盘的 effect。 |
| #7 watchdog 异常被 gather 吞掉 | 不成立，补故障回归 | 具体举出的 hb.stalled 错误发生于 `_watch()` 内，而 watchdog 已在每轮 try/except 中将其写入 errors 并继续循环。run finally 的 gather 用于等待取消清理，不会吞掉该路径原本应有的日志。新增 hb.stalled 抛错测试，验证 errors 含 watchdog 错误且任务继续运行。报告关于 supervised 在 finally 中 pop running 的描述也不符合当前代码；running 是 run 调度器移除的。 |
| #8 ID 去重 | 不成立，补碰撞回归 | 归一化只要求唯一、非空，没有 ID 连号要求。循环每次 suffix 加一，seen_ids 有限，必然找到空位；raw 还限制最多 24 段，因此探测次数受已见 ID 个数约束，不取决于显式 ID 的数值大小。“i+1 远大于 len(seen_ids)”在这里也不成立：循环每处理一段恰好加入一个唯一 ID，下一段开始时 len(seen_ids)==i。新增 33 个原始段反复碰撞、截断到 24 段后仍全部唯一，以及超大显式 ID 重复的测试。保留 B7 的递增修复，不作等价改写。 |
| #9 auth TypeError | 不成立 | 当前请求头/查询参数给出字符串，t.encode() 返回 bytes；token() 返回 SHA256 hexdigest 的字符串切片，其 encode() 也返回 bytes。compare_digest 两边都是 bytes，不存在所称 TypeError。假设将来改变 token 的返回类型不是当前缺陷；非字符串没有 encode 时还可能是 AttributeError，盲目增加 TypeError 也不构成有意义的保障。保留现有 UnicodeEncodeError 防护。 |
| #10 恢复测试掩盖 retry_at | 成立，已增强测试 | 原测试手动清零并写回 retry_at，确实无法验证恢复后的时间门控。现在断言恢复的 retry_at 与 pending 完全一致，不修改 checkpoint；模拟截止前时间验证 ready 为空，再模拟截止后时间运行，验证通过且不重复执行。 |

## 验证

新增 `server/test_review_b8.py`，并修改 `server/test_review_b7.py` 的恢复测试。针对 #2、#3，还在独立 Python 进程中加载 HEAD 的原版 ensemble 执行新增测试：分别复现 blocked 而非 waiting、pending 缺少 usage。该基线检查没有改写工作区文件。

本地临时目录中的测试使用真实 git worktree/merge 和 SQLite，不请求模型服务。主要回归运行方式（从 `server/` 执行）：

```bash
python3 -m unittest test_review_b8 test_review_b7 test_faults test_dogfood_fixes test_orchestra test_ensemble.TestPieces test_review_fixes test_review_b5 -q
```

本环境不能创建监听 socket；最终验证仅在临时 unittest loader 中将 `test_review_fixes.ReviewFixes.test_real_http_and_stream_error_classification` 标记跳过，未修改该测试源文件。`test_ensemble` 本次选用纯单元类 TestPieces。

执行等待与审核等待沿用引擎现有恢复方式：到期后需再次调用 run；本次没有添加常驻定时调度器。首次扩展回归发现只等待会影响故障场景原有的即时换人行为，已调整为优先尝试替代成员，随后重跑相关套件通过。

最终结果：**172 项，171 通过，1 项因 socket 权限跳过，0 失败**。规划失败用例按预期记录 `RuntimeError: bad` 的 traceback；不属于测试失败。`git diff --check` 通过。最终结果已包含全部新增 B8 测试及修订的 B7 测试。

可复现上述环境内运行方式：

```bash
python3 - <<'PY'
import unittest
import test_review_fixes
cls = test_review_fixes.ReviewFixes
name = 'test_real_http_and_stream_error_classification'
setattr(cls, name, unittest.skip('Listening socket creation denied by environment')(getattr(cls, name)))
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'test_review_b8', 'test_review_b7', 'test_faults', 'test_dogfood_fixes',
    'test_orchestra', 'test_ensemble.TestPieces', 'test_review_fixes', 'test_review_b5',
])
result = unittest.TextTestRunner(verbosity=1).run(suite)
raise SystemExit(not result.wasSuccessful())
PY
```
