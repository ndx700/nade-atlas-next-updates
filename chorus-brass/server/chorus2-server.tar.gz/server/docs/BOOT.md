# App 启动与离线重连 API

这些接口沿用 `Authorization: Bearer <token>` 鉴权。

`GET /api/boot` 立即返回本地快照，不等待长轮询，也不访问模型或额度服务：

| 字段 | 内容 |
| --- | --- |
| `epoch`, `v` | 当前进程标识和版本，与 index 一致 |
| `index` | `/api/index` 的视图 |
| `dms` | `/api/dms` 的私信卡片数组 |
| `read_state_supplied` | 是否提供了 `seen` 参数 |
| `config` | `/api/config` 的视图，接口密钥打码、环境变量只列名称 |
| `members` | 全部成员的聊天视图（模型、头像、价格等） |
| `features` | 插件功能开关，与 index 的 `features` 一致 |
| `quota` | `members` 为缓存的统一额度，`quota` 为原有额度视图，`quota_at` 为原有刷新时间 |

`seen` 可传与 `/api/dms` 相同的 JSON：`{"项目ID":{"成员名":已读seq}}`。
启动快照返回 `ETag`，客户端保存响应体和该值，下次发送 `If-None-Match`。
内容相同则返回无响应体的 `304`，客户端继续使用缓存。支持弱标签、多个标签及 `*`。
缓存策略为 `private, no-cache`，按鉴权信息区分；登录失效时返回 `401`，不会返回 `304`。
ETag 覆盖整个响应，包括读取进度、配置、成员、插件功能、额度和进程标识。

`GET /api/chat/{pid}?since=seq` 立即返回该序号之后的消息，以及最新 `seq` 和 `v`。
没有新消息时返回 `200` 和空 `messages`。首次加载传 `since=0`。
客户端同时保存 `v` 和 `epoch`，离线重连时传 `since=seq&v=v&epoch=epoch`，
这样也会收到旧消息的编辑、撤回和删除标记。序号超出服务端范围、版本超前或进程变化时，
返回 `full: true` 的快照，客户端替换缓存。
原有仅传 `v` 的版本增量与长轮询行为继续保留。

`POST /api/say` 可带最长 200 字符的字符串 `client_id`。
同一项目内重试相同发送会返回原消息的 `seq`、`to`、`message` 和当前 `v`、`epoch`，
不会再次写入消息或唤醒成员。顾问请求的 `intent` 标记也会保留。
同一编号改用其他文字、附件或发送选项会返回 `409` 和 `code: client_id_conflict`。

`POST /api/msg` 保留编辑、撤回、置顶和表情操作的原有语义，也接受 `client_id`。
同一项目内相同操作重试会返回首次的 `{ok, message}`，不会再次切换置顶或表情状态。
编号用于不同消息或操作内容时返回 `409`。发送编号与操作编号分别去重。
去重记录写入聊天文件，服务重启后仍有效；编辑和撤回不会删除记录。
未传编号或传空字符串时保留旧客户端行为。写入失败返回可重试错误，不确认未保存的操作。

错误继续提供 `error` 字符串，并提供 `fix`：
`retry`（重试）、`repaste`（重新粘贴密钥）、`relogin`（重新登录）、`topup`（充值）、
`edit_base`（修改接口地址）、`settings`（打开设置）、`none`（无一键修复）。
错误文字使用中文，外部服务响应、异常详情和密钥不会原样返回。
接入接口的旧 `message` 字段继续保留。

验证：在 `server/` 中运行 `/workspace/venv/bin/python -m pytest -q`。
`test_boot.py` 通过 aiohttp 路由和鉴权执行请求，无需开放本地 TCP 端口。
