# Design options and offline replay

`bench/replay.py` replays the three curated project snapshots in
`bench/fixtures/` through the real `ensemble.Ensemble`: dependency scheduling,
parallel card execution, real git worktrees/commits/merges, independent lead
review, and rework. These fixtures represent budget, event-registration, and
support projects; they are synthetic records, not production telemetry.
The real design service runs concurrently with the engine. Each replay starts
with an empty cache, generates every direction in parallel, selects one, and
expands only that direction. Symphony uses the default 20-second auto-pick;
concerto simulates a user choosing once all directions are visible.

Run from `server/`:

```sh
/workspace/venv/bin/python bench/replay.py --rounds 3 --scale 1 --concurrency 3 \
  --seed 20261030 --output bench/replay-results.json
```

The fake members sample seeded log-normal latencies (sigma 0.35, bounded
0.3–15 seconds), with base medians of 2.0/3.0/3.8 seconds. Draft calls multiply
the median by 0.65; execution grows with card effort. Input/output token counts
are also seeded samples, and costs use configured USD prices per million
tokens: flash 0.15/0.60, standard 1/4, lead 3/15. These are illustrative prices,
not a current vendor price list. Each fixture forces one initial review rejection
to exercise rework. All completed calls, including drafting, expansion and
rejected attempts, contribute to token and cost totals. No paid API is called.

`--scale 0.05` provides a faster smoke run. It scales only model sleeps and the
auto-pick timeout; reported wall times are measured, never extrapolated. Tokens
and costs are unchanged. Temporary workspaces are created within `bench/` and
removed after each run. Per-call seeds do not depend on completion order.

## Recorded result

Measured on 2026-10-30 with Python 3.13.5 in the managed Linux worktree,
using the command above (latency scale **1.0**, three concurrent projects).
The complete per-project measurements are in
[`bench/replay-results.json`](../bench/replay-results.json).

| Metric | Result |
| --- | ---: |
| Fixtures × rounds | 3 × 3 = 9 project replays |
| Passed cards | 27 / 27 |
| Total measured wall time | 71.7756 s |
| Total tokens | 187,079 |
| Total simulated cost | $0.294641 |
| Review rejections (all recovered) | 9 |
| Design first-option p50 | 0.8478 s |
| Design first-option p95 | 1.2534 s |
| Design all-options range | 1.2024–2.5012 s |

Percentiles use nearest rank over the nine independently cold design sessions.
This small synthetic sample demonstrates the pipeline and the under-five-second
first-option target; it does not establish a production provider SLA. It includes
real scheduling and disk/git overhead, with realistic simulated model delays.
Early-pick cancellations, invalid output, provider failures and timeouts are
covered separately in `test_designopts.py`.

## Server/client contract

All endpoints use the server's existing authentication middleware.

* `GET /api/design/library` returns `{styles, schema}` with eight local directions.
  Every style has `id`, `name`, `palette`, `type: {heading, body}`, `layout_tags`,
  and a deterministic inline SVG `thumbnail`. The response bytes are generated
  once at module load; the request performs no model or disk work.
* `POST /api/design/start` accepts `{pid, brief, n}` (`n` defaults to 3, range
  1–8). It returns a session with `sid`, ordered `options` and `metrics` immediately.
  Each option starts as `{id, state: "pending"}`. Independent completions become
  `ready` with `spec`, `member`, and `cost_estimate`, or `failed` with a sanitized
  `schema_rejected`, `timeout`, or `member_failed` error. One failure does not
  cancel other slots. API and ACP members are eligible; plain CLIs lack an
  isolated, cancellable approval contract and are excluded. Unhealthy members,
  members with `auto: false`, and explicit `caps.design: false` are excluded.
  Known input-plus-output prices rank the cheapest eligible member; unknown
  prices rank last. The same cheap member serves all parallel drafts.
* `GET /api/design/{sid}` returns the current snapshot. Each completion calls
  `bump(pid)`. Existing `/api/ws` project subscribers also receive
  `{type: "design", pid, data: {sessions: [...]}}` as the snapshot changes.
  Clients can render skeletons for pending slots and render ready specs
  immediately, without waiting for slot order or for all options to finish.
* Specs contain `screens: [{name, blocks: [{type, props}]}]`, `palette`, and
  `type: {heading, body}`. The published schema accepts only header/list/card/
  hero/tabs/form/chart/image block types. There are 1–12 screens, 1–60 blocks
  per screen, 3–8 six-digit hex colors, and a 200 KB JSON limit. Props hold
  client-rendered data. Clients should map block types to native components
  and treat text as text. No raster generation or browser rendering is needed.
* `POST /api/design/{sid}/pick` accepts `{option: <integer slot id>}` for a ready
  option. It cancels pending slots and any previous expansion, returns
  `render.state: "pending"`, and waits for draft cancellation before starting
  a background expansion. The strongest other eligible member (price proxy)
  expands just the chosen spec; a single-member pool falls back to that member.
  Expansion results use the same schema and include detailed content/layout/
  interaction props. Render failures retain the valid draft. Re-picking replaces
  the selection; a revision guard rejects stale render results. Cancelled draft
  slots stay `cancelled`; other completed options remain available to re-pick.
* `metrics.time_to_first_option`, `metrics.time_to_all`, and `metrics.cancelled`
  are seconds/count from session creation. Time-to-all means every draft slot
  has reached a terminal state, including failures or early cancellation.
  First-option stays null if none succeeded. Cache hits have both timings zero.
  Cancelled counts include drafts and replaced in-flight expansions.
  `cost_estimate` is a token-length estimate for deterministic ranking; normal
  server billing still records provider-reported usage.

Symphony auto-picks at `CFG.design_autopick_s` (default 20). If no option is ready
at the deadline, it selects as soon as one becomes ready. All-failed sessions
stop without picking. Ranking is deterministic: valid schema, greatest brief
keyword overlap (including Han characters), lowest estimated cost, lowest slot
id. A user can replace an automatic selection later.

Concierge starts speculative drafting before awaiting its clarification call.
Confirmation attaches that session to the new project instead of paying for a
second draft; cancellation stops speculative work. Direct concerto planning
also starts drafting for UI briefs. Selected drafts/expanded specs are included
in subsequent planning and execution packets without blocking unrelated work.

The cache key is SHA-256 of the NFKC/casefold/whitespace-normalized brief and
option count. The in-memory LRU retains 64 complete validated sets; an atomic
JSON snapshot in `DATA/design-options.json` survives restart. Partial, failed,
and cancelled sets are never cached. Corrupt/unwritable cache files are handled
as a cache miss or memory-only cache. Sessions and in-flight renders are
process-local; after restart, clients start a new session to reuse cached specs.

## Validation in the managed executor

`cd server && /workspace/venv/bin/python -m pytest -q test_designopts.py`
passes **17 tests and 9 subtests**, including a seeded replay through the real
engine. Disk operations remain real in these tests; only the thread-dispatch
wrapper runs inline because this executor delays cross-thread loop wakeups.
WebSocket/HTTP tests drive real server handlers with an in-memory transport.

The ordinary full-suite command was attempted and timed out after 180 seconds
in an existing backup test, following a socket-permission failure. A timer tick
on each asyncio loop allowed the full suite to finish without changing the
tests or application behavior: **645 passed, 122 failed**. Loading the three
modified integration modules from `HEAD` and omitting the new test file gave
**628 passed, 122 failed**, with exactly the same failed test IDs. Of those
baseline failures, 121 are socket `PermissionError`s and one is the existing
empty-file workspace fixture `FileNotFoundError`. A fully green integration run
therefore still requires an executor that permits the repository's test setup.
