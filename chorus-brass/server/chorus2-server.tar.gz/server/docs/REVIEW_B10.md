# B10 — 核实 R_B9_mimo #2、#3、#4、#7、#9

范围：基于当前检出代码核实上述五项；未读取或打印密钥。结论：#2 成立并修复；#9 数字过时成立，但当前正确值为 6；#3、#4 不成立；#7 未证实独立费用丢失，保留账本优先语义并明确注释。

## #2：成立，拆分告警并独立去重

`chorus2.on_usage()` 原先把缺价和币种不一致都写成 `pricing_missing`，并按同一类型、成员和 open 状态去重。先出现的卡会阻止另一种卡；同一 usage 同时含两类信息时，币种提示还会覆盖缺价提示。

修复：分别使用 `pricing_missing` 和 `currency_mismatch`；两类提示独立生成，各自按 kind + member + open 去重。缺价 usage 即使 cost=0 仍建卡；没有 warning 且没有币种差异时不应凭空建卡，原文关于此处“语义混乱”的附带描述不构成另一缺陷。

新增 `Runtime.test_warning_kinds_deduplicate_independently_per_member`：覆盖缺价先到、币种告警先到、单次 usage 同时含两类信息、重复 usage、不同成员、关闭缺价卡后再次告警，同时验证提示内容。修改前这三个顺序场景均失败；修改后通过。

## #3：不成立，全部答案已进入重规划

`chorus2.h_decide()` 在读取请求体的 await 之后，同步保存 answer/state，再检查是否还有 open 澄清卡，最后调用 `queue_plan()`。这一段中的 `save_projects()`、`touch()` 和 `queue_plan()` 都是同步函数，没有 await。`queue_plan()` 从查询 `PLANNING` 到创建 task、登记 task 之间也没有 await；当前 asyncio 事件循环内不存在审查所述的协程 TOCTOU，不需要加锁。这里的结论针对服务现有的单事件循环任务调度，不宣称跨线程安全。

`plan()` 遍历 pending 中所有 state=done 且有 answer 的 clarify 卡，拼入每道问题及答案；API 的 `ask_model()` 和 CLI 的 `add_msg()` 都使用该上下文。

新增 `Runtime.test_concurrent_clarifications_replan_once_with_all_answers_api_and_cli`：两张 open 卡通过 `asyncio.gather()` 并发提交，包含一条重复提交；验证自动排队仅一次、在途重复排队返回同一个 task、重复回答不覆盖原答案、上下文同时包含历史答案和两张新卡的答案。API、CLI 两条路径均验证，且保留 start=false。

## #4：不成立，work 的 finally 已清理 PLANNING

`queue_plan.work()` 原有 finally 明确执行 `PLANNING.pop(pid, None)`，成功、失败都会走到清理；done callback 用于读取异常，不承担清理职责。正常 task 调度下，创建和登记 task 的同步调用结束后 work 才运行；原文假设 task 在登记前已经完成、且缺少 finally 的前提不符合当前代码。

新增 `Runtime.test_immediate_plan_completion_and_failure_allow_retry`：模拟 plan 不挂起即成功或抛异常，验证成功及失败后注册表均无残留，失败仍产生 plan_failed 卡，随后可以重新规划成功；在途重复调用共享 task。

## #7：未证实，不能将两个汇总直接相加

`orchestra.budget_state()` 的优先级是：有非空 cost_split 时，按预算币种汇总项目用量账本；否则回退到 segments.spend.cost。`chorus2.on_usage()` 对各角色用量累计 cost_split，`ask_model()` 的指挥调用也经过真实 record_usage hook。项目账本包含规划、执行、审核等阶段，段落费用不是一个可无条件相加的独立账本。

检索当前生产代码，`orchestra.record_spend()` 没有生产调用点，只有测试调用；未发现“只写入 segments 的旧费用，再增量迁移到 cost_split”的实现或迁移契约，无法据此认定当前服务有丢账路径。即使两类字段同时存在，也无法证明费用互不重叠；按审查建议改为 += 会在段落费用已计入项目账本时重复扣预算，且段落费用字段没有币种维度，会破坏币种隔离。本次保留现有行为，增加明确的账本优先、段落回退注释。

新增 `Budget.test_segment_fallback_and_project_ledger_are_alternative_totals`：无账本/空账本回退段落费用；账本含执行 4、规划 2、审核 3 时总额为 9，不能再加段落的 4；验证预算 warn 状态、切换预算币种、只有外币账本时不把段落费用误算为人民币。B9 原有真实 record_usage hook 测试同时回归。

边界：若另有外部导入的部分账本或历史数据，必须先明确费用来源、重叠范围和币种，再设计迁移；仅靠这两个聚合字段无法无损推断独立费用，本次没有擅自相加或修改历史数据。

## #9：数字过时成立，当前正确值为 6

当前 `test_review_b9.py` 实际为 Storage 2 项、B9Runtime 4 项，共 6 项。原文的 4 项是最初数量，下文 account_cap 返工又补了 2 项；R_B9_mimo 写的 5 项同样不符合当前文件。已将 `REVIEW_B9.md` 改为“最初 4 项；返工新增 2 项，当前共 6 项”，保留原有各轮验证的历史记录。

## 验证结果

- 新增 `server/test_review_b10.py` 共 4 个测试方法，含上述多场景子测试。
- `PYTHONPATH=server python3 -m unittest -q test_review_b10 test_review_b9 test_dogfood_fixes test_orchestra test_autopilot test_review_b7 test_review_b8`：164 项通过，含 B9 全部 6 项。
- 修改的 Python 文件通过 `py_compile`；`git diff --check` 通过。
- 测试通过本地 mock 和直接调用验证，不依赖外部 API、真实凭据或监听 socket。
