# 余额与额度：各种办法都要用上

Ali 10-27 原话：「接入用户接入一个 api，咱们要想各种办法把余额弄出来」。

用户接入一个 key 后，服务器按下面的顺序挨个试，用第一个能拿到数的。每个圆环都要标出数字的来源：「官方」「估算」或「未知」。

## 1. 官方余额接口（最准）
| 平台 | 接口 | 需要什么 |
|---|---|---|
| DeepSeek | GET /user/balance | API key |
| Kimi（Moonshot） | GET /v1/users/me/balance | API key |
| OpenRouter | GET /api/v1/credits、/api/v1/key | API key |
| 硅基流动 | GET /v1/user/info | API key |
| 火山方舟（豆包、Kimi、GLM 共用） | billing QueryBalanceAcct，region cn-north-1 | AK/SK。控制台给的 SK 常常是 base64，签名前先解码 |
| 阿里百炼 | BSS OpenAPI QueryAccountBalance | 阿里云 AK |
| OpenAI | /v1/organization/costs（只有花费，没有余额） | admin key |
| Anthropic | Usage & Cost Admin API（花费） | admin key |
| 中转（one-api / new-api 一类，绝大多数中转都是这个） | /v1/dashboard/billing/subscription 加 /v1/dashboard/billing/usage；或者 /api/user/self | 一般用 sk 就能查 |

加 key 时先探测：挨个试上面这些接口（几秒内就能完成），能查到余额的就记下用哪个接口。

## 2. 响应头
有的平台在每次回复的响应头里带剩余额度（x-ratelimit-remaining-*，部分中转带 quota）。顺手记下来，不用额外请求。

## 3. 自己记账估算（兜底，任何 key 都能用）
- 每次调用都记 token 数，乘上价格表（已有「一键查价格」），算出花了多少。
- 默认不打扰用户：只有前两种办法都拿不到数时，才在这个成员的额度卡片上放一个不显眼的「填写余额」入口，用户不点就一直显示「估算」。
- 余额 = 上次已知余额 − 之后的花费。圆环标「估算」。官方接口能查到时，用官方的数自动校准。

## 4. 报错信号
返回 402、insufficient_quota、余额不足之类的错误时，立刻把余额标为 0，把这个成员标成「休息中」，并在定音里提醒用户充值。不要再反复叫醒它。

## 5. 包月订阅
- Codex：读 ~/.codex/sessions 里的 rate_limits。
- Claude：claude CLI 的 /usage。
- Antigravity：在 pty 里跑 /usage。
显示 5 小时额度和本周额度，以及各自的刷新时间。

## 6. 拿不到余额时：手填一次 + 按量扣减（估算）
不读网页、不用 cookie、不登录控制台。链条到此为止：官方接口 → 响应头 → 自己记账 → 报错信号 → **用户手填**。
- 中转站或平台查不到余额时，额度卡片里出现「填写余额」：用户填一次当前余额（含币种）。
- 之后每次调用按 token 用量 × 该模型单价（设置里可改：输入 / 缓存命中 / 输出，每百万 token）实时扣减，显示剩余，标「估算」。
- 用户再填一个新数字就以它为新基线重新算。
- 没填过、也没有任何信号时显示「未知」。

## 规则
- 同一个账号的多个 key 共用一个余额（比如火山上的豆包、Kimi、GLM），显示成一个圆环。
- 余额上涨就视为充值，圆环回到 100%。
- 查询频率：官方接口每 10 分钟一次；估算每次调用后实时更新。

## 7. 各家现状（2026-10-30 核对；没有就写没有，一律回落到自己记账）
| 平台 / 接入方式 | 官方可查的数 | 我们怎么做 | 来源标签 |
|---|---|---|---|
| 小米 MiMo Token Plan（`tp-`/`ttp-` key，`token-plan-cn.xiaomimimo.com`） | 用量接口 `platform.xiaomimimo.com/api/v1/tokenPlan/usage` **只认网页登录 Cookie**，tp- key 调用返回 401 | 不用。套餐总量（手填，如 41 亿）− 记账 token | 估算 |
| 小米 MiMo 按量（`sk-`） | 无公开余额接口 | 手填余额一次 + 按 token × 单价扣减 | 估算 |
| Google Gemini API（AI Studio key） | 无剩余额度接口；限额按项目、太平洋时间零点重置 | 自己记账 + 429 信号 | 估算 / 报错 |
| Google Vertex AI | 只有 Cloud Billing / 配额控制台（需服务账号） | 自己记账 | 估算 |
| Gemini CLI 订阅 | `gemini -p "/stats model"` 的 “Usage left 75.0% (Resets in 1h 30m)” | cli_quota 解析 | 官方 |
| Antigravity（agy） | 只有交互界面 /usage | pty 读屏（ali/agy_quota.py），10 分钟缓存，作兜底 | 官方（读屏） |
| 智谱 GLM 按量（open.bigmodel.cn） | `GET /api/biz/account/query-customer-account-report`，`Authorization: Bearer <API key>`，`data.availableBalance` | 已接 | 官方 |
| 智谱 GLM Coding Plan | `/api/monitor/usage/quota/limit`（国内 open.bigmodel.cn / 国际 api.z.ai，key 不带 Bearer） | 已接 | 官方 |
| xAI Grok | Management API `GET management-api.x.ai/v1/billing/teams/{team_id}/prepaid/balance`（需管理密钥 + team id，普通 API key 不行） | 填了 mgmt_key/team_id 就查，否则记账 | 官方 / 估算 |
| MiniMax 按量 | `GET api.minimax.chat/v1/user/balance`（GroupId） | 已接 | 官方 |
| MiniMax Token Plan（M Plan key） | 文档化 `GET api.minimaxi.com/v1/token_plan/remains`（国际 api.minimax.io），5 小时 + 每周 | 已接（旧 coding_plan 端点作回退） | 官方 |
| 腾讯混元 | 腾讯云 Billing `DescribeAccountBalance`，需云 SecretId/SecretKey（TC3 签名），API key 不行 | 本版未接签名 → 记账 | 估算 |
| 百度千帆 | 余额在百度智能云计费（AK/SK 签名），千帆 API key 不行 | 本版未接 → 记账 | 估算 |
| GitHub Copilot 订阅 | 没有公开的额度接口（社区用的 copilot_internal 属内部接口） | 不用 → 未知 | 未知 |
| Claude Code 订阅 | `claude -p "/usage" --output-format json`：Current session / Current week 的已用 % 与重置时间 | cli_quota 解析；旧的「读保存的 OAuth token 冒充 claude-cli 调 /api/oauth/usage 或发 Haiku 探测」已删除 | 官方 |
| Codex 订阅 | `~/.codex/sessions/**/*.jsonl` 的 rate_limits；有 ACP 事件时优先 | 已接 | 官方 |
| OpenAI / Anthropic API | 只有花费（Admin key 的 costs/usage 接口），没有「余额」 | 只记花费，不显示余额 | 花费 |
