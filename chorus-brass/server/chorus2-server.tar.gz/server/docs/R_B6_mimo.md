- 1. 中，`server/designopts.py:399-410`：`usage` 估算分支在 `result.usage` 为 `None` 时安全，但若 `usage` 是非 dict（如 `None` 之外的 falsy 或自定义对象），`usage.get` 会抛异常；且 `record_usage` 现在无条件调用，若 `result.usage` 为 `None` 且 `result.text` 为空仍会记账（估算 out=0），可能与"失败不计费"语义冲突。建议：仅在 `result.ok` 且文本非空时记账，或明确失败也计费的契约。
- 2. 中，`server/designopts.py:265-268`：`NoMemberError` 分支放在 `ValueError` 之后，但 `asyncio.TimeoutError` 也是 `Exception`，顺序正确；然而 `NoMemberError` 继承 `RuntimeError`，若 `self.ask` 内部抛出其它 `RuntimeError`（如 "Design member failed"），会被误判为 `no_member`。建议：`NoMemberError` 不继承 `RuntimeError`，或用更精确的异常类型。
- 3. 低，`server/chorus2.py:786-788`：`session["render"]` 可能为 `None` 或缺少 `"state"` 键（如初始化状态），`session["render"]["state"]` 会 `KeyError`/`TypeError`。建议用 `.get("state")`。
- 4. 低，`server/test_designopts.py:328-363`：测试中 `self.c.ROLE.get()` 与 `self.c.account_block`、`self.c.cli_guard` 依赖 `ConciergeTests`/`RouteTests` 的 fixture，但 `RouteTests` 未见 `self.c`、`self.service`、`self.s` 的 setUp 定义（diff 上下文缺失），若实际不存在会 `AttributeError`。请确认 fixture 完整。
- 5. 低，`server/test_designopts.py:523-547`：`test_cancelled_expansion_or_option_does_not_inject_draft` 中 `self.ask = expand` 直接覆盖实例属性，若 `DesignOptions` 通过构造参数持有 `ask` 引用则无效；需确认 `self.service` 使用 `self.ask` 动态查找。
- 6. 低，`server/designopts.py:403-406`：估算公式 `len(...)/4` 对中文/多字节字符严重低估 token 数，可能导致计费偏低。建议按字符类型加权或使用 tokenizer。

Verdict: FIX
