1. **严重 (CRITICAL) - `server/ensemble.py:270`**: `write_files` 会导致路径遍历漏洞和任意文件写入。`str(dest).startswith(str(tree.resolve()) + os.sep)` 存在严重逻辑漏洞：若 `dest` 路径不存在（新写入文件通常尚未存在），在 Python 中对不存在路径调用 `.resolve()` 会解析到祖先存在层级甚至在跨平台/软链接下无法正确解析；此外若子路径包含 `..` 刚好前缀匹配或相对路径规范化不彻底，会突破限制。更致命的是：如果待写入文件位于 `tree` 根目录（如 `dest == tree / "README.md"`），若 `tree` 不带尾部斜杠，检查会通过，但若是 `tree_sibling/xxx` 会因没有严格比较 `pathlib.Path.is_relative_to` 导致越界风险。
   - **修复**：使用 `dest.resolve(strict=False)` 并用 `dest.is_relative_to(tree.resolve())` 判定，且在写入前保证安全。

2. **严重 (CRITICAL) - `server/ensemble.py:195-200`**: Circuit breaker half-open 状态在超时后无法关闭，陷入持续不可用或死锁（breaker never closing）。`Breaker.open()` 仅判断 `until.get(name, 0) > self.now()`。当 `cooldown` 过期后 `open()` 返回 `False`，允许试跑一次。但如果该试跑失败，`fail()` 会将 `fails[name]` 加 1（从 0 变 1），此时 `self.fails[name] < self.threshold`，不会重新设置 `until[name]`，导致后续请求全部打入已宕机的服务；反之若该 member 在多处（如 review/stalled）直接强制赋值 `until`，状态机缺乏 half-open 探测保护。此外，`fails` 计数在失败未达阈值时永远不衰减，跨越数小时的偶发单次失败会累加触发熔断。
   - **修复**：在 `Breaker` 中显式维护 `CLOSED`, `OPEN`, `HALF_OPEN` 三态；在 cooldown 过期后进入 half-open，若试跑失败立即重新进入 open（满额 cooldown），若成功则重置计数。

3. **严重 (CRITICAL) - `server/ensemble.py:190-210, 240-244`**: 指挥（lead）failover 后死锁与卡片永远无法通过 review。当 `lead` 崩溃或不可用时，在 `review()` 内部调用 `self.failover()` 修改了 `self.lead`。但 `reviewer()` 的逻辑是：若 `lead` 存在且不是卡片作者，返回 `lead`；若 `lead` 刚才已经 fail 导致 open，`usable(lead)` 为 `False`。此时 `failover()` 尝试推选新指挥并修改了全局 `self.lead`，但正在运行中的其他并发卡片或当前卡片的 `tried` 集合并不知道原指挥已换，且若此时无候选人（`failover()` 返回 None），代码直接 `return "FIX: 审核没完成"`，该卡片不断重试并耗尽 `max_rework` 变为 `blocked`。更严重的是：`self.failover()` 被并发卡片重入调用时，会并发修改 `self.lead` 状态且无锁保护，造成多核竞态。
   - **修复**：为 `failover` 加锁保护，并在 reviewer 无法获取有效审核者时，若当前所有候选人均不可用，应将卡片置于等待退避而不是作为 `FIX` 判定并永久扣减 pass 权重，避免指挥链全军覆没导致项目直接锁死。

4. **高危 (HIGH) - `server/checkpoints.py:38-42` 与 `server/ensemble.py:176-180`**: 重启后 Checkpoint 断点恢复时发生 double-merge 和状态不一致。在 `resume()` 中：若卡片在重启前已经执行了 `self.ws.merge()` 但在更新 checkpoint `cards` 表前崩溃，此时 `effect(key)` 返回有效，卡片被强行恢复为 `passed` 并加入 `self.done`。然而，`self.ws.merge` 会执行 `git worktree remove`，但其分支可能已被合并或残留；更严重的是，卡片的 `summary` 和 `artifacts` 此时保存在 SQLite 的 `cards` 记录中，但在 `resume()` 里只做了 `c.update(old, state="passed")`，此时如果卡片之前在 `doing` 状态已被 merge（例如在写入 `passed` 事务间隙崩溃），恢复出的 `c` 缺少运行时填充的 `artifacts` 和 `summary`，导致下游依赖该卡片 `inputs` 的卡片在 `packet()` 中无法读到上游产物（`ups` 为空或无产物文件）。
   - **修复**：在 `done_effect` 中持久化卡片最终产物（`artifacts`, `summary`），`resume()` 恢复 passed 状态时若从 `effect` 命中恢复，必须同时回填 `summary` 与 `artifacts`。

5. **高危 (HIGH) - `server/ensemble.py:220-230`**: `watchdog` 与 `supervised` 任务取消存在竞态条件（Race condition），导致卡片同时被两个协程调度运行。在 `_watch()` 中检测到 stalled 时调用了 `t.cancel()`，随后在主调度循环 `run()` 的 `fin, _ = await asyncio.wait(...)` 捕获到取消后，执行 `c["assignee"], c["state"] = "", "todo"` 并重新保存。然而 `supervised` 内部的 `try...except asyncio.CancelledError: raise` 向上抛出时，`t` 刚好在 `fin` 中；但是在 `run()` 的下一轮循环中，若此时 `ready()` 发现该卡片状态为 `todo`，会立即为该卡片创建新的 `supervised` 任务。此时如果被取消的 `run_card` 内部由于 `git` 锁或子进程等待还未真正释放 `tree` 或工作区，两个任务将发生 worktree 冲突，导致 `git worktree add` 报错抛出异常。
   - **修复**：在取消卡片任务后，必须 `await asyncio.gather(t, return_exceptions=True)` 确保旧任务彻底终止、释放 workspace lock 之后，再将卡片置为 `todo`。

6. **中危 (MEDIUM) - `server/ensemble.py:245-248`**: `self.errors` 列表无界膨胀导致内存泄漏（Unbounded Memory）。`watchdog`、`supervised`、`_one_candidate` 和 `save` 中所有的异常信息全部直接 `self.errors.append(...)`。在长时间运行或频繁重试/超时的服务中，`self.errors` 会持续增长且无清理上限。
   - **修复**：将 `self.errors` 改用带最大容量的 `collections.deque(maxlen=1000)`。

7. **中危 (MEDIUM) - `server/ensemble.py:228-232`**: Best-of-N 赛马模式下未清理临时 Worktree 和分支导致磁盘泄漏和后续重试冲突。在 `best_of` 中生成了 `card_id-bo0`, `card_id-bo1` 等子任务并创建了独立 worktree，在 `_one_candidate` 运行完成后，无论 merge 成功与否，未胜出的 candidate worktree 从未被执行 `git worktree remove`，残留的分支和目录会导致磁盘占用膨胀，且若卡片打回重跑 best_of，`git worktree add` 将直接报错崩溃。
   - **修复**：在 `best_of` 的 `finally` 中遍历所有 candidate，强制执行 `git worktree remove --force` 并删除对应临时分支 `card/{sub['id']}`。

FIX
