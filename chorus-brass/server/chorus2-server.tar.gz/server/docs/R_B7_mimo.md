- 1. **高危** `server/ensemble.py:330-350`（`Ensemble.call`）：`probe = ad.name in self.breaker.probing` 在 `claim` 之后取值，但 `finally` 中 `probing.discard` 会把并发探测者的标记一起清掉；更严重的是 `claim` 只在 `name in self.until` 时加入 `probing`，若冷却期已过但 `until` 仍存在（`open()` 返回 False），第一次探测失败后 `fail()` 会重设 `until`，但 `probing` 已在 `finally` 清除，第二次并发调用会再次 `claim` 成功并进入 `probing`，与设计“冷却后只允许一个探测”不符（`test_half_open_allows_only_one_probe` 只覆盖顺序场景）。**修复**：`claim` 返回探测标记（如返回 `(ok, is_probe)`），`call` 用返回值决定是否 `discard`，或在 `claim` 中用引用计数/独立 token 标识本次探测。

- 2. **高危** `server/ensemble.py:330-350`（`Ensemble.call`）：`claim` 失败时直接返回 `A.Result(ok=False, error=BREAKER_BUSY)`，但调用方 `run_card` 中 `elif res.error != BREAKER_BUSY and self.breaker.fail(...)` 只跳过 breaker 计数，仍会 `tried.add(m["name"])` 并把该成员加入失败集合，导致冷却期内该成员被永久排除，冷却结束后也不会再被尝试（`choose` 会跳过 `tried`）。**修复**：`BREAKER_BUSY` 时应 `continue` 而不加入 `tried`，或在 `choose` 中允许冷却期已过的成员重新进入候选。

- 3. **中危** `server/ensemble.py:361-460`（`run_card`）：`_review_pending` 分支中 `res = A.Result(ok=True, **pending)`，但 `pending` 只含 `text`/`artifacts`，缺少 `usage` 字段；后续 `self.account(m, res.usage, "execute")` 在 `res.usage` 为 `None` 时跳过，但 `card["_cost"]` 计算 `sum((res.usage or {})...)` 依赖 `res.usage`，若 `A.Result` 的 `usage` 默认不是 `None` 而是空 dict 则无影响，但若默认是 `None` 且 `price_of` 返回非空，`card["_cost"]` 会算出 0，与实际执行成本不符。**修复**：`_review_pending` 中持久化 `usage` 并在恢复时传入 `A.Result`。

- 4. **中危** `server/ensemble.py:475-520`（`review`）：`tried` 集合在 `review` 内部维护，但 `self.failover()` 被调用后 `self.lead` 已变更，下一轮 `self.reviewer(author, tried)` 会优先返回新 lead，若新 lead 也失败，`tried` 会继续累积，但 `failover()` 每次都可能选回已失败的 reviewer（`failover` 内部只看 `usable`，不看 `tried`）。**修复**：`failover` 接受 `exclude` 参数，或在 `review` 中把 `tried` 传给 `failover`。

- 5. **中危** `server/ensemble.py:543-575`（`resume`）：`effect` 命中时 `c.update({k: effect[k] for k in ("summary", "artifacts") if k in effect})`，但 `effect` 是 `ckpt.effect()` 返回的 dict，若 `done_effect` 之前只存了 `{"by": ...}`（旧版本兼容），`summary`/`artifacts` 缺失，`c` 会保留 `cards` 行中的旧值或为空，下游 `packet` 读不到产物。**修复**：`resume` 中若 `effect` 缺少 `artifacts`，从 `old` 或 `cards` 行回填，或在 `done_effect` 中强制写入这两个字段。

- 6. **中危** `server/ensemble.py:575-600`（`best_of`）：`finally` 中 `await self.ws.discard(sub["id"])` 会删除所有候选 worktree 和分支，包括胜出者的 `w["id"]`；但胜出者已通过 `self.ws.merge(w["id"])` 合并，`merge` 内部已 `worktree remove`，`discard` 再次 `worktree remove --force` 和 `branch -D` 是幂等的，但若 `merge` 失败（`ok=False`），胜出者分支仍存在，`discard` 会删除它，而后续 `card.pop("assignee")` 后 `run_card` 重跑时会重新创建同名分支，无冲突。但若 `merge` 成功后 `done_effect` 写入失败（SQLite 异常），`discard` 会删除分支，导致无法恢复。**修复**：`discard` 只删除未胜出的候选，或在 `done_effect` 成功后再 `discard`。

- 7. **中危** `server/ensemble.py:657-670`（`run` 的 `finally`）：`await asyncio.gather(dog, *tasks, return_exceptions=True)` 中 `dog` 是 watchdog 任务，`tasks` 是 `self.running.values()` 的快照，但 `self.running` 在 `supervised` 的 `finally` 中会 `pop`，若 `supervised` 在 `gather` 期间完成并 `pop`，`tasks` 列表中的引用仍存在，`gather` 会等待已完成的任务，无害；但若 `dog` 在 `gather` 期间抛出异常（如 `hb.stalled` 内部错误），`return_exceptions=True` 会吞掉它，导致 watchdog 崩溃无日志。**修复**：`gather` 后检查 `dog` 的异常并记录。

- 8. **中危** `server/orchestra.py:503-515`（`parse_plan`）：ID 归一化循环改为递增 `suffix`，但若 `seen_ids` 中已有 `s2`、`s3`、`s4`，且新段显式 ID 为 `s2`，`suffix` 从 `i+1` 开始递增，可能跳过 `s5` 直接到 `s6`（若 `i+1` 已被占用），导致 ID 不连续但无功能影响；更严重的是若 `i+1` 远大于 `len(seen_ids)`，循环会多次迭代，但不会死循环。**修复**：用 `while sid in seen_ids: suffix += 1` 从 `len(seen_ids)+1` 开始，或用 `itertools.count`。

- 9. **低危** `server/server.py:508-520`（`auth`）：`except UnicodeEncodeError` 只捕获编码错误，但 `secrets.compare_digest` 还可能抛 `TypeError`（若 `t` 或 `token()` 不是 bytes），当前 `t.encode()` 和 `token().encode()` 都返回 bytes，无风险；但若未来 `token()` 返回非字符串，会 500。**修复**：`except (UnicodeEncodeError, TypeError)`。

- 10. **低危** `server/test_review_b7.py:1-255`：`test_reviewer_outage_waits_without_reexecuting_or_penalizing_author` 中 `self.assertNotIn("runs", e2.stats["w"])` 断言执行未重复，但 `e2.resume()` 后 `p2["cards"][0]["retry_at"] = 0` 手动设置，若 `resume` 未正确恢复 `retry_at`，测试会误通过。**修复**：断言 `resume` 后 `retry_at` 已从 checkpoint 恢复，而非手动覆盖。

**FIX**
