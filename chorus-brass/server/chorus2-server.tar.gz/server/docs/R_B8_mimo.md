- 1. **高** `server/ensemble.py:406-415`（`run_card` 的 BREAKER_BUSY 分支）：`card["assignee"] = ""` 后 `continue`，但下一轮 `m = self.member(card.get("assignee")) if card.get("_review_pending") else self.choose(card, tried | busy)`——`_review_pending` 为假时走 `choose`，没问题；但若该卡原本带 `assignee`（如 best_of/审核后重派），清空 assignee 会丢失原指派语义，且 `busy` 集合在 `run_card` 返回后即丢弃，`_execute_pending` 恢复后 `ready()` 用 `self.choose(c)` 判断可用性时可能又选中同一 busy 成员，导致再次 BUSY 循环而非等待。**修复**：`_execute_pending` 恢复时也应把上次 busy 成员持久化（如 `_busy` 字段）并在 `choose` 中排除，或至少在 `ready()` 中用 `self.choose(c, exclude=...)` 传入历史 busy 集合。

- 2. **中** `server/ensemble.py:412-413`：`card["retry_at"] = time.time() + self.breaker.cooldown` 用 `time.time()`，但 `Breaker` 可注入 `now`（测试中 `now=lambda: now[0]`）。若 `breaker.now` 与 `time.time` 不一致（时钟回拨、测试注入），`retry_at` 与 `breaker.until` 不同步，`ready()` 的 `retry_at <= time.time()` 门控可能提前或延后放行。**修复**：统一用 `self.breaker.now()` 或 `time.time()` 之一，并在 `ready()` 中用同一时钟源比较。

- 3. **中** `server/ensemble.py:448-451`（`_review_pending` 保存 usage）：`res.usage` 可能是 `None`（`A.Result` 默认值未在 diff 中确认），直接存入 `pending["usage"]` 后恢复时 `A.Result(ok=True, **pending)` 若 `usage=None` 会覆盖默认空 dict，`_cost` 计算 `sum((res.usage or {})...)` 虽然安全，但 `self.account(m, res.usage, "execute")` 在恢复分支被跳过（正确），而 `card["_cost"]` 若依赖 `res.usage` 为 dict 的 `.get` 调用会 `AttributeError`。**修复**：保存时 `res.usage or {}`，或在恢复构造 `A.Result` 时显式 `usage=pending.get("usage") or {}`。

- 4. **中** `server/test_review_b8.py:30-55`（`test_older_call_and_rejected_calls_cannot_release_live_probe`）：`self.addAsyncCleanup(self._drain, old)` 在 `old` 已 `await` 完成后仍注册 cleanup，`_drain` 会 `task.cancel()` 一个已完成任务并 `gather`，无害但冗余；更关键的是 `probe.cancel()` 后 `with self.assertRaises(asyncio.CancelledError): await probe`——若 `probe` 在 `cancel()` 前已因 `release[1]` 未设置而挂起，`cancel()` 触发 `CancelledError`，但 `finally` 中 `probing.discard` 是否执行取决于 `call` 的 try/finally 结构（diff 未展示），若 `call` 内部吞掉 `CancelledError` 转为 `A.Result(ok=False)`，断言会失败。**修复**：确认 `call` 的 finally 在取消时仍执行 `probing.discard`，或在测试中改为 `await asyncio.gather(probe, return_exceptions=True)` 后断言 `probing` 状态。

- 5. **低** `server/test_review_b8.py:100-115`（`test_resumed_candidate_keeps_usage_cost_without_double_billing`）：`self.assertEqual([n for n, _ in Fake.log], ["w"])` 依赖 `Fake.log` 是类级共享状态且测试间未清空，若测试顺序变化或并行执行会污染。**修复**：在 `setUp`/测试开头 `Fake.log.clear()`，或改用实例级日志断言。

- 6. **低** `server/docs/REVIEW_B8.md:1`（文档）：中文表述“核实 MiMo 审 B7 的 10 条意见”中“审”字重复（“审 B7”与“意见”搭配略生硬），建议改为“核实 MiMo 对 B7 的 10 条意见”。**修复**：调整措辞。

**FIX**
