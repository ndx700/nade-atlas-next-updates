- 1. 中，`server/chorus2.py:525`，`warnings = {"pricing_missing": u.get("pricing_warning")}` 会把 `None` 也作为键写入，虽然后续 `if warning` 会跳过，但语义上应只在有值时构造，且若 `pricing_warning` 为空字符串也会被跳过（与原行为一致，非回归）；建议改为 `warnings = {}` 后按需 `setdefault`，或显式 `if u.get("pricing_warning")`。
- 2. 中，`server/chorus2.py:526`，币种不一致告警的去重条件仍按 `kind + member + open`，但同一成员在不同 `cur`（如先 `$` 后 `€`）下只会保留第一张卡，后续不同币种的告警被静默吞掉；建议去重键加入 `cur` 或在卡片中记录币种并允许每种币种各一张。
- 3. 低，`server/test_review_b10.py:28`，`self.p['pending'] = []` 在每个 subTest 开始时重置，但 `self.ms[0]` 的 `name` 未显式设置为 `'a'`，测试依赖 `dogfood.Runtime.asyncSetUp` 的隐式初始化；若 fixture 变更会静默失效，建议显式断言 `self.ms[0]['name'] == 'a'`。
- 4. 低，`server/test_review_b10.py:75`，`context = ask.call_args.args[2] if kind == 'api' else add.call_args.args[2]` 假设 `ask_model`/`add_msg` 的第三个位置参数是上下文字符串；若签名改为关键字参数或位置调整，测试会以 `IndexError` 失败而非清晰报错，建议用 `kwargs` 或显式命名参数。
- 5. 低，`server/orchestra.py:941`，新增注释为英文，与项目其他中文注释/文档风格不一致；建议改为中文以保持一致性。

Verdict: FIX
