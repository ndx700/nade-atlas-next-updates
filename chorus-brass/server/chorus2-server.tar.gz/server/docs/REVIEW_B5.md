# B5：MiMo 审查核实与修复

核实范围：仓库根目录 `R_B2.txt` 的 12 条、`R_B3.txt` 的 30 条，以及两份报告末尾的测试/结论说明。所有判断均以当前代码和可复现行为为依据。测试仅使用虚构凭证，不输出配置中的密钥。

## 改动与边界

- `connect._validate_base` 独立解析传统 IPv4 的 1–4 段、十进制、八进制、十六进制形式，不依赖平台的 `inet_aton`。归一化后再判断元数据地址；IPv4-mapped IPv6 继续使用标准库的 `ipv4_mapped`。拒绝这些形式所表示的 `169.254.0.0/16`、`100.100.100.200`，以及原有的 `fd00::/8`、IPv6 link-local 和 Google 元数据主机名。普通域名和本地中转仍可使用，例如 `localhost`、`127.0.0.1`、`127.1`、`192.168.1.1`；这是原有产品约定，并非全面禁用内网中转。此检查不实施 DNS 解析、重绑定防护或 HTTP 重定向策略。
- `add_msg` 失败使用 `remove(m)`；`h_msg` 失败将列表中对应对象的引用替换为深拷贝的旧值。持久化追加/重写都先写临时文件，再替换目标，失败清理临时文件。追加会复制旧文件，代价由原来的追加 O(1) 变为文件长度 O(n)，以避免失败留下半行；未增加断电持久性保证或多进程写锁。
- 修正错误分类、状态详情输出、超时类型丢失、上传失败响应、保存状态缺 member 的检查，以及 HTTPS 反代生成的连接器地址。轮询时跳过已经超时/取消的排队任务；已经下发到连接器的任务仍不能远程撤回。

## 测试索引

新增 `server/test_review_b5.py`，无 socket、DNS 和真实上游请求。以下缩写均对应其中的完整测试名：

| 缩写 | 测试方法 |
| --- | --- |
| 地址 | `test_metadata_spellings_rejected_before_any_probe`、`test_public_domains_and_local_relays_do_not_raise` |
| 添加回滚 | `test_add_failure_removes_only_its_own_message` |
| 修改回滚 | `test_mutation_failure_replaces_reference_and_retry_is_not_acknowledged`（edit/recall/pin/react 四类） |
| 原子写 | `test_failed_append_and_rewrite_preserve_disk_and_clean_temp`（rename 失败、部分写失败、正常重试与重载） |
| 分类 | `test_error_classification_boundaries` |
| seen | `test_seen_validation_is_already_in_read_cursors` |
| 状态详情 | `test_status_uses_explicit_fix_and_complete_empty_detail` |
| 超时 | `test_probe_and_invite_keep_timeout_classification` |
| 遗留任务 | `test_cancelled_and_timed_out_jobs_are_never_dispatched` |
| NaN | `test_nan_wait_is_already_clamped` |
| 清理 | `test_cleanup_awaits_cancelled_tasks` |
| 上传 | `test_upload_disk_failure_and_size_limit_clean_temp` |
| 状态文件 | `test_missing_connector_member_registers_again` |
| 游标 | `test_sequence_cursor_at_zero_version_is_append_delta` |
| 回执 | `test_empty_accepted_targets_are_authoritative` |
| 中转 | `test_relay_override_includes_ambiguous_and_tuple_vendors` |
| 在线状态 | `test_presence_only_clears_offline_reason_and_bumps_on_change` |
| 重名注册 | `test_registration_never_replaces_an_existing_member_queue` |
| 反代 | `test_forwarded_https_is_used_only_for_valid_schemes` |
| 启动路径 | `test_setup_reports_path_without_password` |

## R_B2：逐条结论

| 条目 | 成立/不成立与理由 | 改动 | 测试 |
| --- | --- | --- | --- |
| 1 add_msg 的 pop / 半持久化 | **成立（防御性回滚及写失败）**。当前 persist 是同步函数，普通协程不会在其中穿插执行，报告的协程竞态推理不成立；但 pop 的确没有按对象撤销，原追加写也确实可能留下部分 JSONL，重写失败不清理 tmp。 | 改 `msgs.remove(m)`；追加和重写均临时写入后 replace，finally 清理。 | 添加回滚、原子写；用持久化回调追加另一条消息，验证不会误删。 |
| 2 h_msg 的 clear / client_ops | **成立（按任务要求修正回滚方式）**。原实现会清空同一个 dict；但 clear/update 之间无 await，报告所称另一普通协程看到空 dict 并非当前可触发竞态。request_hash 只是局部计算，失败回滚删除新 client_ops 是正确行为。 | 通过对象身份定位并替换 `CHATS[pid]` 中的引用；保留旧值和失败后的可重试性。 | 修改回滚：验证引用替换、内容恢复、旧引用未清空、失败无 bump，重试后回执可持久化。 |
| 3 h_boot 不校验 seen | **不成立**。`dm_index.read_cursors` 校验 JSON、对象形状、严格整数与非负值，直接抛 `web.HTTPBadRequest`，不必再捕获 ValueError。boot 没有 since 参数。 | 无。 | seen；已有 `test_boot` 的非法查询契约测试。 |
| 4 since 的 v=0 / VER=0 | **不成立**。非 reset 分支随后重新按 seq 和显式 v 筛选 messages；`chat_view(..., 1)` 用来维持 `full=False`，不是用 1 替代 seq 游标。v==VER 表示没有新版本，不需要 reset。直接传 0 反而会错误标记为 full。 | 无。 | 游标；已有 `test_boot` 的 append delta/reset 测试。 |
| 5 intent 的 accepted_to 空列表 | **不成立**。intent 且有 client_id 时显式保存 `[dm]`；无 client_id 时没有该字段，正确采用 targets 兜底。空列表是发送时接受零个目标的有效回执，重试时不应更改。 | 无；未采用 `or targets` 建议。 | 回执；已有 `test_boot` 的 intent/发送回执测试。 |
| 6 h_status 缺 message/fix | **成立（字段一致性）**。`fix` 读取有保护，不会发生报告标题的 KeyError；实际发现 detail 局部变量算出后未被用于返回，空错误缺 message/fix，显式 fix 也被重新分类覆盖。 | 使用统一 detail，空状态返回完整三字段。 | 状态详情；`test_boot.test_connector_registration_expiry_limits_and_probe_failure`。 |
| 7 plugins.view 覆盖 fix | **不成立**。有效的持久化 fix 会由第一个分支保留；仅缺少/非法 fix 时调用 upstream 分类。无 error 的空 payload 与原语义一致，不能强制旧错误全部 none。 | 无。 | 已有 `test_boot.BootAPI.test_plugin_failure_state_has_safe_error_and_fix`；该模块完整运行通过。 |
| 8 “地址”正则过宽 | **成立**。模型名等上下文含“地址”也会被归入 edit_base。 | 缩小为“接口地址”、base URL、endpoint，保留原有接口响应错误模式。 | 分类：普通“地址”上下文与实际接口地址两组。 |
| 9 403 当作密钥错误 | **成立（权限分类）**。报告的 `403 ... quota exceeded` 例子不成立，余额规则本来排第一；但单独 403/Forbidden 并不证明密钥失效。 | 401/明确坏 key 仍为 repaste；一般 403/Forbidden/permission denied 为 settings。 | 分类：403+quota 为 topup，裸 403 为 settings，401/invalid key 为 repaste。 |
| 10 首次启动不知道密码位置 | **成立（可用性）**。不打印密码是正确的，但配置路径可以明确。 | 打印 `cfg_path().resolve()`，不打印密码。 | 启动路径：捕获输出并检查路径与密码不出现。 |
| 11 上传临时文件 / 磁盘失败 | **成立（OSError 响应部分）**。413 return 仍执行 finally，原临时文件清理正确；落盘 OSError 原会成为泛化 500，缺明确重试动作。 | 捕获 OSError，返回固定中文 507 和 retry，仍 finally 清理。 | 上传：413 与 rename 失败均不留下临时文件或发布文件。 |
| 12 插件 network down 测试 | **不成立**。测试已同时断言“连不上”和 retry；未来规则变化会令测试明确失败，不是“静默失败”。 | 无。 | 分类离线测试验证 network down；原 `test_plugins.TestInstall.test_failed_install_reported` 需 socket，沙箱未执行到断言。 |

R_B2 的“编译/导入错误：无”判断成立：本次模块编译和离线测试导入通过。其缺失测试清单已由地址/回滚/分类等新测试补齐；seen 原已有验证，本次增加直接单测核实。

## R_B3：逐条结论

| 条目 | 成立/不成立与理由 | 改动 | 测试 |
| --- | --- | --- | --- |
| 1 inet_aton bytes | **成立**。`ip_address` 不按四字节网络序解释 bytes，而尝试字符串解析并抛 ValueError；原代码只捕获 OSError。标准点分地址不受影响，缩写/整数等走此路径。paste 本身捕获 ValueError，所以并非所有调用都会未捕获崩溃，但会错误拒绝正常输入。 | 删除 inet_aton 路径，独立解析数值 IPv4。 | 地址：拒绝元数据编码，允许普通域名、本地中转及合法非标准本地地址。 |
| 2 依赖平台解析整数/十六进制 | **成立（平台依赖风险）**。不声称本机 libc 已复现放行，但原先 OSError 后直接 return，平台不识别数字写法时会漏掉过滤。 | 独立按进制和段宽解析，不使用 socket；无效数字写法拒绝。 | 地址：十进制、十六进制、八进制、混合段与越界。 |
| 3 十六进制 mapped IPv6 的 ipv4_mapped 为 None | **不成立**。属性按 128 位数值判断映射前缀，十六进制和点分尾部是同一地址，已有归一化能拦截。 | 保留标准库映射判断，无自制低 32 位替代逻辑。 | 地址：`::ffff:a9fe:a9fe`、完整展开、点分以及阿里元数据映射。 |
| 4 其它 API 的 provider key 泄露 | **不成立（未找到所称路径）**。provider 保存 key 是连接所必需，不等于公开返回。`_probe` 已隐藏 key，explain/upstream 返回固定文案；`_test` 把分类后的文案写 INV，metrics 只有数值，quota 并不合并 provider 对象。 | 不扩大到无证据的统一字符串清洗。另修复异常类型过早 str：`_test` 保留异常类型供分类，`_probe` 将空字符串 TimeoutError 转为固定超时文案。 | 已有 `test_boot` 的敏感字段与错误响应检查；超时新测试。 |
| 5 base 与 detect 分支变化 | **不成立**。产品代码与现有测试明确约定：带 URL 的非 Anthropic key 全部走 relay；None（模糊 key）也在此范围，不是被跳过。 | 无。 | 中转新测试；原 `test_connect.TestPaste.test_relay_overrides_every_non_anthropic_vendor` 已包括 None 和 tuple（原类需要 socket）。 |
| 6 cleanup cancel/gather 竞态 | **不成立（所称事件循环竞态）**。cancel 到 gather 参数求值之间无 await，done callback 不会在普通任务间穿插；原测试也已 sleep(0)。 | 防御性改为一次任务列表快照，用同一列表 cancel/gather，明确等待范围。 | 清理：取消任务需要异步 finally，验证 cleanup 等待完成。 |
| 7 remote_status 的 r/seen KeyError | **不成立**。r=None 有短路；REMOTE 仅在注册时创建，始终有 seen，且不持久化所谓旧条目。无有效调用路径创建缺 seen 的条目。 | 无，未用默认 0 掩盖内部对象损坏。 | 在线状态测试含服务器无 REMOTE 条目情况；静态核对所有 REMOTE 写入。 |
| 8 恢复时应清除其它 resting 原因 | **不成立**。余额/命令错误是独立原因；连接恢复不能清除这些状态。refresh_all 不会如报告所称覆盖成其它 reason；离线时 remote_status 会重新标记 OFFLINE_REASON，在线时只删除该原因。 | 无，保留按原因恢复。 | 在线状态：清离线原因但保留“余额不足”；原 poll 不清无关错误测试待 socket 环境复跑。 |
| 9 remote_call 队列遗留任务 | **成立（遗留任务）**。当前 Queue 无界，put 通常不挂起，报告指定的 put 竞态不是主因；实际问题是已经入队但尚未领取的任务，在 caller 取消/超时后仍可能被领取执行。把 wait 注册移到 put 之后反而可能引入结果先到的风险。 | h_jobs 检查 future 是否仍存在且未完成，跳过失效任务，同时按原 deadline 控制剩余等待。 | 遗留任务：超时、取消后的两项均被跳过，后续有效任务仍可领取。 |
| 10 h_status 终态时间缺键 | **不成立（正常生产路径）**。终态只由 `_mark` 设置，时间和 state 同步写入，无 await；INV 为内存态，不存在重启前旧记录。 | 防御性 `.get(state, time.time())` 兼容手工/异常条目。 | 状态详情：删除终态时间键后仍响应；原终态秒数冻结测试待 socket 复跑。 |
| 11 percentile p=0 | **不成立**。原有 `max(0, ceil(...)-1)` 已处理；报告也自行撤回。当前只调用 p50/p95。 | 无。 | 静态核对边界；原 metrics 测试需 socket。 |
| 12 refresh_all 重复 bump | **不成立**。逐成员离线状态改变时 bump、整次配额刷新后 bump 都符合其通知职责，不会导致语义错误；非 remote 成员直接返回。 | 无。 | 静态核对；已有离线 quota/status 测试需 socket。 |
| 13 metrics 覆盖 state/label/reason | **不成立**。状态覆盖是 API 正常合成行为，离线时显示离席与 resting 保持一致。 | 无。 | 静态核对；原 `test_offline_member_rests_in_quota_and_status_until_poll` 需 socket。 |
| 14 status_view 多次 bump | **不成立**。原判断只在状态/原因变化时 mark+bump，相同离线状态不会反复写时间或 bump。 | 无。 | 在线状态：连续读取离线成员只 bump 一次。 |
| 15 quota_view 生成器/重名 | **不成立**。生成器仅遍历一次；同名合并为成员名索引的字典是既定语义。 | 无。 | 静态核对单次遍历和 setdefault/update；既有 quota/status 测试需 socket。 |
| 16 connector.save_state 清理 | **不成立**。finally unlink(missing_ok=True) 正确覆盖成功 replace 和失败路径。 | 无。 | 已执行 `test_connect.TestConnectorState` 三项：原子权限、失败保留旧内容/清 tmp、无效 CLI 重注册。 |
| 17 缺 member 的状态文件 | **成立**。secret 和合法 cli 不能保证 member 存在，后续打印/构造 header 会 KeyError。 | 注册前检查 `not st.get("member")`。 | 状态文件：缺 member 触发重新注册，并保存正确成员。 |
| 18 测试 patch dict 不生效 | **不成立**。函数通过模块全局名读取，patch.object 会生效。 | 无。 | 静态核对；B5 测试同样 patch 模块字典并验证状态。 |
| 19 NaN clamp 失败 | **不成立**。此参数顺序下 `min(30, nan)` 保留 30，随后 max 得 30；报告把顺序/比较行为判断反了。 | 无，无需特判。 | NaN：实际捕获传给 wait_for 的值，等于 30。 |
| 20 call_cli 参数个数 | **不成立**。原函数与 connector 包装函数都是前七个必选参数，sess/skey 有默认值，调用中的七参数正确。 | 无。 | 静态核对签名；已执行 test_review_fixes 的 CLI 相关测试；原 remote 包装 HTTP 测试待 socket 复跑。 |
| 21 quota short 被覆盖 | **不成立**。update 就是要把旧“可用”覆盖为当前“离席”，与测试预期一致。 | 无。 | 静态核对；原离线 quota/status 测试需 socket。 |
| 22 detect 重复添加 relay | **不成立**。seen 按完整 key 去重；不同 key 应分别生成候选，单个 key 只生成一个 relay。 | 无。 | 中转测试及原 detect 测试（原类需 socket）。 |
| 23 name 泄露 key 片段 | **不成立（建议不能解决所称问题）**。任意片段无法可靠与普通名称区分；完整 key 已先脱敏再截断。建议的字符白名单本身允许 key 的字母、数字、下划线和短横线，不能消除片段。 | 无，不添加无效过滤。 | 现有完整 key 脱敏测试；静态核对脱敏先于名称截断。 |
| 24 finally bump / 测试预期 | **不成立（产品逻辑）**。注册保存后 bump 一次，测试调用完成后 finally 再 bump 一次合理，成功和失败均如此。**报告遗漏实际测试预期错误**：原 `assert_called_once` 与代码两次不符。 | `test_connect` 改断言 bump 次数为 2。 | 该测试仍需 socket；另以无 socket 方式调用同一测试方法完成验证，见运行结果。 |
| 25 反代 HTTPS 回调地址 | **成立**。仓库 `server/deploy/nginx-chorus2.conf` 明确设置 X-Forwarded-Proto=$scheme，而后端看到的是 HTTP，生成地址会错误使用 http。 | `_server_url` 接受严格等于 http/https 的转发协议，其它值回退 request.scheme；沿用已有 prefix 规则。部署端应由反代覆盖该头，与现有部署配置一致。 | 反代：合法 https/http 与注入文本、协议列表、其它协议的回退。 |
| 26 同名重注册覆盖 REMOTE | **不成立**。写 REMOTE 前已 `while S.member(nm): nm += '2'`，已有成员会换名，新邀请也不等于重连原成员的协议。 | 无。 | 重名注册：A 已有队列，注册同名产生 A2，原对象身份保留。 |
| 27 同步函数调用 async bump | **不成立**。server.bump 是同步函数；报告也已自行否定。 | 无。 | 在线状态与现有 boot 测试；静态核对定义。 |
| 28 h_status 缺时间键 | **不成立（与 10 重复）**。报告仅靠手工构造破坏 `_mark` 不变量，非正常生产路径。 | 同 10，防御性 get 回退。 | 同状态详情及 10。 |
| 29 patch os.open 影响其它调用 | **不成立**。patch 有上下文范围，测试只针对保存原子状态，无实际冲突。 | 无。 | `test_connect.TestConnectorState.test_atomic_state_has_private_permissions_before_rename` 已执行通过。 |
| 30 KeyboardInterrupt 会被 Exception 捕获 | **不成立**。KeyboardInterrupt 继承 BaseException，测试预期向上传播正确。 | 无。 | 原无效 CLI 状态测试与新缺 member 测试均执行通过。 |

## 运行结果与复跑

- `cd server && python3 -m unittest test_boot test_review_b5 test_connect.TestConnectorState -q`：**43 项通过**（19 项 boot、21 项 B5、3 项状态文件）；boot 在真实 aiohttp 路由和鉴权上运行，但不创建 TCP socket。
- 原 `test_connect.TestPaste` 的 6 项不需 HTTP 的方法，复用 `ReviewB5.asyncSetUp` 代替其 socket 初始化后均通过：relay 覆盖、元数据拒绝、本地中转、失败聊天的两次 bump、脱敏、detect。完整原 HTTP 测试类仍须主管复跑。
- `test_review_fixes` 中除 `test_real_http_and_stream_error_classification`（需要监听 socket）外的 18 项已通过，包含幂等重试、编辑/撤回、CLI、预算等。
- 尝试运行 `test_plugins`、完整 `test_connect`、`test_dm_index` 时，测试初始化的 `socket.socket` 被沙箱以 `PermissionError: [Errno 1] Operation not permitted` 拒绝；这些 HTTP/安装脚本集成测试未完成，不将它们记为通过。主管可在允许 socket 的环境运行 `cd server && python3 -m unittest discover -p 'test_*.py'`。
- 修改模块 `compileall` 与 `git diff --check` 通过。未调用真实模型、输出配置凭证或修改审查输入文件。

最终共 **67 项测试通过**；存在 aiohttp bare function 的既有 DeprecationWarning。网络集成测试的沙箱限制单独列出，不计入通过数。
