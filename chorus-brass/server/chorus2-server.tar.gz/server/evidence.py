"""evidence.py — 证据冗余 (evidence redundancy) for Chorus.

每个段落的关键事实（决策、文件、验收结果）写入三处：

1. 项目 ``memory``（已有 scope 机制，由调用方负责）；
2. ``work/<pid>/events.jsonl`` —— 事件流水，append-only JSONL；
3. ``manifest`` —— 段落产物清单，可被下游读取。

当消息总线传递失败时，下游可以通过 :func:`recover_from_artifacts`
从 events / manifest 重建上游输入，从而让段落仍然能够完成。

设计原则：
- 纯函数 + 文件 IO，路径可注入（不依赖全局状态）；
- 仅使用标准库 + aiohttp（aiohttp 在本模块中不直接使用，但保留依赖约束）；
- 不修改其它已有文件。
"""

from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

__all__ = [
    "EvidenceError",
    "Event",
    "Manifest",
    "append_event",
    "read_events",
    "write_manifest",
    "read_manifest",
    "recover_from_artifacts",
    "build_handoff",
    "record_decision",
    "record_file",
    "record_acceptance",
]


class EvidenceError(RuntimeError):
    """Raised when evidence artifacts are missing or malformed."""


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Event:
    """A single evidence event written to ``events.jsonl``."""

    seg: str
    kind: str
    payload: Mapping[str, Any]
    ts: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "seg": self.seg,
            "kind": self.kind,
            "payload": dict(self.payload),
            "ts": self.ts,
        }

    @staticmethod
    def from_dict(data: Mapping[str, Any]) -> "Event":
        try:
            return Event(
                seg=str(data["seg"]),
                kind=str(data["kind"]),
                payload=dict(data.get("payload", {})),
                ts=float(data.get("ts", time.time())),
                event_id=str(data.get("event_id", uuid.uuid4().hex)),
            )
        except (KeyError, TypeError, ValueError) as exc:  # pragma: no cover
            raise EvidenceError(f"malformed event: {data!r}") from exc


@dataclass
class Manifest:
    """产物清单：记录一个段落产出的关键事实。

    ``manifest`` 与 ``events.jsonl`` 互为冗余：任一存在即可恢复。
    """

    seg: str
    pid: str = ""
    decisions: list[dict[str, Any]] = field(default_factory=list)
    files: list[dict[str, Any]] = field(default_factory=list)
    acceptances: list[dict[str, Any]] = field(default_factory=list)
    upstream: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "seg": self.seg,
            "pid": self.pid,
            "decisions": list(self.decisions),
            "files": list(self.files),
            "acceptances": list(self.acceptances),
            "upstream": dict(self.upstream),
            "meta": dict(self.meta),
        }

    @staticmethod
    def from_dict(data: Mapping[str, Any]) -> "Manifest":
        if not isinstance(data, Mapping):
            raise EvidenceError(f"manifest must be a mapping, got {type(data)!r}")
        if "seg" not in data:
            raise EvidenceError("manifest missing 'seg'")
        return Manifest(
            seg=str(data["seg"]),
            pid=str(data.get("pid", "")),
            decisions=[dict(d) for d in data.get("decisions", [])],
            files=[dict(f) for f in data.get("files", [])],
            acceptances=[dict(a) for a in data.get("acceptances", [])],
            upstream=dict(data.get("upstream", {})),
            meta=dict(data.get("meta", {})),
        )


# ---------------------------------------------------------------------------
# events.jsonl — append_event / read_events
# ---------------------------------------------------------------------------


def append_event(
    path: os.PathLike[str] | str,
    seg: str,
    kind: str,
    payload: Mapping[str, Any] | None = None,
    *,
    ts: float | None = None,
    event_id: str | None = None,
) -> Event:
    """Append one event to a JSONL file and return the written :class:`Event`.

    The file is created (with parent directories) if it does not exist.
    Each line is a self-contained JSON object so partial reads can skip
    corrupted lines without losing the whole stream.
    """
    if not seg:
        raise EvidenceError("seg must be non-empty")
    if not kind:
        raise EvidenceError("kind must be non-empty")

    event = Event(
        seg=seg,
        kind=kind,
        payload=dict(payload or {}),
        ts=time.time() if ts is None else float(ts),
        event_id=event_id or uuid.uuid4().hex,
    )

    file_path = os.fspath(path)
    parent = os.path.dirname(file_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    line = json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True)
    with open(file_path, "a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    return event


def read_events(path: os.PathLike[str] | str) -> list[Event]:
    """Read all events from a JSONL file.

    Missing file → empty list. Corrupted lines are skipped (best-effort),
    because evidence recovery must be resilient to partial writes.
    """
    file_path = os.fspath(path)
    if not os.path.exists(file_path):
        return []
    events: list[Event] = []
    with open(file_path, "r", encoding="utf-8") as fh:
        for raw in fh:
            raw = raw.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(data, Mapping):
                continue
            try:
                events.append(Event.from_dict(data))
            except EvidenceError:
                continue
    return events


# ---------------------------------------------------------------------------
# manifest — write / read
# ---------------------------------------------------------------------------


def write_manifest(path: os.PathLike[str] | str, manifest: Manifest) -> None:
    """Atomically write ``manifest`` as JSON to ``path``."""
    file_path = os.fspath(path)
    parent = os.path.dirname(file_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = file_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(manifest.to_dict(), fh, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp, file_path)


def read_manifest(path: os.PathLike[str] | str) -> Manifest | None:
    """Read a manifest; return ``None`` if the file does not exist."""
    file_path = os.fspath(path)
    if not os.path.exists(file_path):
        return None
    with open(file_path, "r", encoding="utf-8") as fh:
        try:
            data = json.load(fh)
        except json.JSONDecodeError as exc:
            raise EvidenceError(f"corrupted manifest at {file_path}") from exc
    return Manifest.from_dict(data)


# ---------------------------------------------------------------------------
# Handoff construction (used by upstream to publish to downstream)
# ---------------------------------------------------------------------------


def build_handoff(
    seg: str,
    *,
    decisions: Sequence[Mapping[str, Any]] = (),
    files: Sequence[Mapping[str, Any]] = (),
    acceptances: Sequence[Mapping[str, Any]] = (),
    upstream: Mapping[str, Any] | None = None,
    meta: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a handoff message payload (what the message bus would carry).

    The same payload is also persisted to manifest + events so that losing
    the message does not lose the information.
    """
    return {
        "seg": seg,
        "decisions": [dict(d) for d in decisions],
        "files": [dict(f) for f in files],
        "acceptances": [dict(a) for a in acceptances],
        "upstream": dict(upstream or {}),
        "meta": dict(meta or {}),
    }


def record_decision(
    *,
    events_path: os.PathLike[str] | str,
    manifest_path: os.PathLike[str] | str,
    seg: str,
    decision: Mapping[str, Any],
    pid: str = "",
) -> Manifest:
    """Persist a decision to both events.jsonl and manifest; return manifest."""
    payload = dict(decision)
    append_event(events_path, seg, "decision", payload)
    manifest = read_manifest(manifest_path) or Manifest(seg=seg, pid=pid)
    manifest.decisions.append(payload)
    if pid and not manifest.pid:
        manifest.pid = pid
    write_manifest(manifest_path, manifest)
    return manifest


def record_file(
    *,
    events_path: os.PathLike[str] | str,
    manifest_path: os.PathLike[str] | str,
    seg: str,
    file_entry: Mapping[str, Any],
    pid: str = "",
) -> Manifest:
    """Persist a file artifact record to both events.jsonl and manifest."""
    payload = dict(file_entry)
    append_event(events_path, seg, "file", payload)
    manifest = read_manifest(manifest_path) or Manifest(seg=seg, pid=pid)
    manifest.files.append(payload)
    if pid and not manifest.pid:
        manifest.pid = pid
    write_manifest(manifest_path, manifest)
    return manifest


def record_acceptance(
    *,
    events_path: os.PathLike[str] | str,
    manifest_path: os.PathLike[str] | str,
    seg: str,
    acceptance: Mapping[str, Any],
    pid: str = "",
) -> Manifest:
    """Persist an acceptance (验收结果) to both events.jsonl and manifest."""
    payload = dict(acceptance)
    append_event(events_path, seg, "acceptance", payload)
    manifest = read_manifest(manifest_path) or Manifest(seg=seg, pid=pid)
    manifest.acceptances.append(payload)
    if pid and not manifest.pid:
        manifest.pid = pid
    write_manifest(manifest_path, manifest)
    return manifest


# ---------------------------------------------------------------------------
# recover_from_artifacts — the core DoD function
# ---------------------------------------------------------------------------


def recover_from_artifacts(
    seg: str,
    manifest_store: os.PathLike[str] | str | Mapping[str, Any] | None,
    events: os.PathLike[str] | str | Iterable[Mapping[str, Any]] | None,
) -> dict[str, Any]:
    """Rebuild the upstream input for ``seg`` from manifest + events.

    This is the fallback path used when the message bus dropped the handoff
    message. It merges evidence from two redundant stores:

    - ``manifest_store``: path to a manifest JSON file, an already-loaded
      mapping, or ``None``;
    - ``events``: path to an ``events.jsonl`` file, an iterable of event
      mappings (or :class:`Event` objects), or ``None``.

    Returns a dict shaped like :func:`build_handoff`'s payload::

        {
          "seg": str,
          "decisions": [...],
          "files": [...],
          "acceptances": [...],
          "upstream": {...},
          "meta": {...},
          "recovered": bool,          # True if any evidence was found
          "sources": ["manifest", "events"],
        }

    Deduplication: entries are keyed by a stable signature so the same fact
    recorded in both stores appears only once. Order is preserved
    (manifest-first, then events-only entries in chronological order).
    """
    if not seg:
        raise EvidenceError("seg must be non-empty")

    manifest: Manifest | None = None
    if isinstance(manifest_store, Mapping):
        manifest = Manifest.from_dict(manifest_store)
    elif manifest_store is not None:
        manifest = read_manifest(manifest_store)

    event_list: list[Event] = []
    if isinstance(events, (str, os.PathLike)):
        event_list = read_events(events)
    elif events is not None:
        for item in events:
            if isinstance(item, Event):
                event_list.append(item)
            elif isinstance(item, Mapping):
                event_list.append(Event.from_dict(item))
            else:
                raise EvidenceError(f"unsupported event item: {item!r}")

    # Only consider events relevant to this seg (or global events with empty seg).
    relevant = [e for e in event_list if e.seg in ("", seg)]
    relevant.sort(key=lambda e: e.ts)

    decisions: list[dict[str, Any]] = []
    files: list[dict[str, Any]] = []
    acceptances: list[dict[str, Any]] = []
    upstream: dict[str, Any] = {}
    meta: dict[str, Any] = {}
    seen: set[tuple[str, str]] = set()

    def _sig(kind: str, payload: Mapping[str, Any]) -> tuple[str, str]:
        try:
            key = json.dumps(dict(payload), sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError):  # pragma: no cover
            key = repr(dict(payload))
        return (kind, key)

    def _add(kind: str, payload: Mapping[str, Any]) -> None:
        sig = _sig(kind, payload)
        if sig in seen:
            return
        seen.add(sig)
        entry = dict(payload)
        if kind == "decision":
            decisions.append(entry)
        elif kind == "file":
            files.append(entry)
        elif kind == "acceptance":
            acceptances.append(entry)

    sources: list[str] = []

    # 1) manifest first (authoritative snapshot)
    if manifest is not None:
        sources.append("manifest")
        for d in manifest.decisions:
            _add("decision", d)
        for f in manifest.files:
            _add("file", f)
        for a in manifest.acceptances:
            _add("acceptance", a)
        upstream.update(manifest.upstream)
        meta.update(manifest.meta)

    # 2) events (append-only log, may contain facts newer than manifest)
    if event_list:
        sources.append("events")
        for ev in relevant:
            if ev.kind == "decision":
                _add("decision", ev.payload)
            elif ev.kind == "file":
                _add("file", ev.payload)
            elif ev.kind == "acceptance":
                _add("acceptance", ev.payload)
            elif ev.kind == "upstream" and isinstance(ev.payload, Mapping):
                upstream.update(dict(ev.payload))
            elif ev.kind == "meta" and isinstance(ev.payload, Mapping):
                meta.update(dict(ev.payload))

    recovered = bool(sources) and bool(decisions or files or acceptances or upstream or meta)

    return {
        "seg": seg,
        "decisions": decisions,
        "files": files,
        "acceptances": acceptances,
        "upstream": upstream,
        "meta": meta,
        "recovered": recovered,
        "sources": sources,
    }
