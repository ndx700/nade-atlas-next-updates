"""
Chorus 服务端红线（red lines）判定。

策略：红线动作不是禁止，而是「挂起」，直到用户在同意卡片上明确批准该一次动作。
只有 `illegal` 一条是绝对禁止（deny）。其余一律 allow，无需提示。

仅使用 Python 3.11 标准库。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Sequence

__all__ = [
    "Verdict",
    "check",
    "check_spend",
    "card",
    "scrub",
    "LINES",
]

# --------------------------------------------------------------------------- #
# 红线清单
# --------------------------------------------------------------------------- #

LINES: dict[str, str] = {
    "money": "支付、购买、充值等会产生真实花费或资金变动的动作",
    "delete": "删除或销毁用户数据（数据目录、数据库、磁盘内容）",
    "git_force": "强制推送、改写远端分支、删除远端分支或仓库",
    "deploy": "部署上线、改动线上服务、发布制品",
    "external": "对外发送消息、邮件、帖子、评论、工单",
    "secrets": "读取或外泄密钥、凭据、令牌等敏感信息",
    "perms": "修改权限、属主、sudo、账号、全局凭据配置",
    "skills": "安装或执行未经审查的第三方代码",
    "illegal": "违法或攻击性行为（绝对禁止）",
}

_SEVERITY = {"allow": 0, "ask": 1, "deny": 2}

_DEFAULT_PROTECTED_BRANCHES = ("main", "master", "release", "production", "prod")

# --------------------------------------------------------------------------- #
# Verdict
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class Verdict:
    action: str = "allow"  # "allow" | "ask" | "deny"
    line: str = ""
    why: str = ""
    impact: str = ""

    @property
    def allow(self) -> bool:
        return self.action == "allow"


def _ask(line: str, why: str, impact: str) -> Verdict:
    return Verdict(action="ask", line=line, why=why, impact=impact)


def _deny(line: str, why: str, impact: str) -> Verdict:
    return Verdict(action="deny", line=line, why=why, impact=impact)


_ALLOW = Verdict(action="allow")

# --------------------------------------------------------------------------- #
# scrub()
# --------------------------------------------------------------------------- #

_HIDDEN = "‹已隐藏›"

_SCRUB_PATTERNS: tuple[tuple[re.Pattern[str], Any], ...] = (
    # OpenAI / Anthropic 风格 key
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{8,}"), _HIDDEN),
    (re.compile(r"\btp-[A-Za-z0-9_\-]{8,}"), _HIDDEN),
    (re.compile(r"\bttp-[A-Za-z0-9_\-]{8,}"), _HIDDEN),
    # GitHub tokens
    (re.compile(r"\bghp_[A-Za-z0-9]{16,}"), _HIDDEN),
    (re.compile(r"\bgho_[A-Za-z0-9]{16,}"), _HIDDEN),
    (re.compile(r"\bgithub_pat_[A-Za-z0-9_]{16,}"), _HIDDEN),
    # Slack
    (re.compile(r"\bxox[bpa]-[A-Za-z0-9\-]{8,}"), _HIDDEN),
    # AWS
    (re.compile(r"\bAKIA[0-9A-Z]{12,}"), _HIDDEN),
    # Bearer
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._\-]{8,}"), "Bearer " + _HIDDEN),
    # PEM 私钥块
    (
        re.compile(
            r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
            re.DOTALL,
        ),
        _HIDDEN,
    ),
    (
        re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
        _HIDDEN,
    ),
    # key=value 形式
    (
        re.compile(
            r"(?i)\b(api_key|apikey|token|password|secret)\b(\s*[=:]\s*)(\"[^\"]*\"|'[^']*'|[^\s,;&]+)"
        ),
        lambda m: f"{m.group(1)}{m.group(2)}{_HIDDEN}",
    ),
)


def scrub(text: str) -> str:
    """把文本中的密钥/令牌替换成 ‹已隐藏›。"""
    if not text:
        return ""
    out = str(text)
    for pat, repl in _SCRUB_PATTERNS:
        out = pat.sub(repl, out)
    return out


# --------------------------------------------------------------------------- #
# 通用工具
# --------------------------------------------------------------------------- #


def _s(v: Any) -> str:
    if v is None:
        return ""
    return str(v)


def _lower(v: Any) -> str:
    return _s(v).lower()


def _flatten_inp(inp: dict | None) -> str:
    """把 inp 的所有值拼成一段可搜索文本（保留原始大小写）。"""
    if not inp:
        return ""
    parts: list[str] = []
    for k, v in inp.items():
        parts.append(_s(k))
        if isinstance(v, (list, tuple, set)):
            parts.append(" ".join(_s(x) for x in v))
        elif isinstance(v, dict):
            parts.append(_flatten_inp(v))
        else:
            parts.append(_s(v))
    return "\n".join(parts)


def _ctx_list(ctx: dict | None, key: str, default: Sequence[str] = ()) -> list[str]:
    if not ctx:
        return list(default)
    v = ctx.get(key)
    if v is None:
        return list(default)
    if isinstance(v, str):
        return [v]
    try:
        return [str(x) for x in v]
    except TypeError:
        return list(default)


def _norm_path(p: str) -> str:
    p = _s(p).strip().strip("'\"")
    if not p:
        return ""
    # 去掉尾部斜杠（根除外）
    while len(p) > 1 and p.endswith("/"):
        p = p[:-1]
    return p


def _expand_home(p: str, home: str = "/home/user") -> str:
    p = _norm_path(p)
    if p == "~":
        return home
    if p.startswith("~/"):
        return home + "/" + p[2:]
    return p


def _is_inside(child: str, parent: str) -> bool:
    """child 是否位于 parent 之内（含等于）。两者都应是绝对路径或 ~ 形式。"""
    c = _norm_path(child)
    p = _norm_path(parent)
    if not c or not p:
        return False
    if c == p:
        return True
    if p == "/":
        return c.startswith("/")
    return c.startswith(p + "/")


def _data_dir(ctx: dict | None) -> str:
    if not ctx:
        return ""
    return _norm_path(ctx.get("data_dir", ""))


# --------------------------------------------------------------------------- #
# Bash 分段
# --------------------------------------------------------------------------- #

_SPLIT_RE = re.compile(r"(?:\|\||&&|;|\||\n|`|\$\()|\$\)")

_UNWRAP_RE = re.compile(
    r"""^\s*(?:sudo\s+|env\s+(?:[A-Za-z_][A-Za-z0-9_]*=\S*\s+)*|time\s+|nohup\s+)*"""
    r"""(?:/usr/bin/|/bin/)?(?:ba|z|k)?sh\s+(?:-\w+\s+)*-c\s+(?P<q>['"])(?P<body>.*)(?P=q)\s*$""",
    re.DOTALL,
)


def _split_segments(cmd: str) -> list[str]:
    """把命令按 ; && || | 换行 $( ) 反引号 切成片段。"""
    if not cmd:
        return []
    raw = _SPLIT_RE.split(cmd)
    pieces: list[str] = []
    for seg in raw:
        seg = seg.strip().strip("()`").strip()
        if seg:
            pieces.append(seg)
    return pieces


def _strip_prefixes(seg: str) -> str:
    """去掉 sudo/env/time/nohup 等前缀，返回真正的命令体。"""
    s = seg.strip()
    changed = True
    while changed and s:
        changed = False
        # sudo -u user ... / sudo / nohup / time ...
        m = re.match(
            r"^(?:sudo\b\s+(?:-[A-Za-z]\s+\S+\s+)*|nohup\b\s+|time\b\s+|nice\b\s+|ionice\b\s+|command\b\s+|builtin\b\s+|exec\b\s+)",
            s,
        )
        if m:
            s = s[m.end():]
            changed = True
            continue
        # env A=1 B=2 ...
        m = re.match(r"^env\b\s+", s)
        if m:
            s = s[m.end():]
            while True:
                m2 = re.match(r"^(?:-[A-Za-z]\s+)*[A-Za-z_][A-Za-z0-9_]*=\S*\s+", s)
                if not m2:
                    break
                s = s[m2.end():]
            changed = True
            continue
    return s.strip()


def _unwrap_shell(seg: str) -> str | None:
    """如果片段是 bash -c '…' / sh -c "…"，返回内部命令，否则 None。"""
    m = _UNWRAP_RE.match(seg)
    if m:
        return m.group("body")
    return None


def _segments(cmd: str) -> list[str]:
    """递归展开 bash -c 嵌套，返回所有需要检查的命令片段。"""
    out: list[str] = []
    seen: set[str] = set()

    def add(text: str) -> None:
        if text and text not in seen:
            seen.add(text)
            out.append(text)

    def walk(text: str, depth: int = 0) -> None:
        if depth > 8 or not text:
            return
        for seg in _split_segments(text):
            body = _strip_prefixes(seg)
            if not body:
                continue
            inner = _unwrap_shell(body)
            if inner is not None:
                walk(inner, depth + 1)
                add(body)
                continue
            add(body)

    walk(cmd)
    return out


# --------------------------------------------------------------------------- #
# 各红线检测
# --------------------------------------------------------------------------- #

_MONEY_HOSTS = (
    "stripe.com",
    "paypal.com",
    "alipay.com",
    "wechatpay",
    "pay.weixin.qq.com",
)
_MONEY_URL_PATTERNS = (
    re.compile(r"/v1/charges", re.I),
    re.compile(r"/checkout", re.I),
    re.compile(r"/pay\b", re.I),
    re.compile(r"/topup", re.I),
    re.compile(r"/recharge", re.I),
)
_MONEY_TOOL_RE = re.compile(r"(purchase|checkout|order|buy|topup|recharge|pay(?!load))", re.I)

_DELETE_SQL_RE = re.compile(
    r"\b(drop\s+(database|table|schema)|truncate(\s+table)?)\b", re.I
)
_DELETE_CURL_RE = re.compile(r"-X\s+DELETE\b", re.I)
_DELETE_API_RE = re.compile(r"/api/(projects|members)\b", re.I)

_GIT_FORCE_FLAGS = ("--force-with-lease", "--force-if-includes", "--force", "-f")
_PROTECTED_DEFAULT = list(_DEFAULT_PROTECTED_BRANCHES)

_EXTERNAL_HOSTS = (
    "api.telegram.org",
    "slack.com/api",
    "hooks.slack.com",
    "discord.com/api",
    "api.twitter.com",
    "api.x.com",
    "graph.facebook.com",
    "open.feishu.cn",
    "qyapi.weixin.qq.com",
    "oapi.dingtalk.com",
    "api.sendgrid.com",
    "api.mailgun.net",
    "api.resend.com",
)
_EXTERNAL_MAIL_CMDS = {"sendmail", "mail", "mutt", "swaks"}
_EXTERNAL_TOOL_RE = re.compile(
    r"(send|post|tweet|email|publish|comment|create_issue|reply|dm\b)", re.I
)
_READLIKE_TOOL_RE = re.compile(r"^(read|get|fetch|view|list|search|grep|head|tail|cat)$", re.I)

_SECRET_PATH_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"(^|/)\.ssh/"),
    re.compile(r"(^|/)id_rsa"),
    re.compile(r"\.pem$"),
    re.compile(r"\.key$"),
    re.compile(r"(^|/)\.env(\.|$)"),
    re.compile(r"(^|/)\.aws/credentials$"),
    re.compile(r"(^|/)\.config/gh/hosts\.ya?ml$"),
    re.compile(r"(^|/)\.netrc$"),
    re.compile(r"(^|/)\.docker/config\.json$"),
    re.compile(r"(^|/)\.codex/auth\.json$"),
    re.compile(r"(^|/)\.claude/\.credentials\.json$"),
    re.compile(r"(^|/)\.config/chorus/"),
)

_SECRET_ENV_RE = re.compile(
    r"\$\{?[A-Za-z_][A-Za-z0-9_]*(KEY|TOKEN|SECRET|PASSWORD|PASS|CRED)[A-Za-z0-9_]*\}?",
    re.I,
)
_SECRET_UPLOAD_RE = re.compile(r"@[^\s;|&]+", re.I)

_PERMS_CMDS = {"chown", "passwd", "usermod", "visudo", "ssh-keygen", "ssh-add"}
_PERMS_SUDOERS_RE = re.compile(r"/etc/sudoers")
_PERMS_CRONTAB_RE = re.compile(r"\bcrontab\b\s+(-[er]\b|--edit|--remove)", re.I)
_PERMS_GITCRED_RE = re.compile(r"\bgit\s+config\s+--global\b[^\n]*credential", re.I)
_PERMS_GHAUTH_RE = re.compile(r"\bgh\s+auth\b", re.I)
_PERMS_CHORUS_API_RE = re.compile(
    r"\b(PUT|POST|PATCH)\b[^\n]*/api/(members|providers|settings|wallet)\b", re.I
)
_CHMOD_BAD_RE = re.compile(
    r"\bchmod\b\s+(?:-[A-Za-z]+\s+)*(777|[A-Za-z]*\+s|u\+s|g\+s|o\+s)\b", re.I
)

_SKILLS_PIPE_RE = re.compile(
    r"\b(curl|wget)\b[^|\n]*\|\s*(sudo\s+)?(sh|bash|zsh|python3?|node)\b", re.I
)
_SKILLS_PIP_URL_RE = re.compile(r"\bpip3?\s+install\b[^\n]*(https?://|git\+)", re.I)
_SKILLS_NPM_GLOBAL_RE = re.compile(r"\bnpm\s+(i|install|add)\s+(-g|--global)\b", re.I)
_SKILLS_NPX_RE = re.compile(r"\bnpx\s+([A-Za-z0-9@/_.\-]+)", re.I)
_SKILLS_GO_INSTALL_RE = re.compile(r"\bgo\s+install\b", re.I)
_SKILLS_CARGO_INSTALL_RE = re.compile(r"\bcargo\s+install\b", re.I)
_SKILLS_API_INSTALL_RE = re.compile(r"/api/skills/install", re.I)
_SKILLS_DL_RE = re.compile(r"\b(curl|wget)\b", re.I)

_ILLEGAL_SCAN_RE = re.compile(r"\b(nmap|masscan|sqlmap|hydra|hping3|slowloris)\b", re.I)
_ILLEGAL_PIRACY_RE = re.compile(r"(thepiratebay|1337x\.[a-z]+)", re.I)
_ILLEGAL_MALWARE_RE = re.compile(
    r"(ransomware|keylogger|key-logger|键盘记录|勒索软件|勒索病毒)", re.I
)
_ILLEGAL_CSAM_RE = re.compile(
    r"(child\s*porn|csam|儿童色情|未成年色情|幼女|恋童)", re.I
)
_ILLEGAL_STUFFING_RE = re.compile(
    r"(credential[\s_\-]*stuffing|撞库|爆破密码|password[\s_\-]*spray)", re.I
)
_ILLEGAL_FLOOD_RE = re.compile(r"--flood", re.I)

_PRIVATE_IP_RE = re.compile(
    r"^(127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|localhost|::1)$"
)


def _has_non_private_target(text: str) -> bool:
    """nmap/masscan 目标里是否出现非私网 IP/主机。"""
    ips = re.findall(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", text)
    for ip in ips:
        if not _PRIVATE_IP_RE.match(ip):
            return True
    # 带域名目标（非 localhost）
    for tok in re.findall(r"\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b", text, re.I):
        if tok.lower() in {"nmap.org", "example.com"}:
            continue
        if not _PRIVATE_IP_RE.match(tok.lower()):
            return True
    return False


# --------------------------------------------------------------------------- #
# 各 line 的判定函数
# --------------------------------------------------------------------------- #


def _check_money(tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str) -> Verdict | None:
    if _MONEY_TOOL_RE.search(tool):
        return _ask("money", f"工具 {tool} 会发起支付/下单/充值", "会花钱")
    for host in _MONEY_HOSTS:
        if host in flat_l:
            return _ask("money", f"请求指向支付渠道 {host}", "会花钱")
    for pat in _MONEY_URL_PATTERNS:
        if pat.search(flat):
            return _ask("money", f"请求命中支付接口 {pat.pattern}", "会花钱")
    return None


def _check_delete(
    tool: str,
    tool_l: str,
    seg: str,
    seg_l: str,
    flat: str,
    flat_l: str,
    inp: dict,
    ctx: dict | None,
) -> Verdict | None:
    data_dir = _data_dir(ctx)
    # rm -r / rm -rf 目标
    if re.search(r"\brm\b\s+-[a-zA-Z]*r", seg_l) or re.search(
        r"\brm\b\s+(?:-[a-zA-Z]+\s+)*--recursive\b", seg_l
    ):
        rm_part = re.split(r"\brm\b", seg, maxsplit=1)[-1]
        args = [a for a in re.split(r"\s+", rm_part) if a and not a.startswith("-")]
        for a in args:
            an = _norm_path(a)
            if an in {"/", "~", "$HOME", "*", "..", "./..", "./*"}:
                return _ask("delete", f"递归删除 {an} 会毁掉用户数据", "会删除数据")
            if data_dir and (
                _is_inside(an, data_dir)
                or _is_inside(_expand_home(an), data_dir)
                or an == data_dir
            ):
                return _ask("delete", f"递归删除数据目录内 {an}", "会删除数据")
            # 工作区之外的绝对路径 / ~ 路径 / 上级目录：问一下（工作区和 /tmp 内照常执行）
            ws = [_norm_path(w) for w in _ctx_list(ctx, "workspaces", ())]
            if an.startswith(("/", "~", "$HOME", "..")) and not an.startswith("/tmp/"):
                full = _expand_home(an)
                if not any(_is_inside(full, w) or full == w for w in ws):
                    return _ask("delete", f"递归删除工作区之外的 {an}", "会删除数据")
    # find ... -delete
    if re.search(r"\bfind\b", seg_l) and re.search(r"(^|\s)-delete(\s|$)", seg_l):
        return _ask("delete", "find -delete 会删除文件", "会删除数据")
    if re.search(r"\bshred\b", seg_l):
        return _ask("delete", "shred 会不可恢复地销毁文件内容", "会删除数据")
    if re.search(r"\bmkfs(\.\w+)?\b", seg_l):
        return _ask("delete", "mkfs 会格式化文件系统", "会删除数据")
    if re.search(r"\bdd\b", seg_l) and re.search(r"\bof=/dev/", seg_l):
        return _ask("delete", "dd 直接写设备会销毁数据", "会删除数据")
    if re.search(r"\btruncate\b", seg_l) and re.search(r"-s\s+0\b", seg_l):
        return _ask("delete", "truncate -s 0 会清空文件", "会删除数据")
    if _DELETE_SQL_RE.search(seg):
        return _ask("delete", "SQL 语句会删除表/库或清空数据", "会删除数据")
    if _DELETE_CURL_RE.search(seg) and _DELETE_API_RE.search(seg):
        return _ask("delete", "调用 DELETE 接口会删除项目或成员", "会删除数据")
    # Write/Edit 到 data_dir
    if tool_l in {"write", "edit", "multiedit", "notebookedit"}:
        fp = _norm_path(inp.get("file_path") or inp.get("path") or "")
        if fp and data_dir:
            if _is_inside(fp, data_dir) or _is_inside(_expand_home(fp), data_dir):
                return _ask("delete", f"写入数据目录内 {fp} 会覆盖用户数据", "会删除数据")
    return None


def _check_git_force(
    tool: str,
    tool_l: str,
    seg: str,
    seg_l: str,
    flat: str,
    flat_l: str,
    inp: dict,
    ctx: dict | None,
) -> Verdict | None:
    protected = _ctx_list(ctx, "protected_branches", _PROTECTED_DEFAULT)
    protected_l = [b.lower() for b in protected]
    branch = _s(ctx.get("branch") if ctx else "").strip()

    if re.search(r"\bgh\s+repo\s+delete\b", seg_l):
        return _ask("git_force", "gh repo delete 会删除远端仓库", "会改写远端分支")
    if re.search(r"\bgh\s+api\b", seg_l) and re.search(r"-x\s+delete\b|--method\s+delete\b", seg_l):
        return _ask("git_force", "gh api -X DELETE 会删除远端资源", "会改写远端分支")

    if re.search(r"\bgit\s+push\b", seg_l):
        for flag in _GIT_FORCE_FLAGS:
            if flag.startswith("--"):
                pat = re.compile(r"(?<![\w\-])" + re.escape(flag) + r"(?![\w\-])")
            else:
                pat = re.compile(r"(?<![\w\-])" + re.escape(flag) + r"(?![\w\-])")
            if pat.search(seg):
                return _ask("git_force", f"git push {flag} 会改写远端分支历史", "会改写远端分支")
        if re.search(r"\bgit\s+push\b[^\n]*\s\+[A-Za-z0-9_\-./]+", seg):
            return _ask("git_force", "带 + 前缀的 refspec 会强制覆盖远端分支", "会改写远端分支")
        if re.search(r"\bgit\s+push\b[^\n]*\s--delete\b", seg_l) or re.search(
            r"\bgit\s+push\b[^\n]*\s:[A-Za-z0-9_\-./]+", seg
        ):
            return _ask("git_force", "git push --delete 会删除远端分支", "会改写远端分支")
        # 目标分支是否受保护
        m = re.search(r"\bgit\s+push\b(.*)$", seg, re.S)
        tail = m.group(1) if m else ""
        toks = [t for t in re.split(r"\s+", tail) if t and not t.startswith("-")]
        target = ""
        if len(toks) >= 2:
            target = toks[-1].split(":")[-1]
        elif len(toks) == 1:
            target = toks[0].split(":")[-1]
        if target and target.lower() in protected_l:
            return _ask("git_force", f"推送到受保护分支 {target}", "会改写远端分支")
        if not toks and branch and branch.lower() in protected_l:
            return _ask("git_force", f"裸 git push 会推送到受保护分支 {branch}", "会改写远端分支")
    return None


def _check_deploy(tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str) -> Verdict | None:
    words = seg_l.split()
    head = words[0] if words else ""
    head = head.split("/")[-1]

    if head == "kubectl" and re.search(r"\bkubectl\b\s+(apply|delete|rollout)\b", seg_l):
        return _ask("deploy", "kubectl 会改动线上集群", "会部署上线")
    if head == "terraform" and re.search(r"\bterraform\s+(apply|destroy)\b", seg_l):
        return _ask("deploy", "terraform 会改动云基础设施", "会部署上线")
    if head == "helm" and re.search(r"\bhelm\s+(install|upgrade)\b", seg_l):
        return _ask("deploy", "helm 会部署/升级线上服务", "会部署上线")
    if head == "fly" and re.search(r"\bfly\s+deploy\b", seg_l):
        return _ask("deploy", "fly deploy 会部署应用", "会部署上线")
    if head == "vercel" and re.search(r"\bvercel\b[^\n]*--prod\b", seg_l):
        return _ask("deploy", "vercel --prod 会发布到生产", "会部署上线")
    if head == "netlify" and re.search(r"\bnetlify\s+deploy\b[^\n]*--prod\b", seg_l):
        return _ask("deploy", "netlify deploy --prod 会发布到生产", "会部署上线")
    if head == "firebase" and re.search(r"\bfirebase\s+deploy\b", seg_l):
        return _ask("deploy", "firebase deploy 会发布到线上", "会部署上线")
    if head == "eb" and re.search(r"\beb\s+deploy\b", seg_l):
        return _ask("deploy", "eb deploy 会部署到 Elastic Beanstalk", "会部署上线")
    if head == "gcloud" and re.search(r"\bgcloud\b[^\n]*\bdeploy\b", seg_l):
        return _ask("deploy", "gcloud deploy 会部署到云", "会部署上线")
    if head == "aws" and re.search(r"\baws\b[^\n]*\bdeploy\b", seg_l):
        return _ask("deploy", "aws deploy 会部署到云", "会部署上线")
    if head == "systemctl" and re.search(r"\bsystemctl\s+(start|stop|restart|enable|disable)\b", seg_l):
        return _ask("deploy", "systemctl 会改动线上服务状态", "会部署上线")
    if head in {"ssh", "scp", "rsync"} and re.search(r"[@:]", seg):
        return _ask("deploy", f"{head} 会操作远端主机", "会部署上线")
    if head == "docker" and re.search(r"\bdocker\s+push\b", seg_l):
        return _ask("deploy", "docker push 会发布镜像", "会部署上线")
    if head == "npm" and re.search(r"\bnpm\s+publish\b", seg_l):
        return _ask("deploy", "npm publish 会发布包", "会部署上线")
    if head == "twine" and re.search(r"\btwine\s+upload\b", seg_l):
        return _ask("deploy", "twine upload 会发布 Python 包", "会部署上线")
    if head == "cargo" and re.search(r"\bcargo\s+publish\b", seg_l):
        return _ask("deploy", "cargo publish 会发布 crate", "会部署上线")
    if head == "gh" and re.search(r"\bgh\s+release\s+create\b", seg_l):
        return _ask("deploy", "gh release create 会发布 release", "会部署上线")
    return None


def _check_external(
    tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str, inp: dict
) -> Verdict | None:
    words = seg_l.split()
    head = words[0].split("/")[-1] if words else ""
    if head in _EXTERNAL_MAIL_CMDS:
        return _ask("external", f"{head} 会对外发送邮件", "会对外发消息")
    for host in _EXTERNAL_HOSTS:
        if host in flat_l:
            return _ask("external", f"请求会发往外部消息平台 {host}", "会对外发消息")
    # HTTP 方法 POST/PUT 到外部（不含 Chorus 管理接口，那属于 perms）
    if re.search(r"\b(curl|wget)\b", seg_l) and re.search(r"-X\s+(POST|PUT)\b", seg):
        if not _PERMS_CHORUS_API_RE.search(seg) and not _SKILLS_API_INSTALL_RE.search(seg):
            return _ask("external", "HTTP POST/PUT 会向外部发送数据", "会对外发消息")
    # 工具名
    if _EXTERNAL_TOOL_RE.search(tool) and not _READLIKE_TOOL_RE.match(tool_l):
        return _ask("external", f"工具 {tool} 会对外发送内容", "会对外发消息")
    return None


def _secret_path_hit(path: str, ctx: dict | None) -> bool:
    p = _norm_path(path)
    if not p:
        return False
    pl = p.lower()
    for pat in _SECRET_PATH_PATTERNS:
        if pat.search(pl):
            return True
    data_dir = _data_dir(ctx)
    if data_dir and (_is_inside(p, data_dir) or _is_inside(_expand_home(p), data_dir)):
        if pl.endswith("config.json"):
            return True
    for sp in _ctx_list(ctx, "secret_paths"):
        spn = _norm_path(sp)
        if spn and (p == spn or _is_inside(p, spn)):
            return True
    return False


def _check_secrets(
    tool: str,
    tool_l: str,
    seg: str,
    seg_l: str,
    flat: str,
    flat_l: str,
    inp: dict,
    ctx: dict | None,
) -> Verdict | None:
    words = seg_l.split()
    head = words[0].split("/")[-1] if words else ""

    if head in {"env", "printenv"}:
        return _ask("secrets", f"{head} 会打印环境变量，可能包含密钥", "会读取密钥")
    if head == "set" and len(words) == 1:
        return _ask("secrets", "set 会打印所有 shell 变量", "会读取密钥")
    if re.search(r"/proc/[^\s]*/environ", seg):
        return _ask("secrets", "读取 /proc/*/environ 会暴露进程环境变量", "会读取密钥")
    if _SECRET_ENV_RE.search(seg):
        return _ask("secrets", "引用了疑似密钥环境变量", "会读取密钥")

    # 路径检查
    candidates: list[str] = []
    for key in ("file_path", "path", "notebook_path"):
        v = inp.get(key)
        if v:
            candidates.append(_s(v))
    for m in re.finditer(r"(?:^|[\s=:@])((?:~|\.{0,2}/)?[A-Za-z0-9_\-./]*[A-Za-z0-9_\-./])", seg):
        candidates.append(m.group(1))
    for c in candidates:
        if _secret_path_hit(c, ctx):
            return _ask("secrets", f"访问 {scrub(c)} 可能读取到密钥", "会读取密钥")

    # 上传密钥文件
    if re.search(r"\b(curl|wget)\b", seg_l):
        for m in _SECRET_UPLOAD_RE.finditer(seg):
            frag = m.group(0)
            fname = frag[1:] if frag.startswith("@") else frag
            if _secret_path_hit(fname, ctx):
                return _ask("secrets", f"上传 {scrub(fname)} 会外泄密钥", "会读取密钥")
    return None


def _check_perms(tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str) -> Verdict | None:
    words = seg_l.split()
    head = words[0].split("/")[-1] if words else ""

    if head == "chmod" and _CHMOD_BAD_RE.search(seg):
        return _ask("perms", "chmod 会放宽权限或设置 setuid", "会改权限")
    if head in _PERMS_CMDS:
        return _ask("perms", f"{head} 会修改权限/账号/凭据", "会改权限")
    if re.search(r"(^|[\s;&|(`])sudo(\s|$)", seg_l):
        return _ask("perms", "sudo 会以 root 权限执行命令", "会改权限")
    if _PERMS_SUDOERS_RE.search(seg):
        return _ask("perms", "修改 /etc/sudoers 会改变提权规则", "会改权限")
    if _PERMS_CRONTAB_RE.search(seg):
        return _ask("perms", "crontab -e/-r 会改动定时任务", "会改权限")
    if _PERMS_GITCRED_RE.search(seg):
        return _ask("perms", "git config --global credential 会改全局凭据", "会改权限")
    if _PERMS_GHAUTH_RE.search(seg):
        return _ask("perms", "gh auth 会改动 GitHub 登录凭据", "会改权限")
    if _PERMS_CHORUS_API_RE.search(seg):
        return _ask("perms", "写入 Chorus 管理接口会改动成员/配置/钱包", "会改权限")
    return None


def _check_skills(tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str) -> Verdict | None:
    if _SKILLS_PIPE_RE.search(seg):
        return _ask("skills", "下载并直接执行远程脚本", "会安装外来代码")
    if _SKILLS_PIP_URL_RE.search(seg):
        return _ask("skills", "从 URL/git 安装 Python 包", "会安装外来代码")
    if _SKILLS_NPM_GLOBAL_RE.search(seg):
        return _ask("skills", "全局安装 npm 包", "会安装外来代码")
    if _SKILLS_NPX_RE.search(seg):
        m = _SKILLS_NPX_RE.search(seg)
        pkg = m.group(1) if m else ""
        if pkg and pkg not in {"--help", "-v", "--version"}:
            return _ask("skills", f"npx {pkg} 会执行外来代码", "会安装外来代码")
    if _SKILLS_GO_INSTALL_RE.search(seg):
        return _ask("skills", "go install 会安装外来二进制", "会安装外来代码")
    if _SKILLS_CARGO_INSTALL_RE.search(seg):
        return _ask("skills", "cargo install 会安装外来 crate", "会安装外来代码")
    if _SKILLS_API_INSTALL_RE.search(seg):
        return _ask("skills", "调用 /api/skills/install 会安装技能包", "会安装外来代码")
    # 下载 + chmod +x 同一命令
    if _SKILLS_DL_RE.search(seg) and re.search(r"\bchmod\b[^\n]*\+x", seg):
        return _ask("skills", "下载文件并赋予可执行权限", "会安装外来代码")
    return None


def _check_illegal(tool: str, tool_l: str, seg: str, seg_l: str, flat: str, flat_l: str) -> Verdict | None:
    if _ILLEGAL_CSAM_RE.search(flat):
        return _deny("illegal", "涉及儿童性虐待材料，绝对禁止", "违法")
    if _ILLEGAL_MALWARE_RE.search(flat):
        return _deny("illegal", "制作勒索软件/键盘记录器属于违法", "违法")
    if _ILLEGAL_PIRACY_RE.search(flat):
        return _deny("illegal", "访问盗版资源站点属于侵权", "违法")
    if _ILLEGAL_STUFFING_RE.search(flat):
        return _deny("illegal", "撞库/密码喷洒属于攻击行为", "违法")
    m = _ILLEGAL_SCAN_RE.search(seg)
    if m:
        name = m.group(1).lower()
        if name in {"nmap", "masscan"}:
            if _has_non_private_target(seg):
                return _deny("illegal", f"{name} 扫描非私网目标属于网络攻击", "违法")
        elif name == "hping3":
            if _ILLEGAL_FLOOD_RE.search(seg):
                return _deny("illegal", "hping3 --flood 属于拒绝服务攻击", "违法")
        else:
            return _deny("illegal", f"{name} 属于攻击工具", "违法")
    return None


# --------------------------------------------------------------------------- #
# check()
# --------------------------------------------------------------------------- #


def check(tool: str, inp: dict | None = None, ctx: dict | None = None) -> Verdict:
    """判定一次工具调用。deny > ask > allow，取最严重的。"""
    tool_s = _s(tool)
    tool_l = tool_s.lower()
    inp = inp or {}
    flat = _flatten_inp(inp)
    flat_l = flat.lower()

    # 命令来源
    cmd = _s(inp.get("command") or inp.get("cmd") or "")
    if not cmd:
        for k in ("script", "bash", "shell"):
            if inp.get(k):
                cmd = _s(inp.get(k))
                break

    segs = _segments(cmd) if cmd else []
    if not segs and cmd:
        segs = [cmd]
    if not segs:
        segs = [""]  # 保证工具名检查仍然执行
    elif cmd not in segs:
        # 跨片段的模式（curl … | sh、下载 && chmod +x、sudo 前缀）要看整条命令
        segs = segs + [cmd]

    best = _ALLOW

    def merge(v: Verdict | None) -> None:
        nonlocal best
        if v is None:
            return
        if _SEVERITY[v.action] > _SEVERITY[best.action]:
            best = v

    for seg in segs:
        seg_l = seg.lower()
        merge(_check_illegal(tool_s, tool_l, seg, seg_l, flat, flat_l))
        merge(_check_money(tool_s, tool_l, seg, seg_l, flat, flat_l))
        merge(_check_delete(tool_s, tool_l, seg, seg_l, flat, flat_l, inp, ctx))
        merge(_check_git_force(tool_s, tool_l, seg, seg_l, flat, flat_l, inp, ctx))
        merge(_check_deploy(tool_s, tool_l, seg, seg_l, flat, flat_l))
        merge(_check_perms(tool_s, tool_l, seg, seg_l, flat, flat_l))
        merge(_check_secrets(tool_s, tool_l, seg, seg_l, flat, flat_l, inp, ctx))
        merge(_check_skills(tool_s, tool_l, seg, seg_l, flat, flat_l))
        merge(_check_external(tool_s, tool_l, seg, seg_l, flat, flat_l, inp))

    # 工具名级别检查（无命令时也生效）
    if best.action == "allow":
        merge(_check_money(tool_s, tool_l, "", "", flat, flat_l))
        merge(_check_external(tool_s, tool_l, "", "", flat, flat_l, inp))

    return best


# --------------------------------------------------------------------------- #
# check_spend()
# --------------------------------------------------------------------------- #


def check_spend(project_spent: float, cap: float, next_cost_est: float) -> Verdict:
    """预算检查：spent + next > cap → ask；cap <= 0 表示无上限。"""
    try:
        spent = float(project_spent)
    except (TypeError, ValueError):
        spent = 0.0
    try:
        c = float(cap)
    except (TypeError, ValueError):
        c = 0.0
    try:
        nxt = float(next_cost_est)
    except (TypeError, ValueError):
        nxt = 0.0

    if c <= 0:
        return _ALLOW
    if spent + nxt > c:
        return _ask(
            "budget",
            f"本次预计花费 {nxt:g}，累计 {spent + nxt:g} 将超出预算上限 {c:g}",
            "超出预算",
        )
    return _ALLOW


# --------------------------------------------------------------------------- #
# card()
# --------------------------------------------------------------------------- #


def _summarize_what(tool: str, inp: dict) -> str:
    """生成一行摘要（已脱敏，≤200 字符）。"""
    parts: list[str] = []
    cmd = _s(inp.get("command") or inp.get("cmd") or "")
    if cmd:
        parts.append(cmd)
    else:
        for key in ("file_path", "path", "url", "notebook_path", "content"):
            v = inp.get(key)
            if v:
                parts.append(f"{key}={_s(v)}")
    if not parts:
        for k, v in list(inp.items())[:3]:
            parts.append(f"{k}={_s(v)}")
    text = " ".join(parts)
    text = " ".join(text.split())  # 压成一行
    text = scrub(text)
    if len(text) > 200:
        text = text[:199] + "…"
    return text


def card(tool: str, inp: dict, v: Verdict, cost_est: str = "") -> dict:
    """生成同意卡片内容。"""
    inp = inp or {}
    what = _summarize_what(tool, inp)
    title = LINES.get(v.line, "需要确认") if v.line else "需要确认"
    return {
        "line": v.line,
        "title": title,
        "what": what,
        "why": v.why,
        "impact": v.impact,
        "cost": _s(cost_est),
        "expires_in": 600,
    }
