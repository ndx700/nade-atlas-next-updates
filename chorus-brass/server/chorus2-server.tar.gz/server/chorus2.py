"""chorus2 glue: wires the deterministic engines (orchestra, quota_probes, redline, recovery, autopilot, wakegraph,
capabilities, nocturne) into the running server. Everything here is server-side and costs no tokens except the
explicit model calls of the 协奏 engine (plan by 指挥, execute by 声部, review by 指挥)."""
import asyncio
import contextvars
import json
import logging
import re
import secrets
import sys
import time
from asyncio import sleep

import api_errors as errors

from aiohttp import ClientSession, ClientTimeout, web

import autopilot
import capabilities
import cli_quota
import designopts
import nocturne
import orchestra
import quota_probes
import recovery
import redline
import wakegraph

S = None  # the server module
GRAPH = wakegraph.Graph()
HISTORY = {}   # pid -> [(ts, pct)]
LAST_HEADERS = {}  # member -> headers of its last API reply
LAST_ERROR = {}    # member -> {"status","body","at"}
INVITES = {}       # code -> {"expires", "name"}
RUNNING = {}       # pid -> asyncio.Task of the 协奏 loop
PLANNING = {}      # pid -> server-owned task, shielded from request cancellation
LOW_CALLS = {}     # member -> monotonic request timestamps
LOW_BACKOFF = {}   # member -> monotonic retry time
STATE_AT = {}  # member -> when MEMBER_STATE was set; broken/resting expire after CFG["recover_after"] seconds
MEMBER_STATE = {}  # member -> "resting" | "cooldown" | "broken" (set by the failure engine, cleared on success)
STATE_REASON = {}  # member -> plain-Chinese reason for its availability state
LEAD_BUSY = {}  # pid -> count of 指挥 calls in flight (hand-back waits for 0)
CONSENT = {}       # approval id -> {"line", "pid", "who"}
POLICY_CHOICES = ("ask", "auto", "deny")


ROLE = contextvars.ContextVar("chorus_role", default="chat")  # plan | execute | review | chat


# ---------------------------------------------------------------- helpers
def members():
    return S.CFG.get("members", [])


def proj(pid):
    p = S.project(pid)
    if not p:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    p.setdefault("mode", "concerto")
    p.setdefault("segments", [])
    return p


def save_projects():
    S.save(S.DATA / "projects.json", S.PROJECTS)


def price_of(m):
    return S.price(m, m.get("model", "")) if m else None


def stats():
    return S.CFG.setdefault("member_stats", {})


def view(pid):
    p = S.project(pid)
    if not p:
        return None
    p.setdefault("segments", [])
    ms = {}
    for st in GRAPH.steps(pid).items():
        name, v = st
        seg = next((x for x in p["segments"] if x.get("id") == v.get("seg")), None)
        ms[name] = {"stage": v.get("step", ""), "segment": v.get("seg", ""), "pct": orchestra.segment_pct(seg) if seg else 0}
    snap = orchestra.snapshot(p, ms, HISTORY.get(pid, []))
    snap["pending"] = [d for d in p.get("pending", []) if d.get("state", "open") == "open"]
    snap["flow"] = GRAPH.flow(pid, 30)
    snap["cost_split"] = p.get("cost_split", {})
    snap["planning"] = p.get("planning", "idle")
    for sv, seg in zip(snap["segments"], p["segments"]):
        sv.update(goal=seg.get("goal", ""), deliverable=seg.get("deliverable", ""), acceptance=seg.get("acceptance", []),
                  inputs=seg.get("inputs", []), events=[[e.get("at"), e.get("text")] for e in (seg.get("events") or [])[-20:]])
    return snap


def _thread(mid, title, segs, live, paused=False):
    done = sum(1 for x in segs if x.get("stage") == "done")
    outs = [a for x in segs for a in (x.get("artifacts") or [])]
    pending = sum(1 for x in segs if x.get("stage") == "blocked")
    if segs and done == len(segs):
        state = "resolved"
    elif live and not paused and any(x.get("stage") in ("running", "waiting", "review", "rework") for x in segs):
        state = "active"
    else:
        state = "idle"
    return {"id": mid, "title": title, "state": state, "tasks_done": done, "tasks": len(segs), "outputs": len(outs),
            "pending": pending, "pct": round(100 * sum(orchestra.segment_pct(x) for x in segs) / len(segs), 1) if segs else 0,
            "items": [{"id": x["id"], "title": x.get("title", ""), "stage": x.get("stage", ""), "assignee": x.get("assignee", ""),
                       "pct": orchestra.segment_pct(x), "artifacts": x.get("artifacts") or []} for x in segs]}


def overview(pid):
    """讨论串 (乐章 grouped 进行中/空闲/已解决), 资料库 (every artifact), PR (links found in artifacts/results)."""
    p = S.project(pid)
    if not p:
        return None
    threads = [_thread(m["id"], m.get("title", ""), m.get("segments", []), False) for m in p.get("movements", [])]
    if p.get("segments"):
        threads.append(_thread(p.get("movement_id", "m1"), p.get("movement_title") or (p.get("brief") or "")[:24], p["segments"], True, p.get("paused")))
    lib = [{"path": a, "thread": t["id"], "task": it["id"], "by": it["assignee"]} for t in threads for it in t["items"] for a in it["artifacts"]]
    prs = [x for x in lib if re.search(r"github\.com/[^/]+/[^/]+/pull/\d+", x["path"])]
    groups = {k: [t for t in threads if t["state"] == k] for k in ("active", "idle", "resolved")}
    return {"threads": groups, "library": [x for x in lib if x not in prs], "prs": prs}


async def h_overview(request):
    v = overview(request.match_info["pid"])
    if v is None:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    return web.json_response(v)


def reply_to(pid, who, trig):
    """The member's reply to this exact trigger: prefer the server's reply_to link, else the first reply after it."""
    msgs = S.CHATS.get(pid, [])
    mine = [x for x in msgs if x.get("who") == who and x.get("seq", 0) > trig.get("seq", 0)]
    linked = [x for x in mine if x.get("reply_to") == trig.get("seq")]
    return (linked or mine[:1] or [None])[0]


def touch(pid):
    p = S.project(pid)
    if p:
        h = HISTORY.setdefault(pid, [])
        h.append((time.time(), orchestra.project_pct(p)))
        del h[:-200]
    S.bump(pid)


def event(seg, text):
    ev = seg.setdefault("events", [])
    ev.append({"at": time.time(), "kind": "log", "text": text})
    del ev[:-50]


# ---------------------------------------------------------------- quota (all members, every access type)
def ctx_for(session):
    def spent_tokens(name):
        sp = S.load(S.spend_file(), {}).get(name, {})
        return sum(d.get("in", 0) + d.get("out", 0) for d in sp.values())
    def spent_money(pid, cur):
        return S.spent_total(pid, cur)
    def read_file(path):
        import pathlib
        try:
            return pathlib.Path(path).expanduser().read_text(errors="replace")
        except OSError:
            return None
    c = quota_probes.Ctx(session, spent_tokens=spent_tokens, spent_money=spent_money,
                         last_headers=lambda n: LAST_HEADERS.get(n), last_error=lambda n: LAST_ERROR.get(n),
                         read_file=read_file)
    c.cmd_json = cli_quota.cached
    c.acp_limits = lambda n: __import__("adapters").LIMITS.get(n)   # Codex rate limits seen over ACP  # subscription windows read through each vendor's own CLI
    return c


QUOTA2 = {}


async def refresh_one(m):
    """Re-probe one member now (a connector just reported its CLI limits)."""
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        QUOTA2[m["name"]] = await quota_probes.probe(S.provider(m.get("provider")) or {}, m, ctx_for(s))
    S.bump()


async def refresh_all():
    import connect
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        ctx = ctx_for(s)
        for m in list(members()):
            if m.get("kind") == "cli" and not m.get("remote") and cli_quota.which(m) in ("claude", "gemini", "agy"):
                try:
                    await cli_quota.refresh(m)
                except Exception as e:  # noqa: BLE001 - a CLI that fails to report leaves 未知, never blocks others
                    print("cli quota", m.get("name"), type(e).__name__)
            pr = S.provider(m.get("provider")) or {}
            try:
                q = await quota_probes.probe(pr, m, ctx)
                QUOTA2[m["name"]] = q
                if q and q.get("state") not in ("arrears", "unknown") and MEMBER_STATE.get(m["name"]) == "resting":
                    MEMBER_STATE.pop(m["name"], None)  # balance is back
            except Exception as e:  # noqa: BLE001 - one provider must never hide the others
                print("probe", m.get("name"), type(e).__name__)
            connect.remote_status(m["name"])
    S.bump()
    retry_unavailable()


def note_reply(name, status=None, headers=None, body=""):
    """Called after every model call: headers feed the quota chain; error codes mark 欠费 at once."""
    if headers:
        LAST_HEADERS[name] = dict(headers)
    if status and status >= 400:
        LAST_ERROR[name] = {"status": status, "body": body[:400], "at": time.time()}
        q = quota_probes.from_error(status, body)
        if q:
            QUOTA2[name] = q
            S.bump()


async def h_quota_all(request):
    if request.method == "POST" or not QUOTA2:
        await refresh_all()
    import connect
    quotas = connect.quota_view(QUOTA2, (m["name"] for m in members()))
    return web.json_response({"members": quotas, "at": time.time()})


async def quota_loop():
    while True:
        try:
            await refresh_all()
        except Exception as e:  # noqa: BLE001
            print("quota2", type(e).__name__)
        await asyncio.sleep(S.CFG.get("quota_every", 300))


# ---------------------------------------------------------------- red lines + per-member policy
def policy_of(name):
    m = S.member(name) or {}
    return m.get("policy") or {}


def workspaces(pid, who):
    """Folders a member may freely change: its 乐章 work dir and the project's own folder."""
    out = [str(S.DATA / "work")]
    p = S.project(pid) if pid else None
    if p and p.get("folder"):
        out.append(p["folder"])
    m = S.member(who) or {}
    if m.get("cwd"):
        out.append(m["cwd"])
    return out


def gate(tool, inp, who, pid=""):
    """allow / ask / deny for one tool call, per red line and the member's own policy.
    illegal is always deny; a red line is ask unless the member's policy says auto (logged) or deny."""
    v = redline.check(tool, inp or {}, {"data_dir": str(S.DATA), "workspaces": workspaces(pid, who)})
    if v.action == "deny":
        return "deny", v
    if v.action == "ask" and v.line in ((S.project(pid) or {}).get("grants") or {}).get(who, []):
        log(pid, who, f"按本乐章授权同意（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}")
        return "allow", v
    if v.action == "ask" and night_covers(pid, v.line):
        log(pid, who, f"夜间代批（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}", night=True)
        return "allow", v
    if v.action == "ask":
        choice = policy_of(who).get(v.line, "ask")
        if choice == "auto":
            log(pid, who, f"自动同意（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}")
            return "allow", v
        return ("deny" if choice == "deny" else "ask"), v
    return "allow", v


def grant(pid, who, line):
    """'Always allow this category for this member within this 乐章' — never the illegal bottom line."""
    p = S.project(pid)
    if not p or line == "illegal" or line not in redline.LINES:
        return False
    g = p.setdefault("grants", {}).setdefault(who, [])
    if line not in g:
        g.append(line)
    log(pid, "你", f"本乐章里 {who} 的「{redline.LINES[line]}」以后都同意")
    save_projects()
    return True


def log(pid, who, text, night=False):
    if pid:
        S.CFG.setdefault("audit", []).append({"at": time.time(), "pid": pid, "who": who, "text": text, **({"night": True} if night else {})})
        del S.CFG["audit"][:-2000]


# ---------------------------------------------------------------- 夜曲 night grant (user-confirmed scope)
def local_hour(now=None):
    return time.gmtime((now or time.time()) + S.CFG.get("tz", 8) * 3600).tm_hour


def night_covers(pid, line, now=None):
    """True when 夜曲 is on for this 乐章 with a confirmed grant, we are inside its window, the line is granted,
    and (for money) the night spend cap still has room. The illegal bottom line is never covered."""
    if not pid or line == "illegal":
        return False
    p = S.project(pid) or {}
    g = p.get("night") or {}
    if not (g.get("enabled") and g.get("confirmed_at")) or line not in g.get("lines", []):
        return False
    start, end = g.get("window", [23, 7])
    h = local_hour(now)
    inside = (start <= h < end) if start < end else (h >= start or h < end)
    if not inside:
        return False
    if line == "money" and g.get("spent", 0) >= g.get("spend_cap", 0):
        return False
    return True


def night_text(g):
    names = "、".join(redline.LINES.get(x, x) for x in g.get("lines", [])) or "（无）"
    w = g.get("window", [23, 7])
    return (f"开启夜曲后，每天 {w[0]:02d}:00–{w[1]:02d}:00 我会替你同意以下类别：{names}；"
            f"夜间花费上限 ¥{float(g.get('spend_cap') or 0):g}。违法和底线动作仍然一律拦下。"
            f"所有代批都记进场记，并写进早上的序曲。")


async def h_night(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    g = p.setdefault("night", {"enabled": False, "lines": [], "spend_cap": 0, "window": [23, 7]})
    if request.method == "PUT":
        b = await errors.json_object(request)
        lines = [x for x in (b.get("lines") or []) if x in redline.LINES and x != "illegal"]
        win = b.get("window", g["window"])
        if not (isinstance(win, list) and len(win) == 2 and all(isinstance(x, int) and 0 <= x < 24 for x in win)):
            return web.json_response({"error": "时间窗不对", "fix": "settings"}, status=400)
        new = {"lines": lines, "spend_cap": max(0.0, float(b.get("spend_cap") or 0)), "window": win}
        if b.get("enabled"):
            if b.get("confirm") != night_text(new):  # the client must echo the exact text the user saw and confirmed
                return web.json_response({"error": "需要先确认", "fix": "none", "confirm": night_text(new)}, status=409)
            keep = float(g.get("spent") or 0) if g.get("enabled") and time.time() - (g.get("confirmed_at") or 0) < 86400 else 0.0
            g.update(new, enabled=True, confirmed_at=time.time(), spent=keep)
            log(pid, "你", "开启夜曲代批：" + night_text(new))
        else:
            g.update(new, enabled=False, confirmed_at=None)
        save_projects()
        touch(pid)
    return web.json_response({**g, "confirm": night_text(g), "lines_all": {k: v for k, v in redline.LINES.items() if k != "illegal"}})


def night_report(pid, since):
    """For the morning 序曲: every auto-approval made overnight."""
    return [a for a in S.CFG.get("audit", []) if a.get("pid") == pid and a.get("night") and a["at"] >= since]


async def h_overture(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    since = float(request.query.get("since") or time.time() - 12 * 3600)
    done = [{"title": x.get("title"), "summary": x.get("summary", ""), "by": x.get("assignee")} for x in p["segments"]
            if x.get("stage") == "done" and (x.get("done_at") or 0) >= since]
    pend = [d for d in p.get("pending", []) if d.get("state", "open") == "open"]
    approvals = night_report(pid, since)
    recs = [{"member": a["who"], "ok": True} for a in approvals]
    o = nocturne.Overture.build(recs, pend, done, {"total": orchestra.budget_state(p)["spent"]}, time.strftime("%m-%d"))
    o["night_approvals"] = [{"at": a["at"], "who": a["who"], "text": a["text"]} for a in approvals]
    return web.json_response(o)


async def h_policy(request):
    name = request.match_info["name"]
    m = S.member(name)
    if not m:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if request.method == "PUT":
        b = await errors.json_object(request)
        pol = m.setdefault("policy", {})
        if b.get("preset") == "all":   # 全部同意（底线除外）
            for line in redline.LINES:
                if line != "illegal":
                    pol[line] = "auto"
            S.CFG.setdefault("audit", []).append({"at": time.time(), "pid": "", "who": "你", "text": f"{name}：全部同意（底线除外）"})
        for line, choice in (b.get("policy") or {}).items():
            if line == "illegal":
                continue  # the bottom line is never configurable
            if line in redline.LINES and choice in POLICY_CHOICES:
                pol[line] = choice
        if "spend_auto" in b:
            v = float(b["spend_auto"] or 0)
            if v < 0:
                return web.json_response({"error": "金额不能是负数", "fix": "settings"}, status=400)
            m["spend_auto"] = v
        S.save_cfg()
        S.bump()
    return web.json_response({"policy": {k: (m.get("policy") or {}).get(k, "ask") for k in redline.LINES if k != "illegal"},
                              "lines": redline.LINES, "spend_auto": m.get("spend_auto", 0)})


async def h_audit(request):
    pid = request.match_info["pid"]
    return web.json_response({"items": [a for a in S.CFG.get("audit", []) if a.get("pid") == pid][-300:]})


# ---------------------------------------------------------------- CLI wrapper
_BYPASS = [
    (r"\s--dangerously-skip-permissions(?:=\S*)?(?=\s|$)", ""),
    (r"\s--dangerously-bypass-approvals-and-sandbox(?:=\S*)?(?=\s|$)", ""),
    (r"\s--yolo(?:=\S*)?(?=\s|$)", ""),
    (r"\s--permission-mode[ =](?:bypassPermissions|acceptEdits)\b", ""),
    (r"\s(?:-a|--ask-for-approval)[ =]never\b", " -a on-request"),
    (r"\s--full-auto(?:=\S*)?(?=\s|$)", ""),
    (r"\s-c\s+approval_policy=\S+", ""),
]


def cli_guard(cmd):
    """CLI members must route every tool request to /approve/ask (red lines + their own permission settings).
    Flags that would let a CLI approve itself are removed; what the member may auto-approve lives in its policy."""
    import re
    out = " " + cmd
    hits = []
    for pat, rep in _BYPASS:
        out, n = re.subn(pat, rep, out)
        if n:
            hits.append(pat)
    return out[1:], bool(hits)


# ---------------------------------------------------------------- invites (一次性邀请码，10 分钟)
async def h_invite(request):
    now = time.time()
    for k in [k for k, v in INVITES.items() if v["expires"] < now]:
        INVITES.pop(k, None)
    if len(INVITES) >= 20:
        return web.json_response({"error": "未用的邀请码太多了，等几分钟再发", "fix": "retry"}, status=429)
    code = "".join(secrets.choice("23456789ABCDEFGHJKMNPQRSTUVWXYZ") for _ in range(6))
    INVITES[code] = {"expires": time.time() + 600}
    base = request.headers.get("X-Forwarded-Prefix", "")
    url = f"{request.scheme}://{request.host}{base}/api/invite/redeem"
    return web.json_response({"code": code, "expires_in": 600, "http": url,
                              "cmd": f"curl -s -X POST {url} -H 'Content-Type: application/json' -d '{{\"code\":\"{code}\",\"name\":\"你的名字\",\"kind\":\"cli\",\"cmd\":\"claude -p\"}}'",
                              "mcp": {"server": url, "code": code}})


async def h_redeem(request):
    b = await errors.json_object(request)
    inv = INVITES.pop(str(b.get("code", "")).upper(), None)
    if not inv or inv["expires"] < time.time():
        return web.json_response({"error": "邀请码无效或已过期", "fix": "retry"}, status=403)
    name = (b.get("name") or "").strip()[:24]
    import re
    if not re.fullmatch(r"[\w\u4e00-\u9fff .·-]{1,24}", name or ""):
        return web.json_response({"error": "名字只能用文字、数字、空格和 .·-", "fix": "none"}, status=400)
    if not name or S.member(name):
        return web.json_response({"error": "名字为空或已被占用", "fix": "none"}, status=409)
    m = {"name": name, "kind": b.get("kind", "api") if b.get("kind") in ("api", "cli", "dsh") else "api", "auto": True}
    for k in ("cmd", "model", "provider"):
        if b.get(k):
            m[k] = str(b[k])[:400]
    if m.get("cmd"):
        m["cmd"], _ = cli_guard(m["cmd"])
    S.CFG["members"].append(m)
    S.save_cfg()
    S.bump()
    retry_unavailable()
    return web.json_response({"ok": True, "member": name})


# ---------------------------------------------------------------- 最近删除
async def h_trash(request):
    if request.method == "GET":
        return web.json_response({"items": [{"id": p["id"], "name": p["name"], "deleted": p.get("deleted_at", 0)}
                                            for p in S.PROJECTS if p.get("archived")]})
    pid = request.match_info["pid"]
    p = S.project(pid)
    if not p or not p.get("archived"):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if request.method == "POST":
        p.pop("archived", None)
        p.pop("deleted_at", None)
    else:  # DELETE: gone for good, only by the user from 最近删除
        S.PROJECTS.remove(p)
        HISTORY.pop(pid, None)
        t = RUNNING.pop(pid, None)
        if t:
            t.cancel()
    save_projects()
    S.bump()
    return web.json_response({"ok": True, "index": S.index_view()})


# ---------------------------------------------------------------- 协奏 engine
async def ask_model(m, system, prompt, pid=None):
    why = account_block()
    if why:
        raise RuntimeError(why)
    reserve_low(m)
    r = {"who": m["name"], "text": "", "note": ""}
    await S.call_api(None, m, r, system, prompt, m.get("model", ""), "")
    if r.get("usage"):
        S.record_usage(m, m.get("model", ""), r["usage"], pid)  # direct 指挥 calls are billed like any reply
    return r["text"]


# ---------------------------------------------------------------- spend: role split + account caps
def on_usage(m, u, pid):
    cost = float(u.get("cost") or 0)
    cur = u.get("cur", "¥")
    name = m.get("name", "") if isinstance(m, dict) else str(m or "")
    if name:   # per-member metrics (calls, tokens, spend by currency, role mix)
        mt = stats().setdefault(name, {})
        mt["calls"] = mt.get("calls", 0) + 1
        mt["in"] = mt.get("in", 0) + int(u.get("in", 0) or 0)
        mt["out"] = mt.get("out", 0) + int(u.get("out", 0) or 0)
        if cost:
            mt.setdefault("cost", {})[cur] = round(mt.get("cost", {}).get(cur, 0) + cost, 5)
        mt.setdefault("roles", {})[ROLE.get()] = mt.get("roles", {}).get(ROLE.get(), 0) + 1
        mt["last"] = time.time()
    if cost:  # persisted per-minute buckets: caps survive restarts and never lose old entries
        bk = S.CFG.setdefault("spend_buckets", {})
        mk = str(int(time.time() // 60))
        bk.setdefault(mk, {})
        bk[mk][cur] = round(bk[mk].get(cur, 0) + cost, 6)
        if len(bk) > 1600:
            for k in sorted(bk, key=int)[:len(bk) - 1500]:
                bk.pop(k)
    p = S.project(pid) if pid else None
    if p is not None:
        warnings = {"pricing_missing": u.get("pricing_warning")}
        budget_cur = (p.get("budget") or {}).get("cur", "¥")
        if cost and cur != budget_cur:
            warnings["currency_mismatch"] = f"此 API 声部按 {cur} 计费，与项目预算币种 {budget_cur} 不同；请统一币种后使用预算上限，当前费用仅记入对应币种账本。"
        for kind, warning in warnings.items():
            if warning and not any(d.get("kind") == kind and d.get("member") == name and d.get("state") == "open" for d in p.get("pending", [])):
                p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": kind, "member": name,
                    "question": warning, "options": [], "recommended": -1, "deadline": None, "state": "open"})
        g = p.get("night") or {}
        if cost and g.get("enabled") and night_covers(pid, "money"):
            g["spent"] = round(float(g.get("spent") or 0) + cost, 5)  # night spend counts against the grant's cap
        role = ROLE.get()
        row = p.setdefault("cost_split", {}).setdefault(role, {"in": 0, "out": 0, "cost": {}})
        row["in"] += u.get("in", 0)
        row["out"] += u.get("out", 0)
        if cost:
            row["cost"][cur] = round(row["cost"].get(cur, 0) + cost, 5)


def account_spent(window, cur="¥", now=None):
    """Spend in the last window seconds (1-minute resolution), from persisted buckets."""
    now = now or time.time()
    lo, hi = int((now - window) // 60), int(now // 60)
    return sum(v.get(cur, 0) for k, v in (S.CFG.get("spend_buckets") or {}).items() if lo < int(k) <= hi)


def account_block(now=None):
    """'' when under the account caps, else the reason. Caps: CFG.account_caps = {hour, day, cur}; 0 = no cap."""
    caps = S.CFG.get("account_caps") or {}
    cur = caps.get("cur", "¥")
    for key, window, label in (("hour", 3600, "每小时"), ("day", 86400, "每天")):
        cap = float(caps.get(key) or 0)
        if cap > 0 and account_spent(window, cur, now) >= cap:
            return f"账号{label}花费已到上限 {cur}{cap:g}"
    return ""


async def h_caps_account(request):
    if request.method == "PUT":
        b = await errors.json_object(request)
        caps = S.CFG.setdefault("account_caps", {})
        for k in ("hour", "day"):
            if k in b:
                v = float(b[k] or 0)
                if v < 0:
                    return web.json_response({"error": "上限不能是负数", "fix": "settings"}, status=400)
                caps[k] = v
        if b.get("cur"):
            caps["cur"] = str(b["cur"])[:3]
        S.save_cfg()
        S.bump()
    caps = S.CFG.get("account_caps") or {}
    cur = caps.get("cur", "¥")
    return web.json_response({**caps, "spent_hour": round(account_spent(3600, cur), 4), "spent_day": round(account_spent(86400, cur), 4),
                              "blocked": account_block()})


def guard_run_member(orig):
    """Every wake (user @, AI @, 协奏 dispatch, 节拍器) passes the account cap first."""
    async def run(pid, name, trigger, opts):
        why = account_block()
        if why:
            S.add_msg(pid, "系统", f"没有叫醒 {name}：{why}，调高上限或等下一个时段", folded=True)
            log(pid, "调度", f"拦下唤醒 {name}：{why}")
            return None
        mem = next((m for m in members() if m.get("name") == name), {})
        import collab_api
        blocked = collab_api.consent_block(mem)
        if blocked:
            S.add_msg(pid, "系统", f"{name} 第一次使用这把 key，需要你在「定音」里手动允许一次，才会叫醒它" if blocked == "pending" else f"{name} 的模型被你拒绝了，没有叫醒它", folded=True)
            log(pid, "定音", f"拦下唤醒 {name}：{blocked}")
            return None
        reserve_low(mem)
        return await orig(pid, name, trigger, opts)
    run.guarded = True
    return run


def mark(name, state, reason=""):
    MEMBER_STATE[name] = state
    STATE_AT[name] = time.time()
    if reason:
        STATE_REASON[name] = reason
    else:
        STATE_REASON.pop(name, None)


def healthy(name):
    """Quota not in arrears, and not inside a broken/resting window (which expires so members can recover)."""
    import connect
    if connect.remote_status(name):
        return False
    if (QUOTA2.get(name) or {}).get("state") == "arrears":
        return False
    st = MEMBER_STATE.get(name)
    if st in ("broken", "resting", "cooldown"):
        if time.time() - STATE_AT.get(name, 0) < S.CFG.get("recover_after", 900):
            return False
        MEMBER_STATE.pop(name, None)
    return True


def lead_ok(name):
    return bool(S.member(name)) and healthy(name)


def handover_context(p):
    """What the next 指挥 needs: the plan, where every 段落 stands, and the last 场记 lines."""
    rows = [f"{x['id']} {x.get('title','')}｜{x.get('stage')}｜{x.get('assignee') or '-'}｜{(x.get('summary') or '')[:60]}" for x in p.get("segments", [])]
    logs = [a["text"] for a in S.CFG.get("audit", []) if a.get("pid") == p["id"]][-8:]
    return "【交接】需求：" + (p.get("brief") or "")[:400] + "\n谱稿：\n" + "\n".join(rows) + ("\n场记：\n" + "\n".join(logs) if logs else "")


def promote(pid, why):
    """Members are peers; the 指挥 seat moves to the next strongest available member. Returns the new lead or None."""
    p = proj(pid)
    old = p.get("lead_resolved", "")
    out = set(p.setdefault("lead_out", []))
    if old:
        out.add(old)
    cand = [m for m in (candidates(p) or members()) if m["name"] not in out and lead_ok(m["name"])]
    if not cand:
        p["lead_resolved"] = ""
        log(pid, "调度", f"指挥 {old or '-'} 失效（{why}），没有可接任的成员")
        return None
    new = orchestra.pick_lead({**p, "lead": ""}, cand, QUOTA2, stats())
    if not new or new in out:
        new = cand[0]["name"]
    p["lead_out"] = sorted(out)
    if old and not p.get("lead_home"):
        p["lead_home"] = old  # the original seat holder gets it back once healthy
    p["lead_resolved"] = new
    p["handover"] = {"from": old, "to": new, "why": why, "at": time.time(), "context": handover_context(p)}
    S.add_msg(pid, "系统", f"指挥交接：{old or '-'} → {new}（{why}）", handover=True)
    if old:
        GRAPH.record(f"{pid}:lead", pid, old, new, "handover", "", why)
    log(pid, "调度", f"指挥交接 {old or '-'} → {new}：{why}")
    save_projects()
    touch(pid)
    return S.member(new)


def maybe_handback(pid):
    """At a safe point (no 指挥 call in flight, a card just finished): return the seat to the original 指挥 once it is healthy."""
    p = proj(pid)
    home, cur = p.get("lead_home"), p.get("lead_resolved")
    if not home or home == cur or not lead_ok(home) or LEAD_BUSY.get(pid):
        return False
    p["lead_out"] = [x for x in p.get("lead_out", []) if x != home]
    p.pop("lead_home", None)
    p["lead_resolved"] = home
    p["handover"] = {"from": cur, "to": home, "why": "原指挥已恢复", "at": time.time(), "context": handover_context(p)}
    S.add_msg(pid, "系统", f"指挥交还：{cur or '-'} → {home}（原指挥已恢复）", handover=True)
    GRAPH.record(f"{pid}:lead", pid, cur or "调度", home, "handover", "", "原指挥已恢复")
    log(pid, "调度", f"指挥交还 {cur or '-'} → {home}")
    save_projects()
    touch(pid)
    return True


def lead_member(p):
    name = p.get("lead_resolved", "")
    if name and lead_ok(name):
        return S.member(name)
    if name:  # seat holder went bad between calls (arrears / broken / removed)
        return promote(p["id"], "额度不足" if (QUOTA2.get(name) or {}).get("state") == "arrears" else "不可用")
    cand = [m for m in (candidates(p) or members()) if lead_ok(m["name"]) and m["name"] not in p.get("lead_out", [])]
    if not cand:
        return None
    pick = p.get("lead") if p.get("lead") in [m["name"] for m in cand] else orchestra.pick_lead(p, cand, QUOTA2, stats())
    p["lead_resolved"] = pick
    return S.member(pick)


async def lead_call(pid, fn, what):
    """Run fn(lead) with automatic handover on failure (error, timeout, no quota). At most every peer once."""
    p = proj(pid)
    for _ in range(len(members()) + 1):
        lead = lead_member(p)
        if not lead:
            raise RuntimeError("没有可用的指挥")
        LEAD_BUSY[pid] = LEAD_BUSY.get(pid, 0) + 1
        try:
            return lead, await asyncio.wait_for(fn(lead), S.CFG.get("lead_timeout", 600))
        except asyncio.TimeoutError:
            why = f"{what}超时"
        except Exception as e:  # noqa: BLE001 - any failure moves the seat
            why = f"{what}失败：{str(e)[:60]}"
        finally:
            LEAD_BUSY[pid] -= 1
            if LEAD_BUSY[pid] <= 0:
                LEAD_BUSY.pop(pid, None)
        mark(lead["name"], "broken")
        promote(pid, why)
    raise RuntimeError("没有可用的指挥")


REVIEW_SYSTEM = "你是指挥，审核声部交上来的产物。只回答一行：PASS，或 FIX: 具体原因。"


async def review(pid, lead, seg):
    """指挥 review. API leads get a direct call; CLI leads get the same card through run_member."""
    ROLE.set("review")
    prompt = f"段落：{seg.get('title')}\n验收：{seg.get('acceptance')}\n产物摘要：{seg.get('summary', '')}"
    ho = proj(pid).get("handover") or {}
    if ho.get("to") == lead["name"]:
        prompt = ho.get("context", "") + "\n\n" + prompt
    if lead.get("kind", "api") == "api" and lead.get("provider"):
        return await ask_model(lead, REVIEW_SYSTEM, prompt, pid)
    trig = S.add_msg(pid, "系统", REVIEW_SYSTEM + "\n\n" + prompt, folded=True, seg=seg["id"], review=True)
    await S.run_member(pid, lead["name"], trig, {"priority": "now"})
    r = reply_to(pid, lead["name"], trig)
    if not r or not r.get("text", "").strip():
        raise RuntimeError("指挥没有给出审核结论")
    line = next((ln.strip() for ln in r["text"].splitlines() if ln.strip().upper().startswith(("PASS", "FIX"))), "")
    return line or "FIX: 审核结论格式不对"


def note_pass(name, passed):
    """Exponential moving pass rate per member (feeds assign/review_policy)."""
    st = stats().setdefault(name, {})
    st["pass"] = round(0.8 * st.get("pass", 0.8) + 0.2 * (1.0 if passed else 0.0), 4)
    st["reviews"] = st.get("reviews", 0) + 1


async def plan(pid, brief):
    p = proj(pid)
    p["brief"] = brief or p.get("brief", "")
    designopts.speculate(S, pid, p["brief"], p.get("mode", "concerto"))

    answers = "\n\n用户已回答的澄清（请据此重新规划）：\n" + "\n".join(
        f"问题：{d['question']}\n答案：{d['answer']}" for d in p.get("pending", [])
        if d.get("kind") == "clarify" and d.get("state") == "done" and "answer" in d)

    async def do(lead):
        ROLE.set("plan")
        GRAPH.set_step(pid, lead["name"], "planning", "", "写谱稿")
        touch(pid)
        if lead.get("kind", "api") == "api" and lead.get("provider"):
            return await ask_model(lead, prompt, p["brief"] + answers + design_context(pid), pid)
        trig = S.add_msg(pid, "系统", prompt + "\n\n需求：" + p["brief"] + answers + design_context(pid), folded=True, seg="plan")
        await S.run_member(pid, lead["name"], trig, {"priority": "now"})
        r = reply_to(pid, lead["name"], trig)
        if not r or not r.get("text", "").strip():
            raise RuntimeError("没有交谱稿")
        return r["text"]
    prompt = orchestra.PLAN_PROMPT + f"\n本次最多 {orchestra.segment_target(p['brief'])} 个段落；README、示例、打包并入实现段落。"
    lead, text = await lead_call(pid, do, "写谱稿")
    segs = orchestra.parse_plan(text, p["brief"])
    if not segs:
        q = orchestra._extract_json(text)
        if isinstance(q, dict) and q.get("questions"):
            for question in q["questions"][:3]:
                if not isinstance(question, dict) or not question.get("q"):
                    continue
                options = [x for x in question.get("options", []) if isinstance(x, str) and x.strip()]
                default = question.get("default") or "按指挥建议继续"
                if default not in options:
                    options.insert(0, default)
                p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "clarify",
                    "question": question["q"], "options": options, "recommended": options.index(default),
                    "deadline": None, "state": "open"})
        else:
            raise RuntimeError("谱稿格式不对，请重试")
    if p.get("segments") and segs:   # a new 乐章 in the same project: the previous one becomes a past 讨论串
        p.setdefault("movements", []).append({"id": p.get("movement_id") or f"m{len(p.get('movements', [])) + 1}",
                                               "title": p.get("movement_title") or (p.get("brief") or "")[:24],
                                               "segments": p["segments"], "ended": time.time()})
    if segs:
        p["movement_id"] = f"m{len(p.get('movements', [])) + 1}"
        p["movement_title"] = (brief or p.get("brief") or "")[:24]
        p["movement_at"] = time.time()
    p["segments"] = segs
    GRAPH.set_step(pid, lead["name"], "waiting", "", "谱稿已出")
    GRAPH.record(f"{pid}:plan", pid, lead["name"], lead["name"], "lead_plan", note=f"{len(segs)} 个段落")
    save_projects()
    touch(pid)
    return segs


def candidates(p):
    names = set(p.get("members", [])) or {m["name"] for m in members()}
    return [m for m in members() if m["name"] in names and m.get("auto", True)]


def design_context(pid):
    service = getattr(S, "design_options", None)
    session = service.sessions.get((S.project(pid) or {}).get("design_sid")) if service else None
    if not session or session["picked"] is None:
        return ""
    option = session["options"][session["picked"]]
    render = session.get("render") or {}
    if option.get("state") == "cancelled" or render.get("state") == "cancelled":
        return ""
    spec = render.get("spec") or option.get("spec")
    return "\n\n已选界面方向（按此实现）：\n" + json.dumps(spec, ensure_ascii=False)


def execution_pool(p, seg, exclude=()):
    return [m for m in candidates(p) if m["name"] not in exclude and healthy(m["name"])
            and orchestra._available(m, QUOTA2)
            and orchestra._tier_rank(orchestra.tier_of(m)) >= orchestra._tier_rank(orchestra.need_tier(seg.get("difficulty")))
            and (m.get("priority") != "low" or (seg.get("difficulty", 3) <= 2 and low_wait(m) <= 0))]


def low_wait(m):
    if m.get("priority") != "low":
        return 0
    now = time.monotonic()
    calls = LOW_CALLS.setdefault(m["name"], [])
    calls[:] = [t for t in calls if now - t < 60]
    rpm = max(1, int(S.CFG.get("low_priority_rpm", 4)))
    return max(0, LOW_BACKOFF.get(m["name"], 0) - now,
               calls[-rpm] + 60 - now if len(calls) >= rpm else 0)


class LowPriorityLimited(RuntimeError):
    pass


def reserve_low(m):
    # No await between checking and reserving: concurrent dispatches share one window.
    if m.get("priority") == "low":
        if low_wait(m) > 0:
            raise LowPriorityLimited("低优先级声部限流，稍后自动重试")
        LOW_CALLS[m["name"]].append(time.monotonic())


def unavailable(pid, seg):
    p = proj(pid)
    seg.update(stage="blocked", blocked_reason="no_member", assignee="")
    event(seg, "没有能接手的声部")
    if not any(d.get("kind") == "no_member" and d.get("seg") == seg["id"] and d.get("state") == "open" for d in p.get("pending", [])):
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "no_member", "seg": seg["id"],
            "question": "没有能接手的声部，调整成员或额度后会自动重试", "options": ["重试", "跳过这一段", "先停着"],
            "recommended": 0, "deadline": None, "state": "open"})
    save_projects()
    touch(pid)


def retry_unavailable(pid=None):
    """Called on member/quota changes and conduct ticks; never revives other blocks."""
    for p in S.PROJECTS:
        if (pid and p["id"] != pid) or p.get("paused") or p.get("archived"):
            continue
        changed = False
        for seg in p.get("segments", []):
            legacy = (seg.get("events") or [{}])[-1].get("text") == "没有能接手的声部"
            if seg.get("stage") != "blocked" or not (seg.get("blocked_reason") == "no_member" or legacy):
                continue
            if legacy and seg.get("blocked_reason") != "no_member":
                unavailable(p["id"], seg)
            if not execution_pool(p, seg):
                continue
            seg.update(stage="waiting", assignee="")
            seg.pop("blocked_reason", None)
            for d in p.get("pending", []):
                if d.get("kind") == "no_member" and d.get("seg") == seg["id"] and d.get("state") == "open":
                    d["state"] = "done"
            event(seg, "成员或额度已恢复，自动重试")
            changed = True
        if changed:
            save_projects()
            touch(p["id"])
            if pid is None:
                start(p["id"])


async def run_segment(pid, seg):
    p = proj(pid)
    queue = {n: S.QUEUED.get(n, 0) for n in [m["name"] for m in members()]}
    budget = orchestra.budget_state(p)
    # Project caps are optional; autopilot treats zero as an exhausted allowance.
    mode = autopilot.budget_mode(budget["spent"], budget["cap"]) if budget["cap"] > 0 else "normal"
    if mode == "stop":
        seg["stage"] = "blocked"
        event(seg, "预算用完，等你定")
        return
    pool = execution_pool(p, seg)
    explicit = S.member(seg.get("assignee")) or {}
    explicit_ok = explicit and explicit in candidates(p) and healthy(explicit["name"]) and orchestra._available(explicit, QUOTA2)
    if explicit.get("priority") == "low":
        explicit_ok = explicit_ok and explicit in pool
    who = explicit["name"] if explicit_ok else orchestra.assign(seg, pool, QUOTA2, stats(), queue)
    if not who:
        if any(m.get("priority") == "low" and seg.get("difficulty", 3) <= 2 and low_wait(m) > 0
               for m in candidates(p)):
            seg.update(stage="waiting", assignee="", retry_at=time.time() + 1)
            touch(pid)
            return
        unavailable(pid, seg)
        return
    seg["assignee"], seg["stage"], seg["started"] = who, "running", seg.get("started") or time.time()
    lead = lead_member(p)
    src = lead["name"] if lead and lead["name"] != who else "指挥"
    ok = GRAPH.can_wake(f"{pid}:{seg['id']}", src, who, "dispatch", seg.get("title", ""))
    if not ok.ok:
        event(seg, ok.why)
        if (S.member(who) or {}).get("priority") == "low" or seg.get("retry_at"):
            seg.update(stage="waiting", retry_at=time.time() + 60)
            touch(pid)
            return
        seg["stage"] = "blocked"
        return
    GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "dispatch", seg["id"])
    GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
    event(seg, f"派给 {who}")
    touch(pid)
    upstream = {x["id"]: x.get("summary", "") for x in p["segments"] if x["id"] in seg.get("inputs", [])}
    ROLE.set("execute")
    why = account_block()
    if why:
        seg["stage"] = "blocked"
        event(seg, why)
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "account_cap", "seg": seg["id"], "question": why + "，要继续吗？",
                                            "options": ["调高上限后继续", "跳过这一段", "先停着"], "recommended": 2, "deadline": None, "state": "open"})
        touch(pid)
        return
    attempts = {}
    tried = set()  # members this segment already gave up on; reassign never cycles back
    rounds, t0 = 0, time.time()
    while True:
        rounds += 1
        why = account_block()
        if rounds > S.CFG.get("max_rounds", 12) or time.time() - t0 > S.CFG.get("max_segment_s", 4 * 3600) or why:
            seg["stage"] = "blocked"
            why = why or "这一段试了太多次"
            event(seg, why)
            p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "ladder_exhausted", "seg": seg["id"],
                                                "question": f"「{seg.get('title')}」{why}，怎么办？", "options": ["换个思路重来", "跳过这一段", "我来处理"],
                                                "recommended": 0, "deadline": None, "state": "open"})
            touch(pid)
            return
        trig = S.add_msg(pid, "系统", orchestra.task_card_text(seg, upstream) + design_context(pid), folded=True, seg=seg["id"])
        LAST_ERROR.pop(who, None)
        try:
            await S.run_member(pid, who, trig, {"priority": "now"})
        except LowPriorityLimited:
            GRAPH.set_step(pid, who, "resting")
            event(seg, f"{who} 限流，自动改派")
            tried.add(who)
            who = orchestra.assign(seg, execution_pool(p, seg, tried), QUOTA2, stats(), queue)
            if not who:
                seg.update(stage="waiting", assignee="", retry_at=time.time() + 60)
                touch(pid)
                return
            seg["assignee"] = who
            GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], "限流改派")
            GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
            touch(pid)
            continue
        reply = reply_to(pid, who, trig)
        mine = [v for v in S.TASK_STATUS.get(who, {}).values() if v.get("pid") == pid and v.get("since", 0) >= trig["ts"] - 1]
        st = max(mine, key=lambda v: v.get("since", 0)) if mine else {}
        if st.get("todo"):
            orchestra.on_checklist(seg, st["todo"])
        err = st.get("error_code", "")
        text = (reply or {}).get("text", "")
        fail_kind = ""
        if text and not err and st.get("outcome", "succeeded") == "succeeded":
            seg["summary"] = (text.split("[产物]")[-1].split("[/产物]")[0] if "[产物]" in text else text[-200:]).strip()[:200]
            seg["artifacts"] = [a for a in __import__("adapters").artifacts_in(text) if len(a) < 300][:40]   # → 资料库
            if seg["artifacts"]:
                import collab_api
                _t = asyncio.ensure_future(collab_api.record_segment_artifacts(pid, who, seg["artifacts"], seg.get("title", "")))
                _t.add_done_callback(lambda t: t.cancelled() or t.exception())  # 吞掉未取回的异常警告；错误已在函数内打印
            seg["stage"] = "selfcheck"
            event(seg, "自检通过")
            touch(pid)
            lead = lead_member(p)
            if orchestra.review_needed(seg, stats()) and autopilot.review_policy(mode, seg, stats().get(who, {}).get("pass", 0.8)) and lead and lead["name"] != who:
                seg["stage"] = "review"
                GRAPH.set_step(pid, lead["name"], "review", seg["id"], seg.get("title", ""))
                touch(pid)
                try:
                    lead, verdict = await lead_call(pid, lambda L: review(pid, L, seg), "审核")
                except Exception as e:  # noqa: BLE001 - review failure must not pass silently
                    verdict = "FIX: 审核调用失败"
                    event(seg, f"审核调用失败：{e}")
                passed = not verdict.strip().upper().startswith("FIX")
                note_pass(who, passed)
                try:  # 自学习：验收结果记到「这个模型 × 这类任务」上；失败不影响主流程
                    import learn
                    wm = next((m for m in members() if m.get("name") == who), {})
                    learn.update({"model": wm.get("model") or who, "task_type": orchestra.segment_skill(seg),
                                  "outcome": "pass" if passed else "fail", "fail_reason_code": None if passed else "REVIEW_ISSUES",
                                  "tokens": seg.get("est_tokens")}, pid=pid, root=S.DATA / "ledger")
                except Exception as e:
                    log(pid, "学习", f"记录验收结果失败：{type(e).__name__}")
                if not passed:
                    seg["stage"] = "rework"
                    event(seg, f"返工：{verdict[:80]}")
                    fail_kind = "acceptance"
            if not fail_kind:
                MEMBER_STATE.pop(who, None)
                seg["stage"], seg["done_at"] = "done", time.time()
                stats().setdefault(who, {}).update(n=stats().get(who, {}).get("n", 0) + 1)
                GRAPH.set_step(pid, who, "idle", "", "")
                event(seg, "完成")
                touch(pid)
                maybe_handback(pid)
                return
        kind = fail_kind or recovery.classify(LAST_ERROR.get(who, {}).get("status"), LAST_ERROR.get(who, {}).get("body", "") + " " + err, err)
        alts = [m["name"] for m in execution_pool(p, seg, tried | {who})]
        if (S.member(who) or {}).get("priority") == "low" and LAST_ERROR.get(who, {}).get("status") in (429, 503):
            LOW_BACKOFF[who] = time.monotonic() + 60
            event(seg, f"{who} 限流，退避并改派")
            GRAPH.set_step(pid, who, "resting")
            tried.add(who)
            who = orchestra.assign(seg, execution_pool(p, seg, tried), QUOTA2, stats(), queue)
            seg["assignee"] = who
            touch(pid)
            if who:
                GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], "限流改派")
                GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
                continue
            seg.update(stage="waiting", retry_at=time.time() + 60)
            return
        d = recovery.decide(kind, seg, who, attempts, alts, critical=seg.get("difficulty", 3) >= 3)
        attempts = recovery.bump(attempts, d.action)
        seg.setdefault("ladder", []).append({"step": d.action, "at": time.time(), "why": d.note})
        event(seg, d.note or d.action)
        log(pid, "调度", d.note or d.action)
        touch(pid)
        if d.action in ("retry", "backoff", "trim_retry", "rephrase_retry", "feedback_retry", "advisor"):
            await sleep(min(d.delay, 60))
            continue
        if d.member_state:
            mark(who, d.member_state)
        if d.action in ("reassign", "upgrade") and alts:
            tried.add(who)
            nxt = autopilot.escalate(who, candidates(p), QUOTA2, lambda m: orchestra._price_of(m, S), orchestra.tier_of) if d.action == "upgrade" else None
            GRAPH.set_step(pid, who, "resting" if d.member_state == "resting" else "idle")
            who = nxt if nxt in alts else alts[0]
            seg["assignee"] = who
            GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], d.note)
            GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
            continue
        if d.action == "skip":
            seg["stage"] = "done"
            event(seg, "非关键段落已跳过")
            touch(pid)
            return
        seg["stage"] = "blocked"
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "ladder_exhausted", "seg": seg["id"],
                                            "question": f"「{seg.get('title')}」没人能做下去了，怎么办？", "options": ["换个思路重来", "跳过这一段", "我来处理"],
                                            "recommended": 0, "deadline": None, "state": "open"})
        touch(pid)
        return


async def conduct(pid):
    """The 协奏 loop: run every ready 段落 in parallel until all are done or blocked."""
    try:
        while True:
            p = proj(pid)
            if p.get("paused"):
                return
            retry_unavailable(pid)
            todo = [seg for seg in orchestra.ready(p["segments"]) if seg.get("retry_at", 0) <= time.time()]
            if not todo:
                return
            res = await asyncio.gather(*(run_segment(pid, s) for s in todo), return_exceptions=True)
            for sg, r in zip(todo, res):
                if isinstance(r, BaseException) and not isinstance(r, asyncio.CancelledError):
                    sg["stage"] = "blocked"
                    event(sg, f"出错停下：{str(r)[:80]}")
                    log(pid, "调度", f"段落 {sg['id']} 出错：{r!r}"[:200])
            save_projects()
    finally:
        RUNNING.pop(pid, None)
        if S.project(pid):
            maybe_handback(pid)
            save_projects()
            touch(pid)


def start(pid):
    if pid not in RUNNING:
        RUNNING[pid] = asyncio.ensure_future(conduct(pid))


async def h_orch(request):
    pid = request.match_info["pid"]
    proj(pid)
    return web.json_response(view(pid))


def queue_plan(pid, brief):
    if pid in PLANNING:
        return PLANNING[pid]
    p = proj(pid)
    async def work():
        p["planning"] = "planning"
        touch(pid)
        try:
            segs = await plan(pid, brief)
            p["planning"] = "done"
            if p.get("plan_start", True) and segs:
                start(pid)
        except Exception:
            logging.getLogger(__name__).exception("Planning failed for project %s", pid)
            p["planning"] = "failed"
            p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "plan_failed", "state": "open",
                "question": "写谱稿失败，请检查指挥和额度后重试", "options": [], "deadline": None})
            raise
        finally:
            PLANNING.pop(pid, None)
            save_projects()
            touch(pid)

    p["planning"] = "planning"
    touch(pid)
    task = asyncio.create_task(work())
    PLANNING[pid] = task
    task.add_done_callback(lambda t: t.exception() if not t.cancelled() else None)
    return task


async def h_plan(request):
    pid = request.match_info["pid"]
    b = await errors.json_object(request)
    p = proj(pid)
    if pid in PLANNING:
        return web.json_response({"state": "planning"}, status=202)
    if b.get("mode") in capabilities.MODES:
        p["mode"] = b["mode"]
    if b.get("budget") is not None:
        p["budget"] = {"cap": float(b["budget"] or 0), "cur": b.get("cur", "¥")}
    p["plan_start"] = b.get("start", True)
    task = queue_plan(pid, b.get("brief") or p.get("brief", ""))
    if request.query.get("async") == "1" or "respond-async" in request.headers.get("Prefer", "").lower():
        return web.json_response({"state": "planning"}, status=202)
    await asyncio.shield(task)
    return web.json_response(view(pid))


async def h_segment(request):
    pid, sid = request.match_info["pid"], request.match_info["sid"]
    p = proj(pid)
    if request.method == "POST":   # 自己加一节
        b = await errors.json_object(request)
        seg = orchestra.parse_plan(json.dumps([b]))[0]
        used = {x["id"] for x in p["segments"]}
        n = len(p["segments"]) + 1
        while f"s{n}" in used:
            n += 1
        seg["id"] = f"s{n}"
        p["segments"].append(seg)
    else:
        seg = next((x for x in p["segments"] if x["id"] == sid), None)
        if not seg:
            raise errors.http_error(web.HTTPNotFound, fix="retry")
        b = await errors.json_object(request)
        if b.get("assignee") and S.member(b["assignee"]):
            seg["assignee"] = b["assignee"]
            event(seg, f"改派给 {b['assignee']}")
            if seg.get("stage") in ("blocked", "rework"):
                seg["stage"] = "waiting"
        if b.get("stage") in ("waiting", "done", "blocked"):
            seg["stage"] = b["stage"]
    save_projects()
    touch(pid)
    if any(x.get("stage") == "waiting" for x in p["segments"]):
        start(pid)
    return web.json_response(view(pid))


async def h_restart(request):
    """重来 button: a 段落 starts over from scratch (fresh ladder, no tried members, attempts reset)."""
    pid, sid = request.match_info["pid"], request.match_info["sid"]
    p = proj(pid)
    seg = next((x for x in p["segments"] if x["id"] == sid), None)
    if not seg:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if seg.get("stage") == "running":
        raise errors.http_error(web.HTTPConflict, "这一节正在跑，先休止再重来", fix="retry")
    for k in ("ladder", "attempts", "output", "verdict", "tried", "skipped", "error"):
        seg.pop(k, None)
    seg["stage"] = "waiting"
    event(seg, "重来")
    save_projects()
    touch(pid)
    if not p.get("paused"):
        start(pid)
    return web.json_response(view(pid))


async def h_metrics(request):
    name = request.match_info["name"]
    if not S.member(name):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    st = dict(stats().get(name, {}))
    import connect
    reason = connect.remote_status(name)
    st["state"] = MEMBER_STATE.get(name, "ok")
    if reason:
        st.update(label="离席", reason=reason)
    return web.json_response(st)


async def h_decide(request):
    pid = request.match_info["pid"]
    b = await errors.json_object(request)
    p = proj(pid)
    d = next((x for x in p.get("pending", []) if x["id"] == b.get("id")), None)
    if not d:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if d.get("state") == "done":
        return web.json_response(view(pid))
    if d.get("kind") == "clarify":
        options = d.get("options", [])
        choice = b.get("choice", d.get("recommended", 0))
        answer = b.get("answer")
        if answer is None and type(choice) is int and 0 <= choice < len(options):
            answer = options[choice]
        if not isinstance(answer, str) or not answer.strip():
            raise errors.http_error(web.HTTPBadRequest, "请选择或填写这道澄清题的答案", fix="retry")
        d.update(state="done", answer=answer.strip(), choice=choice)
        save_projects()
        touch(pid)
        if not any(x.get("kind") == "clarify" and x.get("state") == "open" for x in p.get("pending", [])):
            queue_plan(pid, p.get("brief", ""))
        return web.json_response(view(pid))
    d["state"], d["choice"] = "done", int(b.get("choice", d.get("recommended", 0)))
    seg = next((x for x in p["segments"] if x["id"] == d.get("seg")), None)
    if seg and d["kind"] in ("ladder_exhausted", "account_cap", "no_member"):
        seg.pop("blocked_reason", None)
        if d["kind"] == "no_member":
            event(seg, "你已选择处理方式")
        seg["stage"] = {0: "waiting", 1: "done", 2: "blocked"}.get(d["choice"], "blocked")
        if d["choice"] == 0:
            seg["ladder"] = []
        if d["choice"] == 1:
            seg["skipped"] = True
            event(seg, "你选了跳过")
    save_projects()
    touch(pid)
    start(pid)
    return web.json_response(view(pid))


async def h_pause(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    p["paused"] = request.path.endswith("/pause")
    save_projects()
    touch(pid)
    if not p["paused"]:
        start(pid)
    return web.json_response(view(pid))


async def h_caps(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    if request.method == "PUT":
        b = await errors.json_object(request)
        for k in ("caps", "connectors", "skills", "ask_first"):
            if k in b:
                p[k] = b[k]
        save_projects()
        touch(pid)
    acct = S.CFG.get("account", {})
    return web.json_response({"effective": capabilities.effective(acct, p), "warnings": capabilities.validate_combo(p.get("mode", "concerto"), p.get("caps", {})),
                              "combos": capabilities.COMBOS})


def register(app, server_module):
    global S
    S = server_module
    designopts.register(app, S, sys.modules[__name__])
    import collab_api
    collab_api.register(app, S)
    S.orchestra_view = view
    if not getattr(S.run_member, "guarded", False):
        S.run_member = guard_run_member(S.run_member)
    if not getattr(S.record_usage, "hooked", False):
        orig_rec = S.record_usage

        def rec(m, model, u, pid=None):
            out = orig_rec(m, model, u, pid)
            on_usage(m, u, pid)
            return out
        rec.hooked = True
        S.record_usage = rec
    r = app.router
    r.add_get("/api/orchestra/{pid}", h_orch)
    r.add_get("/api/orchestra/{pid}/overview", h_overview)
    r.add_post("/api/orchestra/{pid}/plan", h_plan)
    r.add_post("/api/orchestra/{pid}/segments/{sid}", h_segment)
    r.add_patch("/api/orchestra/{pid}/segments/{sid}", h_segment)
    r.add_post("/api/orchestra/{pid}/segments/{sid}/restart", h_restart)
    r.add_get("/api/members/{name}/metrics", h_metrics)
    r.add_post("/api/orchestra/{pid}/decide", h_decide)
    r.add_post("/api/orchestra/{pid}/pause", h_pause)
    r.add_post("/api/orchestra/{pid}/resume", h_pause)
    r.add_get("/api/orchestra/{pid}/caps", h_caps)
    r.add_put("/api/orchestra/{pid}/caps", h_caps)
    r.add_get("/api/orchestra/{pid}/audit", h_audit)
    r.add_get("/api/orchestra/{pid}/night", h_night)
    r.add_put("/api/orchestra/{pid}/night", h_night)
    r.add_get("/api/orchestra/{pid}/overture", h_overture)
    r.add_get("/api/account/caps", h_caps_account)
    r.add_put("/api/account/caps", h_caps_account)
    r.add_get("/api/quota/all", h_quota_all)
    r.add_post("/api/quota/all", h_quota_all)
    r.add_get("/api/members/{name}/policy", h_policy)
    r.add_put("/api/members/{name}/policy", h_policy)
    r.add_post("/api/invite", h_invite)
    r.add_post("/api/invite/redeem", h_redeem)
    r.add_get("/api/trash", h_trash)
    r.add_post("/api/trash/{pid}", h_trash)
    r.add_delete("/api/trash/{pid}", h_trash)

    async def bg(app_):
        t = asyncio.ensure_future(quota_loop())
        async def ticks():
            while True:
                retry_unavailable()
                for p in S.PROJECTS:
                    if not p.get("paused") and not p.get("archived") and any(
                        seg.get("stage") == "waiting" and seg.get("retry_at", float("inf")) <= time.time()
                        for seg in p.get("segments", [])):
                        start(p["id"])
                await asyncio.sleep(1)
        tick = asyncio.create_task(ticks())
        try:
            yield
        finally:
            tasks = [t, tick, *PLANNING.values(), *RUNNING.values()]
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
    app.cleanup_ctx.append(bg)
