#!/usr/bin/env python3
"""Chorus connector: registers this machine's AI CLI with a Chorus server, then runs the jobs it is sent (prompt on
stdin, reply on stdout). Stdlib only. Secrets live in ~/.chorus-connector/state.json (0600) and are never printed."""
import json, os, pathlib, secrets, shutil, socket, subprocess, sys, threading, time, urllib.request

SRV = os.environ.get("CHORUS_SERVER", "").rstrip("/")
STATE = pathlib.Path.home() / ".chorus-connector" / "state.json"
CLIS = {"claude": ["claude", "-p"], "codex": ["codex", "exec", "--skip-git-repo-check", "-"], "gemini": ["gemini", "-p"], "qwen": ["qwen", "-p"],
        "dsh": ["dsh", "--profile", "headless"]}


def req(method, path, headers, body=None, timeout=40):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(SRV + path, data=data, method=method, headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(r, timeout=timeout) as f:
        return json.loads(f.read() or b"{}")


def found():
    out = []
    for n in CLIS:
        p = shutil.which(n)
        if p:
            try:
                v = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=10).stdout.strip()[:40]
            except Exception:
                v = ""
            out.append({"name": n, "version": v})
    return out


def run(job, cmd):
    text = (job.get("system") + "\n\n" if job.get("system") else "") + job.get("prompt", "")
    try:
        p = subprocess.run(cmd, input=text, capture_output=True, text=True, timeout=1800)
        return {"id": job["id"], "text": p.stdout.strip(), "error": "" if p.returncode == 0 else (p.stderr.strip()[-300:] or f"exit {p.returncode}")}
    except Exception as e:
        return {"id": job["id"], "text": "", "error": str(e)[:300]}


QUOTA_EVERY = 600


def codex_limits(home=None):
    """Latest rate_limits event from this machine's own ~/.codex/sessions (newest files first). No auth files read."""
    base = pathlib.Path(home or os.environ.get("CODEX_HOME") or pathlib.Path.home() / ".codex") / "sessions"
    files = sorted(base.rglob("*.jsonl"), key=lambda f: f.stat().st_mtime, reverse=True)[:5] if base.is_dir() else []
    for f in files:
        try:
            lines = f.read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            if '"rate_limits"' not in line:
                continue
            try:
                o = json.loads(line)
            except ValueError:
                continue
            rl = o.get("rate_limits") or (o.get("payload") or {}).get("rate_limits")
            if isinstance(rl, dict) and (rl.get("primary") or rl.get("secondary")):
                return {"kind": "codex", "rate_limits": rl, "at": f.stat().st_mtime}
    return None


def quota_report(cli):
    """The CLI's own usage limits: Codex from its session log, Claude/Gemini from their /usage and /stats reports."""
    if cli == "codex":
        return codex_limits()
    probe = {"claude": ["claude", "-p", "/usage", "--output-format", "json"], "gemini": ["gemini", "-p", "/stats model"]}.get(cli)
    if not probe or not shutil.which(probe[0]):
        return None
    try:
        out = subprocess.run(probe, capture_output=True, text=True, timeout=90, stdin=subprocess.DEVNULL).stdout
    except Exception:
        return None
    return {"kind": cli, "text": out[-20000:]} if out.strip() else None


def quota_loop(h, cli):
    while True:
        try:
            q = quota_report(cli)
            if q:
                req("POST", "/api/connect/pub/quota", h, q, timeout=20)
        except Exception as e:
            print("额度上报失败：", type(e).__name__, flush=True)
        time.sleep(QUOTA_EVERY)


def save_state(st):
    temp = STATE.with_name(f".{STATE.name}.{secrets.token_hex(8)}.tmp")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(st, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, STATE)
    finally:
        temp.unlink(missing_ok=True)


def main():
    STATE.parent.mkdir(parents=True, exist_ok=True)
    st = json.loads(STATE.read_text()) if STATE.exists() else {}
    if not st.get("secret") or not st.get("member") or not isinstance(st.get("cli"), str) or st["cli"] not in CLIS:
        clis = found()
        if not clis:
            print("没找到 claude / codex / gemini 命令行，装好其中一个再运行。"); sys.exit(1)
        r = req("POST", "/api/connect/pub/register", {"X-Chorus-Invite": os.environ.get("CHORUS_INVITE", "")},
                {"clis": clis, "host": socket.gethostname()})
        st = {"member": r["member"], "secret": r["secret"], "cli": clis[0]["name"], "server": SRV}
        save_state(st)
    print(f"已接入 Chorus，成员名「{st['member']}」，保持这个进程运行即可。", flush=True)
    h = {"X-Chorus-Member": st["member"], "X-Chorus-Secret": st["secret"]}
    cmd = CLIS[st["cli"]]
    threading.Thread(target=quota_loop, args=(h, st["cli"]), daemon=True).start()
    while True:
        try:
            j = req("GET", "/api/connect/pub/jobs?wait=25", h, timeout=40).get("job")
            if j:
                req("POST", "/api/connect/pub/result", h, run(j, cmd))
                if st["cli"] == "codex" and (q := codex_limits()):   # a job just ran: its fresh limits
                    req("POST", "/api/connect/pub/quota", h, q, timeout=20)
        except Exception as e:
            print("连接中断，5 秒后重连：", type(e).__name__, flush=True); time.sleep(5)


if __name__ == "__main__":
    if os.environ.get("CHORUS_SERVER_FROM_STATE") and STATE.exists():
        SRV = json.loads(STATE.read_text()).get("server", SRV)
    main()
