"""N14 自学习台账（learn）：只吃事件流，不调 LLM，纯标准库。

* 每个 (model, task_type) 一个 Beta 后验：先验 = profiles.skill_score * 5 伪计数；
  信号 pass / user_adopt 为正，fail / user_redo 为负；证据按 30 天半衰期衰减（旧数据自动收缩回先验）。
* 真实 token / 耗时均值 avg_cost / avg_secs，供 ETA 预估。
* notes_for()：只取近 30 天犯过 >= 3 次的 fail_reason_code，按 频次 x 近期 排序取前 3；
  同 code 合并，连续 10 次没再犯淘汰；每条 <= 30 字（code -> 模板文案），合计 <= 120 token
  （中文按 1.5 字符/token 估算，超出截断）。
* update(event) 增量、full_rebuild(events) 全量；原子写 DATA/ledger/<pid|_global>/learn.json。
* 开关：enabled 默认关（环境变量 LEARN_ENABLED=1 才开），关时不碰磁盘；内存里的纯计算照常。
"""
from __future__ import annotations

import json
import math
import os
import pathlib
import tempfile
import threading
import time
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

try:  # pragma: no cover - 包内/脚本两种导入方式
    from . import profiles  # type: ignore
except Exception:  # pragma: no cover
    try:
        import profiles  # type: ignore
    except Exception:  # pragma: no cover
        profiles = None  # type: ignore

__all__ = [
    "HALF_LIFE_DAYS",
    "NOTES_WINDOW_DAYS",
    "NOTES_MIN_COUNT",
    "NOTES_MAX",
    "NOTE_MAX_CHARS",
    "NOTES_MAX_TOKENS",
    "CHARS_PER_TOKEN",
    "ELIMINATE_AFTER",
    "PRIOR_WEIGHT",
    "NOTE_TEMPLATES",
    "Learner",
    "decay_weight",
    "est_tokens",
    "note_text",
    "get_learner",
    "reset_cache",
    "score",
    "notes_for",
    "cost_stats",
    "update",
    "full_rebuild",
    "reset",
]

# ---- 默认参数（都可被 Learner 构造参数覆盖） ----
HALF_LIFE_DAYS = 30.0        # 证据半衰期
NOTES_WINDOW_DAYS = 30.0     # 注意事项统计窗口
NOTES_MIN_COUNT = 3          # 窗口内至少犯过几次才写进注意事项
NOTES_MAX = 3                # 最多几条注意事项
NOTE_MAX_CHARS = 30          # 每条最多多少字
NOTES_MAX_TOKENS = 120.0     # 合计最多多少 token
CHARS_PER_TOKEN = 1.5        # 中文 1.5 字符/token
ELIMINATE_AFTER = 10         # 连续多少次没再犯就淘汰
PRIOR_WEIGHT = 5.0           # 先验伪计数权重 = skill_score * 5

SIGNAL_WEIGHTS = {"pass": 1.0, "fail": 1.0, "user_adopt": 1.0, "user_redo": 1.0}

# code -> 模板文案（<= 30 字），未知 code 用 "注意：<code>" 兜底
NOTE_TEMPLATES: Dict[str, str] = {
    "MISSING_SOURCE": "缺来源，先补齐引用再落笔",
    "HALLUCINATION": "别编造事实，不确定就标注",
    "FORMAT": "格式不符，按模板输出",
    "TRUNCATED": "输出被截断，分段续写",
    "SPEC_DRIFT": "偏离需求，先复述验收点",
    "TEST_FAIL": "测试没过，先跑再交",
    "STYLE": "风格不统一，对齐既有代码",
    "OVER_BUDGET": "超预算，先给最小方案",
    "TIMEOUT": "超时，拆小步骤做",
    "REWORK": "返工多，先对齐再动手",
    "REVIEW_ISSUES": "评审问题多，先自检再交",
    "LOW_ADOPT": "采纳率低，先问清再写",
}

_DAY = 86400.0


# ---- 小工具 ----
def _num(v: Any, default: Optional[float] = None) -> Optional[float]:
    """把 bool / NaN / inf / 非数字挡掉，返回 float 或 default。"""
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        f = float(v)
        if math.isnan(f) or math.isinf(f):
            return default
        return f
    return default


def _amt(v: Any) -> float:
    """user_adopt / user_redo 可以是 bool 或次数。"""
    if v is True:
        return 1.0
    f = _num(v, 0.0)
    return max(0.0, f or 0.0)


def decay_weight(ts: float, now: float, half_life_days: float = HALF_LIFE_DAYS) -> float:
    """半衰期权重：age=半衰期 -> 0.5；未来时间戳按 1.0 处理。"""
    if half_life_days is None or half_life_days <= 0:
        return 1.0
    age = float(now) - float(ts)
    if age <= 0:
        return 1.0
    return 0.5 ** (age / (float(half_life_days) * _DAY))


def est_tokens(text: str) -> float:
    """中文按 1.5 字符/token 估算。"""
    return len(text or "") / CHARS_PER_TOKEN


def note_text(code: Any, templates: Optional[Dict[str, str]] = None, limit: int = NOTE_MAX_CHARS) -> str:
    """code -> 模板文案，超长截断到 limit 字。"""
    key = str(code or "")
    table = templates if templates is not None else NOTE_TEMPLATES
    text = table.get(key) or table.get(key.upper()) or ("注意：" + key)
    lim = int(limit)
    return text[:lim] if lim > 0 else ""


def _default_prior(model: Any, task_type: Any) -> float:
    """先验 = profiles.skill_score(model, task_type)，失败退回中性 0.6。"""
    if profiles is None:
        return 0.6
    try:
        return float(profiles.skill_score(model, task_type))
    except Exception:
        return 0.6


def _default_root() -> pathlib.Path:
    return pathlib.Path(os.environ.get("DATA", os.environ.get("AICHAT_DATA", "data"))) / "ledger"


# ---- 主体 ----
class Learner:
    """一个台账（一个 pid 一个 learn.json）。纯内存计算 + 可选落盘。"""

    def __init__(
        self,
        root: Any = None,
        pid: Any = None,
        enabled: Optional[bool] = None,
        prior_fn: Optional[Callable[[Any, Any], float]] = None,
        prior_weight: float = PRIOR_WEIGHT,
        half_life_days: float = HALF_LIFE_DAYS,
        notes_window_days: float = NOTES_WINDOW_DAYS,
        notes_min_count: int = NOTES_MIN_COUNT,
        notes_max: int = NOTES_MAX,
        note_max_chars: int = NOTE_MAX_CHARS,
        notes_max_tokens: float = NOTES_MAX_TOKENS,
        eliminate_after: int = ELIMINATE_AFTER,
        templates: Optional[Dict[str, str]] = None,
        signal_weights: Optional[Dict[str, float]] = None,
    ) -> None:
        self.root = pathlib.Path(root) if root is not None else _default_root()
        self.pid = str(pid) if pid else "_global"
        if self.pid in (".", "..") or "/" in self.pid or "\\" in self.pid:
            raise ValueError("pid 必须是单个目录名")
        if enabled is None:
            enabled = os.environ.get("LEARN_ENABLED", "").strip().lower() in ("1", "true", "yes", "on")
        self.enabled = bool(enabled)
        self.prior_fn = prior_fn or _default_prior
        self.prior_weight = float(prior_weight)
        self.half_life_days = float(half_life_days)
        self.notes_window_days = float(notes_window_days)
        self.notes_min_count = int(notes_min_count)
        self.notes_max = int(notes_max)
        self.note_max_chars = int(note_max_chars)
        self.notes_max_tokens = float(notes_max_tokens)
        self.eliminate_after = int(eliminate_after)
        self.templates = dict(templates) if templates else None
        self.signal_weights = dict(signal_weights) if signal_weights else dict(SIGNAL_WEIGHTS)
        self._lock = threading.RLock()
        self.state: Dict[str, Any] = self._blank()
        if self.enabled:
            self.load()

    # ---- 状态骨架 ----
    @staticmethod
    def _key(model: Any, task_type: Any) -> str:
        return "%s||%s" % (model, task_type)

    def _blank(self) -> Dict[str, Any]:
        return {"version": 1, "pid": self.pid, "updated_at": None, "cells": {}}

    @property
    def path(self) -> pathlib.Path:
        return self.root / self.pid / "learn.json"

    def _now(self, now: Optional[float] = None) -> float:
        return float(time.time()) if now is None else float(now)

    def _prior(self, model: Any, task_type: Any) -> Tuple[float, float]:
        p = _num(self.prior_fn(model, task_type), 0.6)
        p = min(1.0, max(0.0, p))
        w = max(0.0, self.prior_weight)
        return w * p, w * (1.0 - p)

    def _cell(self, model: Any, task_type: Any, create: bool = False) -> Optional[Dict[str, Any]]:
        key = self._key(model, task_type)
        cells = self.state.setdefault("cells", {})
        cell = cells.get(key)
        if cell is None and create:
            cell = {
                "model": str(model),
                "task_type": str(task_type),
                "ev": [],
                "tokens_sum": 0.0,
                "tokens_n": 0,
                "secs_sum": 0.0,
                "secs_n": 0,
                "rework_sum": 0.0,
                "issues_sum": 0.0,
                "n_events": 0,
                "codes": {},
            }
            cells[key] = cell
        return cell

    # ---- 信号 ----
    def _signal(self, event: Dict[str, Any]) -> Tuple[float, float]:
        w = self.signal_weights
        a = b = 0.0
        outcome = str(event.get("outcome") or "").strip().lower()
        if outcome == "pass":
            a += float(w.get("pass", 1.0))
        elif outcome == "fail":
            b += float(w.get("fail", 1.0))
        a += float(w.get("user_adopt", 1.0)) * _amt(event.get("user_adopt"))
        b += float(w.get("user_redo", 1.0)) * _amt(event.get("user_redo"))
        return a, b

    # ---- 增量 / 全量 ----
    def update(self, event: Any, now: Optional[float] = None) -> bool:
        """增量吃一条事件。返回是否真的落账。"""
        with self._lock:
            ok = self._apply(event, now=now)
            if ok and self.enabled:
                self.save()
            return ok

    def full_rebuild(self, events: Iterable[Any], now: Optional[float] = None) -> int:
        """全量重建：清空后重放事件流。"""
        with self._lock:
            self.state = self._blank()
            n = 0
            for ev in events or ():
                if self._apply(ev, now=now):
                    n += 1
            if self.enabled:
                self.save()
            return n

    def _apply(self, event: Any, now: Optional[float] = None) -> bool:
        if not isinstance(event, dict):
            return False
        model = event.get("model")
        task_type = event.get("task_type")
        if model is None or task_type is None or str(model) == "" or str(task_type) == "":
            return False
        ts = _num(event.get("ts"))
        if ts is None:
            ts = self._now(now)
        cell = self._cell(model, task_type, create=True)

        a, b = self._signal(event)
        if a or b:
            cell["ev"].append({"ts": ts, "a": a, "b": b})

        tok = _num(event.get("tokens"))
        if tok is not None and tok >= 0:
            cell["tokens_sum"] += tok
            cell["tokens_n"] += 1
        secs = _num(event.get("secs"))
        if secs is not None and secs >= 0:
            cell["secs_sum"] += secs
            cell["secs_n"] += 1
        rw = _num(event.get("rework_rounds"))
        if rw is not None and rw >= 0:
            cell["rework_sum"] += rw
        iss = _num(event.get("review_issues"))
        if iss is not None and iss >= 0:
            cell["issues_sum"] += iss

        # 只有失败事件携带的原因才算再次犯错。
        code = event.get("fail_reason_code") if b > 0 else None
        codes = cell["codes"]
        for old, rec in list(codes.items()):
            if str(code) != str(old):
                rec["since"] = int(rec.get("since", 0)) + 1
        if code is not None and str(code) != "":
            key = str(code)
            rec = codes.get(key)
            if rec is None:
                rec = {"hits": [], "since": 0, "last_ts": ts}
                codes[key] = rec
            rec["hits"] = list(rec.get("hits") or []) + [ts]
            rec["since"] = 0
            rec["last_ts"] = ts
        # 连续 N 次没再犯 -> 淘汰
        for old in list(codes.keys()):
            if int(codes[old].get("since", 0)) >= int(self.eliminate_after):
                codes.pop(old, None)

        cell["n_events"] = int(cell.get("n_events", 0)) + 1
        self._prune(cell, ts)
        self.state["updated_at"] = ts
        return True

    def _prune(self, cell: Dict[str, Any], ts: float) -> None:
        """丢掉权重已可忽略的证据、远超窗口的命中记录，控制体积。"""
        keep_age = max(self.half_life_days, 1.0) * 40.0 * _DAY
        cell["ev"] = [e for e in cell.get("ev", []) if (ts - float(e.get("ts", ts))) <= keep_age]
        win = max(self.notes_window_days, 1.0) * 3.0 * _DAY
        for rec in cell.get("codes", {}).values():
            rec["hits"] = [t for t in (rec.get("hits") or []) if (ts - float(t)) <= win]

    # ---- 查询 ----
    def posterior(self, model: Any, task_type: Any, now: Optional[float] = None) -> Dict[str, Any]:
        now = self._now(now)
        a0, b0 = self._prior(model, task_type)
        a, b = a0, b0
        n_eff = 0.0
        cell = self._cell(model, task_type)
        if cell:
            for e in cell.get("ev", []):
                w = decay_weight(e.get("ts", now), now, self.half_life_days)
                a += w * float(e.get("a", 0.0))
                b += w * float(e.get("b", 0.0))
                n_eff += w
        total = a + b
        return {
            "alpha": a,
            "beta": b,
            "prior_alpha": a0,
            "prior_beta": b0,
            "n_eff": n_eff,
            "score": round(a / total, 4) if total > 0 else 0.5,
        }

    def score(self, model: Any, task_type: Any, now: Optional[float] = None) -> float:
        """模型 x 任务类型的后验期望 0..1；没数据时就是先验。"""
        return float(self.posterior(model, task_type, now)["score"])

    def cost_stats(self, model: Any, task_type: Any, now: Optional[float] = None) -> Dict[str, Any]:
        """真实 token / 耗时均值，供 ETA。avg_cost = 平均 token 数。"""
        cell = self._cell(model, task_type)
        if not cell:
            return {"avg_cost": None, "avg_tokens": None, "avg_secs": None,
                    "avg_rework": None, "avg_issues": None, "n": 0}
        tn = int(cell.get("tokens_n", 0))
        sn = int(cell.get("secs_n", 0))
        n = int(cell.get("n_events", 0))
        avg_tok = (cell["tokens_sum"] / tn) if tn else None
        avg_secs = (cell["secs_sum"] / sn) if sn else None
        return {
            "avg_cost": avg_tok,
            "avg_tokens": avg_tok,
            "avg_secs": avg_secs,
            "avg_rework": (cell["rework_sum"] / n) if n else None,
            "avg_issues": (cell["issues_sum"] / n) if n else None,
            "n": n,
        }

    def notes_detail(self, model: Any, task_type: Any, now: Optional[float] = None) -> List[Dict[str, Any]]:
        """候选注意事项（已合并同 code、已淘汰、已按 频次x近期 排序），带明细。"""
        now = self._now(now)
        cell = self._cell(model, task_type)
        if not cell:
            return []
        half = max(self.half_life_days, 0.0) * _DAY
        win_start = now - max(self.notes_window_days, 0.0) * _DAY
        cand: List[Dict[str, Any]] = []
        for code, rec in (cell.get("codes") or {}).items():
            if int(rec.get("since", 0)) >= int(self.eliminate_after):
                continue
            hits = [float(t) for t in (rec.get("hits") or []) if win_start <= float(t) <= now]
            if len(hits) < int(self.notes_min_count):
                continue
            last_ts = max(hits)
            recency = 1.0 if half <= 0 else 0.5 ** (max(0.0, now - last_ts) / half)
            cand.append({
                "code": str(code),
                "count": len(hits),
                "last_ts": last_ts,
                "recency": recency,
                "score": len(hits) * recency,
            })
        cand.sort(key=lambda d: (-d["score"], -d["count"], d["code"]))
        return cand[: max(0, int(self.notes_max))]

    def notes_for(self, model: Any, task_type: Any, now: Optional[float] = None) -> List[str]:
        """注意事项文案列表：每条 <= 30 字，合计 <= 120 token，超出截断。"""
        out: List[str] = []
        total = 0.0
        for d in self.notes_detail(model, task_type, now):
            text = self.note_text(d["code"])
            remain = float(self.notes_max_tokens) - total
            max_chars = remain * CHARS_PER_TOKEN
            if max_chars <= 0:
                break
            if len(text) > max_chars:
                text = text[: int(max_chars)]
            if not text:
                break
            out.append(text)
            total += est_tokens(text)
        return out

    def note_text(self, code: Any) -> str:
        return note_text(code, self.templates, self.note_max_chars)

    # ---- 重置 ----
    def reset(self, member: Any = None) -> int:
        """reset(member)：清掉该成员（按 model）所有任务类型的账；None/'*' 清全部。返回删掉的 cell 数。"""
        with self._lock:
            cells = self.state.setdefault("cells", {})
            if member is None or member == "*":
                n = len(cells)
                self.state = self._blank()
            else:
                if isinstance(member, dict):
                    model = member.get("model")
                    task = member.get("task_type")
                else:
                    model, task = str(member), None
                if model is None or str(model) == "":
                    raise ValueError("reset(member) 需要 member['model']")
                drop = []
                for key, cell in cells.items():
                    if str(cell.get("model")) != str(model):
                        continue
                    if task is not None and str(cell.get("task_type")) != str(task):
                        continue
                    drop.append(key)
                for key in drop:
                    cells.pop(key, None)
                n = len(drop)
            if self.enabled:
                self.save()
            return n

    # ---- 持久化（原子写） ----
    def load(self) -> Dict[str, Any]:
        p = self.path
        if not p.exists():
            return self.state
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return self.state
        self.state = self._normalize(data)
        return self.state

    def save(self) -> Optional[pathlib.Path]:
        if not self.enabled:
            return None
        p = self.path
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self.state, ensure_ascii=False, sort_keys=True)
        tmp = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=p.parent,
                                             prefix=".learn.", suffix=".tmp", delete=False) as f:
                tmp = pathlib.Path(f.name)
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, p)
        finally:
            if tmp is not None:
                tmp.unlink(missing_ok=True)
        return p

    def _normalize(self, data: Any) -> Dict[str, Any]:
        blank = self._blank()
        if not isinstance(data, dict):
            return blank
        raw = data.get("cells")
        cells: Dict[str, Any] = {}
        if isinstance(raw, dict):
            for key, c in raw.items():
                if not isinstance(c, dict):
                    continue
                skey = str(key)
                k_model, k_task = skey.split("||", 1) if "||" in skey else (skey, "")
                cell = {
                    "model": str(c.get("model", k_model)),
                    "task_type": str(c.get("task_type", k_task)),
                    "ev": [],
                    "tokens_sum": 0.0,
                    "tokens_n": 0,
                    "secs_sum": 0.0,
                    "secs_n": 0,
                    "rework_sum": 0.0,
                    "issues_sum": 0.0,
                    "n_events": 0,
                    "codes": {},
                }
                for e in c.get("ev") or []:
                    if not isinstance(e, dict):
                        continue
                    ts = _num(e.get("ts"))
                    if ts is None:
                        continue
                    cell["ev"].append({"ts": ts, "a": _num(e.get("a"), 0.0) or 0.0,
                                       "b": _num(e.get("b"), 0.0) or 0.0})
                for f in ("tokens_sum", "secs_sum", "rework_sum", "issues_sum"):
                    cell[f] = _num(c.get(f), 0.0) or 0.0
                for f in ("tokens_n", "secs_n", "n_events"):
                    cell[f] = int(_num(c.get(f), 0) or 0)
                codes = c.get("codes")
                if isinstance(codes, dict):
                    for code, cc in codes.items():
                        if not isinstance(cc, dict):
                            continue
                        hits = [t for t in (_num(x) for x in (cc.get("hits") or [])) if t is not None]
                        cell["codes"][str(code)] = {
                            "hits": hits,
                            "since": int(_num(cc.get("since"), 0) or 0),
                            "last_ts": _num(cc.get("last_ts"), max(hits) if hits else 0.0) or 0.0,
                        }
                cells[self._key(cell["model"], cell["task_type"])] = cell
        out = dict(blank)
        out["cells"] = cells
        out["pid"] = str(data.get("pid", self.pid))
        out["updated_at"] = _num(data.get("updated_at"))
        return out


# ---- 模块级便捷入口（按 (root, pid) 缓存实例） ----
_LEARNERS: Dict[Tuple[str, str], Learner] = {}
_CACHE_LOCK = threading.Lock()


def get_learner(pid: Any = None, root: Any = None, **kw: Any) -> Learner:
    key = (str(pathlib.Path(root) if root is not None else _default_root()), str(pid) if pid else "_global")
    with _CACHE_LOCK:
        lr = _LEARNERS.get(key)
        if lr is None:
            lr = Learner(root=root, pid=pid, **kw)
            _LEARNERS[key] = lr
        return lr


def reset_cache() -> None:
    with _CACHE_LOCK:
        _LEARNERS.clear()


def score(model: Any, task_type: Any, now: Optional[float] = None, pid: Any = None,
          root: Any = None, **kw: Any) -> float:
    return get_learner(pid, root, **kw).score(model, task_type, now)


def notes_for(model: Any, task_type: Any, now: Optional[float] = None, pid: Any = None,
              root: Any = None, **kw: Any) -> List[str]:
    return get_learner(pid, root, **kw).notes_for(model, task_type, now)


def cost_stats(model: Any, task_type: Any, now: Optional[float] = None, pid: Any = None,
               root: Any = None, **kw: Any) -> Dict[str, Any]:
    return get_learner(pid, root, **kw).cost_stats(model, task_type, now)


def update(event: Any, now: Optional[float] = None, pid: Any = None, root: Any = None, **kw: Any) -> bool:
    return get_learner(pid, root, **kw).update(event, now)


def full_rebuild(events: Iterable[Any], now: Optional[float] = None, pid: Any = None,
                 root: Any = None, **kw: Any) -> int:
    return get_learner(pid, root, **kw).full_rebuild(events, now)


def reset(member: Any = None, pid: Any = None, root: Any = None, **kw: Any) -> int:
    return get_learner(pid, root, **kw).reset(member)
