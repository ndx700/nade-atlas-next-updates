"""Deterministic failure-decision engine for Chorus (no LLM involved).

Every rule in this module is mechanical: the same failure sequence always
produces the same decision (jitter aside — the RNG is injectable for tests).
Pure Python 3.11 standard library.
"""

from __future__ import annotations

import email.utils
import random
import re
import time
from dataclasses import dataclass
from datetime import timezone

__all__ = [
    "KINDS",
    "Decision",
    "classify",
    "decide",
    "bump",
    "cooldown_until",
    "trim_messages",
    "log_line",
    "N_RETRY",
    "N_BACKOFF",
    "BACKOFF_BASE",
    "BACKOFF_CAP",
    "ELLIPSIS",
]

KINDS = (
    "arrears",
    "rate_limit",
    "server",
    "timeout",
    "network",
    "context_length",
    "refusal",
    "acceptance",
    "auth",
    "unknown",
)

# --- tuning constants -------------------------------------------------------
N_RETRY = 3          # plain retries for server / timeout / network / unknown
N_BACKOFF = 4        # backoff steps for rate_limit
BACKOFF_BASE = 2.0   # seconds
BACKOFF_CAP = 60.0   # seconds

ELLIPSIS = "…（已省略）…"

# --- body / exception sniffing tables --------------------------------------
_ARREARS_MARKERS = (
    "insufficient_quota",
    "insufficient balance",
    "余额不足",
    "欠费",
    "arrearage",
    "exceeded your current quota",
    "credit balance is too low",
    "billing",
)

_RATE_MARKERS = (
    "rate limit",
    "rate_limit",
    "too many requests",
    "请求过于频繁",
    "overloaded",
)

_CONTEXT_MARKERS = (
    "context_length_exceeded",
    "maximum context length",
    "too many tokens",
    "prompt is too long",
    "上下文过长",
    "context length",
)

_REFUSAL_MARKERS = (
    "i can't help",
    "i cannot assist",
    "无法协助",
    "我不能",
    "content_filter",
    "safety",
    "refused",
)

_AUTH_MARKERS = (
    "invalid api key",
    "invalid_api_key",
    "unauthorized",
    "authentication",
)

_TIMEOUT_MARKERS = (
    "timeout",
    "timed out",
    "超时",
)

_NETWORK_MARKERS = (
    "clientconnectorerror",
    "connection reset",
    "econnrefused",
    "name or service not known",
    "network",
)

_KIND_LABEL = {
    "server": "服务端错误",
    "timeout": "请求超时",
    "network": "网络异常",
    "unknown": "未知错误",
}


def _has(low: str, needles: tuple[str, ...]) -> bool:
    """Substring test against an already-lowercased blob."""
    return any(n in low for n in needles)


def classify(status: int | None, body: str = "", exc: str = "") -> str:
    """Map an HTTP status / response body / exception text to a failure kind."""
    body = body or ""
    exc = exc or ""
    low = (body + "\n" + exc).lower()

    if exc.strip().lower() == "acceptance" or (status is None and "acceptance" in low):
        return "acceptance"

    if status in (401, 403) or _has(low, _AUTH_MARKERS):
        return "auth"

    if status == 402 or _has(low, _ARREARS_MARKERS):
        return "arrears"

    if status in (429, 529) or _has(low, _RATE_MARKERS):
        return "rate_limit"

    if _has(low, _CONTEXT_MARKERS) or (status == 400 and "context" in low):
        return "context_length"

    if _has(low, _TIMEOUT_MARKERS):
        return "timeout"

    if _has(low, _NETWORK_MARKERS):
        return "network"

    if _has(low, _REFUSAL_MARKERS):
        return "refusal"

    if status is not None and 500 <= status <= 599:
        return "server"

    return "unknown"


@dataclass
class Decision:
    """What the orchestrator should do next for one segment/member pair."""

    action: str
    delay: float = 0.0
    member_state: str = ""   # "" | "resting" | "cooldown" | "broken"
    note: str = ""           # Chinese one-liner for 场记
    hud: str = ""            # short HUD tag


def _get(attempts: dict, key: str) -> int:
    try:
        return int((attempts or {}).get(key, 0) or 0)
    except (TypeError, ValueError, IndexError):
        return 0


def _jitter(n: int, rng) -> float:
    """Full jitter: rng() * min(cap, base * 2**n)."""
    ceiling = min(BACKOFF_CAP, BACKOFF_BASE * (2 ** max(0, n)))
    return float(rng()) * ceiling


def _skip(d: Decision) -> Decision:
    """Convert a would-be ask_user into a skip for non-critical segments."""
    note = d.note.replace("，需要你定", "，非关键段落已跳过")
    if "非关键段落已跳过" not in note:
        note = note + "，非关键段落已跳过"
    return Decision("skip", 0.0, d.member_state, note, "跳过")


def decide(
    kind: str,
    seg: dict,
    member: str,
    attempts: dict,
    alternatives: list[str],
    critical: bool = True,
    rng=random.random,
) -> Decision:
    """Deterministic decision for one failure of one segment on one member.

    ``attempts`` holds per-segment counters; the caller bumps them with
    :func:`bump` after acting on the returned decision.
    ``alternatives`` is pre-sorted by the caller (best/largest-context first).
    """
    attempts = attempts or {}
    alts = list(alternatives or [])
    target = alts[0] if alts else ""
    member = member or "?"
    if rng is None:
        rng = random.random

    if kind == "arrears":
        if target:
            d = Decision("reassign", 0.0, "resting",
                         f"{member} 余额不足，转给 {target}", "改派")
        else:
            d = Decision("ask_user", 0.0, "resting",
                         f"{member} 余额不足，需要你定", "等你定")

    elif kind == "rate_limit":
        n = _get(attempts, "backoff")
        if n < N_BACKOFF:
            delay = _jitter(n, rng)
            d = Decision("backoff", delay, "",
                         f"{member} 触发限流，退避 {delay:.1f}s 后重试",
                         f"重试 {n + 1}/{N_BACKOFF}")
        elif target:
            d = Decision("reassign", 0.0, "cooldown",
                         f"{member} 限流未恢复，转给 {target}", "改派")
        else:
            d = Decision("backoff", BACKOFF_CAP, "cooldown",
                         f"{member} 限流未恢复，保持退避 {BACKOFF_CAP:.0f}s 后重试",
                         f"重试 {N_BACKOFF}/{N_BACKOFF}")

    elif kind in ("server", "timeout", "network"):
        label = _KIND_LABEL[kind]
        n = _get(attempts, "retry")
        if n < N_RETRY:
            delay = _jitter(n, rng)
            d = Decision("retry", delay, "",
                         f"{member} {label}，第 {n + 1} 次重试",
                         f"重试 {n + 1}/{N_RETRY}")
        elif target:
            d = Decision("reassign", 0.0, "",
                         f"{member} {label}重试耗尽，转给 {target}", "改派")
        else:
            d = Decision("ask_user", 0.0, "",
                         f"{member} {label}重试耗尽，需要你定", "等你定")

    elif kind == "context_length":
        n = _get(attempts, "trim")
        if n < 1:
            d = Decision("trim_retry", 0.0, "",
                         f"{member} 上下文过长，压缩后重试", "压缩上下文")
        elif n < 2:
            d = Decision("trim_retry", 0.0, "",
                         f"{member} 上下文仍过长，摘要压缩后重试", "压缩上下文")
        elif target:
            d = Decision("reassign", 0.0, "",
                         f"{member} 上下文过长，转给上下文更大的 {target}", "改派")
        else:
            d = Decision("ask_user", 0.0, "",
                         f"{member} 上下文过长，需要你定", "等你定")

    elif kind == "refusal":
        n = _get(attempts, "rephrase")
        if n < 1:
            d = Decision("rephrase_retry", 0.0, "",
                         f"{member} 拒绝回答，改写后重试", "重试 1/1")
        elif target:
            d = Decision("reassign", 0.0, "",
                         f"{member} 拒绝回答，转给 {target}", "改派")
        elif critical:
            d = Decision("ask_user", 0.0, "",
                         f"{member} 拒绝回答，需要你定", "等你定")
        else:
            d = Decision("skip", 0.0, "",
                         f"{member} 拒绝回答，非关键段落已跳过", "跳过")

    elif kind == "acceptance":
        fb = _get(attempts, "feedback")
        up = _get(attempts, "upgrade")
        if fb < 2:
            d = Decision("feedback_retry", 0.0, "",
                         f"{member} 验收未过，反馈重试 {fb + 1}/2",
                         f"重试 {fb + 1}/2")
        elif up < 1:
            d = Decision("upgrade", 0.0, "",
                         f"{member} 反馈重试无效，升级模型", "升级")
        elif not critical:
            d = Decision("skip", 0.0, "",
                         f"{member} 验收未过，非关键段落已跳过", "跳过")
        else:
            d = Decision("ask_user", 0.0, "",
                         f"{member} 验收未过，需要你定", "等你定")

    elif kind == "auth":
        if target:
            d = Decision("reassign", 0.0, "broken",
                         f"{member} 鉴权失败，转给 {target}", "改派")
        else:
            d = Decision("ask_user", 0.0, "broken",
                         f"{member} 鉴权失败，需要你定", "等你定")

    else:  # unknown (and anything not in KINDS)
        n = _get(attempts, "retry")
        if n < 1:
            d = Decision("retry", _jitter(0, rng), "",
                         f"{member} 未知错误，重试一次", "重试 1/1")
        elif target:
            d = Decision("reassign", 0.0, "",
                         f"{member} 未知错误，转给 {target}", "改派")
        else:
            d = Decision("ask_user", 0.0, "",
                         f"{member} 未知错误，需要你定", "等你定")

    if d.action == "ask_user" and not critical:
        d = _skip(d)
    return d


_ACTION_COUNTER = {
    "retry": "retry",
    "backoff": "backoff",
    "trim_retry": "trim",
    "rephrase_retry": "rephrase",
    "feedback_retry": "feedback",
    "upgrade": "upgrade",
    "reassign": "reassign",
}


def bump(attempts: dict, action: str) -> dict:
    """Return a copy of ``attempts`` with the counter for ``action`` incremented."""
    out = dict(attempts or {})
    key = _ACTION_COUNTER.get(action)
    if key is not None:
        try:
            cur = int(out.get(key, 0) or 0)
        except (TypeError, ValueError, IndexError):
            cur = 0
        out[key] = cur + 1
    return out


_DURATION_RE = re.compile(r"(\d+(?:\.\d+)?)(ms|h|m|s)")
_UNIT_SECONDS = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0}


def _parse_duration(value: str) -> float | None:
    """Parse reset strings such as "1m30s", "6ms", "2s", or a bare number."""
    if value is None:
        return None
    text = str(value).strip().lower()
    if not text:
        return None
    total = 0.0
    found = False
    for num, unit in _DURATION_RE.findall(text):
        found = True
        total += float(num) * _UNIT_SECONDS[unit]
    if found:
        return total
    try:
        return float(text)
    except ValueError:
        return None


def cooldown_until(kind: str, headers: dict | None, now: float) -> float | None:
    """Absolute timestamp until which the member should be left alone, or None.

    Honours ``Retry-After`` (seconds or HTTP date) and
    ``x-ratelimit-reset-requests`` / ``x-ratelimit-reset-tokens``
    (duration strings such as ``1m30s``, ``6ms``, ``2s``).
    The longest requirement wins.
    """
    if kind in ("context_length", "refusal", "acceptance", "auth"):
        return None
    if not headers:
        return None

    lowered = {str(k).lower(): v for k, v in headers.items()}
    waits: list[float] = []

    retry_after = lowered.get("retry-after")
    if retry_after is not None:
        text = str(retry_after).strip()
        secs: float | None = None
        if text:
            try:
                secs = float(text)
            except ValueError:
                dt = None
                try:
                    dt = email.utils.parsedate_to_datetime(text)
                except (TypeError, ValueError, IndexError):
                    dt = None
                if dt is not None:
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    secs = dt.timestamp() - float(now)
        if secs is not None:
            waits.append(max(0.0, secs))

    for key in ("x-ratelimit-reset-requests", "x-ratelimit-reset-tokens"):
        raw = lowered.get(key)
        if raw is None:
            continue
        secs = _parse_duration(raw)
        if secs is not None:
            waits.append(max(0.0, secs))

    if not waits:
        return None
    return float(now) + max(waits)


def trim_messages(messages: list[dict], max_chars: int) -> list[dict]:
    """Rule-based context trimming (no LLM).

    Keeps system messages and the last user message intact, drops the oldest
    middle messages first, then truncates the longest remaining middle message
    to head 40% + ELLIPSIS + tail 40%.  The last user message is never removed.
    """
    src = messages or []
    msgs: list[dict] = []
    for m in src:
        msgs.append(dict(m) if isinstance(m, dict) else {"role": "", "content": str(m)})
    if not msgs:
        return []

    def clen(idx: int) -> int:
        return len(str(msgs[idx].get("content", "")))

    try:
        limit = int(max_chars)
    except (TypeError, ValueError, IndexError):
        limit = 0

    total = sum(clen(i) for i in range(len(msgs)))

    last_user = None
    for i in range(len(msgs) - 1, -1, -1):
        if msgs[i].get("role") == "user":
            last_user = i
            break

    protected = {i for i, m in enumerate(msgs) if m.get("role") == "system"}
    if last_user is not None:
        protected.add(last_user)

    middle = [i for i in range(len(msgs)) if i not in protected]
    dropped: set[int] = set()

    # phase 1 — drop the oldest middle messages, keeping at least one
    while total > limit:
        live = [i for i in middle if i not in dropped]
        if len(live) <= 1:
            break
        oldest = live[0]
        dropped.add(oldest)
        total -= clen(oldest)

    # phase 2 — truncate the longest remaining middle message(s)
    if total > limit:
        live = [i for i in middle if i not in dropped]
        for i in sorted(live, key=lambda k: -clen(k)):
            if total <= limit:
                break
            cur = str(msgs[i].get("content", ""))
            length = len(cur)
            if length <= 0:
                continue
            head = int(length * 0.4)
            tail = int(length * 0.4)
            new = cur[:head] + ELLIPSIS + (cur[length - tail:] if tail > 0 else "")
            if len(new) < length:
                total -= length - len(new)
                msgs[i]["content"] = new

    # phase 3 — give up and drop remaining middle messages (oldest first)
    if total > limit:
        for i in middle:
            if total <= limit:
                break
            if i in dropped:
                continue
            dropped.add(i)
            total -= clen(i)

    return [msgs[i] for i in range(len(msgs)) if i not in dropped]


def log_line(seg_id: str, member: str, kind: str, d: Decision) -> dict:
    """One 场记 line describing what just happened."""
    return {
        "at": time.time(),
        "seg": seg_id,
        "who": member,
        "kind": kind,
        "action": d.action,
        "note": d.note,
    }
