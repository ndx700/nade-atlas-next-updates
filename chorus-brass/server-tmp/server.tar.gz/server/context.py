"""What a member is shown of a chat, kept cheap (Ali 10-25: 别让客户花太多冤枉钱).

Three layers, cheapest first:
  1. The newest messages verbatim, up to a token budget (not the model's whole window: 1M tokens of history on
     every reply costs real money). Pinned messages take priority, but share the budget and may be truncated.
  2. Older messages that still fit are pruned: long code blocks, pasted files and walls of text become one-line
     stubs. Free, and nothing is made up.
  3. Whatever falls off the end is folded into a structured 前情提要 (decisions / todos / files / open questions),
     updated incrementally by the cheapest member, in batches rather than per message.
"""
import re

BUDGETS = {"save": 8000, "standard": 20000, "more": 60000}
VERBATIM = 6  # the newest messages are never pruned
SUMMARY_BATCH = 4000  # tokens of fallen-off messages before the summary is rewritten

CJK = re.compile(r"[　-鿿가-힯＀-￯]")
FENCE = re.compile(r"```[^\n]*\n(.*?)```", re.S)


def tokens(text):
    """Rough count: a CJK character is about one token, other text about four characters per token."""
    if not text:
        return 0
    cjk = len(CJK.findall(text))
    return cjk + (len(text) - cjk) // 4 + 1


def prune(text):
    """An older message, shortened without inventing anything."""
    def fence(m):
        body = m.group(1)
        n = body.count("\n") + 1
        return m.group(0) if len(body) < 600 else f"[代码 {n} 行，已省略]"
    t = FENCE.sub(fence, text)
    if len(t) > 1500:
        t = t[:700] + f"\n…（中间省略 {len(t) - 1000} 字）…\n" + t[-300:]
    return t


def window(msgs, budget, line):
    """Pick what goes into the prompt, newest first. Returns (kept messages oldest first, fallen-off messages)."""
    budget = max(0, int(budget))
    selected = {}
    used = 0

    def take(m, short, limit):
        rendered = line(m, short)
        if tokens(rendered) <= limit:
            return m, short
        # Work on a copy: never change stored chat text or pin state.
        marker = "\n[置顶消息过大，已按上下文预算截断]" if m.get("pinned") else "\n[消息已按上下文预算截断]"
        lo, hi = 0, len(m["text"])
        best = None
        while lo <= hi:
            mid = (lo + hi) // 2
            candidate = {**m, "text": m["text"][:mid] + marker}
            if tokens(line(candidate, False)) <= limit:
                best = candidate
                lo = mid + 1
            else:
                hi = mid - 1
        return (best, False) if best is not None else None

    pinned = [m for m in msgs if m.get("pinned")]
    rest = [m for m in msgs if not m.get("pinned")]
    # Share the pin allowance, reserving half for the latest unpinned request.
    for i, m in enumerate(pinned):
        item = take(m, False, max(0, (budget - used - (budget // 2 if rest else 0)) // (len(pinned) - i) - 1))
        if item:
            selected[m["seq"]] = item
            used += tokens(line(*item)) + 1
    for i in range(len(rest) - 1, -1, -1):
        m = rest[i]
        short = len(rest) - i > VERBATIM
        remaining = budget - used - 1
        if tokens(line(m, short)) > remaining and any(not x[0].get("pinned") for x in selected.values()):
            break
        item = take(m, short, remaining)
        if not item:
            break
        selected[m["seq"]] = item
        used += tokens(line(*item)) + 1
    out = sorted(selected.values(), key=lambda x: x[0]["seq"])
    fallen = [m for m in msgs if m["seq"] not in selected]
    # Include message separators in the reported estimate.
    used = tokens("\n\n".join(line(*item) for item in out))
    return out, fallen, used


SUMMARY_SYSTEM = """你负责给一个多人 AI 协作群写「前情提要」，让成员在看不到早期消息时也能接着干活。
只根据给你的内容写，不要编造。保持简短，用下面的固定栏目（没有内容的栏目写「无」）：

## 目标
## 已经定下的事
## 进行中 / 待办（谁负责）
## 涉及的文件和链接
## 还没解决的问题
## 重要原话（Ali 的明确要求，原文照抄，最多 8 条）"""


def summary_prompt(old, msgs, line):
    body = "\n\n".join(line(m, True) for m in msgs)
    head = f"这是之前的前情提要：\n\n{old}\n\n---\n下面是之后的新消息，请把它们并进提要，输出完整的新提要：" if old else "下面是群里较早的消息，请写前情提要："
    return head + "\n\n" + body
