import asyncio
import json
import unittest

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

import chorus2 as c
import concierge as cg
import server as s
import voice
from test_chorus2 import Base


class TestDraft(unittest.TestCase):
    def setUp(self):
        self.ms = [{"name": "强", "kind": "api"}, {"name": "码", "kind": "cli"}, {"name": "眼", "kind": "api", "caps": {"vision": True}},
                   {"name": "欠", "kind": "cli"}]
        self.price = {"强": 60, "码": 2, "眼": 1, "欠": 0.1}

    def d(self, brief, answers=(), **kw):
        return cg.draft(brief, list(answers), self.ms, lambda m: {"out": self.price[m["name"]]}, {}, lambda n: n != "欠", **kw)

    def test_intent_detection(self):
        self.assertTrue(cg.wants_project("我想做一个记账 app"))
        self.assertTrue(cg.wants_project("I want to build a habit tracker"))
        self.assertFalse(cg.wants_project("今天天气怎么样"))

    def test_plan_capabilities_cost_quota(self):
        p = self.d("我想做一个记账 app，界面要好看", ["预算 30 元"])
        self.assertEqual((p["mode"], p["lead"]), ("symphony", "强"))
        self.assertIn("码", p["members"])          # cheapest code_exec (欠 is in arrears)
        self.assertIn("眼", p["members"])          # vision
        self.assertNotIn("欠", p["members"])
        self.assertEqual(p["budget"], {"cap": 30.0, "cur": "¥"})

    def test_concerto_default_budget_and_account_cap(self):
        p = self.d("帮我写个脚本整理照片", account_cap=5)
        self.assertEqual(p["mode"], "concerto")
        self.assertEqual(p["budget"]["cap"], 5)

    def test_nobody_healthy(self):
        self.assertIn("error", cg.draft("我想做个网站", [], self.ms, lambda m: None, {}, lambda n: False))


class TestConciergeFlow(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.started = []
        self.addCleanup(setattr, c, "start", c.start)
        self.addCleanup(setattr, c, "plan", c.plan)
        c.start = lambda pid: self.started.append(pid)

        async def fake_plan(pid, brief):
            self.started.append("plan:" + pid)
            return ["segment"]
        c.plan = fake_plan
        self.cg = cg.Concierge(s, c)

    async def test_ask_card_confirm_creates_and_starts(self):
        pid = self.P()["id"]
        name = s.CFG["members"][0]["name"]
        self.assertTrue(self.cg.claims(pid, name, "我想做一个记账 app"))
        i = await self.cg.on_user(pid, name, "我想做一个记账 app")
        self.assertEqual(i["stage"], "asking")
        self.assertTrue(self.cg.claims(pid, name, "给自己用"))           # answers go to the concierge, not a plain reply
        await self.cg.on_user(pid, name, "给自己用，预算 12 元")
        self.assertEqual(i["stage"], "card")
        card = [m for m in s.CHATS[pid] if m.get("card")][-1]["card"]
        self.assertEqual((card["type"], card["budget"]["cap"]), ("plan", 12.0))
        new = await self.cg.confirm(i["id"], {"name": "记账"})
        await c.PLANNING[new]
        p = s.project(new)
        self.assertEqual((p["name"], p["mode"], p["budget"]["cap"]), ("记账", "symphony", 12.0))
        self.assertEqual(self.started, ["plan:" + new, new])
        self.assertEqual(await self.cg.confirm(i["id"]), new)               # one-shot
        self.assertFalse(self.cg.claims(pid, name, "谢谢"))

    async def test_cancel(self):
        pid = self.P()["id"]
        name = s.CFG["members"][0]["name"]
        await self.cg.on_user(pid, name, "帮我做个网站")
        i = await self.cg.on_user(pid, name, "直接做")
        self.assertTrue(self.cg.cancel(i["id"]))
        self.assertFalse(self.cg.cancel(i["id"]))


class TestSentences(unittest.TestCase):
    def test_split_keeps_tail(self):
        done, tail = voice.sentences("你好。我在想办法！还没说完")
        self.assertEqual((done, tail), (["你好。", "我在想办法！"], "还没说完"))


class TestVoiceWS(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.pid = self.P()["id"]
        self.name = s.CFG["members"][0]["name"]
        self.tts = []
        self.stopped = []

        async def fake_asr(S, audio, fmt):
            return audio.decode()

        async def fake_tts(who, text, voice_=None):
            self.tts.append(text)
            return f"/files/tts-{len(self.tts)}.mp3"

        async def send_member(pid, name, trig, text):
            m = s.add_msg(pid, name, "", name, live=True)
            for part in ("好的。", "我来", "安排！"):
                await asyncio.sleep(0.02)
                m["text"] += part
            if text == "慢":
                await asyncio.sleep(10)
            m["live"] = False

        async def stop_member(name):
            self.stopped.append(name)
        for k, v in (("voice_asr", fake_asr), ("tts_file", fake_tts), ("stop_member", stop_member)):
            self.addCleanup(setattr, s, k, getattr(s, k, None))
            setattr(s, k, v)
        app = web.Application()
        app.router.add_get("/ws", lambda q: voice.handle(q, s, send_member))
        self.ws_client = TestClient(TestServer(app))
        await self.ws_client.start_server()
        self.addAsyncCleanup(self.ws_client.close)

    async def recv_until(self, ws, kind, n=30):
        got = []
        for _ in range(n):
            m = json.loads((await asyncio.wait_for(ws.receive(), 5)).data)
            got.append(m)
            if m["type"] == kind and (kind != "reply" or m.get("final")):
                return got
        return got

    async def test_turn_streams_sentences_and_keeps_transcript(self):
        ws = await self.ws_client.ws_connect("/ws")
        await ws.send_str(json.dumps({"type": "start", "project": self.pid, "to": self.name}))
        await ws.send_bytes("你好".encode())
        await ws.send_str(json.dumps({"type": "end"}))
        got = await self.recv_until(ws, "reply")
        self.assertEqual(got[0], {"type": "transcript", "text": "你好"})
        self.assertEqual(self.tts, ["好的。", "我来安排！"])
        self.assertEqual([g["url"] for g in got if g["type"] == "audio"], ["/files/tts-1.mp3", "/files/tts-2.mp3"])
        self.assertTrue(any(m.get("voice") and m["text"] == "你好" for m in s.CHATS[self.pid]))
        await ws.close()

    async def test_barge_in_interrupts(self):
        ws = await self.ws_client.ws_connect("/ws")
        await ws.send_str(json.dumps({"type": "start", "project": self.pid, "to": self.name}))
        await ws.send_bytes("慢".encode())
        await ws.send_str(json.dumps({"type": "end"}))
        await self.recv_until(ws, "audio")
        await ws.send_str(json.dumps({"type": "barge"}))
        got = await self.recv_until(ws, "interrupted")
        self.assertEqual(got[-1]["type"], "interrupted")
        self.assertEqual(self.stopped, [])
        await ws.close()

    async def test_unknown_target_errors(self):
        ws = await self.ws_client.ws_connect("/ws")
        await ws.send_str(json.dumps({"type": "start", "project": "nope", "to": self.name}))
        self.assertEqual(json.loads((await ws.receive()).data)["type"], "error")
        await ws.close()
