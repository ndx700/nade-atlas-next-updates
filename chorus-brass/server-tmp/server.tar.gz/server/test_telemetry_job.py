import asyncio
import json
import pathlib
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import server as s
import telemetry_job as job
import chorus2


class TelemetryJobTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        tmp = self.enterContext(tempfile.TemporaryDirectory())
        self.enterContext(patch.object(s, "DATA", pathlib.Path(tmp)))
        self.enterContext(patch.object(s, "CFG", {"tz": 8, "collab": {"telemetry": True}}))
        self.now = 1700000000
        self.enterContext(patch.object(s, "RESULTS", [
            {"at": self.now, "member": "private-name", "ok": True, "project": "secret"},
            {"at": self.now - 86400, "member": "old", "ok": True},
        ]))
        self.enterContext(patch.object(s, "member", return_value={"model": "safe-model"}))
        self.session = MagicMock()
        self.session.__aenter__ = AsyncMock(return_value=self.session)
        self.session.__aexit__ = AsyncMock(return_value=False)
        self.response = MagicMock(status=204)
        self.response.__aenter__ = AsyncMock(return_value=self.response)
        self.response.__aexit__ = AsyncMock(return_value=False)
        self.session.post.return_value = self.response
        self.client = self.enterContext(patch.object(job, "ClientSession", return_value=self.session))

    async def test_requires_explicit_true(self):
        s.CFG["telemetry_url"] = "https://example.test/report"
        for collab in ({}, None, {"telemetry": False}, {"telemetry": 1}, {"telemetry": "true"}):
            s.CFG["collab"] = collab
            self.assertEqual(await job.run_daily(s, self.now), "disabled")
        self.client.assert_not_called()
        self.assertEqual(list(s.DATA.iterdir()), [])

    async def test_local_only_sanitized_and_daily_persistent(self):
        self.assertEqual(await job.run_daily(s, self.now), "local_only")
        report = json.loads((s.DATA / "telemetry_out.json").read_text())
        self.assertEqual(report["stats"][0]["passed"], 1)
        self.assertNotIn("private-name", json.dumps(report))
        self.assertNotIn("secret", json.dumps(report))
        self.assertEqual(await job.run_daily(s, self.now + 60), "already_attempted")
        self.assertEqual(await job.run_daily(s, self.now + 86400), "local_only")
        self.client.assert_not_called()

    async def test_put_exact_sanitized_local_report(self):
        s.CFG["telemetry_url"] = "https://example.test/report"
        s.member.return_value = {"model": "alice@example.test"}
        self.assertEqual(await job.run_daily(s, self.now), "sent")
        report = json.loads((s.DATA / "telemetry_out.json").read_text())
        self.assertNotIn("alice@", json.dumps(report))
        self.session.post.assert_called_once_with(s.CFG["telemetry_url"], json=report, allow_redirects=False)
        self.assertEqual(await job.run_daily(s, self.now), "already_attempted")
        self.assertEqual(self.session.post.call_count, 1)

    async def test_http_error_and_network_error_do_not_retry_today(self):
        s.CFG["telemetry_url"] = "https://example.test/report"
        self.response.status = 500
        self.assertEqual(await job.run_daily(s, self.now), "send_failed")
        self.assertEqual(await job.run_daily(s, self.now), "already_attempted")
        self.session.post.side_effect = OSError("private failure")
        self.assertEqual(await job.run_daily(s, self.now + 86400), "send_failed")
        self.assertEqual(await job.run_daily(s, self.now + 86400), "already_attempted")
        self.assertEqual(self.session.post.call_count, 2)

    async def test_timezone_midnight_and_concurrent_ticks(self):
        s.CFG["telemetry_url"] = "https://example.test/report"
        midnight = 1700064000  # 2023-11-16 00:00 UTC+8
        results = await asyncio.gather(job.run_daily(s, midnight - 1), job.run_daily(s, midnight - 1))
        self.assertEqual(sorted(results), ["already_attempted", "sent"])
        self.assertEqual(await job.run_daily(s, midnight), "sent")

    async def test_context_lifecycle(self):
        started, stopped = asyncio.Event(), asyncio.Event()
        async def loop(server):
            started.set()
            try:
                await asyncio.wait_for(asyncio.Event().wait(), 5)
            finally:
                stopped.set()
        with patch.object(job, "telemetry_job", loop):
            ctx = job.context(None)
            await asyncio.wait_for(anext(ctx), 5)
            await asyncio.wait_for(started.wait(), 5)
            with self.assertRaises(StopAsyncIteration):
                await asyncio.wait_for(anext(ctx), 5)
        self.assertTrue(stopped.is_set())
        self.assertIn(job.context, s.make_app().cleanup_ctx)


class CLITimeoutTests(unittest.IsolatedAsyncioTestCase):
    async def test_default_unlimited_zero_unlimited_explicit_timeout_preserved(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(s, "DATA", pathlib.Path(tmp)), \
             patch.object(s, "CFG", {}), patch.object(s, "RUNNING", {}), \
             patch.object(s, "kill_process_group", new_callable=AsyncMock) as kill, \
             patch.object(s, "live"), patch.object(s, "approve_all_for", return_value=False):
            for cmd in ("codex exec", "claude -p"):
                for config, expected in (({}, None), ({"timeout": 0}, None), ({"timeout": 7200}, 7200)):
                    proc = MagicMock(stdin=MagicMock(), stdout=self.empty_stream(),
                                           stderr=self.empty_stream(), wait=AsyncMock(return_value=0), returncode=0)
                    proc.stdin.drain = AsyncMock()
                    actual_wait_for = asyncio.wait_for
                    seen = []
                    async def capture(future, timeout):
                        seen.append(timeout)
                        return await actual_wait_for(future, timeout)
                    with patch.object(s.asyncio, "create_subprocess_shell", AsyncMock(return_value=proc)), \
                         patch.object(s.asyncio, "wait_for", capture):
                        await s.call_cli(None, {"cmd": cmd, **config}, {"who": "test"}, "system", "prompt", "", "")
                    self.assertEqual(seen, [expected])
                    kill.assert_awaited_with(proc)

    async def test_explicit_cli_timeout_still_cleans_process(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(s, "DATA", pathlib.Path(tmp)), \
             patch.object(s, "CFG", {}), patch.object(s, "RUNNING", {}), \
             patch.object(s, "kill_process_group", new_callable=AsyncMock) as kill, \
             patch.object(s, "live"), patch.object(s, "approve_all_for", return_value=False):
            proc = MagicMock(stdin=MagicMock(), stdout=asyncio.StreamReader(), stderr=self.empty_stream(),
                             wait=AsyncMock(return_value=0), returncode=0)
            proc.stdin.drain = AsyncMock()
            with patch.object(s.asyncio, "create_subprocess_shell", AsyncMock(return_value=proc)):
                with self.assertRaisesRegex(RuntimeError, "超时了"):
                    await s.call_cli(None, {"cmd": "codex exec", "timeout": 0.01},
                                     {"who": "test"}, "", "prompt", "", "")
            kill.assert_awaited_once_with(proc)
            self.assertEqual(s.RUNNING["test"], set())

    async def test_lead_timeout_tiers(self):
        for kind, cfg, expected in (("cli", {}, None), ("dsh", {}, None),
                                    ("api", {}, 240), ("cli", {"lead_timeout": 90}, 90),
                                    ("cli", {"lead_timeout": 0}, None)):
            lead = {"name": "test", "kind": kind}
            actual_wait_for = asyncio.wait_for
            seen = []
            async def capture(future, timeout):
                seen.append(timeout)
                return await actual_wait_for(future, timeout)
            with patch.object(chorus2, "S", SimpleNamespace(CFG=cfg)), \
                 patch.object(chorus2, "proj", return_value={}), \
                 patch.object(chorus2, "members", return_value=[lead]), \
                 patch.object(chorus2, "lead_member", return_value=lead), \
                 patch.object(chorus2, "LEAD_BUSY", {}), \
                 patch.object(chorus2.asyncio, "wait_for", capture):
                self.assertEqual(await chorus2.lead_call("p", AsyncMock(return_value="done"), "plan"),
                                 (lead, "done"))
            self.assertEqual(seen, [expected])

    @staticmethod
    def empty_stream():
        # CLI output now uses read(n), like the real subprocess StreamReader.
        stream = asyncio.StreamReader()
        stream.feed_eof()
        return stream


if __name__ == "__main__":
    unittest.main()
