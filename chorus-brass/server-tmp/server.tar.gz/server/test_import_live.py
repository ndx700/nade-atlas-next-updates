"""Real HTTP smoke test: seed_demo + server process + local mock model only."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from seed_demo import seed


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


class ImportLive(unittest.TestCase):
    def test_seeded_import_endpoints(self):
        with tempfile.TemporaryDirectory(prefix='round3-import-') as tmp:
            try:
                model_port, port = free_port(), free_port()
            except PermissionError:
                self.skipTest('sandbox denies local sockets; run on socket-enabled host')
            data = seed(Path(tmp) / 'demo', f'http://127.0.0.1:{model_port}/v1')
            env = {**os.environ, 'AICHAT_DATA': str(data), 'AICHAT_PORT': str(port),
                   'AICHAT_PASSWORD': 'DEMO-LOGIN-1101'}
            processes = []
            with (Path(tmp) / 'service.log').open('w+') as log:
                try:
                    for args in ([sys.executable, str(ROOT / 'tools/mock_models.py'), '--port', str(model_port)],
                                 [sys.executable, str(ROOT / 'server/server.py')]):
                        processes.append(subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=log))
                    base = f'http://127.0.0.1:{port}'
                    headers = {'Authorization': 'Bearer ' + hashlib.sha256(b'DEMO-LOGIN-1101').hexdigest()[:32],
                               'Content-Type': 'application/json'}

                    def request(path, body=None):
                        req = urllib.request.Request(base + path, headers=headers,
                            data=json.dumps(body).encode() if body is not None else None)
                        with urllib.request.urlopen(req, timeout=10) as response:
                            return response.status, json.load(response)

                    for _ in range(100):
                        try:
                            request('/api/index')
                            break
                        except (OSError, urllib.error.URLError):
                            time.sleep(.05)
                    else:
                        log.seek(0)
                        self.fail('server startup failed: ' + log.read())
                    body = {'text': '- 喜欢简短回复\n- 只使用临时数据\n- 喜欢简短回复', 'scope': 'all'}
                    status, result = request('/api/memory/import', body)
                    self.assertEqual(status, 200)
                    self.assertEqual(result['added'], 2)
                    self.assertEqual(len(result['items']), 2)
                    self.assertEqual(request('/api/memory/import', body)[1]['added'], 0)
                    status, result = request('/api/import', {'text': json.dumps([
                        {'role': 'user', 'content': '演示导入'}, {'role': 'assistant', 'content': '收到'}]), 'name': 'demo.json'})
                    self.assertEqual(status, 200)
                    self.assertEqual(result['conversations'][0]['count'], 2)
                    _, committed = request('/api/import/commit', {'token': result['token']})
                    pid = committed['projects'][0]
                    messages = [json.loads(x) for x in (data / 'chats' / (pid + '.jsonl')).read_text().splitlines()]
                    self.assertEqual([m['text'] for m in messages], ['演示导入', '收到'])
                    # Uploaded file path, not just pasted text.
                    (data / 'files/export.json').write_text('[{"role":"user","content":"file"}]')
                    self.assertEqual(request('/api/import', {'url': '/files/export.json'})[1]['conversations'][0]['count'], 1)
                    for path in ('/api/memory/import', '/api/import'):
                        with self.assertRaises(urllib.error.HTTPError) as caught:
                            request(path, {})
                        self.assertEqual(caught.exception.code, 400)
                    (data / 'files/broken.zip').write_bytes(b'PKbroken')
                    for path in ('/api/memory/import', '/api/import'):
                        with self.assertRaises(urllib.error.HTTPError) as caught:
                            request(path, {'url': '/files/broken.zip'})
                        self.assertEqual(caught.exception.code, 400)
                finally:
                    for process in processes:
                        process.terminate()
                    for process in processes:
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
