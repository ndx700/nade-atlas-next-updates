"""定音卡：每个模型第一次用某把 key 时，要用户手动允许一次；换模型或换 key 重新允许。
只存 key 的短指纹，不存 key 本身。存 DATA/consent.json。"""
from __future__ import annotations
import hashlib, json, os, pathlib, time


def fingerprint(model: str, key: str) -> str:
    h = hashlib.sha256(("chorus-consent:" + (key or "")).encode()).hexdigest()[:16]
    return f"{(model or '').strip().lower()}|{h}"


def _path(data) -> pathlib.Path:
    return pathlib.Path(data) / "consent.json"


def load(data) -> dict:
    try:
        return json.loads(_path(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(data, st) -> None:
    p = _path(data); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp"); tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8"); os.replace(tmp, p)


def status(data, model: str, key: str) -> str:
    """allowed | denied | pending"""
    return load(data).get(fingerprint(model, key), {}).get("state", "pending")


def request(data, member: str, model: str, key: str, reason: str = "") -> dict:
    """第一次遇到就登记为待定音；已决定的不改。"""
    st = load(data); fp = fingerprint(model, key)
    if fp not in st:
        st[fp] = {"state": "pending", "member": member, "model": model, "key_tail": (key or "")[-4:], "reason": reason, "at": int(time.time())}
        _save(data, st)
    return {"id": fp, **st[fp]}


def decide(data, fp: str, allow: bool) -> bool:
    st = load(data)
    if fp not in st:
        return False
    st[fp]["state"] = "allowed" if allow else "denied"; st[fp]["decided_at"] = int(time.time())
    _save(data, st)
    return True


def forget_member(data, member: str, others=None) -> int:
    """成员被删除：它在定音里的卡片一起删掉。others={model: 还在用这个模型的成员名}：
    同一把 key 同一个模型还有别的成员在用时，卡片过户给它，不让对方重新允许。"""
    st = load(data)
    others = others or {}
    gone = 0
    for fp in list(st):
        v = st[fp]
        if not isinstance(v, dict) or v.get("member") != member:
            continue
        heir = others.get(v.get("model"))
        if heir:
            v["member"] = heir
        else:
            st.pop(fp)
            gone += 1
    _save(data, st)
    return gone


def rename_member(data, old: str, new: str) -> None:
    st = load(data)
    hit = False
    for v in st.values():
        if isinstance(v, dict) and v.get("member") == old:
            v["member"] = new
            hit = True
    if hit:
        _save(data, st)


def revoke(data, fp: str) -> bool:
    st = load(data)
    if fp not in st:
        return False
    st[fp]["state"] = "pending"; _save(data, st)
    return True


def pending(data) -> list:
    return [{"id": k, **v} for k, v in load(data).items() if v.get("state") == "pending"]
