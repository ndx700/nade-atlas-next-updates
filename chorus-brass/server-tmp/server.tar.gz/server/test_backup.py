"""Offline backup/restore regression tests; never stop a real service."""
import asyncio
import io
import json
from pathlib import Path
import tarfile
import tempfile
import time
import unittest
from unittest.mock import patch

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer, make_mocked_request
from unittest.mock import Mock
import backup as b
import restore_executor as e
import server as s

PASSWORD = "test backup password 123"


def seed(data):
    data.mkdir(exist_ok=True)
    for name in ("chats", "files", "tmp", "work", "memory", "summaries", "skills"):
        (data / name).mkdir(exist_ok=True)
    (data / "config.json").write_text(json.dumps({"password": "login-secret", "members": [],
                                                "providers": [{"id": "pr", "key": "api-secret"}]}))
    (data / "projects.json").write_text(json.dumps([{"id": "p", "name": "Project", "members": []}]))
    (data / "chats/p.jsonl").write_text(json.dumps({"seq": 1, "who": "Ali", "at": "10-26 12:00", "text": "hello", "client_id": "stable", "request_hash": "hash"}) + "\n")
    (data / "files/x.txt").write_bytes(b"attachment\n")
    (data / "memory/p-p.json").write_text('[{"id":"m","text":"decision"}]')
    (data / "tmp/incomplete").write_text("temporary-secret")
    (data / "work/private").write_text("cli-secret")
    (data / "unknown-private.json").write_text('"unknown-secret"')


class InProcessClient:
    """Exercise registered routes and auth when the sandbox denies TCP sockets."""
    def __init__(self, app):
        self.app = app

    async def request(self, method, path, headers=None, json=None, data=None):
        import json as codec
        raw = codec.dumps(json).encode() if json is not None else data or b""
        if isinstance(raw, str):
            raw = raw.encode()
        content = Mock()
        content.read = unittest.mock.AsyncMock(return_value=raw)
        async def chunks(size):
            for offset in range(0, len(raw), size):
                yield raw[offset:offset + size]
        content.iter_chunked = chunks
        request = make_mocked_request(method, path, headers={**(headers or {}), "Content-Length": str(len(raw))},
                                      app=self.app, payload=content)
        match = await self.app.router.resolve(request)
        match.add_app(self.app)
        request._match_info = match
        response = await s.auth(request, match.handler)
        async def read():
            return response._path.read_bytes() if isinstance(response, web.FileResponse) else response.body
        async def body():
            return codec.loads(await read())
        response.read = read
        response.json = body
        return response

    async def get(self, path, **kwargs):
        return await self.request("GET", path, **kwargs)

    async def post(self, path, **kwargs):
        return await self.request("POST", path, **kwargs)

    async def put(self, path, **kwargs):
        return await self.request("PUT", path, **kwargs)


class FakeService:
    def __init__(self, health=(True,)):
        self.calls = []
        self.results = iter(health)

    def stop(self):
        self.calls.append("stop")

    def start(self):
        self.calls.append("start")

    def healthy(self):
        self.calls.append("health")
        return next(self.results)


class BackupTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = Path(self.tmp.name) / "data"
        seed(self.data)
        self.m = b.BackupManager(self.data, lambda: {})

    async def done_backup(self):
        row = await self.m.start_backup(PASSWORD)
        await asyncio.gather(*self.m.tasks)
        row = self.m.list()[0]
        self.assertEqual(row["state"], "completed", row)
        return row

    async def queued_plan(self):
        row = await self.done_backup()
        plan = await self.m.plan(row["id"], PASSWORD)
        return self.m.commit(plan["id"], plan["archive_sha256"], True)

    async def test_encrypted_roundtrip_preserves_identifiers_and_excludes_private_roots(self):
        row = await self.done_backup()
        archive = self.m.path("", row["id"]).with_suffix(".chorus")
        raw = archive.read_bytes()
        for secret in (b"login-secret", b"api-secret", b"attachment"):
            self.assertNotIn(secret, raw)
        plan = await self.m.plan(row["id"], PASSWORD)
        self.assertEqual(plan["counts"], {"projects": 1, "messages": 1, "attachments": 1})
        stage = self.m.path("stage-", plan["id"])
        msg = json.loads((stage / "chats/p.jsonl").read_text())
        self.assertEqual((msg["seq"], msg["client_id"], msg["request_hash"]), (1, "stable", "hash"))
        for name in ("tmp", "work", "unknown-private.json", "backups"):
            self.assertFalse((stage / name).exists())
        self.assertNotIn(PASSWORD, "".join(p.read_text() for p in self.m.root.glob("*.json")))

    async def test_wrong_password_tamper_and_truncation_rejected_before_extract(self):
        row = await self.done_backup()
        archive = self.m.path("", row["id"]).with_suffix(".chorus")
        original = archive.read_bytes()
        raw = self.m.root / "decrypted.tar"
        with self.assertRaises(b.BackupError):
            b.decrypt(archive, raw, "wrong password 123")
        self.assertFalse(raw.exists())
        for broken in (original[:-1], original[:100] + bytes([original[100] ^ 1]) + original[101:], original + b"extra"):
            archive.write_bytes(broken)
            with self.assertRaises(b.BackupError):
                b.decrypt(archive, raw, PASSWORD)
            self.assertFalse(raw.exists())

    async def test_snapshot_is_stable_across_attachment_replace_and_new_messages(self):
        stage = self.m.root / "snapshot"
        stage.mkdir()
        b.capture_snapshot(self.data, stage)
        tmp = self.data / "tmp/replacement"
        tmp.write_bytes(b"new contents")
        tmp.replace(self.data / "files/x.txt")
        (self.data / "chats/p.jsonl").write_text('{"seq":2,"text":"new"}\n')
        self.assertEqual((stage / "files/x.txt").read_bytes(), b"attachment\n")
        self.assertEqual(json.loads((stage / "chats/p.jsonl").read_text())["seq"], 1)

    async def test_links_and_state_limits_rejected(self):
        (self.data / "files/link").symlink_to(self.data / "config.json")
        with self.assertRaises(b.BackupError):
            await self.m.start_backup(PASSWORD)
        self.assertFalse(self.m.busy.locked())
        (self.data / "files/link").unlink()
        with patch.object(b, "MAX_STATE", 1):
            with self.assertRaises(b.BackupError):
                await self.m.start_backup(PASSWORD)
        self.assertFalse(list(self.m.root.glob(".capture-*")))

    async def test_commit_expiry_digest_confirmation_and_single_use(self):
        row = await self.done_backup()
        plan = await self.m.plan(row["id"], PASSWORD)
        for checksum, confirm in (("wrong", True), (plan["archive_sha256"], False)):
            with self.assertRaises(b.BackupError):
                self.m.commit(plan["id"], checksum, confirm)
        self.m.commit(plan["id"], plan["archive_sha256"], True)
        with self.assertRaises(b.BackupError):
            self.m.commit(plan["id"], plan["archive_sha256"], True)
        second = await self.m.plan(row["id"], PASSWORD)
        with self.assertRaises(b.BackupError):
            self.m.commit(second["id"], second["archive_sha256"], True)
        with patch.object(b.time, "time", return_value=second["expires_at"] + 1):
            self.m.expire_plans()
        self.assertFalse(self.m.path("stage-", second["id"]).exists())

    async def test_successful_restore_and_mount_directory_preserved(self):
        plan = await self.queued_plan()
        (self.data / "chats/p.jsonl").write_text('{"seq":2,"text":"after backup"}\n')
        inode = self.data.stat().st_ino
        service = FakeService()
        result = e.apply(self.data, self.m.path("plan-", plan["id"]).with_suffix(".json"), service)
        self.assertEqual(result["state"], "completed")
        self.assertEqual(service.calls, ["stop", "start", "health"])
        self.assertEqual(self.data.stat().st_ino, inode)
        self.assertEqual(json.loads((self.data / "chats/p.jsonl").read_text())["seq"], 1)
        previous = self.m.path("pre-restore-", plan["id"])
        self.assertEqual(json.loads((previous / "chats/p.jsonl").read_text())["seq"], 2)
        self.assertTrue((self.data / "unknown-private.json").exists())
        self.assertFalse((self.m.root / "restore-active.json").exists())

    async def test_failed_health_rolls_back_to_pre_restore_data(self):
        plan = await self.queued_plan()
        (self.data / "files/x.txt").write_bytes(b"latest")
        service = FakeService((False, True))
        path = self.m.path("plan-", plan["id"]).with_suffix(".json")
        with self.assertRaises(b.BackupError):
            e.apply(self.data, path, service)
        self.assertEqual(b.read_json(path)["state"], "rolled_back")
        self.assertEqual((self.data / "files/x.txt").read_bytes(), b"latest")
        self.assertEqual(service.calls, ["stop", "start", "health", "stop", "start", "health"])

    async def test_failed_rollback_health_can_be_retried(self):
        plan = await self.queued_plan()
        path = self.m.path("plan-", plan["id"]).with_suffix(".json")
        with self.assertRaises(b.BackupError):
            e.apply(self.data, path, FakeService((False, False)))
        self.assertEqual(b.read_json(path)["state"], "rollback_failed")
        result = e.apply(self.data, path, FakeService())
        self.assertEqual(result["state"], "rolled_back")

    async def test_backup_failure_is_recorded_and_lock_released(self):
        with patch.object(b, "make_archive", side_effect=OSError("test private path")):
            row = await self.m.start_backup(PASSWORD)
            await asyncio.gather(*self.m.tasks)
        row = b.read_json(self.m.path("backup-", row["id"]).with_suffix(".json"))
        self.assertEqual(row["state"], "failed")
        self.assertNotIn("test private path", str(row))
        self.assertFalse(self.m.busy.locked())
        self.assertFalse(list(self.m.root.glob(".capture-*")))

    async def test_crash_mid_switch_startup_guard_and_recovery(self):
        plan = await self.queued_plan()
        path = self.m.path("plan-", plan["id"]).with_suffix(".json")
        stage = self.m.path("stage-", plan["id"])
        previous = self.m.path("pre-restore-", plan["id"])
        previous.mkdir()
        original = [n for n in b.STATE_ROOTS if (self.data / n).exists()]
        b.write_json(self.m.path("journal-", plan["id"]).with_suffix(".json"), {"state": "switching", "original": original})
        (self.data / "config.json").rename(previous / "config.json")
        (stage / "config.json").rename(self.data / "config.json")
        plan["state"] = "applying"
        b.write_json(path, plan)
        b.write_json(self.m.root / "restore-active.json", {"id": plan["id"], "state": "switching"})
        with self.assertRaises(b.BackupError):
            e.startup_guard(self.data)
        result = e.apply(self.data, path, FakeService())
        self.assertEqual(result["state"], "rolled_back")
        self.assertEqual(b.read_json(self.data / "config.json")["password"], "login-secret")

    async def test_executor_refuses_changed_stage(self):
        plan = await self.queued_plan()
        (self.m.path("stage-", plan["id"]) / "files/x.txt").write_bytes(b"tampered")
        service = FakeService()
        with self.assertRaises(b.BackupError):
            e.apply(self.data, self.m.path("plan-", plan["id"]).with_suffix(".json"), service)
        self.assertEqual(service.calls, [])

    async def test_cancelled_preflight_waits_for_worker_before_cleaning_plaintext(self):
        import threading
        row = await self.done_backup()
        started, release = threading.Event(), threading.Event()

        def unpack(archive, password, stage):
            stage.mkdir()
            (stage / "private").write_text("private contents")
            started.set()
            release.wait(5)
            self.assertTrue((stage / "private").exists())
            return {}, {}

        with patch.object(b, "unpack_archive", unpack):
            task = asyncio.create_task(self.m.plan(row["id"], PASSWORD))
            await asyncio.to_thread(started.wait, 5)
            self.assertTrue(started.is_set())
            task.cancel()
            await asyncio.sleep(0)
            self.assertFalse(task.done())
            release.set()
            with self.assertRaises(asyncio.CancelledError):
                await task
        self.assertFalse(list(self.m.root.glob("stage-*")))
        self.assertFalse(self.m.busy.locked())

    async def test_lifetime_lock_rejects_second_writer(self):
        with b.writer_lock(self.data):
            with self.assertRaises(b.BackupError):
                with b.writer_lock(self.data):
                    pass
        with b.writer_lock(self.data):
            pass

    async def test_retention_preserves_plans_and_reports_interrupted_job(self):
        row = await self.done_backup()
        await self.m.plan(row["id"], PASSWORD)
        second = await self.done_backup()
        self.m.config = lambda: {"backups": {"keep": 1}}
        self.m.prune()
        self.assertEqual(len(self.m.list()), 2)
        second.update(state="running")
        b.write_json(self.m.path("backup-", second["id"]).with_suffix(".json"), second)
        (self.m.root / ".capture-left").mkdir()
        self.m._recover()
        self.assertFalse((self.m.root / ".capture-left").exists())
        self.assertEqual(b.read_json(self.m.path("backup-", second["id"]).with_suffix(".json"))["state"], "failed")

    async def test_external_schedule_key_outside_data_and_private(self):
        key = Path(self.tmp.name) / "backup.key"
        key.write_text(PASSWORD)
        key.chmod(0o600)
        self.assertEqual(self.m.external_key(key), PASSWORD)
        key.chmod(0o644)
        with self.assertRaises(b.BackupError):
            self.m.external_key(key)
        inner = self.data / "key"
        inner.write_text(PASSWORD)
        inner.chmod(0o600)
        with self.assertRaises(b.BackupError):
            self.m.external_key(inner)

    async def test_scheduler_runs_using_external_key_and_writes_result(self):
        key = Path(self.tmp.name) / "schedule.key"
        key.write_text(PASSWORD)
        key.chmod(0o600)
        self.m.config = lambda: {"backups": {"interval_hours": 24, "key_file": str(key), "keep": 2}}
        started = asyncio.Event()

        async def sleep(_):
            started.set()
            await asyncio.Future()

        with patch.object(b.asyncio, "sleep", sleep):
            task = asyncio.create_task(self.m.schedule_loop())
            await started.wait()
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        await asyncio.gather(*self.m.tasks)
        rows = self.m.list()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["state"], "completed")
        self.assertTrue(rows[0]["scheduled"])
        self.assertEqual(b.read_json(self.m.root / "schedule.json")["state"], "completed")

    async def test_settings_reject_bad_retention_interval_and_missing_key(self):
        for value in ({"keep": 0}, {"interval_hours": -1}, {"interval_hours": float("nan")},
                      {"key_file": 42}, {"password": PASSWORD}, []):
            with self.assertRaises(b.BackupError):
                b.validate_options(value)
        self.assertEqual(b.validate_options({})["interval_hours"], 24)

    async def test_malicious_tar_paths_links_duplicates_versions_and_hashes(self):
        snapshot = self.m.root / "source"
        snapshot.mkdir()
        b.capture_snapshot(self.data, snapshot)
        good = b.manifest_for(snapshot, "test")

        def pack(manifest, special=None):
            raw = self.m.root / "malicious.tar"
            with tarfile.open(raw, "w") as tar:
                body = json.dumps(manifest).encode()
                info = tarfile.TarInfo("manifest.json")
                info.size = len(body)
                tar.addfile(info, io.BytesIO(body))
                for row in good["files"]:
                    body = (snapshot / row["path"]).read_bytes()
                    info = tarfile.TarInfo(row["path"])
                    info.size = len(body)
                    tar.addfile(info, io.BytesIO(body))
                if special:
                    tar.addfile(special, io.BytesIO(b"X") if special.size else None)
            enc = self.m.root / "malicious.chorus"
            enc.unlink(missing_ok=True)
            b.encrypt(raw, enc, PASSWORD)
            return enc

        for name in ("../escape", "/absolute", "files/../escape", "files\\escape", "files//x", "manifest.json"):
            with self.subTest(name=name):
                info = tarfile.TarInfo(name)
                info.size = 1
                target = self.m.root / ("bad-" + str(time.time_ns()))
                with self.assertRaises(b.BackupError):
                    b.unpack_archive(pack(good, info), PASSWORD, target)
        link = tarfile.TarInfo("files/link")
        link.type, link.linkname = tarfile.SYMTYPE, "../../config.json"
        duplicate = tarfile.TarInfo("config.json")
        duplicate.size = 1
        bad_version = {**good, "data_version": 999}
        bad_hash = json.loads(json.dumps(good))
        bad_hash["files"][0]["sha256"] = "0" * 64
        cases = [(good, link), (good, duplicate), (bad_version, None), (bad_hash, None)]
        for manifest, special in cases:
            with self.assertRaises(b.BackupError):
                b.unpack_archive(pack(manifest, special), PASSWORD, self.m.root / ("bad-" + str(time.time_ns())))

    async def test_api_auth_boundaries_and_real_http_flow(self):
        old_cfg = s.CFG
        s.CFG = {"password": "test-login"}
        self.addCleanup(setattr, s, "CFG", old_cfg)
        app = web.Application(middlewares=[s.auth])
        manager = b.register(app, self.data, lambda: {"backups": {"interval_hours": 0}})
        client = TestClient(TestServer(app))
        self.addAsyncCleanup(client.close)
        try:
            await client.start_server()
        except PermissionError:
            await client.close()
            self.addAsyncCleanup(manager.cleanup, app)
            client = InProcessClient(app)
        token = s.token()
        headers = {"Authorization": "Bearer " + token}
        self.assertEqual((await client.get("/api/backups")).status, 401)
        response = await client.post("/api/backups", headers=headers, json={"password": PASSWORD})
        self.assertEqual(response.status, 202)
        row = await response.json()
        self.assertFalse(any(r.get("scheduled") for r in manager.list()))
        await asyncio.gather(*manager.tasks)
        response = await client.get("/api/backups/" + row["id"] + "/download", headers=headers)
        self.assertEqual(response.status, 200)
        self.assertTrue((await response.read()).startswith(b.MAGIC))
        archive = manager.path("", row["id"]).with_suffix(".chorus").read_bytes()
        response = await client.put("/api/backups/import", headers=headers, data=archive)
        self.assertEqual(response.status, 201)
        imported = await response.json()
        self.assertTrue(imported["imported"])
        self.assertEqual(imported["sha256"], b.digest(manager.path("", row["id"]).with_suffix(".chorus")))
        self.assertEqual((await client.put("/api/backups/import", headers=headers, data=b"invalid" * 10)).status, 400)
        row = imported
        response = await client.post("/api/restore/plan", headers=headers,
                                     json={"backup_id": row["id"], "password": PASSWORD})
        self.assertEqual(response.status, 200)
        plan = await response.json()
        response = await client.post("/api/restore/commit", headers=headers,
                                     json={"plan_id": plan["id"], "archive_sha256": plan["archive_sha256"], "confirm_overwrite": True})
        self.assertEqual(response.status, 202)
        self.assertEqual((await response.json())["state"], "queued")
        self.assertEqual((await client.post("/api/backups", headers=headers, data='"bad"')).status, 400)
        self.assertEqual((await client.post("/api/backups", headers=headers, data=b"x" * 8193)).status, 400)

    async def test_executor_health_uses_authenticated_index(self):
        with patch.object(s, "CFG", {"password": "login-secret"}), patch.object(s, "PROJECTS", []):
            app = web.Application(middlewares=[s.auth])
            app.router.add_get("/api/hello", s.h_hello)
            app.router.add_get("/api/index", s.h_index)
            client = TestClient(TestServer(app))
            await client.start_server()
            try:
                url = str(client.make_url("/api/hello"))
                service = e.Service("systemd", "chorus.service", url, self.data)
                self.assertTrue(await asyncio.to_thread(service.healthy))
            finally:
                await client.close()
        with self.assertRaises(b.BackupError):
            e.Service("systemd", "chorus.service", "http://example.com/api/hello", self.data)

    async def test_service_adapters_use_fixed_argv_without_shell(self):
        from types import SimpleNamespace
        for mode, status in (("systemd", "inactive\n"), ("docker", "false\n")):
            with patch.object(e.subprocess, "run", return_value=SimpleNamespace(stdout=status)) as run:
                service = e.Service(mode, "target", "http://127.0.0.1:8790/api/hello", self.data)
                service.stop()
                service.start()
                self.assertEqual(run.call_args_list[0].args[0], ["systemctl" if mode == "systemd" else "docker", "stop", "target"])
                self.assertTrue(all(not call.kwargs.get("shell") for call in run.call_args_list))


class UploadTests(unittest.IsolatedAsyncioTestCase):
    async def test_video_publishes_only_after_download_and_cleans_staging(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            for n in ("tmp", "files"):
                (data / n).mkdir()
            messages = []

            async def create(*args, **kwargs):
                from types import SimpleNamespace
                path = Path(args[args.index("-o") + 1].replace("%(ext)s", "mp4"))
                path.write_bytes(b"video")

                async def out():
                    self.assertFalse(list((data / "files").iterdir()))
                    yield ("FILE " + str(path) + "\n").encode()

                async def err():
                    for x in ():
                        yield x

                async def wait():
                    return 0

                return SimpleNamespace(returncode=0, stdout=out(), stderr=err(), wait=wait)

            job = {"project": "p", "url": "https://example.test/video", "dm": "", "title": "Test"}
            with patch.object(s, "DATA", data), patch.object(s.asyncio, "create_subprocess_exec", create), patch.object(s, "add_msg", side_effect=lambda *a: messages.append(a)):
                await s.fetch_video(job)
            self.assertEqual(job["state"], "done")
            self.assertEqual(len(messages), 1)
            self.assertEqual(next((data / "files").iterdir()).read_bytes(), b"video")
            self.assertFalse(list((data / "tmp").iterdir()))

    async def test_upload_cancel_and_oversize_never_publish(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            for n in ("tmp", "files"):
                (data / n).mkdir()

            class Stream:
                def __init__(self, fail=False):
                    self.fail = fail

                async def iter_chunked(self, _):
                    yield b"part"
                    self.assert_empty()
                    if self.fail:
                        raise asyncio.CancelledError()
                    yield b"done"

                def assert_empty(self):
                    assert not list((data / "files").iterdir())

            class Request:
                match_info = {"name": "test.txt"}
                content = Stream(True)

            with patch.object(s, "DATA", data), patch.object(s, "CFG", {"max_upload_mb": 1}):
                with self.assertRaises(asyncio.CancelledError):
                    await s.h_upload(Request())
                self.assertFalse(list((data / "tmp").iterdir()))
                Request.content = Stream()
                response = await s.h_upload(Request())
                self.assertEqual(response.status, 200)
                self.assertEqual(next((data / "files").iterdir()).read_bytes(), b"partdone")
                for p in (data / "files").iterdir():
                    p.unlink()
                s.CFG["max_upload_mb"] = 0
                response = await s.h_upload(Request())
                self.assertEqual(response.status, 413)
                self.assertFalse(list((data / "files").iterdir()))
                self.assertFalse(list((data / "tmp").iterdir()))


if __name__ == "__main__":
    unittest.main()
