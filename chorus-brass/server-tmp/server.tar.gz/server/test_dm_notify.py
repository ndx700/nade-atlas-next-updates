import asyncio
import json
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import AsyncMock, patch

import dm_notify
import server as s


class Notifications(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        (root / 'chats').mkdir()
        values = dict(DATA=root, CFG={'password': 'test', 'tz': 8, 'members': [{'name': '龙娘'}, {'name': '小克'}]},
                      PROJECTS=[{'id': 'p', 'members': ['龙娘', '小克']}], CHATS={'p': []},
                      APPROVALS={}, CHANGED=asyncio.Event(), PVER={})
        for key, value in values.items():
            self.enterContext(patch.object(s, key, value))
        self.enterContext(patch.object(dm_notify, 'S', s))

    async def send(self, text='已完成检查', name='龙娘', reason='progress', link=None):
        return await dm_notify.notify_user(name, reason, text, link or {'pid': 'p'})

    async def test_limit_merge_and_restart(self):
        first = await self.send()
        self.assertEqual(first['status'], 'sent')
        self.assertEqual(first['message']['dm'], '龙娘')
        self.assertEqual((await self.send(reason='other'))['status'], 'merged')
        self.assertEqual(first['message']['notification']['count'], 2)
        s.CHATS['p'] = s.load_chat('p')  # quota and coalescing survive restart
        self.assertEqual((await self.send('检查二'))['status'], 'sent')
        self.assertEqual((await self.send('检查三'))['status'], 'sent')
        self.assertEqual((await self.send('检查四'))['status'], 'limited')
        self.assertEqual((await self.send())['status'], 'merged')
        self.assertEqual((await self.send('检查四', name='小克'))['status'], 'sent')
        for m in s.CHATS['p']:
            m['notification']['day'] = '2000-01-01'
        self.assertEqual((await self.send('检查四'))['status'], 'sent')

    async def test_muted_audited_without_consuming_quota(self):
        s.CFG['dm_prefs'] = {'龙娘': {'muted': True}}
        self.assertEqual((await self.send())['status'], 'muted')
        self.assertEqual(s.CHATS['p'], [])
        records = [json.loads(x) for x in (s.DATA / 'audit.jsonl').read_text().splitlines()]
        self.assertEqual(records[-1]['args']['status'], 'muted')

    async def test_money_and_external_require_cards_even_with_auto_approval(self):
        s.CFG['approve_all'] = True
        for text, line in [('需要购买额度', 'money'), ('发送邮件给客户', 'external')]:
            result = await self.send(text)
            self.assertEqual(result['status'], 'consent')
            m = result['message']
            self.assertEqual(m['approval']['state'], 'pending')
            self.assertEqual(m['approval']['line'], line)
            self.assertNotEqual(m['text'], text)
            a = s.APPROVALS[m['approval']['id']]
            a['future'].set_result(False)
        await asyncio.sleep(0)
        self.assertFalse(s.APPROVALS)

    async def test_reason_and_link_also_checked(self):
        self.assertEqual((await self.send(reason='payment'))['status'], 'consent')
        self.assertEqual((await self.send('检查二', link={'pid': 'p', 'action': 'send_email'}))['status'], 'consent')
        for a in list(s.APPROVALS.values()):
            a['future'].set_result(False)
        await asyncio.sleep(0)

    async def test_new_private_project_and_validation(self):
        s.PROJECTS.clear()
        result = await self.send(link='https://example.com/result')
        self.assertEqual(result['status'], 'sent')
        self.assertEqual(s.PROJECTS[0]['members'], ['龙娘'])
        with self.assertRaises(ValueError):
            await self.send(name='unknown')
        with self.assertRaises(ValueError):
            await self.send(text=' ')

    async def test_existing_approval_handler_can_decide_card(self):
        result = await self.send('需要付款')
        message = result['message']
        request = SimpleNamespace(match_info={'id': message['approval']['id']}, method='POST',
                                  json=AsyncMock(return_value={'allow': True}))
        response = await s.h_approve(request)
        self.assertEqual(response.status, 200)
        self.assertEqual(message['approval']['state'], 'allow')
        await asyncio.sleep(0)
        self.assertFalse(s.APPROVALS)
        self.assertEqual(len(s.CHATS['p']), 1)  # no automatic action or followup text

    async def test_new_risk_cannot_merge_into_previous_plain_text(self):
        self.assertEqual((await self.send())['status'], 'sent')
        self.assertEqual((await self.send(reason='payment'))['status'], 'consent')
        for a in list(s.APPROVALS.values()):
            a['future'].set_result(False)
        await asyncio.sleep(0)

    async def test_card_timeout(self):
        loop = asyncio.get_running_loop()
        timer = SimpleNamespace(cancel=lambda: None)
        with patch.object(loop, 'call_later', return_value=timer) as later:
            result = await self.send('发送邮件')
        later.call_args.args[1]()
        self.assertEqual(result['message']['approval']['state'], 'timeout')
        self.assertFalse(s.APPROVALS)
        await asyncio.sleep(0)

    async def test_hook_engine_reused_and_follows_data_directory(self):
        import hooks
        with patch.object(hooks, 'HookEngine', wraps=hooks.HookEngine) as factory:
            await self.send('first')
            engine = s._dm_hook_engine
            await self.send('second')
            self.assertIs(s._dm_hook_engine, engine)
            self.assertEqual(factory.call_count, 1)
            with tempfile.TemporaryDirectory() as other:
                with patch.object(s, 'DATA', Path(other)), patch.object(s, 'persist'), patch.object(s, 'add_msg', return_value={}):
                    await self.send('third')
                    self.assertIsNot(s._dm_hook_engine, engine)
                    self.assertEqual(factory.call_count, 2)
