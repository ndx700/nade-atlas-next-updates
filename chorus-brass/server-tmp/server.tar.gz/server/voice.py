"""Voice conversation with any AI in a 私信: push-to-talk or hands-free duplex over one WebSocket.

  client -> {"type":"start","to":name,"project":pid}   then binary audio chunks (16 kHz mono WAV/OGG/WebM)
  client -> {"type":"end"}        utterance finished (button released, or client-side VAD heard silence)
  client -> {"type":"barge"}      the user started talking over the AI: stop the answer and the speech now
  server -> {"type":"transcript","text"}  {"type":"reply","text","final"}  {"type":"audio","url","i"}
            {"type":"interrupted"}  {"type":"error","text"}
ASR is any OpenAI-compatible /audio/transcriptions (cheap: SenseVoice / whisper on a relay; set in 设置 → 语音);
TTS reuses server.tts_file (doubao / openai-compatible). The member's answer is streamed sentence by sentence into
TTS while it is still being written, so speech starts after the first sentence, not the whole answer. Both sides of
the conversation stay in the 私信 as normal messages (voice=True).
"""
from __future__ import annotations

import asyncio
import background
import json
import re

from aiohttp import ClientError, ClientSession, ClientTimeout, FormData, WSMsgType, web

SENT = re.compile(r"(.+?[。！？!?；;\n]|.+?[.](?=\s))", re.S)
MAX_AUDIO = 20 * 1024 * 1024


def sentences(buf: str) -> tuple[list[str], str]:
    """Complete sentences in buf, plus the unfinished tail."""
    out, pos = [], 0
    for m in SENT.finditer(buf):
        seg = m.group(0).strip()
        if seg:
            out.append(seg)
        pos = m.end()
    return out, buf[pos:]


async def asr(S, audio: bytes, fmt: str = "wav") -> str:
    cfg = S.CFG.get("asr") or {}
    pr = S.provider(cfg.get("provider") or (S.CFG.get("tts") or {}).get("provider") or "openai")
    if not pr or not pr.get("key"):
        raise ValueError("还没设置语音识别接口（设置 → 语音 → 识别）")
    async def attempt():
        # Multipart streams are consumed by a request; rebuild for each retry.
        form = FormData()
        form.add_field("file", audio, filename=f"speech.{fmt}", content_type=f"audio/{fmt}")
        form.add_field("model", cfg.get("model") or "whisper-1")
        if cfg.get("language"):
            form.add_field("language", cfg["language"])
        async with ClientSession(trust_env=True, timeout=ClientTimeout(total=4)) as s:
            async with s.post(pr["base"].rstrip("/") + "/audio/transcriptions", data=form,
                              headers={"Authorization": "Bearer " + pr.get("key", "")}, proxy=pr.get("proxy") or None) as r:
                if r.status >= 400:
                    raise RuntimeError(f"语音识别 HTTP {r.status}")
                j = await r.json(content_type=None)
        return (j.get("text") or "").strip()

    async with asyncio.timeout(8):
        try:
            return await asyncio.wait_for(attempt(), 4)
        except (TimeoutError, OSError, RuntimeError, ClientError):
            return await asyncio.wait_for(attempt(), 4)



class Turn:
    """One utterance -> transcript -> member answer (streamed) -> speech. Cancellable at any point (barge-in)."""

    def __init__(self, S, ws, pid, name, send_member, poll=0.12):
        self.S, self.ws, self.pid, self.name = S, ws, pid, name
        self.send_member, self.poll = send_member, poll

    async def say(self, obj):
        if not self.ws.closed:
            await self.ws.send_str(json.dumps(obj, ensure_ascii=False))

    async def run(self, audio: bytes, fmt: str):
        S = self.S
        text = await S.voice_asr(S, audio, fmt)
        if not text:
            await self.say({"type": "error", "text": "没听清，再说一遍？"})
            return
        await self.say({"type": "transcript", "text": text})
        trig = S.add_msg(self.pid, "Ali", text, self.name, voice=True)
        job = background.spawn(self.send_member(self.pid, self.name, trig, text))
        try:
            await self.speak_reply(trig, job)
        except BaseException:
            # Follow-up branches may outlive the initial answer task.
            await S.stop_round(self.pid, f"{self.pid}:{trig['seq']}")
            raise
        finally:
            if not job.done():
                job.cancel()
            await asyncio.gather(job, return_exceptions=True)

    def reply(self, trig):
        return next((m for m in self.S.CHATS.get(self.pid, []) if m.get("seq", 0) > trig["seq"] and m.get("who") == self.name
                     and m.get("dm") == self.name and not m.get("recalled")), None)

    async def speak_reply(self, trig, job):
        spoken, i, said = 0, 0, ""
        while True:
            m = self.reply(trig)
            text = (m or {}).get("text", "")
            final = job.done() and (m is None or not m.get("live"))
            new, tail = sentences(text[spoken:])
            if final and tail.strip():
                new, tail = new + [tail.strip()], ""
            for seg in new:
                said += seg
                try:
                    url = await self.S.tts_file(self.name, seg)
                    await self.say({"type": "audio", "url": url, "i": i})
                    i += 1
                except ValueError as e:
                    await self.say({"type": "error", "text": str(e)})
            spoken = len(text) - len(tail)
            if text:
                await self.say({"type": "reply", "text": text, "final": final})
            if final:
                return
            await asyncio.sleep(self.poll)


async def handle(request, S, send_member):
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=MAX_AUDIO)
    await ws.prepare(request)
    buf, pid, name, fmt, current = bytearray(), "", "", "wav", None

    async def stop_current():
        nonlocal current
        if current and not current.done():
            current.cancel()
            await asyncio.gather(current, return_exceptions=True)
            if not ws.closed:
                await ws.send_str(json.dumps({"type": "interrupted"}))
        current = None

    try:
        async for msg in ws:
            if msg.type == WSMsgType.BINARY:
                if len(buf) + len(msg.data) > MAX_AUDIO:
                    buf.clear()
                    await ws.send_str(json.dumps({"type": "error", "text": "这段话太长了"}))
                    continue
                buf.extend(msg.data)
            elif msg.type == WSMsgType.TEXT:
                try:
                    c = json.loads(msg.data)
                except ValueError:
                    continue
                t = c.get("type")
                if t == "start":
                    p = S.project(c.get("project", ""))
                    if not p or not S.member(c.get("to", "")):
                        await ws.send_str(json.dumps({"type": "error", "text": "没有这个对话"}))
                        continue
                    await stop_current()
                    pid, name, fmt = p["id"], c["to"], c.get("format", "wav")
                    buf.clear()
                elif t == "barge":
                    buf.clear()
                    await stop_current()
                elif t == "end" and name:
                    audio = bytes(buf)
                    buf.clear()
                    await stop_current()
                    if audio:
                        turn = Turn(S, ws, pid, name, send_member)

                        async def go(turn=turn, audio=audio):
                            try:
                                await turn.run(audio, fmt)
                            except asyncio.CancelledError:
                                raise
                            except Exception as e:  # noqa: BLE001 - a failed turn never kills the call
                                await turn.say({"type": "error", "text": str(e)[:120]})
                        current = background.spawn(go())
            elif msg.type == WSMsgType.ERROR:
                break
    finally:
        await stop_current()
    return ws
