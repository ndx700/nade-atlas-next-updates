"""Role/task integration tests with isolated DATA; no model calls or service control."""
import asyncio
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from aiohttp.test_utils import TestClient, TestServer
import server as s
import task_cards as tc
from test_review_fixes import Request


class Cards(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.enterContext(patch.object(s, "DATA", Path(self.tmp.name)))
        for name in ("chats", "memory", "summaries", "skills", "tmp"):
            (s.DATA / name).mkdir()
        self.enterContext(patch.object(s, "CFG", {"password": "test", "providers": [],
            "members": [{"name": "A", "role": "开发"}, {"name": "B"}], "owner": "群主"}))
        self.enterContext(patch.object(s, "PROJECTS", [{"id": pid, "name": pid, "members": ["A", "B"]} for pid in ("p", "q")]))
        for name in ("CHATS", "PVER", "STATUS", "TASK_STATUS", "LAST_RESULT", "QUOTA"):
            self.enterContext(patch.object(s, name, {}))
        self.enterContext(patch.object(s, "RESULTS", []))
        self.enterContext(patch.object(s, "VER", 0))
        self.enterContext(patch.object(s, "CHANGED", asyncio.Event()))
        self.enterContext(patch.object(__import__("chorus2"), "S", s))
        self.cards = s.cards()

    async def req(self, method, body=None, pid="p", tid=None):
        r = Request(body, pid=pid, **({"id": tid} if tid else {}))
        r.method = method
        return json.loads((await self.cards.handle(r)).body)

    async def create(self, **extra):
        return (await self.req("POST", {"title": "实现任务", **extra}))["item"]

    def proposal(self, task, **extra):
        b = {"id": task["id"], "base_revision": task["revision"], "status": "已完成", **extra}
        return "[任务候选]" + json.dumps(b, ensure_ascii=False) + "[/任务候选]"

    def reply(self, text, **extra):
        return s.add_msg("p", "A", text, **extra)

    async def test_role_save_existing_route_and_read_views(self):
        with patch.object(s, "refresh_quota", AsyncMock()):
            await s.h_member(Request({"name": "A", "owns": [str(x) for x in range(8)],
                "avoid": ["部署"], "style": "简洁", "role": "开发"}))
            await asyncio.sleep(0)
        m = s.member("A")
        self.assertEqual(len(m["owns"]), 5)
        self.assertEqual(m["role"], "开发")
        self.assertEqual(s.load(s.cfg_path(), {})["members"][0]["style"], "简洁")
        self.assertEqual(s.member_view(m)["avoid"], ["部署"])
        config = json.loads((await s.h_config(Request())).body)
        self.assertEqual(config["members"][0]["style"], "简洁")

    async def test_invalid_role_does_not_mutate_member_or_add_one(self):
        for body in ({"name": "A", "role": "changed", "owns": "bad"},
                     {"name": "New", "avoid": [17]}, {"name": "A", "style": "a" * 301}):
            with self.assertRaises(s.web.HTTPBadRequest):
                await s.h_member(Request(body))
        self.assertEqual(s.member("A")["role"], "开发")
        self.assertIsNone(s.member("New"))

    async def test_roles_in_group_and_private_prompts(self):
        s.member("A").update(owns=["后端"], avoid=["发布"], style="简短")
        s.member("B").update(owns=["客户端"])
        for dm in ("", "A"):
            sysp, _, _ = s.build_prompt("p", "A", {"text": "hi", "dm": dm}, False)
            for expected in ("后端", "发布", "简短"):
                self.assertIn(expected, sysp)
            if not dm:
                self.assertIn("客户端", sysp)

    async def test_create_update_delete_and_persistence(self):
        task = await self.create(owner="A")
        self.assertEqual((task["status"], task["revision"]), ("待办", 1))
        updated = (await self.req("PATCH", {"revision": 1, "status": "进行中"}, tid=task["id"]))["item"]
        self.assertEqual(updated["revision"], 2)
        self.assertEqual(tc.TaskCards(s).read("p")["items"], [updated])
        await self.req("DELETE", tid=task["id"])
        self.assertEqual(self.cards.read("p")["items"], [])
        self.assertEqual([x["action"] for x in self.cards.read_audit("p")], ["create", "update", "delete"])

    async def test_project_and_path_isolation(self):
        task = await self.create()
        self.assertEqual((await self.req("GET", pid="q"))["items"], [])
        for pid in ("missing", "../p", "p/../q"):
            with self.assertRaises(s.web.HTTPNotFound):
                await self.req("POST", {"title": "x"}, pid=pid)
        with self.assertRaises(s.web.HTTPNotFound):
            await self.req("PATCH", {"revision": 1, "status": "已完成"}, pid="q", tid=task["id"])

    async def test_fields_validate_status_owner_sources(self):
        s.add_msg("q", "Ali", "only other room", seq=42)
        private = s.add_msg("p", "Ali", "private", dm="A")
        for fields in ({"status": "done"}, {"owner": "outsider"}, {"title": ""},
                       {"source_message_ids": [42]}, {"source_message_ids": [private["seq"]]},
                       {"source_message_ids": [True]}):
            with self.assertRaises(s.web.HTTPBadRequest):
                await self.create(**fields)
        msg = self.reply("public")
        self.assertEqual((await self.create(source_message_ids=[msg["seq"]]))["source_message_ids"], [msg["seq"]])

    async def test_proposal_waits_for_confirmation_and_deduplicates(self):
        task = await self.create()
        reply = self.reply(self.proposal(task))
        self.assertEqual(self.cards.propose("p", reply), 1)
        self.assertEqual(tc.TaskCards(s).propose("p", reply), 0)
        data = self.cards.read("p")
        self.assertEqual(data["items"][0]["status"], "待办")
        self.assertEqual(data["proposals"][0]["state"], "pending")
        cid = data["proposals"][0]["id"]
        result = await self.req("PATCH", {"action": "confirm", "proposal_id": cid}, tid=task["id"])
        self.assertEqual(result["item"]["status"], "已完成")
        self.assertEqual(result["item"]["source_message_ids"], [reply["seq"]])
        self.assertEqual(self.cards.read_audit("p")[-1]["proposal_id"], cid)
        with self.assertRaises(s.web.HTTPConflict):
            await self.req("PATCH", {"action": "confirm", "proposal_id": cid}, tid=task["id"])

    async def test_ai_cannot_create_delete_or_confirm(self):
        task = await self.create()
        for changes in ({"id": "new"}, {"state": "confirmed"}, {"action": "delete"},
                        {"confirmed_by": "Ali"}, {"source_message_ids": [99]}, {"title": "overwrite"}):
            self.assertEqual(self.cards.propose("p", self.reply(self.proposal(task, **changes))), 0)
        self.assertEqual(len(self.cards.read("p")["items"]), 1)

    async def test_stale_updates_and_stale_confirm_are_conflicts(self):
        task = await self.create()
        self.cards.propose("p", self.reply(self.proposal(task)))
        cid = self.cards.read("p")["proposals"][0]["id"]
        await self.req("PATCH", {"revision": 1, "owner": "B"}, tid=task["id"])
        for body in ({"revision": 1, "status": "已完成"}, {"status": "已完成"},
                     {"action": "confirm", "proposal_id": cid}):
            with self.assertRaises(s.web.HTTPConflict):
                await self.req("PATCH", body, tid=task["id"])
        self.assertEqual(self.cards.propose("p", self.reply(self.proposal(task))), 0)

    async def test_reject_and_delete_obsolete(self):
        task = await self.create()
        self.cards.propose("p", self.reply(self.proposal(task)))
        cid = self.cards.read("p")["proposals"][0]["id"]
        await self.req("PATCH", {"action": "reject", "proposal_id": cid}, tid=task["id"])
        self.assertEqual(self.cards.read("p")["items"][0]["status"], "待办")
        self.cards.propose("p", self.reply(self.proposal(task)))
        await self.req("DELETE", tid=task["id"])
        self.assertEqual([x["state"] for x in self.cards.read("p")["proposals"]], ["rejected", "obsolete"])

    async def test_recalled_source_cannot_be_confirmed(self):
        task = await self.create()
        reply = self.reply(self.proposal(task))
        self.cards.propose("p", reply)
        cid = self.cards.read("p")["proposals"][0]["id"]
        reply["recalled"] = True
        with self.assertRaises(s.web.HTTPBadRequest):
            await self.req("PATCH", {"action": "confirm", "proposal_id": cid}, tid=task["id"])

    async def test_ignore_live_failed_stopped_private_unpersisted_and_code_samples(self):
        task = await self.create()
        text = self.proposal(task)
        for extra in ({"live": True}, {"failed": True}, {"stopped": True}, {"dm": "A"}):
            self.assertEqual(self.cards.propose("p", self.reply(text, **extra)), 0)
        self.assertEqual(self.cards.propose("p", {"who": "A", "text": text, "seq": 1000}), 0)
        for text in ("```json\n" + text + "\n```", "[任务候选]bad[/任务候选]", self.proposal(task, base_revision=True)):
            self.assertEqual(self.cards.propose("p", self.reply(text)), 0)

    async def test_superseded_relations_cannot_cross_room_or_cycle(self):
        first = await self.create()
        second = await self.create()
        await self.req("PATCH", {"revision": 1, "superseded_by": second["id"]}, tid=first["id"])
        with self.assertRaises(s.web.HTTPBadRequest):
            await self.req("PATCH", {"revision": 1, "superseded_by": first["id"]}, tid=second["id"])
        with self.assertRaises(s.web.HTTPConflict):
            await self.req("DELETE", tid=second["id"])
        with self.assertRaises(s.web.HTTPBadRequest):
            await self.create(superseded_by="missing")

    async def test_prompt_contains_confirmed_tasks_only_not_candidate_status(self):
        task = await self.create()
        self.cards.propose("p", self.reply(self.proposal(task)))
        prompt = self.cards.prompt("p").split("\n若要")[0]
        self.assertIn('"status": "待办"', prompt)
        self.assertNotIn('"status": "已完成"', prompt)
        sysp, _, _ = s.build_prompt("p", "A", {"text": "hi", "dm": "A"}, False)
        self.assertNotIn("已确认任务", sysp)

    async def test_real_answer_persists_before_proposing_and_parser_failure_isolated(self):
        task = await self.create()
        trigger = s.add_msg("p", "Ali", "start")
        async def api(pid, member, reply, *args):
            reply["text"] = self.proposal(task)
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", AsyncMock()), patch.object(s, "dispatch"):
            await s.answer("p", "A", trigger, {})
            await asyncio.sleep(0)
        self.assertEqual(len(self.cards.read("p")["proposals"]), 1)
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", AsyncMock()), patch.object(s, "dispatch") as dispatch, patch.object(tc.TaskCards, "propose", side_effect=OSError("disk")):
            await s.answer("p", "A", trigger, {})
            await asyncio.sleep(0)
            dispatch.assert_called_once()
        self.assertFalse(s.CHATS["p"][-1].get("failed"))
        self.assertEqual(len(s.load_chat("p")), 3)

    async def test_http_auth_and_new_routes(self):
        app = s.make_app()
        app.on_startup.clear()
        async with TestClient(TestServer(app)) as client:
            for method, path, data in (("GET", "/api/tasks/p", None), ("POST", "/api/tasks/p", {"title": "x"}),
                                       ("PATCH", "/api/tasks/p/missing", {}), ("DELETE", "/api/tasks/p/missing", None)):
                r = await client.request(method, path, json=data)
                self.assertEqual(r.status, 401)
            client.session.headers.update(Authorization="Bearer " + s.token())
            r = await client.post("/api/tasks/p", json={"title": "from client"})
            self.assertEqual(r.status, 201)
            task = (await r.json())["item"]
            r = await client.patch("/api/tasks/p/" + task["id"], json={"revision": 1, "status": "卡住"})
            self.assertEqual(r.status, 200)
            r = await client.get("/api/tasks/missing")
            self.assertEqual(r.status, 404)

    async def test_corrupt_store_never_silently_overwritten(self):
        await self.create()
        self.cards.path("p").write_text("broken")
        with self.assertRaises(ValueError):
            await self.create()
        self.assertEqual(self.cards.path("p").read_text(), "broken")

    async def test_encrypted_backup_roundtrip_includes_roles_tasks_candidates_audit(self):
        import backup
        task = await self.create()
        s.member("A").update(owns=["后端"], style="简短")
        s.save_cfg()
        s.save(s.DATA / "projects.json", s.PROJECTS)
        self.cards.propose("p", self.reply(self.proposal(task)))
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            snapshot = tmp / "snapshot"
            snapshot.mkdir()
            backup.capture_snapshot(s.DATA, snapshot)
            archive, stage = tmp / "backup.chorus", tmp / "stage"
            backup.make_archive(snapshot, archive, "long test password 123", "test")
            backup.unpack_archive(archive, "long test password 123", stage)
            self.assertEqual(s.load(stage / "tasks/p.json", {}), self.cards.read("p"))
            self.assertEqual(s.load(stage / "config.json", {})["members"][0]["owns"], ["后端"])
        self.assertEqual(self.cards.path("p").relative_to(s.DATA).as_posix(), "tasks/p.json")
        self.assertEqual(task["status"], "待办")


if __name__ == "__main__":
    unittest.main()
