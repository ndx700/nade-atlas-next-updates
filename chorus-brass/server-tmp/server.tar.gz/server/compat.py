"""Python 3.10 兼容：asyncio.timeout 是 3.11 才有的。"""
import asyncio

if hasattr(asyncio, "timeout"):
    timeout = asyncio.timeout
else:
    class timeout:
        def __init__(self, delay):
            self.delay, self._fired, self._h, self._task = delay, False, None, None

        async def __aenter__(self):
            self._task = asyncio.current_task()
            self._h = asyncio.get_running_loop().call_later(self.delay, self._fire)
            return self

        def _fire(self):
            self._fired = True
            self._task.cancel()

        async def __aexit__(self, et, ev, tb):
            self._h.cancel()
            if self._fired and et is asyncio.CancelledError:
                raise asyncio.TimeoutError() from None
            return False
