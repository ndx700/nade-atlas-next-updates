import unittest
from types import SimpleNamespace
import server as s


class Throttle(unittest.TestCase):
    def test_backoff_after_ten_failures(self):
        req = SimpleNamespace(app={}, headers={}, remote="1.2.3.4")
        for _ in range(9):
            self.assertFalse(s.auth_throttled(req, record=True))
        self.assertTrue(s.auth_throttled(req, record=True))
        other = SimpleNamespace(app=req.app, headers={}, remote="5.6.7.8")
        self.assertFalse(s.auth_throttled(other))


if __name__ == "__main__":
    unittest.main()
