"""Offline unit tests for server.manifest (task card N4).

Run with either::

    python -m unittest server.test_manifest
    pytest server/test_manifest.py

No network access is required; all fixtures live in a temporary directory.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path

from manifest import (
    ArtifactManifest,
    ManifestIntegrityError,
    ManifestNotFoundError,
    ManifestRegistry,
    register_artifact,
    resolve_inputs,
    sha256_bytes,
    sha256_file,
    verify_artifact,
)


def run(coro):
    """Run ``coro`` to completion on a fresh event loop (sync test helper)."""
    return asyncio.run(coro)


class ManifestTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.store = self.root / "manifest.json"
        self.registry = ManifestRegistry(self.store)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    # -- helpers ---------------------------------------------------------
    def _write(self, name: str, content: bytes) -> Path:
        p = self.root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content)
        return p


class TestSha256(ManifestTestCase):
    def test_sha256_bytes_matches_hashlib(self) -> None:
        data = b"chorus artifact payload"
        self.assertEqual(sha256_bytes(data), hashlib.sha256(data).hexdigest())

    def test_sha256_file_matches_hashlib(self) -> None:
        p = self._write("a.bin", b"hello world")
        self.assertEqual(sha256_file(p), hashlib.sha256(b"hello world").hexdigest())


class TestRegister(ManifestTestCase):
    def test_register_computes_sha256_and_bytes(self) -> None:
        payload = b"# report\ncontent\n"
        p = self._write("report.md", payload)

        manifest = run(
            self.registry.register(
                path=p,
                seg="seg-3",
                producer="member-a",
                checks={"passed": True, "at": 1790000000},
                refs=["art_prev"],
                created_at=1790000000,
            )
        )

        self.assertTrue(manifest.id.startswith("art_"))
        self.assertEqual(manifest.seg, "seg-3")
        self.assertEqual(manifest.producer, "member-a")
        self.assertEqual(manifest.sha256, hashlib.sha256(payload).hexdigest())
        self.assertEqual(manifest.bytes, len(payload))
        self.assertEqual(manifest.mime, "text/markdown")
        self.assertEqual(manifest.refs, ["art_prev"])
        self.assertEqual(manifest.created_at, 1790000000)
        self.assertTrue(manifest.passed)
        self.assertEqual(manifest.checked_at, 1790000000)

    def test_register_persists_to_disk(self) -> None:
        p = self._write("a.txt", b"abc")
        m = run(self.registry.register(path=p, seg="seg-1", producer="m"))

        raw = json.loads(self.store.read_text("utf-8"))
        self.assertEqual(raw["version"], 1)
        self.assertIn(m.id, raw["artifacts"])
        self.assertEqual(raw["artifacts"][m.id]["sha256"], m.sha256)

    def test_register_missing_file_raises(self) -> None:
        with self.assertRaises(FileNotFoundError):
            run(self.registry.register(path=self.root / "nope.md", seg="s", producer="m"))

    def test_register_explicit_id_overwrites(self) -> None:
        p1 = self._write("v1.txt", b"one")
        p2 = self._write("v2.txt", b"two")
        m1 = run(self.registry.register(path=p1, seg="s", producer="m", artifact_id="art_fixed"))
        m2 = run(self.registry.register(path=p2, seg="s", producer="m", artifact_id="art_fixed"))
        self.assertEqual(m1.id, m2.id)
        self.assertNotEqual(m1.sha256, m2.sha256)
        got = run(self.registry.get("art_fixed"))
        self.assertEqual(got.sha256, m2.sha256)


class TestVerify(ManifestTestCase):
    def test_verify_passes_for_untouched_file(self) -> None:
        p = self._write("a.txt", b"stable")
        m = run(self.registry.register(path=p, seg="s", producer="m"))
        verified = run(self.registry.verify(m.id))
        self.assertEqual(verified.sha256, m.sha256)

    def test_verify_detects_tampering(self) -> None:
        p = self._write("a.txt", b"original")
        m = run(self.registry.register(path=p, seg="s", producer="m"))
        p.write_bytes(b"tampered!")

        with self.assertRaises(ManifestIntegrityError) as ctx:
            run(self.registry.verify(m.id))
        self.assertEqual(ctx.exception.artifact_id, m.id)
        self.assertEqual(ctx.exception.expected, m.sha256)
        self.assertNotEqual(ctx.exception.actual, m.sha256)

    def test_verify_missing_file_raises(self) -> None:
        p = self._write("a.txt", b"x")
        m = run(self.registry.register(path=p, seg="s", producer="m"))
        p.unlink()
        with self.assertRaises(FileNotFoundError):
            run(self.registry.verify(m.id))

    def test_verify_unknown_id_raises(self) -> None:
        with self.assertRaises(ManifestNotFoundError):
            run(self.registry.verify("art_missing"))


class TestResolveInputs(ManifestTestCase):
    def test_resolve_returns_signature_checks_and_digest(self) -> None:
        p = self._write("report.md", b"# hi")
        m = run(
            self.registry.register(
                path=p,
                seg="seg-3",
                producer="member-a",
                checks={"passed": True, "at": 1790000000},
                created_at=1790000000,
            )
        )

        result = run(self.registry.resolve([m.id]))
        self.assertEqual(result["warnings"], [])
        self.assertEqual(len(result["artifacts"]), 1)
        entry = result["artifacts"][0]
        self.assertEqual(entry["id"], m.id)
        self.assertEqual(entry["sha256"], m.sha256)
        self.assertEqual(entry["checks"], {"passed": True, "at": 1790000000})
        self.assertEqual(entry["path"], str(p))
        self.assertEqual(entry["bytes"], len(b"# hi"))

    def test_resolve_missing_manifest_falls_back_to_legacy_path_with_warning(self) -> None:
        legacy = self._write("legacy.txt", b"legacy content")
        result = run(
            self.registry.resolve(
                ["art_legacy"],
                legacy_paths={"art_legacy": legacy},
            )
        )
        self.assertEqual(len(result["artifacts"]), 1)
        entry = result["artifacts"][0]
        self.assertTrue(entry["legacy"])
        self.assertEqual(entry["sha256"], hashlib.sha256(b"legacy content").hexdigest())
        self.assertEqual(len(result["warnings"]), 1)
        self.assertIn("manifest missing", result["warnings"][0])
        self.assertIn("art_legacy", result["warnings"][0])

    def test_resolve_unknown_id_without_legacy_path_warns(self) -> None:
        result = run(self.registry.resolve(["art_ghost"]))
        self.assertEqual(result["artifacts"], [])
        self.assertEqual(len(result["warnings"]), 1)
        self.assertIn("art_ghost", result["warnings"][0])

    def test_resolve_mixed_known_and_legacy(self) -> None:
        p = self._write("known.md", b"known")
        m = run(self.registry.register(path=p, seg="s", producer="m"))
        legacy = self._write("legacy.bin", b"legacy")

        result = run(
            self.registry.resolve(
                [m.id, "art_legacy", "art_ghost"],
                legacy_paths={"art_legacy": legacy},
            )
        )
        self.assertEqual(len(result["artifacts"]), 2)
        self.assertEqual(len(result["warnings"]), 2)
        ids = {a["id"] for a in result["artifacts"]}
        self.assertEqual(ids, {m.id, "art_legacy"})


class TestModuleLevelApi(ManifestTestCase):
    def test_register_verify_resolve_via_default_registry(self) -> None:
        import manifest as manifest_mod

        # Point the shared registry at a temp store for this test.
        manifest_mod.default_registry(self.store)
        try:
            p = self._write("api.md", b"api payload")
            m = run(
                register_artifact(
                    path=p,
                    seg="seg-9",
                    producer="member-b",
                    checks={"passed": True, "at": 1790000001},
                )
            )
            verified = run(verify_artifact(m.id))
            self.assertEqual(verified.id, m.id)

            result = run(resolve_inputs([m.id]))
            self.assertEqual(result["warnings"], [])
            self.assertEqual(result["artifacts"][0]["id"], m.id)
        finally:
            # Reset so other tests are unaffected.
            manifest_mod._DEFAULT_REGISTRY = None


class TestPersistenceAcrossInstances(ManifestTestCase):
    def test_new_registry_instance_sees_existing_store(self) -> None:
        p = self._write("persist.md", b"persist me")
        m = run(self.registry.register(path=p, seg="s", producer="m"))

        second = ManifestRegistry(self.store)
        got = run(second.get(m.id))
        self.assertEqual(got.sha256, m.sha256)
        self.assertEqual(got.bytes, m.bytes)

    def test_corrupted_store_is_treated_as_empty(self) -> None:
        self.store.write_text("{not json", "utf-8")
        second = ManifestRegistry(self.store)
        with self.assertRaises(ManifestNotFoundError):
            run(second.get("art_any"))


class TestConcurrency(ManifestTestCase):
    def test_concurrent_registers_all_persist(self) -> None:
        async def go() -> list[str]:
            paths = []
            for i in range(8):
                p = self._write(f"f{i}.bin", f"payload-{i}".encode())
                paths.append(p)
            results = await asyncio.gather(
                *[
                    self.registry.register(path=p, seg=f"seg-{i}", producer="m")
                    for i, p in enumerate(paths)
                ]
            )
            return [r.id for r in results]

        ids = run(go())
        self.assertEqual(len(set(ids)), 8)
        raw = json.loads(self.store.read_text("utf-8"))
        self.assertEqual(len(raw["artifacts"]), 8)


class TestArtifactManifestModel(unittest.TestCase):
    def test_from_dict_roundtrip(self) -> None:
        data = {
            "id": "art_x",
            "seg": "seg-3",
            "producer": "member-name",
            "path": "work/p1/deliverable/report.md",
            "sha256": "0" * 64,
            "mime": "text/markdown",
            "bytes": 12345,
            "checks": {"passed": True, "at": 1790000000},
            "refs": ["art_a", "art_b"],
            "created_at": 1790000000,
        }
        m = ArtifactManifest.from_dict(data)
        self.assertEqual(m.to_dict(), data)
        self.assertTrue(m.passed)
        self.assertEqual(m.checked_at, 1790000000)
        sig = m.signature()
        self.assertEqual(sig["id"], "art_x")
        self.assertEqual(sig["sha256"], "0" * 64)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
