import os as _os
_os.environ.setdefault("CHORUS_CONSENT", "off")  # 定音由 test_collab_api 单独覆盖
"""Integration tests for the chorus2 glue: real aiohttp routes + the real 协奏 loop with fake members."""
import asyncio
import pathlib
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

import chorus2 as c
import server as s
import wakegraph


def seg(i, **kw):
    d = {"id": f"s{i}", "title": f"段{i}", "goal": "g", "deliverable": "d", "acceptance": ["ok"], "checks": [{"type": "file_exists", "path": f"结果{i}.txt"}], "inputs": [],
         "difficulty": 1, "stage": "waiting", "assignee": "", "todo": [], "events": []}
    d.update(kw)
    return d


class Base(unittest.IsolatedAsyncioTestCase):
    # Handler/scheduler tests can opt out of opening a TCP listener.
    no_http_tests = frozenset()

    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        data = pathlib.Path(self.tmp.name)
        for n in ("chats", "files", "tmp", "work", "memory", "summaries", "skills"):
            (data / n).mkdir()
        keys = ("CFG", "PROJECTS", "DATA", "CHATS", "TASK_STATUS", "run_member", "save_cfg", "save")
        self.saved = {k: getattr(s, k) for k in keys}
        self.addCleanup(lambda: [setattr(s, k, v) for k, v in self.saved.items()])
        s.DATA = data
        s.CFG = {"password": "pw", "members": [
            {"name": "强", "kind": "api", "provider": "p1", "model": "big-pro", "auto": True},
            {"name": "甲", "kind": "api", "provider": "p2", "model": "flash", "auto": True},
            {"name": "乙", "kind": "api", "provider": "p2", "model": "flash", "auto": True}],
            "providers": [{"id": "p1", "base": "x", "key": ""}, {"id": "p2", "base": "y", "key": ""}]}
        s.save_cfg = lambda: None
        s.save = lambda *a, **k: None
        s.PROJECTS = [{"id": "p", "name": "P", "members": ["强", "甲", "乙"], "mode": "concerto",
                       "segments": [], "lead_resolved": "强"}]
        s.CHATS = {}
        s.TASK_STATUS = {}
        c.GRAPH = wakegraph.Graph()
        for d in (c.QUOTA2, c.LAST_ERROR, c.INVITES, c.RUNNING, c.MEMBER_STATE, c.STATE_AT, c.LEAD_BUSY, c.HISTORY):
            d.clear()
        self.behaviour = {}
        self.calls = []
        self.verdicts = []

        async def fake_run(pid, name, trig, opts):
            self.calls.append(name)
            st = {"task_id": str(len(self.calls)), "pid": pid, "since": time.time(), "todo": [["a", True]]}
            if trig.get("review"):
                s.add_msg(pid, name, self.verdicts.pop(0) if self.verdicts else "PASS", reply_to=trig["seq"])
                st.update(outcome="succeeded", error_code="")
            else:
                plan = self.behaviour.get(name) or ["ok"]
                b = plan.pop(0) if len(plan) > 1 else plan[0]
                if b == "ok":
                    filename = "结果" + str(trig.get("seg", "s1"))[1:] + ".txt"
                    pathlib.Path(c.SEGMENT_CWD.get(), filename).write_text("verified output")
                    s.add_msg(pid, name, f"完成了 [产物]{filename}[/产物]", reply_to=trig["seq"])
                    st.update(outcome="succeeded", error_code="")
                else:
                    c.note_reply(name, b[1], None, b[2])
                    st.update(outcome="failed", error_code="")
            s.TASK_STATUS.setdefault(name, {})[st["task_id"]] = st
        s.run_member = fake_run

        async def fake_ask(m, system, prompt, pid=None):
            self.calls.append("ask:" + m["name"])
            return self.verdicts.pop(0) if self.verdicts else "PASS"
        orig = c.ask_model
        type(self).orig_ask = staticmethod(orig)
        c.ask_model = fake_ask
        self.addCleanup(setattr, c, "ask_model", orig)
        app = web.Application(middlewares=[s.auth])
        c.register(app, s)
        app.cleanup_ctx.clear()
        if self._testMethodName in self.no_http_tests:
            return
        self.client = TestClient(TestServer(app))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)
        self.h = {"Authorization": "Bearer " + s.token()}

    async def run_all(self):
        c.start("p")
        t = c.RUNNING.get("p")
        if t:
            await asyncio.wait_for(t, 10)

    def P(self):
        return s.project("p")


class TestRoutes(Base):
    async def test_auth_required(self):
        self.assertEqual((await self.client.get("/api/orchestra/p")).status, 401)
        self.assertEqual((await self.client.get("/api/orchestra/nope", headers=self.h)).status, 404)
        self.assertEqual((await self.client.get("/api/orchestra/p", headers=self.h)).status, 200)

    async def test_invite_single_use_conflict_expiry(self):
        code = (await (await self.client.post("/api/invite", headers=self.h)).json())["code"]
        r = await self.client.post("/api/invite/redeem", json={"code": code.lower(), "name": "新人", "kind": "cli", "cmd": "claude -p"})
        self.assertEqual(r.status, 400)  # 邀请码不能提交在本机执行的命令
        r = await self.client.post("/api/invite/redeem", json={"code": code.lower(), "name": "新人"})
        self.assertEqual(r.status, 200)
        self.assertEqual(s.member("新人")["kind"], "api")
        self.assertEqual((await self.client.post("/api/invite/redeem", json={"code": code, "name": "再来"})).status, 403)
        code2 = (await (await self.client.post("/api/invite", headers=self.h)).json())["code"]
        self.assertEqual((await self.client.post("/api/invite/redeem", json={"code": code2, "name": "甲"})).status, 409)
        code3 = (await (await self.client.post("/api/invite", headers=self.h)).json())["code"]
        c.INVITES[code3]["expires"] = time.time() - 1
        self.assertEqual((await self.client.post("/api/invite/redeem", json={"code": code3, "name": "晚"})).status, 403)

    async def test_policy_preset_never_touches_illegal(self):
        r = await self.client.put("/api/members/甲/policy", headers=self.h,
                                  json={"preset": "all", "policy": {"illegal": "auto", "delete": "deny", "bogus": "auto", "money": "maybe"}})
        pol = (await r.json())["policy"]
        self.assertNotIn("illegal", pol)
        self.assertEqual(pol["delete"], "deny")
        self.assertEqual(pol["money"], "auto")
        self.assertNotIn("illegal", s.member("甲")["policy"])
        self.assertEqual((await self.client.put("/api/members/无/policy", headers=self.h, json={})).status, 404)

    async def test_gate(self):
        self.assertEqual(c.gate("Bash", {"command": "ls"}, "甲", "p")[0], "allow")
        self.assertEqual(c.gate("Bash", {"command": "git push --force origin main"}, "甲", "p")[0], "ask")
        s.member("甲")["policy"] = {"git_force": "auto", "illegal": "auto"}
        self.assertEqual(c.gate("Bash", {"command": "git push --force origin main"}, "甲", "p")[0], "allow")
        self.assertTrue(any("自动同意" in a["text"] for a in s.CFG["audit"]))
        self.assertEqual(c.gate("Bash", {"command": "masscan 8.8.8.0/24"}, "甲", "p")[0], "deny")
        s.member("甲")["policy"] = {"git_force": "deny"}
        self.assertEqual(c.gate("Bash", {"command": "git push --force origin main"}, "甲", "p")[0], "deny")

    async def test_trash_restore_purge(self):
        self.P()["archived"] = True
        items = (await (await self.client.get("/api/trash", headers=self.h)).json())["items"]
        self.assertEqual([i["id"] for i in items], ["p"])
        self.assertEqual((await self.client.post("/api/trash/p", headers=self.h)).status, 200)
        self.assertFalse(self.P().get("archived"))
        self.assertEqual((await self.client.delete("/api/trash/p", headers=self.h)).status, 404)
        self.P()["archived"] = True
        self.assertEqual((await self.client.delete("/api/trash/p", headers=self.h)).status, 200)
        self.assertIsNone(s.project("p"))

    async def test_arrears_error_marks_quota(self):
        c.note_reply("甲", 402, None, '{"error":"Insufficient Balance"}')
        self.assertEqual(c.QUOTA2["甲"]["state"], "arrears")


class TestConcerto(Base):
    no_http_tests = {"test_ladder_exhausted_asks_then_decide"}

    async def test_happy_path_parallel_then_dependent(self):
        self.P()["segments"] = [seg(1), seg(2), seg(3, inputs=["s1", "s2"])]
        await self.run_all()
        v = await (await self.client.get("/api/orchestra/p", headers=self.h)).json()
        self.assertEqual([x["stage"] for x in self.P()["segments"]], ["done"] * 3)
        self.assertEqual(v["pct"], 100.0)
        self.assertNotIn("强", self.calls)
        self.assertTrue(v["flow"]["edges"])

    async def test_arrears_reassigns(self):
        self.P()["segments"] = [seg(1, assignee="甲")]
        self.behaviour["甲"] = [("err", 402, "Insufficient Balance")]
        await self.run_all()
        sg = self.P()["segments"][0]
        self.assertEqual(sg["stage"], "done")
        self.assertNotEqual(sg["assignee"], "甲")
        self.assertEqual(sg["ladder"][0]["step"], "reassign")

    async def test_review_fix_then_pass_updates_pass_rate(self):
        self.P()["segments"] = [seg(1, difficulty=5, assignee="甲")]
        self.verdicts = ["FIX: 缺测试", "PASS"]
        await self.run_all()
        sg = self.P()["segments"][0]
        self.assertEqual(sg["stage"], "done")
        self.assertIn("feedback_retry", [x["step"] for x in sg["ladder"]])
        self.assertEqual(self.calls.count("甲"), 2)
        self.assertEqual(s.CFG["member_stats"]["甲"]["reviews"], 2)
        self.assertLess(s.CFG["member_stats"]["甲"]["pass"], 0.8)

    async def test_cli_lead_reviews_through_run_member(self):
        s.member("强").update(kind="cli", provider="")
        self.P()["segments"] = [seg(1, difficulty=5, assignee="甲")]
        self.verdicts = ["FIX: 不对", "PASS"]
        await self.run_all()
        self.assertEqual(self.P()["segments"][0]["stage"], "done")
        self.assertEqual(self.calls.count("强"), 2)
        self.assertFalse([x for x in self.calls if x.startswith("ask:")])

    async def test_ladder_exhausted_asks_then_decide(self):
        for m in ("甲", "乙", "强"):
            self.behaviour[m] = [("err", 401, "invalid api key")]
        self.P()["segments"] = [seg(1, difficulty=5, assignee="甲")]
        await self.run_all()
        self.assertEqual(self.P()["segments"][0]["stage"], "blocked")
        pend = [d for d in self.P()["pending"] if d["state"] == "open"]
        self.assertEqual(len(pend), 1)
        self.assertEqual(pend[0]["kind"], "ladder_exhausted")
        self.assertEqual(pend[0]["options"][1], "跳过这一段")
        calls_before = list(self.calls)
        request = SimpleNamespace(match_info={"pid": "p"}, json=AsyncMock(
            return_value={"id": pend[0]["id"], "choice": 1}))
        r = await c.h_decide(request)
        self.assertEqual(r.status, 200)
        task = c.RUNNING.get("p")
        if task:
            await asyncio.wait_for(task, 10)
        # A deliberate skip is terminal, but must not claim successful output.
        self.assertEqual(self.P()["segments"][0]["stage"], "skipped")
        self.assertTrue(self.P()["segments"][0]["skipped"])
        self.assertEqual(pend[0]["state"], "done")
        self.assertEqual(pend[0]["choice"], 1)
        self.assertEqual(self.calls, calls_before)

    async def test_budget_stop_blocks_without_calls(self):
        self.P()["segments"] = [seg(1)]
        self.P()["budget"] = {"cap": 1.0, "cur": "¥"}
        orig = c.orchestra.budget_state
        c.orchestra.budget_state = lambda p: {"spent": 5.0, "cap": 1.0}
        self.addCleanup(setattr, c.orchestra, "budget_state", orig)
        await self.run_all()
        self.assertEqual(self.P()["segments"][0]["stage"], "blocked")
        self.assertEqual(self.calls, [])

    async def test_pause_then_resume(self):
        self.P()["segments"] = [seg(1)]
        await self.client.post("/api/orchestra/p/pause", headers=self.h)
        await self.run_all()
        self.assertEqual(self.calls, [])
        await self.client.post("/api/orchestra/p/resume", headers=self.h)
        t = c.RUNNING.get("p")
        if t:
            await asyncio.wait_for(t, 10)
        self.assertEqual(self.P()["segments"][0]["stage"], "done")


if __name__ == "__main__":
    unittest.main()


class TestNight(Base):
    async def test_confirm_required_and_scope(self):
        body = {"enabled": True, "lines": ["git_force", "illegal", "money"], "spend_cap": 5, "window": [0, 0]}
        r = await self.client.put("/api/orchestra/p/night", headers=self.h, json=body)
        self.assertEqual(r.status, 409)
        text = (await r.json())["confirm"]
        self.assertIn("违法和底线动作仍然一律拦下", text)
        self.assertNotIn("违法", text.split("：")[1].split("；")[0])  # illegal is not in the granted list
        r = await self.client.put("/api/orchestra/p/night", headers=self.h, json={**body, "confirm": text})
        self.assertEqual(r.status, 200)
        self.assertEqual(c.gate("Bash", {"command": "git push --force origin main"}, "甲", "p")[0], "allow")
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "甲", "p")[0], "ask")  # perms not granted
        self.assertEqual(c.gate("Bash", {"command": "masscan 8.8.8.0/24"}, "甲", "p")[0], "deny")
        o = await (await self.client.get("/api/orchestra/p/overture", headers=self.h)).json()
        self.assertEqual(len(o["night_approvals"]), 1)

    async def test_window_and_spend_cap(self):
        self.P()["night"] = {"enabled": True, "confirmed_at": 1, "lines": ["money"], "spend_cap": 2, "window": [23, 7], "spent": 0}
        day = time.mktime((2026, 10, 30, 12, 0, 0, 0, 0, -1)) - (s.CFG.get("tz", 8) * 3600 - (-time.timezone))
        noon = c.local_hour(day)
        self.assertFalse(c.night_covers("p", "money", day) if not (noon >= 23 or noon < 7) else False)
        night = day + ((24 - noon) % 24) * 3600  # local midnight
        self.assertTrue(c.night_covers("p", "money", night))
        self.P()["night"]["spent"] = 2
        self.assertFalse(c.night_covers("p", "money", night))
        self.assertFalse(c.night_covers("p", "illegal", night))

    async def test_disable_needs_no_confirm(self):
        r = await self.client.put("/api/orchestra/p/night", headers=self.h, json={"enabled": False, "lines": []})
        self.assertEqual(r.status, 200)
        self.assertFalse(c.night_covers("p", "git_force"))
        self.assertEqual((await self.client.put("/api/orchestra/p/night", headers=self.h, json={"window": [25, 1]})).status, 400)


class TestLeadHandover(Base):
    no_http_tests = {"test_review_failure_promotes_new_lead_gets_context", "test_review_failure_never_promotes_executor"}
    async def test_plan_failure_promotes_and_notices(self):
        async def ask(m, system, prompt, pid=None):
            if m["name"] == "强":
                raise RuntimeError("insufficient balance")
            return '[{"title":"a","goal":"g","deliverable":"d","acceptance":["x"],"difficulty":1}]'
        c.ask_model = ask
        r = await self.client.post("/api/orchestra/p/plan", headers=self.h, json={"brief": "做个东西", "start": False})
        self.assertEqual(r.status, 200)
        p = self.P()
        self.assertNotEqual(p["lead_resolved"], "强")
        self.assertEqual(p["lead_home"], "强")
        self.assertEqual(p["handover"]["from"], "强")
        self.assertIn("谱稿", p["handover"]["context"])
        notes = [m["text"] for m in s.CHATS["p"] if m.get("handover")]
        self.assertEqual(len(notes), 1)
        self.assertTrue(notes[0].startswith("指挥交接：强 → "))

    async def test_review_failure_promotes_new_lead_gets_context(self):
        seen = []

        async def ask(m, system, prompt, pid=None):
            if m["name"] == "强":
                raise asyncio.TimeoutError()
            seen.append((m["name"], prompt))
            return "PASS"
        c.ask_model = ask
        s.member("乙")["model"] = "big-pro"
        self.P()["segments"] = [seg(1, difficulty=5, assignee="甲")]
        await self.run_all()
        self.assertEqual(self.P()["segments"][0]["stage"], "done")
        self.assertTrue(seen and seen[0][1].startswith("【交接】"))
        self.assertEqual([name for name, _ in seen], ["乙"])
        self.assertEqual(self.P()["lead_resolved"], "乙")
        self.assertEqual(self.P()["segments"][0]["reviews"], [{"member": "乙", "verdict": "PASS"}])
        self.assertNotIn("甲", self.P()["lead_out"])
        self.assertFalse(c.LEAD_BUSY)

    async def test_review_failure_never_promotes_executor(self):
        seen = []
        async def ask(m, system, prompt, pid=None):
            seen.append(m["name"])
            raise RuntimeError("review unavailable")
        c.ask_model = ask
        # The executor is the strongest remaining member; still cannot self-review.
        s.member("甲")["model"] = "big-pro"
        self.P()["segments"] = [seg(1, difficulty=5, assignee="甲")]
        await self.run_all()
        self.assertEqual(seen, ["强", "乙"])
        self.assertNotEqual(self.P()["segments"][0]["stage"], "done")
        self.assertNotIn("甲", self.P().get("lead_out", []))

    async def test_no_lead_left(self):
        for m in ("强", "甲", "乙"):
            c.mark(m, "broken")
        r = await self.client.post("/api/orchestra/p/plan", headers=self.h, json={"brief": "x", "start": False})
        self.assertEqual(r.status, 500)

    async def test_handback_after_recovery_at_safe_point(self):
        self.P().update(lead_resolved="乙", lead_home="强", lead_out=["强"])
        c.mark("强", "broken")
        self.P()["segments"] = [seg(1, assignee="甲"), seg(2, assignee="甲", inputs=["s1"])]
        self.assertFalse(c.maybe_handback("p"))  # still broken
        c.STATE_AT["强"] = 0  # recover window passed
        c.LEAD_BUSY["p"] = 1
        self.assertFalse(c.maybe_handback("p"))  # a 指挥 call is in flight: not a safe point
        c.LEAD_BUSY["p"] = 0
        await self.run_all()
        p = self.P()
        self.assertEqual(p["lead_resolved"], "强")
        self.assertNotIn("lead_home", p)
        self.assertNotIn("强", p["lead_out"])
        notes = [m["text"] for m in s.CHATS["p"] if m.get("handover")]
        self.assertEqual(notes, ["指挥交还：乙 → 强（原指挥已恢复）"])
        self.assertEqual(p["handover"]["to"], "强")

    async def test_arrears_quota_blocks_handback(self):
        self.P().update(lead_resolved="乙", lead_home="强", lead_out=["强"])
        c.QUOTA2["强"] = {"state": "arrears"}
        self.assertFalse(c.maybe_handback("p"))
        c.QUOTA2["强"] = {"state": "ok"}
        self.assertTrue(c.maybe_handback("p"))


class TestCliGuardAndCaps(Base):
    def test_cli_guard(self):
        for raw, want in [("claude -p --dangerously-skip-permissions x", "claude -p x"),
                          ("codex exec --dangerously-bypass-approvals-and-sandbox -m m", "codex exec -m m"),
                          ("codex exec -a never -s read-only", "codex exec -a on-request -s read-only"),
                          ("claude -p --permission-mode bypassPermissions", "claude -p"),
                          ("gemini --yolo", "gemini")]:
            self.assertEqual(c.cli_guard(raw), (want, True), raw)
        self.assertEqual(c.cli_guard("claude -p --model x"), ("claude -p --model x", False))

    async def test_cli_auto_policy_passes_logged_illegal_blocked(self):
        s.member("甲")["kind"] = "cli"
        await self.client.put("/api/members/甲/policy", headers=self.h, json={"preset": "all"})
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "甲", "p")[0], "allow")
        self.assertTrue(any("自动同意" in a["text"] for a in s.CFG["audit"]))
        self.assertEqual(c.gate("Bash", {"command": "masscan 8.8.8.0/24"}, "甲", "p")[0], "deny")

    async def test_account_cap_blocks_wakes_and_segments(self):
        r = await self.client.put("/api/account/caps", headers=self.h, json={"hour": 1, "day": 10})
        self.assertEqual((await r.json())["blocked"], "")
        self.assertEqual((await self.client.put("/api/account/caps", headers=self.h, json={"hour": -1})).status, 400)
        c.on_usage(s.member("甲"), {"in": 10, "out": 10, "cost": 1.5, "cur": "¥"}, "p")
        self.assertIn("每小时", c.account_block())
        self.P()["segments"] = [seg(1)]
        await self.run_all()
        self.assertEqual(self.calls, [])
        self.assertEqual(self.P()["segments"][0]["stage"], "blocked")
        self.assertEqual([d["kind"] for d in self.P()["pending"]], ["account_cap"])
        trig = s.add_msg("p", "你", "@甲 来")
        self.assertIsNone(await s.run_member("p", "甲", trig, {}))
        self.assertEqual(self.calls, [])
        later = time.time() + 3661
        self.assertEqual(c.account_block(later), "")

    async def test_cost_split_by_role(self):
        tok = c.ROLE.set("review")
        c.on_usage(s.member("强"), {"in": 5, "out": 1, "cost": 0.2, "cur": "¥"}, "p")
        c.ROLE.reset(tok)
        c.ROLE.set("execute")
        c.on_usage(s.member("甲"), {"in": 7, "out": 2, "cost": 0.1, "cur": "¥"}, "p")
        split = (await (await self.client.get("/api/orchestra/p", headers=self.h)).json())["cost_split"]
        self.assertEqual(split["review"]["cost"]["¥"], 0.2)
        self.assertEqual(split["execute"]["in"], 7)

    async def test_ladder_choice_two_keeps_blocked(self):
        self.P()["segments"] = [seg(1, stage="blocked")]
        self.P()["pending"] = [{"id": "d1", "kind": "ladder_exhausted", "seg": "s1", "state": "open", "options": ["a", "b", "c"]}]
        await self.client.post("/api/orchestra/p/decide", headers=self.h, json={"id": "d1", "choice": 2})
        self.assertEqual(self.P()["segments"][0]["stage"], "blocked")


class TestReviewFixes(Base):
    async def test_retry_loop_is_bounded(self):
        s.CFG["max_rounds"] = 3
        self.behaviour["甲"] = [("err", 500, "server error")]
        self.P()["members"] = ["强", "甲"]
        self.P()["segments"] = [seg(1, assignee="甲")]
        orig = c.recovery.decide
        c.recovery.decide = lambda *a, **k: c.recovery.Decision("retry", 0.0, "", "重试")
        self.addCleanup(setattr, c.recovery, "decide", orig)
        await self.run_all()
        self.assertEqual(self.P()["segments"][0]["stage"], "blocked")
        self.assertLessEqual(self.calls.count("甲"), 3)

    async def test_lead_direct_call_respects_account_cap(self):
        s.CFG["account_caps"] = {"hour": 1}
        c.on_usage(s.member("甲"), {"cost": 2, "cur": "¥"}, "p")
        with self.assertRaises(RuntimeError):
            await type(self).orig_ask(s.member("强"), "s", "p", "p")

    async def test_night_spend_accumulates(self):
        self.P()["night"] = {"enabled": True, "confirmed_at": time.time(), "lines": ["money"], "spend_cap": 1, "window": [0, 0], "spent": 0}
        c.on_usage(s.member("甲"), {"cost": 0.6, "cur": "¥"}, "p")
        c.on_usage(s.member("甲"), {"cost": 0.6, "cur": "¥"}, "p")
        self.assertAlmostEqual(self.P()["night"]["spent"], 1.2)
        self.assertFalse(c.night_covers("p", "money"))

    async def test_spend_buckets_survive_restart(self):
        s.CFG["account_caps"] = {"hour": 1}
        c.on_usage(s.member("甲"), {"cost": 1.5, "cur": "¥"}, "p")
        import importlib  # simulated restart: module state reloads, persisted buckets in CFG remain
        cfg = s.CFG
        importlib.reload(c)
        c.S = s
        s.CFG = cfg
        self.assertIn("每小时", c.account_block())

    async def test_redeem_rejects_bad_name_and_strips_bypass(self):
        code = (await (await self.client.post("/api/invite", headers=self.h)).json())["code"]
        self.assertEqual((await self.client.post("/api/invite/redeem", json={"code": code, "name": "../x"})).status, 400)
        code = (await (await self.client.post("/api/invite", headers=self.h)).json())["code"]
        r = await self.client.post("/api/invite/redeem", json={"code": code, "name": "新", "kind": "cli", "cmd": "claude -p --dangerously-skip-permissions"})
        self.assertEqual(r.status, 400)
        self.assertIsNone(s.member("新"))

    async def test_segment_exception_does_not_kill_others(self):
        self.P()["segments"] = [seg(1), seg(2)]
        orig = c.run_segment

        async def boom(pid, sg):
            if sg["id"] == "s1":
                raise ValueError("bad")
            return await orig(pid, sg)
        c.run_segment = boom
        self.addCleanup(setattr, c, "run_segment", orig)
        await self.run_all()
        st = {x["id"]: x["stage"] for x in self.P()["segments"]}
        self.assertEqual(st, {"s1": "blocked", "s2": "done"})

    async def test_new_segment_id_unique(self):
        self.P()["segments"] = [seg(1), seg(3)]
        self.P()["paused"] = True
        await self.client.post("/api/orchestra/p/segments/new", headers=self.h, json={"title": "x", "goal": "g", "deliverable": "d", "acceptance": ["a"]})
        ids = [x["id"] for x in self.P()["segments"]]
        self.assertEqual(len(ids), len(set(ids)))


class TestGrant(Base):
    async def test_grant_scope_project_only_and_never_illegal(self):
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "甲", "p")[0], "ask")
        self.assertTrue(c.grant("p", "甲", "perms"))
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "甲", "p")[0], "allow")
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "乙", "p")[0], "ask")   # other member
        s.PROJECTS.append({"id": "q", "name": "Q", "members": [], "segments": []})
        self.assertEqual(c.gate("Bash", {"command": "sudo apt install x"}, "甲", "q")[0], "ask")   # other 乐章
        self.assertFalse(c.grant("p", "甲", "illegal"))
        self.assertEqual(c.gate("Bash", {"command": "masscan 8.8.8.0/24"}, "甲", "p")[0], "deny")


class TestButtonsAndMetrics(Base):
    async def test_restart_segment_resets_and_conflicts_when_running(self):
        p = self.P()
        p.setdefault("segments", []).append({"id": "sx", "title": "x", "stage": "blocked", "ladder": ["甲"], "attempts": 3, "tried": ["甲"]})
        self.addCleanup(setattr, c, "start", c.start)
        c.start = lambda pid: None
        r = await self.client.post(f"/api/orchestra/{p['id']}/segments/sx/restart", headers=self.h)
        self.assertEqual(r.status, 200)
        seg = next(x for x in self.P()["segments"] if x["id"] == "sx")
        self.assertEqual(seg["stage"], "waiting")
        self.assertNotIn("attempts", seg)
        seg["stage"] = "running"
        self.assertEqual((await self.client.post(f"/api/orchestra/{p['id']}/segments/sx/restart", headers=self.h)).status, 409)
        self.assertEqual((await self.client.post(f"/api/orchestra/{p['id']}/segments/nope/restart", headers=self.h)).status, 404)

    async def test_member_metrics(self):
        c.on_usage({"name": "甲"}, {"in": 10, "out": 5, "cost": 0.2, "cur": "¥"}, None)
        r = await (await self.client.get("/api/members/甲/metrics", headers=self.h)).json()
        self.assertEqual((r["calls"], r["in"], r["out"], r["cost"]["¥"], r["state"]), (1, 10, 5, 0.2, "ok"))
        self.assertEqual((await self.client.get("/api/members/无/metrics", headers=self.h)).status, 404)


class TestRelayWallet(unittest.IsolatedAsyncioTestCase):
    async def test_relay_manual_balance_minus_spend(self):
        import quota_probes as qp
        ctx = qp.Ctx(None, spent_money=lambda pid, cur: 7.5)
        pr = {"id": "r1", "base": "https://relay.example/v1", "kind": "relay", "wallet": {"amount": 100, "spent0": 2.5, "cur": "¥"}}
        q = await qp.probe(pr, {"name": "m", "kind": "api", "provider": "r1"}, ctx)
        self.assertEqual((q["method"], q["source"], q["accounts"][0]["amount"]), ("wallet", "estimate", 95.0))


class TestOverview(Base):
    async def test_threads_library_prs(self):
        p = self.P()
        p["movements"] = [{"id": "m1", "title": "旧", "segments": [{"id": "a", "stage": "done", "artifacts": ["https://github.com/x/y/pull/3"]}]}]
        p["segments"] = [{"id": "s1", "title": "写", "stage": "done", "artifacts": ["app.py"]}, {"id": "s2", "title": "测", "stage": "running"}]
        p["movement_id"] = "m2"
        v = await (await self.client.get(f"/api/orchestra/{p['id']}/overview", headers=self.h)).json()
        self.assertEqual([t["id"] for t in v["threads"]["resolved"]], ["m1"])
        act = v["threads"]["active"][0]
        self.assertEqual((act["tasks_done"], act["tasks"], act["outputs"]), (1, 2, 1))
        self.assertEqual(v["library"][0]["path"], "app.py")
        self.assertIn("pull/3", v["prs"][0]["path"])
        p["paused"] = True
        v = await (await self.client.get(f"/api/orchestra/{p['id']}/overview", headers=self.h)).json()
        self.assertEqual(v["threads"]["idle"][0]["id"], "m2")


class TestDogfoodHttp(Base):
    async def test_async_query_and_prefer(self):
        for suffix, headers in (("?async=1", self.h), ("", {**self.h, "Prefer": "respond-async"})):
            entered, release = asyncio.Event(), asyncio.Event()
            async def ask(*args):
                entered.set()
                await release.wait()
                return '[{"title":"实现","difficulty":1}]'
            c.ask_model = ask
            r = await self.client.post("/api/orchestra/p/plan" + suffix, headers=headers, json={"start": False})
            self.assertEqual(r.status, 202)
            self.assertEqual(await r.json(), {"state": "planning"})
            await asyncio.wait_for(entered.wait(), 2)
            task = c.PLANNING["p"]
            release.set()
            await asyncio.wait_for(task, 2)
            self.assertEqual(self.P()["planning"], "done")

    async def test_real_disconnect_keeps_server_plan_alive(self):
        entered, release = asyncio.Event(), asyncio.Event()
        async def ask(*args):
            entered.set()
            await release.wait()
            return '[{"title":"实现","difficulty":1}]'
        c.ask_model = ask
        url = self.client.make_url("/api/orchestra/p/plan")
        reader, writer = await asyncio.open_connection(url.host, url.port)
        body = b'{"start":false}'
        writer.write((f"POST {url.path} HTTP/1.1\r\nHost: {url.host}\r\nAuthorization: {self.h['Authorization']}\r\nContent-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n").encode() + body)
        await writer.drain()
        await asyncio.wait_for(entered.wait(), 2)
        task = c.PLANNING["p"]
        writer.close()
        await writer.wait_closed()
        release.set()
        await asyncio.wait_for(task, 2)
        self.assertEqual(self.P()["planning"], "done")
        self.assertEqual(len(self.P()["segments"]), 1)
