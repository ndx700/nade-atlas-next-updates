"""Connector contracts without listening sockets or real service managers."""
import asyncio
import json
import os
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import AsyncMock, Mock, patch
import connect
from connector import connector as agent


class Contracts(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.server = SimpleNamespace(DATA=self.root, CFG={'members': []},
            PROJECTS=[{'id': 'p', 'members': []}, {'id': 'other', 'members': []}], save_cfg=Mock(), bump=Mock())
        self.server.join_member = lambda n: [p['members'].append(n) for p in self.server.PROJECTS if n not in p['members']]
        self.server.member = lambda name: next((m for m in self.server.CFG['members'] if m['name'] == name), None)
        for key, val in dict(S=self.server, REMOTE={}, INV={}, TEST_TASKS=set()).items():
            self.enterContext(patch.object(connect, key, val))
        self.enterContext(patch.object(connect, '_test', AsyncMock()))

    async def register(self, host='machine', project='p'):
        inv = connect.new_invite('https://example.com', project)
        req = SimpleNamespace(headers={'X-Chorus-Invite': inv['token']},
            json=AsyncMock(return_value={'host': host, 'name': 'AI', 'clis': [
                {'name': 'claude', 'version': '1'}, {'name': 'codex'}, {'name': 'claude'}]}))
        result = json.loads((await connect.h_register(req)).body)
        await asyncio.gather(*connect.TEST_TASKS)
        return result

    async def test_all_clis_scope_reuse_rotation_and_other_host(self):
        first = await self.register()
        self.assertEqual({m['cli'] for m in first['members']}, {'claude', 'codex'})
        self.assertEqual(len(self.server.CFG['members']), 2)
        self.assertEqual(len(self.server.PROJECTS[0]['members']), 2)
        self.assertEqual(self.server.PROJECTS[1]['members'], [])
        second = await self.register(project='other')
        self.assertEqual([m['member'] for m in first['members']], [m['member'] for m in second['members']])
        for old, new in zip(first['members'], second['members']):
            self.assertNotEqual(old['secret'], new['secret'])
            self.assertEqual(connect.REMOTE[new['member']]['hash'], connect._h(new['secret']))
        self.assertEqual(len(self.server.CFG['members']), 2)
        await self.register(host='other-machine', project='')
        self.assertEqual(len(self.server.CFG['members']), 4)
        # 不指定乐章的邀请（从设置里邀请）：和其他接入方式一致，进所有在用乐章
        self.assertEqual(len(self.server.PROJECTS[0]['members']), 4)
        self.assertEqual(len(self.server.PROJECTS[1]['members']), 4)

    def test_atomic_remote_private_and_failure_preserves_old(self):
        path = self.root / 'remote_connectors.json'
        path.write_text('{"old": true}')
        connect.REMOTE['incomplete'] = {}
        original = os.replace
        def replace(src, dst):
            self.assertEqual(Path(src).stat().st_mode & 0o777, 0o600)
            self.assertIn('incomplete', json.loads(Path(src).read_text()))
            original(src, dst)
        with patch.object(connect.os, 'replace', side_effect=OSError('disk')):
            with self.assertRaises(OSError):
                connect.save_remote()
        self.assertEqual(json.loads(path.read_text()), {'old': True})
        self.assertEqual(list(self.root.iterdir()), [path])
        with patch.object(connect.os, 'replace', replace):
            connect.save_remote()
        connect.REMOTE.clear()
        connect.load_remote()
        self.assertEqual(connect.REMOTE['incomplete']['hash'], '')

    def test_systemd_and_launchd_services(self):
        import plistlib
        with patch.object(agent.pathlib.Path, 'home', return_value=self.root), patch.object(agent, 'STATE', self.root / 'state.json'), patch.object(agent.subprocess, 'run') as run:
            with patch.object(agent.sys, 'platform', 'linux'):
                agent.install_service()
            service = (self.root / '.config/systemd/user/chorus-connector.service').read_text()
            self.assertIn('WantedBy=default.target', service)
            self.assertIn('Restart=always', service)
            self.assertNotIn('CHORUS_INVITE', service)
            self.assertIn(unittest.mock.call(['loginctl', 'enable-linger', str(os.getuid())], check=True), run.call_args_list)
            self.assertEqual(run.call_args.args[0][:3], ['systemctl', '--user', 'restart'])
            with patch.object(agent.sys, 'platform', 'darwin'):
                agent.install_service()
            plist = plistlib.loads((self.root / 'Library/LaunchAgents/com.chorus.connector.plist').read_bytes())
            self.assertTrue(plist['RunAtLoad'])
            self.assertTrue(plist['KeepAlive'])
            self.assertEqual(run.call_args.args[0][1], 'bootstrap')

    def test_connector_persists_and_starts_every_cli(self):
        state = self.root / 'state.json'
        members = [{'member': cli, 'cli': cli, 'secret': cli + '-secret'} for cli in ('claude', 'codex')]
        with patch.object(agent, 'STATE', state), patch.object(agent, 'SRV', 'https://example.com'), patch.dict(os.environ, {'CHORUS_INVITE': 'invite'}), patch.object(agent, 'found', return_value=[{'name': 'claude'}, {'name': 'codex'}]), patch.object(agent, 'req', return_value={'members': members}), patch.object(agent, 'install_service') as install, patch.object(agent.sys, 'argv', ['connector.py', '--install']):
            agent.main()
            install.assert_called_once()
        self.assertEqual(json.loads(state.read_text())['members'], members)
        with patch.object(agent, 'STATE', state), patch.dict(os.environ, {}, clear=True), patch.object(agent, 'worker') as worker, patch.object(agent.threading, 'Thread') as thread, patch.object(agent.sys, 'argv', ['connector.py']):
            agent.main()
        worker.assert_called_once_with(members[0])
        self.assertEqual(thread.call_args.kwargs['args'], (members[1],))

    async def test_invite_binds_requested_project_and_rejects_unknown(self):
        req = SimpleNamespace(headers={}, scheme='https', host='example.com', can_read_body=True,
                              json=AsyncMock(return_value={'project': 'p'}))
        response = json.loads((await connect.h_new(req)).body)
        self.assertEqual(connect.INV[response['token']]['project'], 'p')
        req.json = AsyncMock(return_value={'project': 'missing'})
        from aiohttp import web
        with self.assertRaises(web.HTTPBadRequest):
            await connect.h_new(req)

    async def test_legacy_host_cli_is_reused_and_pending_call_released(self):
        self.server.CFG['members'] = [{'name': 'legacy', 'remote': True, 'host': 'machine', 'cmd': 'claude -p'}]
        future = asyncio.get_running_loop().create_future()
        connect.REMOTE['legacy'] = {'hash': 'old', 'wait': {'pending': future}}
        result = await self.register()
        self.assertEqual(result['members'][0]['member'], 'legacy')
        self.assertIn('重新注册', future.result()['error'])
        self.assertEqual(len(self.server.CFG['members']), 2)

    def test_service_failure_is_reported(self):
        import subprocess
        with patch.object(agent.pathlib.Path, 'home', return_value=self.root), patch.object(agent.sys, 'platform', 'linux'), patch.object(agent.subprocess, 'run', side_effect=subprocess.CalledProcessError(1, 'loginctl')):
            with self.assertRaises(subprocess.CalledProcessError):
                agent.install_service()
