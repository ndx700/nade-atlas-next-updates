"""Fault-injection suite (hard gate): one broken member / card / 指挥 / restart must never stall the others."""
import asyncio
import pathlib
import tempfile
import unittest

import adapters as A
import checkpoints as CK
import ensemble as E


class Fake(A.Adapter):
    kind = "cli"
    log: list = []

    async def run(self, packet, emit, approve, cwd="", system=""):
        mode = self.member.get("mode", "ok")
        Fake.log.append((self.name, mode))
        emit(A.Step(self.name, "start"))
        if self.member.get("lead_role") and "审核任务卡" in packet:
            if mode == "down":
                return A.Result(ok=False, error="503")
            return A.Result(ok=True, text="PASS")
        if mode == "error":
            return A.Result(ok=False, error="500 internal", status=500)
        if mode == "hang":
            await asyncio.sleep(3600)
        if mode == "crash":
            raise RuntimeError("adapter blew up")
        if mode == "malformed":
            return A.Result(ok=True, text="\x00garbage", artifacts=["nope.py"])
        if mode == "down":
            return A.Result(ok=False, error="503")
        cid = packet.split("任务卡 ")[1].split()[0] if "任务卡 " in packet else "x"
        f = pathlib.Path(cwd) / f"{cid}_{self.name}.txt"
        f.write_text("ok")
        await asyncio.sleep(0.01)
        return A.Result(ok=True, text="done", artifacts=[f.name], usage={"in": 1, "out": 1})


def cards(n):
    return {"title": "t", "cards": [{"id": f"c{i}", "title": f"卡{i}", "acceptance": "有文件", "eta": 60} for i in range(n)]}


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.events = []
        Fake.log = []

    def ens(self, project, members, lead="L", **kw):
        price = {m["name"]: {"in": 1, "out": m.get("price", 1)} for m in members}
        kw.setdefault("card_timeout", 2)
        return E.Ensemble("p", project, members, Fake, E.Workspace(self.root / "ws"), self._ok, lambda *a: None,
                          self.events.append, lambda m: price[m["name"]], {}, lead=lead, stall_check=0.2, **kw)

    async def _ok(self, *a):
        return True

    def lead(self, mode="ok"):
        return {"name": "L", "kind": "cli", "mode": mode, "lead_role": True, "price": 50}


class TestFaults(Base):
    async def check_isolated(self, bad_mode, eta=60, **kw):
        members = [self.lead(), {"name": "bad", "kind": "cli", "mode": bad_mode, "price": 0.1},
                   {"name": "good", "kind": "cli", "price": 1}]
        p = cards(4)
        for c in p["cards"]:
            c["eta"] = eta
        e = self.ens(p, members, **kw)
        pct = await asyncio.wait_for(e.run(), 30)
        self.assertEqual(pct, 100.0, [c["state"] for c in p["cards"]])
        self.assertTrue(all(c["assignee"] == "good" for c in p["cards"]))
        return e

    async def test_member_error(self):
        e = await self.check_isolated("error")
        self.assertTrue(e.breaker.open("bad") or any(ev.kind == "breaker" for ev in self.events))

    async def test_member_hang_timeout(self):
        await self.check_isolated("hang", card_timeout=0.5)

    async def test_member_hang_watchdog_without_timeout(self):
        await self.check_isolated("hang", eta=0.5, card_timeout=None)
        self.assertTrue(any(ev.kind == "stall" for ev in self.events))

    async def test_adapter_crash(self):
        await self.check_isolated("crash")

    async def test_malformed_output(self):
        await self.check_isolated("malformed")

    async def test_quota_zero(self):
        members = [self.lead(), {"name": "broke", "kind": "cli", "price": 0.1}, {"name": "good", "kind": "cli"}]
        p = cards(3)
        e = self.ens(p, members, available=lambda m: m["name"] != "broke")
        self.assertEqual(await asyncio.wait_for(e.run(), 30), 100.0)
        self.assertNotIn("broke", [n for n, _ in Fake.log])     # never even woken

    async def test_lead_failure_failover(self):
        members = [self.lead("down"), {"name": "W", "kind": "cli", "price": 1},
                   {"name": "L2", "kind": "cli", "lead_role": True, "price": 30}]
        p = cards(2)
        e = self.ens(p, members)
        self.assertEqual(await asyncio.wait_for(e.run(), 30), 100.0)
        self.assertEqual(e.lead, "L2")
        self.assertTrue(any(ev.kind == "handover" for ev in self.events))

    async def test_engine_bug_restarts_card_others_continue(self):
        members = [self.lead(), {"name": "good", "kind": "cli"}]
        p = cards(3)
        e = self.ens(p, members)
        real, boom = e.run_card, {"n": 0}

        async def flaky(card):
            if card["id"] == "c1" and boom["n"] < 1:
                boom["n"] += 1
                raise KeyError("engine bug")
            return await real(card)
        e.run_card = flaky
        self.assertEqual(await asyncio.wait_for(e.run(), 30), 100.0)
        self.assertTrue(any("engine bug" in x for x in e.errors))
        self.assertTrue(any(ev.kind == "crash" for ev in self.events))

    async def test_engine_bug_forever_blocks_only_that_card(self):
        members = [self.lead(), {"name": "good", "kind": "cli"}]
        p = cards(3)
        e = self.ens(p, members)
        real = e.run_card

        async def bad(card):
            if card["id"] == "c0":
                raise ValueError("always")
            return await real(card)
        e.run_card = bad
        await asyncio.wait_for(e.run(), 30)
        self.assertEqual([c["state"] for c in p["cards"]], ["blocked", "passed", "passed"])

    async def test_server_restart_mid_run_resumes_without_redoing(self):
        db = CK.Checkpoints(self.root / "ck.db")
        members = [self.lead(), {"name": "good", "kind": "cli"}]
        p = cards(3)
        p["cards"][2]["inputs"] = ["c0", "c1"]
        e = self.ens(p, members, ckpt=db)
        # Freeze the dependent card before it runs: polling can miss the window
        # between the first two checkpoints and completion of the whole run.
        entered = asyncio.Event()
        original = e.run_card

        async def pause_last(card):
            if card["id"] == "c2":
                entered.set()
                await asyncio.Event().wait()
            return await original(card)

        e.run_card = pause_last
        task = asyncio.create_task(e.run())
        try:
            await asyncio.wait_for(entered.wait(), 5)
            self.assertEqual([c["state"] for c in p["cards"][:2]], ["passed", "passed"])
        finally:
            task.cancel()                              # "server dies"
            with self.assertRaises(asyncio.CancelledError):
                await asyncio.wait_for(task, 5)
        db.close()
        Fake.log = []
        db2 = CK.Checkpoints(self.root / "ck.db")
        p2 = cards(3)
        p2["cards"][2]["inputs"] = ["c0", "c1"]
        e2 = self.ens(p2, members, ckpt=db2)
        self.assertEqual(await asyncio.wait_for(e2.run(), 30), 100.0)
        worked = [n for n, m in Fake.log if n == "good"]
        self.assertEqual(len(worked), 1)                # exactly the unfinished card ran again
        db2.close()

    async def test_breaker_reopens_after_cooldown(self):
        t = [0.0]
        b = E.Breaker(threshold=2, cooldown=10, now=lambda: t[0])
        b.fail("x")
        self.assertFalse(b.open("x"))
        self.assertTrue(b.fail("x"))
        self.assertTrue(b.open("x"))
        t[0] = 11
        self.assertFalse(b.open("x"))

    async def test_all_members_down_ends_blocked_not_hung(self):
        members = [self.lead("down"), {"name": "a", "kind": "cli", "mode": "error"}]
        p = cards(2)
        e = self.ens(p, members)
        await asyncio.wait_for(e.run(), 30)
        self.assertTrue(all(c["state"] == "blocked" for c in p["cards"]))


class TestApprovedFeatures(Base):
    async def test_best_of_n_cheapest_pass_merged(self):
        members = [self.lead(), {"name": "a", "kind": "cli", "price": 5}, {"name": "b", "kind": "cli", "price": 1},
                   {"name": "c", "kind": "cli", "mode": "error", "price": 0.5}]
        p = cards(1)
        p["cards"][0]["best_of"] = 3
        e = self.ens(p, members)
        self.assertEqual(await asyncio.wait_for(e.run(), 30), 100.0)
        self.assertEqual(p["cards"][0]["assignee"], "b")          # both a and b passed; b is cheaper
        self.assertTrue(any("赛马胜出" in ev.text for ev in self.events))
        self.assertTrue((self.root / "ws/main/c0-bo1_b.txt").exists() or any((self.root / "ws/main").glob("c0*_b.txt")))

    async def test_agents_md_shared_and_in_packet(self):
        seen = []

        class Spy(Fake):
            async def run(self, packet, emit, approve, cwd="", system=""):
                seen.append(packet)
                return await super().run(packet, emit, approve, cwd, system)
        members = [self.lead(), {"name": "good", "kind": "cli"}]
        p = cards(1)
        e = self.ens(p, members)
        e.make = Spy
        await asyncio.wait_for(e.run(), 30)
        self.assertTrue((self.root / "ws/main/AGENTS.md").exists())
        self.assertIn("AGENTS.md", seen[0])

    async def test_author_never_reviews_own_card(self):
        members = [self.lead(), {"name": "w", "kind": "cli", "lead_role": True}]
        p = cards(1)
        p["cards"][0]["assignee"] = "L"           # the 指挥 did the work itself
        e = self.ens(p, members)
        await asyncio.wait_for(e.run(), 30)
        reviews = [n for n, _ in Fake.log]
        self.assertEqual(p["cards"][0]["state"], "passed")
        self.assertIn("w", reviews)               # someone else reviewed

    async def test_overlapping_files_never_run_together(self):
        live, peak = [0], [0]

        class Slow(Fake):
            async def run(self, packet, emit, approve, cwd="", system=""):
                if "审核任务卡" not in packet:
                    live[0] += 1
                    peak[0] = max(peak[0], live[0])
                    await asyncio.sleep(0.05)
                    live[0] -= 1
                return await super().run(packet, emit, approve, cwd, system)
        members = [self.lead(), {"name": "a", "kind": "cli"}, {"name": "b", "kind": "cli"}]
        p = cards(2)
        for c in p["cards"]:
            c["files"] = ["app.py"]
        e = self.ens(p, members)
        e.make = Slow
        self.assertEqual(await asyncio.wait_for(e.run(), 30), 100.0)
        self.assertEqual(peak[0], 1)

    async def test_a2a_states_and_metrics(self):
        members = [self.lead(), {"name": "good", "kind": "cli"}]
        p = cards(1)
        e = self.ens(p, members)
        await asyncio.wait_for(e.run(), 30)
        self.assertEqual(p["cards"][0]["a2a"], "completed")
        st = e.stats["good"]
        self.assertEqual((st["runs"], st["fails"], st["in"]), (1, 0, 1))
        self.assertGreaterEqual(st["avg_s"], 0)
