import unittest
import server as s


class Names(unittest.TestCase):
    def test_skill_dirname_never_escapes(self):
        for raw in ("..", ".", "../x", "a/../..", "", None, "...", ".hidden"):
            n = s.skill_dirname(raw)
            self.assertNotIn("/", n)
            self.assertFalse(n.startswith("."))
            self.assertNotEqual(n, "")
        self.assertEqual(s.skill_dirname("my skill"), "my-skill")


if __name__ == "__main__":
    unittest.main()
