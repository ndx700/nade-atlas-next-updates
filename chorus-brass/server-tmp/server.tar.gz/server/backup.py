"""Encrypted Chorus snapshots and staged restore plans. Linux, one server writer.

No service-control privileges here. restore_executor.py applies committed plans
after stopping the writer. All private staging lives in DATA/backups (mode 0700).
"""
import asyncio
import contextlib
import fcntl
import hashlib
import io
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import tarfile
import tempfile
import time

from aiohttp import web
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

FORMAT_VERSION = DATA_VERSION = 1
# Register new persistent modules here when adding them; unknown private files
# and host/CLI credentials are deliberately excluded. Roles currently live in config.
STATE_ROOTS = ("config.json", "projects.json", "spend.json", "sessions.json",
               "chats", "memory", "summaries", "skills", "files", "tasks", "roles")
MAGIC = b"CHORUSB1"  # v1: scrypt(n=32768,r=8,p=1), salt16, GCM nonce12, ciphertext, tag16
CHUNK = 1 << 20
ID = re.compile(r"^[a-f0-9]{32}$")
MAX_STATE = 64 << 20
MAX_TOTAL = 20 << 30
MAX_FILES = 100000
MAX_MANIFEST = 16 << 20
MAX_ARCHIVE = MAX_TOTAL + (MAX_FILES + 10) * 1024
PLAN_TTL = 900


class BackupError(ValueError):
    pass


def write_json(path, value):
    path = Path(path)
    # Create a private inode before writing any secret bytes.
    fd, name = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            os.fchmod(f.fileno(), 0o600)
            json.dump(value, f, ensure_ascii=False, indent=1)
            f.flush()
            os.fsync(f.fileno())
        tmp.replace(path)
        sync_dir(path.parent)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(CHUNK), b""):
            h.update(b)
    return h.hexdigest()


async def worker(func, *args):
    """Cancellation must not race a live thread accessing private staging."""
    task = asyncio.create_task(asyncio.to_thread(func, *args))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        try:
            await task
        except Exception:
            pass
        raise


def private_dir(path):
    path = Path(path)
    if path.is_symlink():
        raise BackupError("备份目录不能是符号链接")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path, 0o700)
    return path


@contextlib.contextmanager
def writer_lock(data, *, startup=False):
    """Server holds this for its entire lifetime; executor takes it while stopped."""
    path = Path(data) / ".chorus-writer.lock"
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            owner = os.read(fd, 64).decode("ascii", errors="ignore").strip()
            owner = owner if owner.isdecimal() else "未知"
            message = f"这个数据目录已有服务在跑（pid {owner}）" if startup else f"服务仍在写入，不能恢复（pid {owner}）"
            raise BackupError(message) from None
        os.fchmod(fd, 0o600)
        os.ftruncate(fd, 0)
        os.write(fd, str(os.getpid()).encode("ascii"))
        os.fsync(fd)
        yield
    finally:
        os.close(fd)


def check_password(password):
    if not isinstance(password, str) or not 12 <= len(password) <= 1024:
        raise BackupError("备份口令须为 12～1024 个字符")


def validate_options(value):
    if not isinstance(value, dict) or value.keys() - {"interval_hours", "keep", "key_file"}:
        raise BackupError("备份设置字段无效")
    hours, keep = value.get("interval_hours", 24), value.get("keep", 7)
    if type(hours) not in (int, float) or not 0 <= hours <= 8760:
        raise BackupError("定时备份间隔须为 0～8760 小时，0 表示关闭")
    if type(keep) is not int or not 1 <= keep <= 100:
        raise BackupError("备份保留数须为 1～100")
    if not isinstance(value.get("key_file", ""), str):
        raise BackupError("定时备份须配置外部密钥文件")
    return {**value, "interval_hours": hours, "keep": keep}


def key_for(password, salt):
    check_password(password)
    return Scrypt(salt=salt, length=32, n=32768, r=8, p=1).derive(password.encode("utf-8"))


def encrypt(source, target, password):
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    header = MAGIC + salt + nonce
    enc = Cipher(algorithms.AES(key_for(password, salt)), modes.GCM(nonce)).encryptor()
    enc.authenticate_additional_data(header)
    with Path(source).open("rb") as src, Path(target).open("xb") as dst:
        os.chmod(target, 0o600)
        dst.write(header)
        for b in iter(lambda: src.read(CHUNK), b""):
            dst.write(enc.update(b))
        dst.write(enc.finalize())
        dst.write(enc.tag)
        dst.flush()
        os.fsync(dst.fileno())


def decrypt(source, target, password):
    """Target is private and must never be parsed until GCM finalize succeeds."""
    size = Path(source).stat().st_size
    if size < 52 or size > MAX_ARCHIVE:
        raise BackupError("备份大小无效")
    try:
        with Path(source).open("rb") as src, Path(target).open("xb") as dst:
            os.chmod(target, 0o600)
            header = src.read(36)
            if header[:8] != MAGIC:
                raise BackupError("不支持的加密格式")
            src.seek(-16, os.SEEK_END)
            tag = src.read(16)
            dec = Cipher(algorithms.AES(key_for(password, header[8:24])),
                         modes.GCM(header[24:36], tag)).decryptor()
            dec.authenticate_additional_data(header)
            src.seek(36)
            left = size - 52
            while left:
                b = src.read(min(CHUNK, left))
                if not b:
                    raise BackupError("备份被截断")
                dst.write(dec.update(b))
                left -= len(b)
            dst.write(dec.finalize())
    except (InvalidTag, BackupError):
        Path(target).unlink(missing_ok=True)
        raise BackupError("口令错误、备份损坏或格式不兼容") from None


def safe_name(name):
    if not isinstance(name, str) or not name:
        raise BackupError("归档包含不允许的路径")
    p = PurePosixPath(name)
    if ("\\" in name or "\x00" in name or
            p.is_absolute() or any(x in ("", ".", "..") for x in name.split("/")) or
            p.parts[0] not in STATE_ROOTS or name.endswith((".tmp", ".part", ".ytdl")) or
            name == "manifest.json"):
        raise BackupError("归档包含不允许的路径")
    if (p.parts[0].endswith(".json") and len(p.parts) != 1 or
            not p.parts[0].endswith(".json") and len(p.parts) == 1):
        raise BackupError("文件与持久目录结构不符")
    return p


def state_files(data):
    """Refuse links/devices, including linked ancestor directories."""
    for root in STATE_ROOTS:
        start = Path(data) / root
        if not start.exists() and not start.is_symlink():
            continue
        children = start.rglob("*") if start.is_dir() and not start.is_symlink() else ()
        for p in itertools.chain((start,), children):
            mode = p.lstat().st_mode
            if stat.S_ISLNK(mode) or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                raise BackupError("持久目录包含链接或特殊文件")
            if stat.S_ISREG(mode):
                rel = p.relative_to(data).as_posix()
                if p.name.endswith((".tmp", ".part", ".ytdl")) and not rel.startswith(("files/", "uploads/")):
                    continue  # 只跳过服务端自己的临时文件，用户上传的同名附件要进备份
                safe_name(rel)
                yield rel, p


def capture_snapshot(data, target):
    """Call on the event loop WITHOUT await. Freeze state, hardlink immutable files.

    Server upload/video/TTS writers must publish by rename. CLI work/, app/, tmp/
    and backups/ are outside the registered data set. Out-of-band edits unsupported.
    """
    state_size = total = count = 0
    for rel, src in state_files(data):
        size = src.stat().st_size
        total += size
        count += 1
        if total > MAX_TOTAL or count > MAX_FILES:
            raise BackupError("备份超过文件数或总大小限制")
        dst = Path(target) / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if rel.startswith("files/"):
            os.link(src, dst, follow_symlinks=False)
        else:
            state_size += size
            if state_size > MAX_STATE:
                raise BackupError("持久状态超过 64 MiB，请离线备份")
            dst.write_bytes(src.read_bytes())
    if not (Path(target) / "config.json").is_file() or not (Path(target) / "projects.json").is_file():
        raise BackupError("缺少配置或项目清单")
    if shutil.disk_usage(target).free < total * 3 + (16 << 20):
        raise BackupError("备份暂存空间不足")


def manifest_for(snapshot, server_version):
    rows = [{"path": rel, "size": p.stat().st_size, "sha256": digest(p)}
            for rel, p in sorted(state_files(snapshot))]
    return {"format_version": FORMAT_VERSION, "data_version": DATA_VERSION,
            "server_version": server_version, "created_at": time.time(),
            "credentials": "full-encrypted", "roots": list(STATE_ROOTS), "files": rows}


def make_archive(snapshot, target, password, server_version):
    m = manifest_for(snapshot, server_version)
    with tempfile.TemporaryDirectory(dir=Path(target).parent, prefix=".pack-") as tmp:
        raw = Path(tmp) / "snapshot.tar"
        with tarfile.open(raw, "w", format=tarfile.USTAR_FORMAT) as tar:
            info = tarfile.TarInfo("manifest.json")
            body = json.dumps(m, ensure_ascii=False).encode("utf-8")
            info.size, info.mode = len(body), 0o600
            tar.addfile(info, io.BytesIO(body))
            for row in m["files"]:
                p = Path(snapshot) / row["path"]
                info = tarfile.TarInfo(row["path"])
                info.size, info.mode = row["size"], 0o600
                with p.open("rb") as src:
                    tar.addfile(info, src)
        encrypt(raw, target, password)
    return m


def validate_manifest(m):
    if (not isinstance(m, dict) or m.get("format_version") != FORMAT_VERSION or
            m.get("data_version") != DATA_VERSION or m.get("roots") != list(STATE_ROOTS) or
            m.get("credentials") != "full-encrypted"):
        raise BackupError("备份格式、范围或数据版本不兼容")
    rows = m.get("files")
    if not isinstance(rows, list) or len(rows) > MAX_FILES:
        raise BackupError("文件清单无效")
    out, size, state_size = {}, 0, 0
    for row in rows:
        if not isinstance(row, dict):
            raise BackupError("文件清单无效")
        name = row.get("path")
        if not isinstance(name, str) or not name:
            raise BackupError("文件路径无效")
        safe_name(name)
        n = row.get("size")
        if type(n) is not int or n < 0 or n > MAX_TOTAL or name in out:
            raise BackupError("文件大小或重复路径无效")
        if not re.fullmatch(r"[a-f0-9]{64}", str(row.get("sha256", ""))):
            raise BackupError("校验值无效")
        size += n
        if not name.startswith("files/"):
            state_size += n
        out[name] = row
    if size > MAX_TOTAL or state_size > MAX_STATE or not {"config.json", "projects.json"} <= out.keys():
        raise BackupError("备份不完整或超过大小限制")
    for name in out:
        if any(str(p) in out for p in PurePosixPath(name).parents if str(p) != "."):
            raise BackupError("文件与目录路径冲突")
    return out, size


def check_data(stage):
    """Strict trial load of schemas the current server actually consumes."""
    cfg = read_json(Path(stage) / "config.json")
    projects = read_json(Path(stage) / "projects.json")
    if (not isinstance(cfg, dict) or not isinstance(cfg.get("password", ""), str) or
            not isinstance(cfg.get("members", []), list) or not isinstance(cfg.get("providers", []), list)):
        raise BackupError("配置结构无效")
    for rows, key in ((cfg.get("members", []), "name"), (cfg.get("providers", []), "id")):
        keys = set()
        for item in rows:
            if not isinstance(item, dict) or not isinstance(item.get(key), str) or not item[key] or item[key] in keys:
                raise BackupError("成员或服务商结构无效")
            keys.add(item[key])
    if not isinstance(projects, list):
        raise BackupError("项目清单无效")
    ids = set()
    for p in projects:
        if (not isinstance(p, dict) or not isinstance(p.get("id"), str) or
                not re.fullmatch(r"[\w一-鿿.-]+", p["id"]) or not isinstance(p.get("name"), str) or
                p["id"] in (".", "..") or p["id"] in ids or not isinstance(p.get("members"), list) or
                not all(isinstance(n, str) for n in p.get("members", []))):
            raise BackupError("项目结构无效")
        ids.add(p["id"])
    messages = 0
    for rel, path in state_files(stage):
        if rel.endswith(".json"):
            value = read_json(path)
            if rel.startswith(("memory/", "roles/", "tasks/")) and not isinstance(value, (list, dict)):
                raise BackupError("持久数据结构无效")
            if rel.startswith("memory/") and (not isinstance(value, list) or any(
                    not isinstance(item, dict) or not isinstance(item.get("text"), str) for item in value)):
                raise BackupError("记忆数据结构无效")
        if rel.startswith("chats/"):
            prev = 0
            with path.open(encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    msg = json.loads(line)
                    if not isinstance(msg, dict) or type(msg.get("seq")) is not int or msg["seq"] <= prev:
                        raise BackupError("聊天序号无效")
                    if not all(isinstance(msg.get(k), str) for k in ("who", "text", "at")):
                        raise BackupError("聊天消息结构无效")
                    prev = msg["seq"]
                    messages += 1
    return {"projects": len(projects), "messages": messages,
            "attachments": sum(1 for rel, _ in state_files(stage) if rel.startswith("files/"))}


def unpack_archive(archive, password, stage):
    stage = private_dir(stage)
    with tempfile.TemporaryDirectory(dir=stage.parent, prefix=".unpack-") as tmp:
        raw = Path(tmp) / "snapshot.tar"
        decrypt(archive, raw, password)
        try:
            with tarfile.open(raw, "r:") as tar:
                first = tar.next()
                if first is None or first.name != "manifest.json" or first.type != tarfile.REGTYPE or first.size > MAX_MANIFEST:
                    raise BackupError("缺少有效清单")
                m = json.load(tar.extractfile(first))
                rows, total = validate_manifest(m)
                if shutil.disk_usage(stage).free < total + (16 << 20):
                    raise BackupError("恢复暂存空间不足")
                seen = set()
                for member in tar:
                    if member is first:  # TarFile iteration includes its cached first member
                        continue
                    name = member.name
                    if (name in seen or name not in rows or member.type != tarfile.REGTYPE or
                            member.sparse is not None or member.size != rows[name]["size"]):
                        raise BackupError("归档包含额外、重复或特殊条目")
                    safe_name(name)
                    dest = stage / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    h = hashlib.sha256()
                    with tar.extractfile(member) as src, dest.open("xb") as dst:
                        os.chmod(dest, 0o600)
                        for b in iter(lambda: src.read(CHUNK), b""):
                            dst.write(b)
                            h.update(b)
                    if h.hexdigest() != rows[name]["sha256"]:
                        raise BackupError("文件校验失败")
                    seen.add(name)
                if seen != rows.keys():
                    raise BackupError("归档缺少文件")
        except (tarfile.TarError, UnicodeError, json.JSONDecodeError) as e:
            raise BackupError("归档损坏") from e
    try:
        counts = check_data(stage)
    except (ValueError, TypeError, KeyError) as e:
        raise BackupError("持久数据试加载失败") from e
    return m, counts


def verify_stage(stage, m):
    rows, _ = validate_manifest(m)
    actual = {rel: p for rel, p in state_files(stage)}
    if actual.keys() != rows.keys():
        raise BackupError("恢复暂存文件发生变化")
    for rel, p in actual.items():
        if p.stat().st_size != rows[rel]["size"] or digest(p) != rows[rel]["sha256"]:
            raise BackupError("恢复暂存校验失败")
    return check_data(stage)


class BackupManager:
    def __init__(self, data, config, server_version="1"):
        self.data = Path(data)
        self.root = private_dir(self.data / "backups")
        self.config, self.server_version = config, server_version
        self.busy = asyncio.Lock()
        self.tasks = set()
        self.schedule_task = None

    def path(self, kind, ident):
        if not isinstance(ident, str) or not ID.fullmatch(ident):
            raise BackupError("编号无效")
        return self.root / (kind + ident)

    def spawn(self, coro):
        task = asyncio.create_task(coro)
        self.tasks.add(task)
        def finished(t):
            self.tasks.discard(t)
            if not t.cancelled():
                t.exception()  # The job record is the error channel; no unhandled tracebacks.
        task.add_done_callback(finished)
        return task

    def list(self):
        rows = [read_json(p) for p in self.root.glob("backup-*.json")]
        return sorted(rows, key=lambda r: r["created_at"], reverse=True)

    def _recover(self):
        # A killed process cannot resume its snapshot or password. Completed
        # archives are published before the completed record, so interruption
        # yields an explicit failed job, never a falsely successful backup.
        for row in self.list():
            if row["state"] == "running":
                row.update(state="failed", error="备份被服务重启中断")
                write_json(self.path("backup-", row["id"]).with_suffix(".json"), row)
        for prefix in (".capture-", ".pack-", ".unpack-"):
            for p in self.root.glob(prefix + "*"):
                shutil.rmtree(p)
        for p in self.root.glob("*.partial"):
            p.unlink()
        self.expire_plans()

    def expire_plans(self):
        for p in self.root.glob("plan-*.json"):
            plan = read_json(p)
            if plan["state"] == "planned" and plan["expires_at"] < time.time():
                shutil.rmtree(self.path("stage-", plan["id"]), ignore_errors=True)
                plan["state"] = "expired"
                write_json(p, plan)

    async def start_backup(self, password, scheduled=False):
        check_password(password)
        if self.busy.locked():
            raise BackupError("另一个备份或预检正在运行")
        await self.busy.acquire()
        ident = secrets.token_hex(16)
        work = None
        row = {"id": ident, "state": "running", "created_at": time.time(), "scheduled": scheduled}
        try:
            work = Path(tempfile.mkdtemp(dir=self.root, prefix=".capture-"))
            capture_snapshot(self.data, work)
            write_json(self.path("backup-", ident).with_suffix(".json"), row)
            self.spawn(self._pack(ident, work, password, row))
        except BaseException:
            if work:
                shutil.rmtree(work, ignore_errors=True)
            self.busy.release()
            raise
        return row

    async def _pack(self, ident, work, password, row):
        partial = self.path("", ident).with_suffix(".partial")
        try:
            m = await worker(make_archive, work, partial, password, self.server_version)
            final = self.path("", ident).with_suffix(".chorus")
            partial.replace(final)
            sync_dir(self.root)
            row.update(state="completed", size=final.stat().st_size, sha256=await worker(digest, final),
                       format_version=m["format_version"], data_version=m["data_version"])
        except Exception:
            # Never return exception strings: a library/OS error may contain a
            # private path or credential-bearing configuration content.
            row.update(state="failed", error="备份失败，请检查空间和持久文件")
        finally:
            password = None
            partial.unlink(missing_ok=True)
            shutil.rmtree(work, ignore_errors=True)
            try:
                write_json(self.path("backup-", ident).with_suffix(".json"), row)
                if row.get("scheduled"):
                    write_json(self.root / "schedule.json", {"state": row["state"], "at": time.time(), "backup_id": ident})
                self.prune()
            finally:
                self.busy.release()

    def prune(self):
        keep = self.config().get("backups", {}).get("keep", 7)
        if type(keep) is not int or not 1 <= keep <= 100:
            raise BackupError("备份保留数须为 1～100")
        pinned = {read_json(p)["backup_id"] for p in self.root.glob("plan-*.json")
                  if read_json(p)["state"] in ("planned", "queued", "applying")}
        completed = [r for r in self.list() if r["state"] == "completed"]
        for row in completed[keep:]:
            if row["id"] not in pinned:
                self.path("", row["id"]).with_suffix(".chorus").unlink(missing_ok=True)
                self.path("backup-", row["id"]).with_suffix(".json").unlink()

    async def plan(self, ident, password):
        check_password(password)
        if self.busy.locked():
            raise BackupError("另一个备份或预检正在运行")
        async with self.busy:
            self.expire_plans()
            if len(list(self.root.glob("stage-*"))) >= 3:
                raise BackupError("恢复计划过多，请等待现有计划过期")
            row = read_json(self.path("backup-", ident).with_suffix(".json"))
            if row["state"] != "completed":
                raise BackupError("备份尚未完成")
            archive = self.path("", ident).with_suffix(".chorus")
            if await worker(digest, archive) != row["sha256"]:
                raise BackupError("备份校验失败")
            pid = secrets.token_hex(16)
            stage = self.path("stage-", pid)
            try:
                m, counts = await worker(unpack_archive, archive, password, stage)
                plan = {"id": pid, "backup_id": ident, "archive_sha256": row["sha256"],
                        "state": "planned", "created_at": time.time(), "expires_at": time.time() + PLAN_TTL,
                        "manifest": m, "counts": counts, "overwrite_roots": list(STATE_ROOTS),
                        "requires_external_executor": True,
                        "warning": "恢复将覆盖上述数据；备份点后的消息和修改会被替换，恢复前数据会另存"}
                write_json(self.path("plan-", pid).with_suffix(".json"), plan)
                return plan
            except BaseException:
                shutil.rmtree(stage, ignore_errors=True)
                raise

    async def import_archive(self, request):
        """Transfer a downloaded encrypted backup to another server without unpacking."""
        if self.busy.locked():
            raise BackupError("另一个备份或预检正在运行")
        async with self.busy:
            ident = secrets.token_hex(16)
            partial = self.path("", ident).with_suffix(".partial")
            size, h, header = 0, hashlib.sha256(), bytearray()
            try:
                with partial.open("xb") as dst:
                    os.chmod(partial, 0o600)
                    async for chunk in request.content.iter_chunked(CHUNK):
                        size += len(chunk)
                        if size > MAX_ARCHIVE:
                            raise BackupError("备份上传超过大小限制")
                        if len(header) < 8:
                            header.extend(chunk[:8 - len(header)])
                        if len(header) == 8 and header != MAGIC:
                            raise BackupError("不支持的加密格式")
                        h.update(chunk)
                        dst.write(chunk)
                    dst.flush()
                    os.fsync(dst.fileno())
                if size < 52:
                    raise BackupError("备份大小无效")
                final = self.path("", ident).with_suffix(".chorus")
                partial.replace(final)
                sync_dir(self.root)
                row = {"id": ident, "state": "completed", "created_at": time.time(),
                       "size": size, "sha256": h.hexdigest(), "imported": True, "verified": False}
                write_json(self.path("backup-", ident).with_suffix(".json"), row)
                return row
            finally:
                partial.unlink(missing_ok=True)

    def commit(self, ident, archive_sha256, confirm):
        path = self.path("plan-", ident).with_suffix(".json")
        plan = read_json(path)
        if plan["state"] != "planned" or plan["expires_at"] < time.time():
            raise BackupError("恢复计划已使用或过期")
        if confirm is not True or archive_sha256 != plan["archive_sha256"]:
            raise BackupError("请确认覆盖范围并提交计划中的备份校验值")
        if any(read_json(p)["state"] in ("queued", "applying") for p in self.root.glob("plan-*.json")):
            raise BackupError("已有恢复任务待执行")
        plan["state"] = "queued"
        write_json(path, plan)
        return plan

    def external_key(self, filename):
        path = Path(filename).resolve(strict=True)
        if path == self.data or self.data in path.parents:
            raise BackupError("定时备份密钥必须位于 DATA 之外")
        mode = path.stat().st_mode
        if not stat.S_ISREG(mode) or mode & 0o077:
            raise BackupError("外部密钥文件权限须为 0600 或更严格")
        if path.stat().st_size > 4096:
            raise BackupError("外部密钥文件过大")
        value = path.read_text(encoding="utf-8").rstrip("\r\n")
        check_password(value)
        return value

    def scheduled_password(self, cfg):
        if cfg.get("key_file"):
            return self.external_key(cfg["key_file"])
        # Local automatic snapshots are encrypted; keep the recovery key private.
        key = self.root / "schedule.key"
        if not key.exists():
            try:
                fd = os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                pass
            else:
                with os.fdopen(fd, "w") as f:
                    f.write(secrets.token_urlsafe(48))
        if key.is_symlink() or not stat.S_ISREG(key.stat().st_mode) or key.stat().st_mode & 0o077:
            raise BackupError("本机备份密钥权限无效")
        value = key.read_text().strip()
        check_password(value)
        return value

    async def schedule_loop(self):
        retry_at = 0
        while True:
            try:
                self.expire_plans()
                cfg = self.config().get("backups", {})
                hours = cfg.get("interval_hours", 24)
                if type(hours) not in (int, float) or not 0 <= hours <= 8760:
                    raise BackupError("定时备份间隔无效")
                rows = [r for r in self.list() if r.get("scheduled") and r["state"] == "completed"]
                last = max((r["created_at"] for r in rows), default=0)
                if hours and time.time() >= max(last + hours * 3600, retry_at) and not self.busy.locked():
                    retry_at = time.time() + max(300, hours * 3600)
                    password = self.scheduled_password(cfg)
                    await self.start_backup(password, scheduled=True)
                    password = None
                    write_json(self.root / "schedule.json", {"state": "running", "at": time.time()})
            except Exception:
                write_json(self.root / "schedule.json", {"state": "failed", "error": "请检查定时备份间隔、密钥文件和存储空间", "at": time.time()})
            await asyncio.sleep(60)

    async def startup(self, app):
        self._recover()
        self.schedule_task = asyncio.create_task(self.schedule_loop())

    async def cleanup(self, app):
        if self.schedule_task:
            self.schedule_task.cancel()
            await asyncio.gather(self.schedule_task, return_exceptions=True)
        # Do not cancel to_thread while it still accesses plaintext staging.
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)


def register(app, data, config, server_version="1"):
    manager = BackupManager(data, config, server_version)

    async def handler(request):
        try:
            op = request.match_info.route.name
            if op == "backups-list":
                schedule = manager.root / "schedule.json"
                return web.json_response({"backups": manager.list(), "schedule": read_json(schedule) if schedule.exists() else None})
            if op == "backups-download":
                ident = request.match_info["id"]
                row = read_json(manager.path("backup-", ident).with_suffix(".json"))
                if row["state"] != "completed":
                    raise BackupError("备份尚未完成")
                return web.FileResponse(manager.path("", ident).with_suffix(".chorus"), headers={
                    "Content-Disposition": 'attachment; filename="' + ident + '.chorus"', "Cache-Control": "no-store"})
            if op == "restore-status":
                plan = read_json(manager.path("plan-", request.match_info["id"]).with_suffix(".json"))
                return web.json_response({k: v for k, v in plan.items() if k != "manifest"})
            if op == "backups-transfer":
                return web.json_response(await manager.import_archive(request), status=201)
            if request.content_length and request.content_length > 8192:
                raise BackupError("请求过大")
            raw = await request.content.read(8193)
            if len(raw) > 8192:
                raise BackupError("请求过大")
            body = json.loads(raw)
            if not isinstance(body, dict):
                raise BackupError("请求须为 JSON 对象")
            if op == "backups-create":
                return web.json_response(await manager.start_backup(body.get("password")), status=202)
            if op == "restore-plan":
                return web.json_response(await manager.plan(body.get("backup_id"), body.get("password")))
            if op == "restore-commit":
                plan = manager.commit(body.get("plan_id"), body.get("archive_sha256"), body.get("confirm_overwrite"))
                return web.json_response({"id": plan["id"], "state": plan["state"], "requires_external_executor": True}, status=202)
        except FileNotFoundError:
            return web.json_response({"error": "备份或计划不存在"}, status=404)
        except (BackupError, json.JSONDecodeError) as e:
            return web.json_response({"error": str(e)}, status=400)
        except UnicodeError:
            return web.json_response({"error": "请求编码无效"}, status=400)

    r = app.router
    r.add_get("/api/backups", handler, name="backups-list")
    r.add_post("/api/backups", handler, name="backups-create")
    r.add_put("/api/backups/import", handler, name="backups-transfer")
    r.add_get("/api/backups/{id}/download", handler, name="backups-download")
    r.add_post("/api/restore/plan", handler, name="restore-plan")
    r.add_post("/api/restore/commit", handler, name="restore-commit")
    r.add_get("/api/restore/{id}", handler, name="restore-status")
    app.on_startup.append(manager.startup)
    app.on_cleanup.append(manager.cleanup)
    return manager
