"""B5 regressions: no listening sockets, DNS lookups, or real credentials."""
import asyncio
import copy
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import AsyncMock, Mock, patch

from aiohttp import web
import api_errors as errors
import chorus2 as c
import connect
from connector import connector as agent
import dm_index
import server as s


class Request(SimpleNamespace):
    async def json(self):
        return self.body


class ReviewB5(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        for name in ('chats', 'tmp', 'files'):
            (root / name).mkdir()
        for key, value in dict(DATA=root, CFG={'password': 'test', 'providers': [], 'members': []},
                               PROJECTS=[], CHATS={}, PVER={}, VER=0, CHANGED=asyncio.Event()).items():
            self.enterContext(patch.object(s, key, value))
        for key, value in dict(S=s, C2=c, INV={}, REMOTE={}, TEST_TASKS=set()).items():
            self.enterContext(patch.object(connect, key, value))
        for key in ('MEMBER_STATE', 'STATE_AT', 'STATE_REASON', 'QUOTA2'):
            self.enterContext(patch.object(c, key, {}))
        self.enterContext(patch.object(c, 'S', s))

    async def test_metadata_spellings_rejected_before_any_probe(self):
        blocked = ['169.254.169.254', '169.254.43518', '169.16689662',
                   '2852039166', '0xa9fea9fe', '0251.0376.0251.0376',
                   '0xa9.0xfe.0xa9.0xfe', '100.100.100.200', '1684301000',
                   '[::ffff:169.254.169.254]', '[::ffff:a9fe:a9fe]',
                   '[0:0:0:0:0:ffff:a9fe:a9fe]', '[::ffff:100.100.100.200]',
                   '[fd00:ec2::254]', '[fdff::1]', '[fe80::1]',
                   'metadata.google.internal', 'METADATA.GOOG.']
        fetch = AsyncMock()
        with patch.object(s, 'fetch_models', fetch):
            for host in blocked:
                with self.subTest(host=host):
                    result = await connect.paste('http://' + host + '/v1 sk-' + 'a' * 40)
                    self.assertEqual((result['ok'], result['fix']), (False, 'edit_base'))
        fetch.assert_not_awaited()
        self.assertEqual(s.CFG['providers'], [])

    def test_public_domains_and_local_relays_do_not_raise(self):
        for host in ('api.example.com', 'localhost', '127.0.0.1', '192.168.1.1',
                     '10.1.2.3', '[::1]', '[fc00::1]', '8.8.8.8', '127.1', '0x7f000001'):
            connect._validate_base('http://' + host + '/v1')
        for host in ('4294967296', '169.254.999999', '089.1'):
            with self.assertRaises(ValueError):
                connect._validate_base('http://' + host + '/v1')

    def test_add_failure_removes_only_its_own_message(self):
        other = {'seq': 2, 'who': 'Other', 'text': 'keep'}
        def fail(pid, message):
            s.CHATS[pid].append(other)
            raise OSError('write failed')
        with patch.object(s, 'persist', side_effect=fail), patch.object(s, 'bump') as bump:
            with self.assertRaises(OSError):
                s.add_msg('p', 'Ali', 'retry me')
        self.assertEqual(s.CHATS['p'], [other])
        bump.assert_not_called()

    async def test_mutation_failure_replaces_reference_and_retry_is_not_acknowledged(self):
        for op in ('edit', 'recall', 'pin', 'react'):
            with self.subTest(op=op):
                s.CHATS['p'] = []
                original = s.add_msg('p', 'Ali', 'before', reactions={'x': ['A']})
                before = copy.deepcopy(original)
                req = Request(body={'project': 'p', 'seq': 1, 'op': op, 'text': 'after',
                                    'emoji': 'x', 'client_id': 'operation'})
                with patch.object(s, 'persist', side_effect=OSError('disk')), patch.object(s, 'bump') as bump:
                    with self.assertRaises(OSError):
                        await s.h_msg(req)
                self.assertIsNot(s.CHATS['p'][0], original)
                self.assertEqual(s.CHATS['p'][0], before)
                self.assertTrue(original)  # outstanding references were never cleared
                self.assertNotIn('client_ops', s.CHATS['p'][0])
                bump.assert_not_called()
                result = json.loads((await s.h_msg(req)).body)
                retry = json.loads((await s.h_msg(req)).body)
                self.assertEqual(result, retry)
                self.assertIn('operation', s.load_chat('p')[0]['client_ops'])

    def test_failed_append_and_rewrite_preserve_disk_and_clean_temp(self):
        message = s.add_msg('p', 'Ali', 'before')
        path = s.chat_file('p')
        before = path.read_bytes()
        for mode in ('append', 'rewrite'):
            with self.subTest(mode=mode), patch.object(Path, 'replace', side_effect=OSError('rename')):
                with self.assertRaises(OSError):
                    if mode == 'append':
                        s.add_msg('p', 'Ali', 'after')
                    else:
                        s.persist('p')
            self.assertEqual(path.read_bytes(), before)
            self.assertEqual(s.CHATS['p'], [message])
            self.assertFalse(path.with_suffix('.tmp').exists())
        def partial_copy(old, new):
            new.write('partial')
            raise OSError('disk full')
        with patch.object(s.shutil, 'copyfileobj', side_effect=partial_copy):
            with self.assertRaises(OSError):
                s.add_msg('p', 'Ali', 'partial')
        self.assertEqual(path.read_bytes(), before)
        self.assertFalse(path.with_suffix('.tmp').exists())
        s.add_msg('p', 'Ali', 'after')
        self.assertEqual([m['text'] for m in s.load_chat('p')], ['before', 'after'])

    def test_error_classification_boundaries(self):
        for text, fix in [('HTTP 403 Forbidden: quota exceeded', 'topup'),
                          ('HTTP 403 Forbidden', 'settings'), ('HTTP 401', 'repaste'),
                          ('invalid api key', 'repaste'), ('模型名含地址', 'settings'),
                          ('地址格式不对', 'settings'), ('接口地址不对', 'edit_base'),
                          ('base_url invalid', 'edit_base'), ('network down', 'retry')]:
            self.assertEqual(errors.upstream(text)['fix'], fix)

    def test_seen_validation_is_already_in_read_cursors(self):
        for raw in ('{"p":{"A":-1}}', '{', '[]', '{"p":{"A":true}}'):
            with self.assertRaises(web.HTTPBadRequest):
                dm_index.read_cursors(raw)

    async def test_status_uses_explicit_fix_and_complete_empty_detail(self):
        inv = connect.new_invite('http://localhost')
        record = connect.INV[inv['token']]
        req = Request(match_info={'tok': inv['id']})
        data = json.loads((await connect.h_status(req)).body)
        self.assertEqual((data['error'], data['message'], data['fix']), ('', '', 'none'))
        connect._mark(record, 'error', '检查命令行', 'settings')
        data = json.loads((await connect.h_status(req)).body)
        self.assertEqual((data['message'], data['fix']), ('检查命令行', 'settings'))
        del record['at']['error']
        self.assertIsInstance(json.loads((await connect.h_status(req)).body)['seconds'], (float, int))
        del record['fix']  # legacy record still uses fixed public error copy
        record['error'] = 'network down'
        self.assertEqual(json.loads((await connect.h_status(req)).body)['fix'], 'retry')

    async def test_cancelled_and_timed_out_jobs_are_never_dispatched(self):
        remote = {'queue': asyncio.Queue(), 'wait': {}}
        connect.REMOTE['A'] = remote
        call = asyncio.create_task(connect.remote_call('A', '', '', timeout=0.001))
        await call
        call = asyncio.create_task(connect.remote_call('A', '', ''))
        await asyncio.sleep(0)
        call.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await call
        self.assertEqual(remote['wait'], {})
        fut = asyncio.get_running_loop().create_future()
        remote['wait']['valid'] = fut
        await remote['queue'].put({'id': 'valid'})
        with patch.object(connect, '_member_of', return_value=('A', remote)):
            result = json.loads((await connect.h_jobs(Request(query={'wait': '1'}))).body)
        self.assertEqual(result['job']['id'], 'valid')
        self.assertTrue(remote['queue'].empty())
        fut.cancel()

    async def test_nan_wait_is_already_clamped(self):
        remote = {'queue': asyncio.Queue(), 'wait': {}}
        async def timeout(coro, wait):
            coro.close()
            self.assertEqual(wait, 30)
            raise asyncio.TimeoutError
        with patch.object(connect, '_member_of', return_value=('A', remote)), patch.object(connect.asyncio, 'wait_for', timeout):
            await connect.h_jobs(Request(query={'wait': 'nan'}))

    async def test_cleanup_awaits_cancelled_tasks(self):
        app = web.Application()
        with patch.object(connect, 'patch_call_cli'):
            connect.register(app, s, c)
        finished = []
        async def work():
            try:
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(0)
                finished.append(True)
        task = asyncio.create_task(work())
        connect.TEST_TASKS.add(task)
        task.add_done_callback(connect.TEST_TASKS.discard)
        await asyncio.sleep(0)
        await app.on_cleanup[-1](app)
        self.assertTrue(task.done())
        self.assertEqual(finished, [True])

    async def test_upload_disk_failure_and_size_limit_clean_temp(self):
        async def chunks(size):
            yield b'x' * size
        for oversized in (False, True):
            with self.subTest(oversized=oversized):
                s.CFG['max_upload_mb'] = 0 if oversized else 1
                req = Request(match_info={'name': 'test'}, content=SimpleNamespace(iter_chunked=lambda _: chunks(1)))
                with patch.object(Path, 'replace', side_effect=OSError('disk')):
                    result = await s.h_upload(req)
                self.assertEqual(result.status, 413 if oversized else 507)
                self.assertEqual(json.loads(result.body)['fix'], 'none' if oversized else 'retry')
                self.assertEqual(list((s.DATA / 'tmp').iterdir()), [])
                self.assertEqual(list((s.DATA / 'files').iterdir()), [])

    def test_missing_connector_member_registers_again(self):
        state = s.DATA / 'state.json'
        state.write_text(json.dumps({'secret': 'dummy', 'cli': 'claude'}))
        request = Mock(side_effect=[{'member': 'new', 'secret': 'dummy'}, KeyboardInterrupt])
        with patch.object(agent, 'STATE', state), patch.object(agent, 'found', return_value=[{'name': 'claude'}]), \
                patch.object(agent, 'req', request), patch('builtins.print'):
            with self.assertRaises(KeyboardInterrupt):
                agent.main()
        self.assertEqual(request.call_args_list[0].args[:2], ('POST', '/api/connect/pub/register'))
        self.assertEqual(json.loads(state.read_text())['member'], 'new')

    async def test_probe_and_invite_keep_timeout_classification(self):
        inv = connect.new_invite('http://localhost')
        with patch.object(connect, 'remote_call', AsyncMock(side_effect=asyncio.TimeoutError())):
            await connect._test(inv['token'], 'A')
        record = connect.INV[inv['token']]
        self.assertEqual(record['fix'], 'retry')
        with patch.object(s, 'fetch_models', AsyncMock(side_effect=asyncio.TimeoutError())):
            result = await connect.paste('sk-ant-' + 'a' * 32)
        self.assertEqual(result['fix'], 'retry')

    async def test_sequence_cursor_at_zero_version_is_append_delta(self):
        s.PROJECTS = [{'id': 'p', 'name': 'P', 'members': []}]
        s.add_msg('p', 'Ali', 'old')
        s.CHATS['p'] = s.load_chat('p')
        s.VER = 0
        result = json.loads((await s.h_chat(Request(match_info={'pid': 'p'}, query={'since': '1', 'v': '0'}))).body)
        self.assertFalse(result['full'])
        self.assertEqual(result['messages'], [])

    def test_empty_accepted_targets_are_authoritative(self):
        message = s.add_msg('p', 'Ali', 'hello', accepted_to=[])
        self.assertEqual(s.say_receipt(message, ['A'])['to'], [])

    def test_relay_override_includes_ambiguous_and_tuple_vendors(self):
        for key in ('sk-' + 'a' * 40, 'sk-or-v1-' + 'a' * 48):
            found = connect.detect('http://localhost/v1 ' + key)
            self.assertEqual([(v[0], base) for _, v, base in found], [('relay', 'http://localhost/v1')])

    def test_presence_only_clears_offline_reason_and_bumps_on_change(self):
        s.CFG['members'] = [{'name': 'A', 'remote': True}]
        with patch.object(s, 'bump') as bump:
            connect.remote_status('A')
            connect.remote_status('A')
            bump.assert_called_once()
        connect.REMOTE['A'] = {'seen': connect.time.time()}
        connect.remote_status('A')
        self.assertNotIn('A', c.MEMBER_STATE)
        c.mark('A', 'resting', '余额不足')
        connect.remote_status('A')
        self.assertEqual(c.STATE_REASON['A'], '余额不足')
        self.assertEqual(c.MEMBER_STATE['A'], 'resting')

    async def test_registration_never_replaces_an_existing_member_queue(self):
        old = {'queue': asyncio.Queue(), 'wait': {}}
        connect.REMOTE['A'] = old
        s.CFG['members'] = [{'name': 'A', 'remote': True}]
        inv = connect.new_invite('http://localhost')
        request = Request(headers={'X-Chorus-Invite': inv['token']}, body={'name': 'A', 'clis': [{'name': 'claude'}]})
        with patch.object(s, 'save_cfg'), patch.object(connect, '_test', AsyncMock()):
            response = await connect.h_register(request)
            tasks = list(connect.TEST_TASKS)
            await asyncio.gather(*tasks)
            await asyncio.sleep(0)
        self.assertEqual(json.loads(response.body)['member'], 'A·remote·claude')
        self.assertIs(connect.REMOTE['A'], old)

    def test_forwarded_https_is_used_only_for_valid_schemes(self):
        for value, expected in (('https', 'https'), ('http', 'http'), ('ftp', 'http'),
                                ('https,http', 'http'), ("https'; bad", 'http')):
            req = Request(scheme='http', host='relay.example', headers={
                'X-Forwarded-Proto': value, 'X-Forwarded-Prefix': '/chorus2'})
            self.assertEqual(connect._server_url(req), expected + '://relay.example/chorus2')

    def test_setup_reports_path_without_password(self):
        with patch.object(s, 'load', return_value={}), patch.object(s, 'save_cfg'), \
                patch.dict(s.os.environ, {'AICHAT_PASSWORD': '', 'AICHAT_OWNER': ''}), patch('builtins.print') as output:
            s.setup()
        text = ' '.join(str(call.args) for call in output.call_args_list)
        self.assertIn(str(s.cfg_path().resolve()), text)
        self.assertNotIn(s.CFG['password'], text)


if __name__ == '__main__':
    unittest.main()
