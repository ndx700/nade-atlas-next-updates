import asyncio, unittest
import compat


class T(unittest.IsolatedAsyncioTestCase):
    async def test_fires(self):
        with self.assertRaises(asyncio.TimeoutError):
            async with compat.timeout(0.05):
                await asyncio.sleep(1)

    async def test_ok(self):
        async with compat.timeout(1):
            await asyncio.sleep(0.01)
