"""Context budgets: pure window tests and isolated prompt construction."""
import copy
from unittest.mock import patch

import pytest
import context
import server as s


@pytest.mark.parametrize('quality,expected', [('save', 8000), ('standard', 20000), ('max', 60000)])
def test_project_quality_controls_budget_and_prompt(tmp_path, quality, expected):
    p = {'id': 'p', 'name': '项目', 'members': ['ai'], 'quality': quality}
    m = {'name': 'ai', 'context': '123'}
    msg = {'seq': 1, 'text': '你好', 'who': 'Ali', 'at': 'now'}
    with patch.multiple(s, DATA=tmp_path, CFG={'context': 'save'}), \
            patch.object(s, 'project', return_value=p), \
            patch.object(s, 'member', return_value=m), \
            patch.object(s, 'scope_msgs', return_value=[msg]), \
            patch.object(s, 'memory', return_value=[]), \
            patch.object(s, 'summary', return_value={'text': '', 'upto': 0}), \
            patch.object(s, 'invoked_skills', return_value=[]), \
            patch.object(s, 'cards') as cards:
        cards.return_value.prompt.return_value = ''
        assert s.budget_for(m, p) == expected
        assert s.build_prompt('p', 'ai', msg, False)[2]['budget'] == expected


def test_legacy_member_and_global_budget_fallback():
    with patch.object(s, 'CFG', {'context': 'more'}):
        assert s.budget_for({}) == 60000
        assert s.budget_for({'context': 'save'}, {}) == 8000
        assert s.budget_for({'context': '321'}) == 321


def line(m, short):
    return f"[{m['seq']}] " + (context.prune(m['text']) if short else m['text'])


@pytest.mark.parametrize('text', ['龙' * 10000, 'abcd' * 10000])
def test_oversized_pins_are_bounded_visible_and_do_not_mutate(text):
    msgs = [{'seq': 1, 'text': text, 'pinned': True},
            {'seq': 2, 'text': text, 'pinned': True},
            {'seq': 3, 'text': '最近消息'}]
    original = copy.deepcopy(msgs)
    kept, fallen, used = context.window(msgs, 180, line)
    rendered = '\n\n'.join(line(*item) for item in kept)
    assert used == context.tokens(rendered) <= 180
    assert [m['seq'] for m, _ in kept] == [1, 2, 3]
    assert rendered.count('置顶消息过大，已按上下文预算截断') == 2
    assert not fallen
    assert msgs == original


def test_pin_and_recent_message_cannot_exceed_budget():
    msgs = [{'seq': 1, 'text': '固定要求', 'pinned': True},
            {'seq': 2, 'text': '龙' * 10000}]
    kept, fallen, used = context.window(msgs, 100, line)
    assert used <= 100
    assert [m['seq'] for m, _ in kept] == [1, 2]
    assert '消息已按上下文预算截断' in kept[-1][0]['text']
    assert not fallen


@pytest.mark.parametrize('budget', [0, 1, 20, 100])
def test_oversized_newest_and_tiny_budgets(budget):
    msgs = [{'seq': 1, 'text': '龙' * 10000}]
    kept, fallen, used = context.window(msgs, budget, line)
    assert used <= budget
    assert len(kept) + len(fallen) == 1
    if kept:
        assert '消息已按上下文预算截断' in line(*kept[0])


def test_normal_history_keeps_order_and_prunes_only_older_messages():
    msgs = [{'seq': i, 'text': 'hello'} for i in range(10)]
    kept, fallen, used = context.window(msgs, 1000, line)
    assert [m for m, _ in kept] == msgs
    assert [short for _, short in kept] == [True] * 4 + [False] * 6
    assert not fallen
    assert used == context.tokens('\n\n'.join(line(*item) for item in kept))


def test_pin_truncation_survives_real_message_rendering(tmp_path):
    msg = {'seq': 1, 'text': '原文' * 10000, 'pinned': True, 'at': 'now', 'who': 'Ali'}
    with patch.multiple(s, DATA=tmp_path, CFG={}, CHATS={'p': [msg]}):
        render = s.msg_line('p', False)
        kept, fallen, used = context.window([msg], 100, render)
        result = render(*kept[0])
        assert '📌' in result
        assert '置顶消息过大，已按上下文预算截断' in result
        assert used == context.tokens(result) <= 100
        assert not fallen
        assert msg['text'] == '原文' * 10000
