"""
server/verify.py — 服务端验收执行器（Task card N1）。

只暴露 ``run_checks``（以及少量可测试的内部工具），不修改 ``chorus2.py``。
集成方式（由审查人完成）：在段落状态机 ``done`` 之前调用::

    seg["verification"] = await run_checks(seg, workdir, guards)
    if not seg["verification"]["passed"]:
        # 进入升级阶梯，而不是直接完成

设计要点
--------
* ``checks`` 结构化；向后兼容：字符串 ``acceptance`` 视为 ``manual``。
* ``manual`` 不计入通过（``passed`` 只看机器可查项）。
* 安全：命令白名单、超时、cwd 限制在 ``work/<pid>``、输出截断 4KB、
  禁止网络命令（可选）、审计日志。
* 仅使用标准库 + aiohttp（本模块实际只用标准库）。
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import shlex
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Mapping, MutableMapping, Sequence

__all__ = [
    "run_checks",
    "CheckError",
    "MAX_OUTPUT_BYTES",
    "DEFAULT_TIMEOUT",
    "ALLOWED_COMMANDS",
    "NETWORK_COMMANDS",
]

# --------------------------------------------------------------------------- #
# 常量
# --------------------------------------------------------------------------- #

#: 命令输出截断上限（4KB）
MAX_OUTPUT_BYTES = 4096

#: 单条命令默认超时（秒）
DEFAULT_TIMEOUT = 120

#: 命令超时硬上限（秒）
MAX_TIMEOUT = 900

#: 允许执行的命令白名单（首 token，按 basename 匹配）
ALLOWED_COMMANDS: frozenset[str] = frozenset(
    {
        "pytest",
        "python",
        "python3",
        "npm",
        "npx",
        "node",
        "yarn",
        "pnpm",
        "mvn",
        "gradle",
        "./gradlew",
        "gradlew",
        "go",
        "cargo",
        "make",
        "ruff",
        "mypy",
        "black",
        "flake8",
        "tox",
        "unittest",
    }
)

#: 被视为"网络命令"的白名单成员（默认拒绝，可用 guards["allow_network"]=True 放开）
NETWORK_COMMANDS: frozenset[str] = frozenset({"npm", "npx", "yarn", "pnpm", "go", "cargo"})

#: regex flags 字符串 -> re 标志位
_FLAG_MAP: Mapping[str, int] = {
    "i": re.IGNORECASE,
    "m": re.MULTILINE,
    "s": re.DOTALL,
    "x": re.VERBOSE,
    "a": re.ASCII,
    "u": re.UNICODE,
}

#: count 的 unit -> 计数函数
_COUNT_UNITS: Mapping[str, Callable[[str], int]] = {
    "line": lambda text: len([ln for ln in text.splitlines() if ln.strip()]),
    "lines": lambda text: len([ln for ln in text.splitlines() if ln.strip()]),
    "char": len,
    "chars": len,
    "byte": lambda text: len(text.encode("utf-8", "replace")),
    "bytes": lambda text: len(text.encode("utf-8", "replace")),
    "match": lambda text: 0,  # 由调用方特殊处理
}

#: JSON Schema 支持的类型关键字
_JSON_TYPES: Mapping[str, tuple[type, ...]] = {
    "object": (dict,),
    "array": (list,),
    "string": (str,),
    "number": (int, float),
    "integer": (int,),
    "boolean": (bool,),
    "null": (type(None),),
}


class CheckError(Exception):
    """校验配置错误（例如未知 check 类型、非法 flags）。"""


# --------------------------------------------------------------------------- #
# 工具
# --------------------------------------------------------------------------- #


def _truncate(text: str, limit: int = MAX_OUTPUT_BYTES) -> tuple[str, bool]:
    raw = text.encode("utf-8", "replace")
    if len(raw) <= limit:
        return text, False
    head = raw[:limit].decode("utf-8", "replace")
    return head + "\n...[truncated]", True


def _resolve_within(root: Path, rel: str) -> Path:
    """把 rel 解析到 root 之内；越界则抛 CheckError。"""
    if not isinstance(rel, str) or not rel.strip():
        raise CheckError("path must be a non-empty string")
    candidate = (root / rel).resolve()
    root_resolved = root.resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise CheckError(f"path escapes workdir: {rel!r}") from exc
    return candidate


def _workdir_root(workdir: str | os.PathLike[str]) -> Path:
    root = Path(workdir).resolve()
    if not root.exists():
        raise CheckError(f"workdir does not exist: {root}")
    if not root.is_dir():
        raise CheckError(f"workdir is not a directory: {root}")
    return root


def _parse_flags(flags: Any) -> int:
    if flags is None:
        return 0
    if isinstance(flags, int):
        return flags
    if not isinstance(flags, str):
        raise CheckError(f"invalid regex flags: {flags!r}")
    value = 0
    for ch in flags:
        if ch not in _FLAG_MAP:
            raise CheckError(f"unsupported regex flag: {ch!r}")
        value |= _FLAG_MAP[ch]
    return value


def _as_int(value: Any, default: int | None = None) -> int | None:
    if value is None:
        return default
    if isinstance(value, bool):
        raise CheckError("boolean is not a valid integer here")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    raise CheckError(f"invalid integer: {value!r}")


def _check_command_token(cmd: str) -> tuple[str, list[str]]:
    """返回 (首 token basename, 全部 token)。"""
    try:
        tokens = shlex.split(cmd, posix=os.name != "nt")
    except ValueError as exc:
        raise CheckError(f"cannot parse cmd: {cmd!r}") from exc
    if not tokens:
        raise CheckError("empty cmd")
    head = tokens[0]
    base = os.path.basename(head)
    if head.startswith("./"):
        base = head
    return base, tokens


# --------------------------------------------------------------------------- #
# JSON Schema（最小子集，离线实现）
# --------------------------------------------------------------------------- #


def _validate_json_schema(value: Any, schema: Any, path: str = "$") -> list[str]:
    """返回错误列表；空列表表示通过。支持 type/required/properties/items/enum/const。"""
    errors: list[str] = []
    if not isinstance(schema, Mapping):
        raise CheckError("schema must be an object")

    if "type" in schema:
        expected = schema["type"]
        names = expected if isinstance(expected, (list, tuple)) else [expected]
        ok = False
        for name in names:
            types = _JSON_TYPES.get(str(name))
            if types is None:
                raise CheckError(f"unsupported schema type: {name!r}")
            if name == "number" and isinstance(value, bool):
                continue
            if name == "integer" and isinstance(value, bool):
                continue
            if isinstance(value, types):
                ok = True
                break
        if not ok:
            errors.append(f"{path}: expected type {expected!r}, got {type(value).__name__}")
            return errors  # 类型不符时不再深入

    if "enum" in schema:
        if value not in list(schema["enum"]):
            errors.append(f"{path}: value {value!r} not in enum")

    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: value {value!r} != const {schema['const']!r}")

    if isinstance(value, Mapping):
        required = schema.get("required")
        if isinstance(required, (list, tuple)):
            for key in required:
                if key not in value:
                    errors.append(f"{path}: missing required key {key!r}")
        props = schema.get("properties")
        if isinstance(props, Mapping):
            for key, sub in props.items():
                if key in value:
                    errors.extend(_validate_json_schema(value[key], sub, f"{path}.{key}"))
        additional = schema.get("additionalProperties")
        if additional is False and isinstance(props, Mapping):
            for key in value:
                if key not in props:
                    errors.append(f"{path}: unexpected key {key!r}")

    if isinstance(value, list) and "items" in schema:
        items = schema["items"]
        for idx, item in enumerate(value):
            errors.extend(_validate_json_schema(item, items, f"{path}[{idx}]"))

    return errors


# --------------------------------------------------------------------------- #
# Runners
# --------------------------------------------------------------------------- #

Runner = Callable[[Mapping[str, Any], Path, Mapping[str, Any]], Awaitable[dict]]


def _base_result(check: Mapping[str, Any], state: str, detail: str, **extra: Any) -> dict:
    out: dict[str, Any] = {
        "type": check.get("type", "manual"),
        "state": state,
        "detail": detail,
    }
    out.update(extra)
    return out


async def _run_command(check: Mapping[str, Any], workdir: Path, guards: Mapping[str, Any]) -> dict:
    cmd = check.get("cmd")
    if not isinstance(cmd, str) or not cmd.strip():
        return _base_result(check, "fail", "cmd must be a non-empty string")

    try:
        base, tokens = _check_command_token(cmd)
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    # 白名单
    allowed = guards.get("allowed_commands") or ALLOWED_COMMANDS
    allowed_set = {str(a) for a in allowed}
    if base not in allowed_set and tokens[0] not in allowed_set:
        return _base_result(
            check,
            "fail",
            f"command not allowed by whitelist: {base!r}",
            code=None,
        )

    # 网络命令
    network_set = {str(a) for a in (guards.get("network_commands") or NETWORK_COMMANDS)}
    if base in network_set and not guards.get("allow_network", False):
        return _base_result(
            check,
            "fail",
            f"network command blocked: {base!r} (set guards['allow_network']=True to allow)",
            code=None,
        )

    # cwd 限制
    cwd_rel = check.get("cwd", ".")
    try:
        cwd = _resolve_within(workdir, str(cwd_rel))
    except CheckError as exc:
        return _base_result(check, "fail", str(exc), code=None)
    if not cwd.is_dir():
        return _base_result(check, "fail", f"cwd does not exist: {cwd_rel!r}", code=None)

    timeout = _as_int(check.get("timeout"), DEFAULT_TIMEOUT)
    if timeout is None:
        timeout = DEFAULT_TIMEOUT
    timeout = max(1, min(timeout, MAX_TIMEOUT))

    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    env.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    # 防止子进程继承敏感 token（可选）
    for key in list(env):
        if key.upper().startswith(("GITHUB_TOKEN", "OPENAI_API_KEY", "ANTHROPIC_API_KEY")):
            env.pop(key, None)

    started = time.time()
    try:
        proc = await asyncio.create_subprocess_exec(
            *tokens,
            cwd=str(cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=(os.name == "posix"),
        )
    except (OSError, ValueError) as exc:
        return _base_result(check, "fail", f"failed to start command: {exc}", code=None)

    try:
        stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        timed_out = False
    except asyncio.TimeoutError:
        timed_out = True
        try:
            if proc.returncode is None:
                if os.name == "posix":
                    import signal

                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                else:
                    proc.kill()
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=5)
        except asyncio.TimeoutError:
            pass
        stdout_b, stderr_b = b"", b""

    duration = round(time.time() - started, 3)
    stdout, out_trunc = _truncate(stdout_b.decode("utf-8", "replace"))
    stderr, err_trunc = _truncate(stderr_b.decode("utf-8", "replace"))

    if timed_out:
        return _base_result(
            check,
            "fail",
            f"command timed out after {timeout}s",
            code=None,
            duration=duration,
            stdout=stdout,
            stderr=stderr,
            truncated=out_trunc or err_trunc,
        )

    code = proc.returncode
    state = "pass" if code == 0 else "fail"
    detail = f"exit code {code}"
    return _base_result(
        check,
        state,
        detail,
        code=code,
        duration=duration,
        stdout=stdout,
        stderr=stderr,
        truncated=out_trunc or err_trunc,
    )


async def _run_file_exists(check: Mapping[str, Any], workdir: Path, guards: Mapping[str, Any]) -> dict:
    rel = check.get("path")
    try:
        target = _resolve_within(workdir, str(rel))
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    if not target.exists():
        return _base_result(check, "fail", f"missing file: {rel!r}", size=None)
    if not target.is_file():
        return _base_result(check, "fail", f"not a regular file: {rel!r}", size=None)

    size = target.stat().st_size
    min_bytes = _as_int(check.get("min_bytes"), None)
    max_bytes = _as_int(check.get("max_bytes"), None)

    if min_bytes is not None and size < min_bytes:
        return _base_result(
            check,
            "fail",
            f"file too small: {size} < min_bytes {min_bytes}",
            size=size,
        )
    if max_bytes is not None and size > max_bytes:
        return _base_result(
            check,
            "fail",
            f"file too large: {size} > max_bytes {max_bytes}",
            size=size,
        )
    return _base_result(check, "pass", f"file exists ({size} bytes)", size=size)


async def _run_json_schema(check: Mapping[str, Any], workdir: Path, guards: Mapping[str, Any]) -> dict:
    rel = check.get("path")
    schema = check.get("schema")
    if not isinstance(schema, Mapping):
        return _base_result(check, "fail", "schema must be an object")

    try:
        target = _resolve_within(workdir, str(rel))
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    if not target.is_file():
        return _base_result(check, "fail", f"missing file: {rel!r}")

    try:
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return _base_result(check, "fail", f"cannot read file: {exc}")

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        return _base_result(check, "fail", f"invalid JSON: {exc}")

    try:
        errors = _validate_json_schema(data, schema)
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    if errors:
        detail, _ = _truncate("; ".join(errors))
        return _base_result(check, "fail", f"schema mismatch: {detail}", errors=errors[:20])
    return _base_result(check, "pass", "schema satisfied")


async def _run_regex(check: Mapping[str, Any], workdir: Path, guards: Mapping[str, Any]) -> dict:
    rel = check.get("path")
    pattern = check.get("pattern")
    if not isinstance(pattern, str) or not pattern:
        return _base_result(check, "fail", "pattern must be a non-empty string")

    try:
        # 规划出的规则几乎都按「行」写（^# 标题$），没写 flags 时默认按行匹配
        flags = _parse_flags(check.get("flags")) if check.get("flags") is not None else re.MULTILINE
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    try:
        target = _resolve_within(workdir, str(rel))
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    if not target.is_file():
        return _base_result(check, "fail", f"missing file: {rel!r}")

    try:
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return _base_result(check, "fail", f"cannot read file: {exc}")

    try:
        rx = re.compile(pattern, flags)
    except re.error as exc:
        return _base_result(check, "fail", f"invalid regex: {exc}")

    m = rx.search(text)
    if not m:
        return _base_result(check, "fail", f"pattern not found: {pattern!r}", matches=0)
    return _base_result(
        check,
        "pass",
        f"pattern matched at offset {m.start()}",
        matches=1,
    )


async def _run_count(check: Mapping[str, Any], workdir: Path, guards: Mapping[str, Any]) -> dict:
    rel = check.get("path")
    unit = str(check.get("unit", "line")).lower()

    try:
        target = _resolve_within(workdir, str(rel))
    except CheckError as exc:
        return _base_result(check, "fail", str(exc))

    if not target.is_file():
        return _base_result(check, "fail", f"missing file: {rel!r}")

    try:
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return _base_result(check, "fail", f"cannot read file: {exc}")

    if unit == "match":
        pattern = check.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            return _base_result(check, "fail", "unit='match' requires a pattern")
        try:
            flags = _parse_flags(check.get("flags"))
            rx = re.compile(pattern, flags)
        except (CheckError, re.error) as exc:
            return _base_result(check, "fail", f"invalid regex: {exc}")
        value = len(rx.findall(text))
    else:
        counter = _COUNT_UNITS.get(unit)
        if counter is None:
            return _base_result(
                check,
                "fail",
                f"unsupported unit: {unit!r} (use line/lines/char/chars/byte/bytes/match)",
            )
        value = counter(text)

    min_v = _as_int(check.get("min"), None)
    max_v = _as_int(check.get("max"), None)

    if min_v is not None and value < min_v:
        return _base_result(
            check,
            "fail",
            f"{unit} count {value} < min {min_v}",
            count=value,
            unit=unit,
        )
    if max_v is not None and value > max_v:
        return _base_result(
            check,
            "fail",
            f"{unit} count {value} > max {max_v}",
            count=value,
            unit=unit,
        )
    return _base_result(
        check,
        "pass",
        f"{unit} count {value} within bounds",
        count=value,
        unit=unit,
    )


_RUNNERS: Mapping[str, Runner] = {
    "command": _run_command,
    "file_exists": _run_file_exists,
    "json_schema": _run_json_schema,
    "regex": _run_regex,
    "count": _run_count,
}


# --------------------------------------------------------------------------- #
# 入口
# --------------------------------------------------------------------------- #


def _normalize_checks(seg: Mapping[str, Any]) -> list[Any]:
    """从 seg 提取 checks；向后兼容字符串 acceptance。"""
    raw = seg.get("checks")
    if raw is None or raw == []:
        acc = seg.get("acceptance")
        if isinstance(acc, str) and acc.strip():
            return [{"type": "manual", "text": acc}]
        if isinstance(acc, list):
            return [a if isinstance(a, Mapping) else {"type": "manual", "text": str(a)} for a in acc]
        return []
    if isinstance(raw, Mapping):
        raw = [raw]
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        raise CheckError("checks must be a list")
    return list(raw)


async def run_checks(
    seg: Mapping[str, Any],
    workdir: str | os.PathLike[str],
    guards: Mapping[str, Any] | None = None,
) -> dict:
    """服务器侧执行机器可查的验收；manual 类型不计入通过。

    参数
    ----
    seg:
        段落（或任务单）字典，需含 ``checks``（或旧版 ``acceptance`` 字符串）。
    workdir:
        项目工作目录（通常是 ``work/<pid>``）。所有 ``path``/``cwd`` 都被限制在其内部。
    guards:
        安全护栏，可选键：
        * ``allowed_commands``: 允许的命令白名单（默认 ``ALLOWED_COMMANDS``）
        * ``network_commands``: 视为网络命令的集合（默认 ``NETWORK_COMMANDS``）
        * ``allow_network``: bool，是否允许网络命令（默认 False）
        * ``audit``: 可调用对象 ``fn(record: dict) -> None``，审计日志回调

    返回
    ----
    ``{"passed": bool, "manual": bool, "results": [...], "at": float, "by": "server"}``
    """
    guards = dict(guards or {})
    root = _workdir_root(workdir)

    checks = _normalize_checks(seg)
    results: list[dict] = []

    for check in checks:
        if not isinstance(check, Mapping):
            results.append(
                {
                    "type": "manual",
                    "state": "fail",
                    "detail": f"invalid check entry: {check!r}",
                }
            )
            continue

        kind = str(check.get("type", "manual")).lower()
        if kind == "manual":
            results.append(
                {
                    "type": "manual",
                    "state": "manual",
                    "detail": check.get("text"),
                }
            )
            continue

        runner = _RUNNERS.get(kind)
        if runner is None:
            results.append(
                {
                    "type": kind,
                    "state": "fail",
                    "detail": f"unknown check type: {kind!r}",
                }
            )
            continue

        try:
            result = await runner(check, root, guards)
        except CheckError as exc:
            result = {"type": kind, "state": "fail", "detail": str(exc)}
        except Exception as exc:  # 防御性：单条 check 崩溃不应拖垮整体
            result = {
                "type": kind,
                "state": "fail",
                "detail": f"internal error: {type(exc).__name__}: {exc}",
            }
        results.append(result)

    machine = [r for r in results if r.get("state") != "manual"]
    passed = all(r.get("state") == "pass" for r in machine) if machine else True
    has_manual = any(r.get("state") == "manual" for r in results)
    passed = passed and not has_manual

    payload = {
        "passed": passed,
        "manual": has_manual,
        "results": results,
        "at": time.time(),
        "by": "server",
    }

    audit = guards.get("audit")
    if callable(audit):
        try:
            audit(
                {
                    "event": "verify",
                    "passed": passed,
                    "manual": has_manual,
                    "count": len(results),
                    "at": payload["at"],
                    "by": "server",
                    "results": [
                        {"type": r.get("type"), "state": r.get("state"), "detail": r.get("detail")}
                        for r in results
                    ],
                }
            )
        except Exception:
            pass  # 审计失败不影响验收结果

    return payload
