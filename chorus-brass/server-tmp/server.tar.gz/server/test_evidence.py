"""Tests for server.evidence — offline, stdlib-only (unittest).

Run:  python -m unittest server.test_evidence -v
  or: pytest server/test_evidence.py
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

# Allow running from repo root without installing a package.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import evidence  # noqa: E402
from evidence import (  # noqa: E402
    EvidenceError,
    Event,
    Manifest,
    append_event,
    build_handoff,
    read_events,
    read_manifest,
    recover_from_artifacts,
    record_acceptance,
    record_decision,
    record_file,
    write_manifest,
)


class EvidenceTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = self._tmp.name
        self.events_path = os.path.join(self.root, "work", "p1", "events.jsonl")
        self.manifest_path = os.path.join(self.root, "work", "p1", "manifest.json")

    def tearDown(self) -> None:
        self._tmp.cleanup()


class TestAppendEvent(EvidenceTestCase):
    def test_append_creates_dirs_and_file(self) -> None:
        ev = append_event(self.events_path, "seg-a", "decision", {"id": "d1", "text": "go"})
        self.assertTrue(os.path.exists(self.events_path))
        self.assertEqual(ev.seg, "seg-a")
        self.assertEqual(ev.kind, "decision")

    def test_append_is_append_only(self) -> None:
        append_event(self.events_path, "seg-a", "decision", {"id": "d1"})
        append_event(self.events_path, "seg-a", "file", {"path": "a.py"})
        events = read_events(self.events_path)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0].kind, "decision")
        self.assertEqual(events[1].kind, "file")

    def test_append_rejects_empty_seg_or_kind(self) -> None:
        with self.assertRaises(EvidenceError):
            append_event(self.events_path, "", "decision", {})
        with self.assertRaises(EvidenceError):
            append_event(self.events_path, "seg-a", "", {})

    def test_read_events_skips_corrupted_lines(self) -> None:
        append_event(self.events_path, "seg-a", "decision", {"id": "d1"})
        with open(self.events_path, "a", encoding="utf-8") as fh:
            fh.write("{not valid json\n")
        append_event(self.events_path, "seg-a", "file", {"path": "a.py"})
        events = read_events(self.events_path)
        self.assertEqual(len(events), 2)

    def test_read_events_missing_file_returns_empty(self) -> None:
        self.assertEqual(read_events(os.path.join(self.root, "nope.jsonl")), [])


class TestManifest(EvidenceTestCase):
    def test_write_and_read_roundtrip(self) -> None:
        m = Manifest(seg="seg-a", pid="p1", decisions=[{"id": "d1"}])
        write_manifest(self.manifest_path, m)
        loaded = read_manifest(self.manifest_path)
        assert loaded is not None
        self.assertEqual(loaded.seg, "seg-a")
        self.assertEqual(loaded.decisions, [{"id": "d1"}])

    def test_read_missing_returns_none(self) -> None:
        self.assertIsNone(read_manifest(self.manifest_path))

    def test_read_corrupted_raises(self) -> None:
        os.makedirs(os.path.dirname(self.manifest_path), exist_ok=True)
        with open(self.manifest_path, "w", encoding="utf-8") as fh:
            fh.write("{broken")
        with self.assertRaises(EvidenceError):
            read_manifest(self.manifest_path)


class TestRecordHelpers(EvidenceTestCase):
    def test_record_decision_writes_both_stores(self) -> None:
        record_decision(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-a",
            decision={"id": "d1", "text": "ship it"},
            pid="p1",
        )
        events = read_events(self.events_path)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].kind, "decision")
        m = read_manifest(self.manifest_path)
        assert m is not None
        self.assertEqual(m.decisions, [{"id": "d1", "text": "ship it"}])
        self.assertEqual(m.pid, "p1")

    def test_record_file_and_acceptance(self) -> None:
        record_file(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-a",
            file_entry={"path": "server/x.py", "sha": "abc"},
            pid="p1",
        )
        record_acceptance(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-a",
            acceptance={"check": "tests", "ok": True},
            pid="p1",
        )
        m = read_manifest(self.manifest_path)
        assert m is not None
        self.assertEqual(len(m.files), 1)
        self.assertEqual(len(m.acceptances), 1)
        self.assertEqual(len(read_events(self.events_path)), 2)


class TestRecoverFromArtifacts(EvidenceTestCase):
    def test_recover_from_manifest_only(self) -> None:
        m = Manifest(
            seg="seg-a",
            pid="p1",
            decisions=[{"id": "d1", "text": "use plan A"}],
            files=[{"path": "server/a.py", "sha": "abc"}],
            acceptances=[{"check": "unit", "ok": True}],
            upstream={"from": "seg-0"},
        )
        write_manifest(self.manifest_path, m)

        recovered = recover_from_artifacts("seg-a", self.manifest_path, None)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(recovered["sources"], ["manifest"])
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(recovered["decisions"][0]["id"], "d1")
        self.assertEqual(recovered["files"][0]["path"], "server/a.py")
        self.assertTrue(recovered["acceptances"][0]["ok"])
        self.assertEqual(recovered["upstream"], {"from": "seg-0"})

    def test_recover_from_events_only(self) -> None:
        append_event(self.events_path, "seg-a", "decision", {"id": "d1"})
        append_event(self.events_path, "seg-a", "file", {"path": "a.py"})
        append_event(self.events_path, "seg-a", "acceptance", {"check": "smoke", "ok": True})

        recovered = recover_from_artifacts("seg-a", None, self.events_path)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(recovered["sources"], ["events"])
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(len(recovered["files"]), 1)
        self.assertEqual(len(recovered["acceptances"]), 1)

    def test_recover_dedupes_across_stores(self) -> None:
        # Same fact recorded in both manifest and events → appears once.
        record_decision(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-a",
            decision={"id": "d1", "text": "same"},
            pid="p1",
        )
        recovered = recover_from_artifacts("seg-a", self.manifest_path, self.events_path)
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(recovered["sources"], ["manifest", "events"])

    def test_recover_ignores_other_seg_events(self) -> None:
        append_event(self.events_path, "seg-a", "decision", {"id": "d1"})
        append_event(self.events_path, "seg-b", "decision", {"id": "d2"})
        recovered = recover_from_artifacts("seg-a", None, self.events_path)
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(recovered["decisions"][0]["id"], "d1")

    def test_recover_accepts_in_memory_inputs(self) -> None:
        manifest_dict = {
            "seg": "seg-a",
            "pid": "p1",
            "decisions": [{"id": "d1"}],
            "files": [],
            "acceptances": [],
            "upstream": {},
            "meta": {},
        }
        events_list = [
            {"seg": "seg-a", "kind": "file", "payload": {"path": "x.py"}, "ts": 1.0},
        ]
        recovered = recover_from_artifacts("seg-a", manifest_dict, events_list)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(len(recovered["files"]), 1)

    def test_recover_empty_inputs_not_recovered(self) -> None:
        recovered = recover_from_artifacts("seg-a", None, None)
        self.assertFalse(recovered["recovered"])
        self.assertEqual(recovered["sources"], [])
        self.assertEqual(recovered["decisions"], [])

    def test_recover_rejects_empty_seg(self) -> None:
        with self.assertRaises(EvidenceError):
            recover_from_artifacts("", None, None)


class TestDoDHandoffDropped(EvidenceTestCase):
    """DoD: 人为丢弃一条 handoff 消息，段落仍能从 manifest 恢复并完成。"""

    def test_downstream_completes_despite_dropped_handoff(self) -> None:
        # --- Upstream segment "seg-0" produces key facts -----------------
        upstream_handoff = build_handoff(
            "seg-0",
            decisions=[{"id": "d1", "text": "use plan A"}],
            files=[{"path": "server/core.py", "sha": "deadbeef"}],
            acceptances=[{"check": "unit", "ok": True}],
            upstream={"from": "root"},
            meta={"author": "agent-1"},
        )

        # Persist to the two redundant stores (memory is out of scope here).
        record_decision(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-0",
            decision=upstream_handoff["decisions"][0],
            pid="p1",
        )
        record_file(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-0",
            file_entry=upstream_handoff["files"][0],
            pid="p1",
        )
        record_acceptance(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-0",
            acceptance=upstream_handoff["acceptances"][0],
            pid="p1",
        )

        # --- Message bus drops the handoff --------------------------------
        delivered_message: dict | None = None  # simulate total loss

        # --- Downstream segment "seg-1" runs ------------------------------
        if delivered_message is None:
            # Fallback: rebuild input from artifacts.
            recovered = recover_from_artifacts("seg-0", self.manifest_path, self.events_path)
        else:
            recovered = delivered_message

        self.assertTrue(recovered["recovered"])
        self.assertEqual(len(recovered["decisions"]), 1)
        self.assertEqual(recovered["decisions"][0]["text"], "use plan A")
        self.assertEqual(recovered["files"][0]["path"], "server/core.py")
        self.assertTrue(recovered["acceptances"][0]["ok"])

        # Downstream can now complete: it records its own acceptance.
        record_acceptance(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-1",
            acceptance={"check": "downstream-done", "ok": True},
            pid="p1",
        )
        m = read_manifest(self.manifest_path)
        assert m is not None
        seg1_accepts = [a for a in m.acceptances if a.get("check") == "downstream-done"]
        self.assertEqual(len(seg1_accepts), 1)
        self.assertTrue(seg1_accepts[0]["ok"])

    def test_recover_from_manifest_when_events_also_lost(self) -> None:
        # Even if events.jsonl is lost, manifest alone suffices.
        record_decision(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-0",
            decision={"id": "d1", "text": "plan A"},
            pid="p1",
        )
        os.remove(self.events_path)  # simulate events loss

        recovered = recover_from_artifacts("seg-0", self.manifest_path, self.events_path)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(recovered["sources"], ["manifest"])
        self.assertEqual(recovered["decisions"][0]["text"], "plan A")

    def test_recover_from_events_when_manifest_also_lost(self) -> None:
        # Even if manifest is lost, events.jsonl alone suffices.
        record_decision(
            events_path=self.events_path,
            manifest_path=self.manifest_path,
            seg="seg-0",
            decision={"id": "d1", "text": "plan A"},
            pid="p1",
        )
        os.remove(self.manifest_path)  # simulate manifest loss

        recovered = recover_from_artifacts("seg-0", self.manifest_path, self.events_path)
        self.assertTrue(recovered["recovered"])
        self.assertEqual(recovered["sources"], ["events"])
        self.assertEqual(recovered["decisions"][0]["text"], "plan A")


class TestEventSerialization(EvidenceTestCase):
    def test_event_roundtrip(self) -> None:
        ev = Event(seg="s", kind="decision", payload={"a": 1}, ts=123.0, event_id="abc")
        d = ev.to_dict()
        self.assertEqual(json.loads(json.dumps(d))["event_id"], "abc")
        ev2 = Event.from_dict(d)
        self.assertEqual(ev2.seg, "s")
        self.assertEqual(ev2.payload, {"a": 1})
        self.assertEqual(ev2.ts, 123.0)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
