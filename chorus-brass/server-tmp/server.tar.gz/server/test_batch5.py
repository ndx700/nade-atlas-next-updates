"""Message scheduling regressions; no network or production storage."""
import asyncio
import gc
import pathlib
import tempfile
import shlex
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import background
import server as s
import test_member_timeout


class Scheduling(test_member_timeout.MemberTimeout):
    async def test_now_queues_in_same_room(self):
        first = await self.start()
        await self.start(root='second', opts={'priority': 'now'})
        self.assertEqual(len(s.ROOTS['second']['started']), 0)
        first.cancel()
        await asyncio.wait_for(asyncio.gather(first, return_exceptions=True), 3)
        await asyncio.sleep(0)
        self.assertTrue(s.ROOTS['second']['started'])

    async def test_room_stop_does_not_kill_other_room_processes(self):
        await self.start()
        other = await self.start(pid='q', root='other')
        with patch.object(s, 'RUNNING', {'A': {object()}}), patch.object(s, 'kill_process_group', AsyncMock()) as kill:
            await s.h_room_stop(type('Req', (), {'match_info': {'pid': 'p'}, 'query': {'root_id': 'root'}})())
            kill.assert_not_called()
        self.assertFalse(other.done())

    async def test_cli_output_resets_silence_clock_and_action_stops(self):
        with tempfile.TemporaryDirectory() as cwd:
            reply = {'who': 'A', 'seq': 1, 'text': ''}
            emitted = asyncio.Event()
            resumed = asyncio.Event()
            gate = pathlib.Path(cwd) / 'resume'
            code = ("import sys,time,pathlib;sys.stdin.read();sys.stdout.write('x');sys.stdout.flush();"
                    f"gate=pathlib.Path({str(gate)!r});"
                    "exec('while not gate.exists(): time.sleep(.01)');"
                    "sys.stderr.write('y');sys.stderr.flush();time.sleep(30)")
            def live(*args, **kwargs):
                if kwargs.get('text') == 'x':
                    emitted.set()
                if kwargs.get('note') == 'y':
                    resumed.set()
            async def answer(*args):
                await s.call_cli('p', {'name': 'A', 'cwd': cwd, 'cmd': 'python3 -c ' + shlex.quote(code)}, reply, '', '', '', '')
            with patch.object(s, 'answer', answer), patch.object(s, 'live', live):
                task = asyncio.create_task(s.run_member('p', 'A', {}, {'root_id': 'root'}))
                self.tasks.append(task)
                await asyncio.wait_for(emitted.wait(), 3)
                watch = next(iter(s.ROOTS['root']['timeout_watch'].values()))
                self.assertTrue(watch['silence'])
                self.advance(479)
                self.assertEqual(s.CHATS, {})
                gate.touch()
                await asyncio.wait_for(resumed.wait(), 3)
                self.advance(1)
                self.assertEqual(s.CHATS, {})
                self.advance(479)
                msg = s.CHATS['p'][0]
                self.assertIn('无输出', msg['text'])
                self.assertEqual(s.msg_view(msg)['action']['label'], '叫停本轮')
                self.assertEqual(msg['action']['url'], '/api/room/p/stop?root_id=root')
                await s.h_room_stop(type('Req', (), {'match_info': {'pid': 'p'}, 'query': {'root_id': 'root'}})())
                self.assertTrue(task.cancelled())
                self.assertFalse(s.RUNNING['A'])
                self.assertFalse(background.cwd_lock(cwd).locked())

    async def test_cli_chunk_boundaries_preserve_utf8(self):
        with tempfile.TemporaryDirectory() as cwd:
            code = ("import os,time;data='龙'.encode();os.write(1,data[:1]);"
                    "time.sleep(.03);os.write(1,data[1:]);os.write(2,data[:2]);"
                    "time.sleep(.03);os.write(2,data[2:])")
            reply = {'who': 'A'}
            with patch.object(s, 'live', lambda pid, reply, **values: reply.update(values)):
                await s.call_cli('p', {'name': 'A', 'cwd': cwd, 'cmd': 'python3 -c ' + shlex.quote(code)},
                                 reply, '', '', '', '')
            self.assertEqual(reply['text'], '龙')
            self.assertEqual(reply['note'], '龙')

    async def test_cwd_queue_does_not_count_as_silent_execution(self):
        with tempfile.TemporaryDirectory() as cwd:
            lock = background.cwd_lock(cwd)
            await lock.acquire()
            async def answer(*args):
                await s.call_cli('p', {'cwd': cwd}, {}, '', '', '', '')
            with patch.object(s, 'answer', answer):
                task = asyncio.create_task(s.run_member('p', 'A', {}, {'root_id': 'root'}))
                self.tasks.append(task)
                await asyncio.sleep(0)
                self.advance(900)
                self.assertEqual(s.CHATS, {})
                task.cancel()
                await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 3)
                lock.release()


class Background(IsolatedAsyncioTestCase):
    async def test_retains_pending_and_releases_completed_tasks(self):
        event = asyncio.Event()
        task = background.spawn(asyncio.wait_for(event.wait(), 3))
        gc.collect()
        self.assertIn(task, background.BACKGROUND)
        event.set()
        await asyncio.wait_for(task, 3)
        await asyncio.sleep(0)
        self.assertNotIn(task, background.BACKGROUND)

    async def test_cwd_aliases_share_lock_but_worktrees_do_not(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / 'tree').mkdir()
            (root / 'alias').symlink_to(root / 'tree', target_is_directory=True)
            self.assertIs(background.cwd_lock(root / 'tree'), background.cwd_lock(root / 'alias'))
            self.assertIsNot(background.cwd_lock(root / 'tree'), background.cwd_lock(root / 'other'))

    async def test_cli_and_ensemble_use_same_cwd_queue(self):
        import ensemble

        async def drain(task):
            task.cancel()
            await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 3)

        with tempfile.TemporaryDirectory() as tmp:
            lock = background.cwd_lock(tmp)
            with patch.object(s, '_call_cli', AsyncMock()) as call:
                async with lock:
                    task = asyncio.create_task(s.call_cli('p', {'cwd': tmp}, {}, '', '', '', ''))
                    self.addAsyncCleanup(drain, task)
                    await asyncio.sleep(0)
                    call.assert_not_awaited()
                await asyncio.wait_for(task, 3)
                call.assert_awaited_once()
            # The ensemble call must wait on that very same lock.
            engine = object.__new__(ensemble.Ensemble)
            engine.breaker = ensemble.Breaker()
            engine.card_timeout = None
            adapter = type('Adapter', (), {'name': 'A', 'run': AsyncMock(return_value='ok')})()
            async with lock:
                task = asyncio.create_task(engine.call(adapter, '', None, None, cwd=tmp))
                self.addAsyncCleanup(drain, task)
                await asyncio.sleep(0)
                adapter.run.assert_not_awaited()
            self.assertEqual(await asyncio.wait_for(task, 3), 'ok')

    def test_all_fire_and_forget_calls_use_retained_helper(self):
        import ast
        for path in pathlib.Path(__file__).parent.glob('*.py'):
            if path.name.startswith('test') or path.name == 'background.py':
                continue
            tree = ast.parse(path.read_text())
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and isinstance(n.func.value, ast.Name) and n.func.value.id == 'asyncio'
                                 and n.func.attr == 'ensure_future' for n in ast.walk(tree)), path.name)
