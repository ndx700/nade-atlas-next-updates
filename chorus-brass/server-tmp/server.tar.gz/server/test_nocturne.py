"""nocturne.py 的单元测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import nocturne as noct


def make_duty(**kw):
    base = {"id": "d1", "pid": "p1", "member": "夜莺", "task": "看 issue"}
    base.update(kw)
    return noct.Duty(**base)


class DutyTest(unittest.TestCase):
    def test_defaults(self):
        duty = make_duty()
        self.assertEqual(duty.window, (23, 7))
        self.assertEqual(duty.every_min, 60)
        self.assertEqual(duty.daily_cap, 5.0)
        self.assertEqual(duty.triggers, [])
        self.assertEqual(duty.connectors, {})
        self.assertTrue(duty.enabled)

    def test_default_lists_not_shared(self):
        first = make_duty()
        second = make_duty()
        first.triggers.append({"kind": "interval", "min": 30})
        first.connectors["github"] = "write"
        self.assertEqual(second.triggers, [])
        self.assertEqual(second.connectors, {})


class WindowTest(unittest.TestCase):
    def test_normal_window(self):
        duty = make_duty(window=(9, 18))
        self.assertTrue(noct.in_window(duty, 9))
        self.assertTrue(noct.in_window(duty, 17))
        self.assertFalse(noct.in_window(duty, 18))
        self.assertFalse(noct.in_window(duty, 8))

    def test_wrap_midnight(self):
        duty = make_duty(window=(23, 7))
        self.assertTrue(noct.in_window(duty, 23))
        self.assertTrue(noct.in_window(duty, 0))
        self.assertTrue(noct.in_window(duty, 2))
        self.assertTrue(noct.in_window(duty, 6))
        self.assertFalse(noct.in_window(duty, 7))
        self.assertFalse(noct.in_window(duty, 12))

    def test_equal_bounds_means_round_the_clock(self):
        duty = make_duty(window=(8, 8))
        for hour in range(24):
            self.assertTrue(noct.in_window(duty, hour), hour)

    def test_hour_wraps(self):
        duty = make_duty(window=(23, 7))
        self.assertTrue(noct.in_window(duty, 25))  # 1 点


class IntervalTest(unittest.TestCase):
    def test_unknown_quota_uses_every_min(self):
        self.assertEqual(noct.interval_for(make_duty(), None), 60)

    def test_high_quota_uses_every_min(self):
        self.assertEqual(noct.interval_for(make_duty(), 80.0), 60)
        self.assertEqual(noct.interval_for(make_duty(), 50.0), 60)

    def test_mid_quota_slows_to_240(self):
        self.assertEqual(noct.interval_for(make_duty(), 30.0), 240)
        self.assertEqual(noct.interval_for(make_duty(), 20.0), 240)

    def test_mid_quota_keeps_longer_every_min(self):
        duty = make_duty(every_min=300)
        self.assertEqual(noct.interval_for(duty, 30.0), 300)

    def test_low_quota_is_480(self):
        self.assertEqual(noct.interval_for(make_duty(), 10.0), 480)
        self.assertEqual(noct.interval_for(make_duty(), 5.0), 480)

    def test_low_quota_outside_window_is_none(self):
        duty = make_duty(window=(23, 7))
        self.assertIsNone(noct.interval_for(duty, 10.0, local_hour=12))

    def test_low_quota_inside_window_is_480(self):
        duty = make_duty(window=(23, 7))
        self.assertEqual(noct.interval_for(duty, 10.0, local_hour=2), 480)

    def test_almost_exhausted_stops(self):
        self.assertIsNone(noct.interval_for(make_duty(), 4.9))
        self.assertIsNone(noct.interval_for(make_duty(), 0.0))


class DueTest(unittest.TestCase):
    def test_first_run_fires(self):
        duty = make_duty(window=(9, 18))
        self.assertTrue(noct.due(duty, None, 1000.0, 10, 80.0, 0.0))

    def test_daily_cap_reached(self):
        duty = make_duty(window=(9, 18), daily_cap=5.0)
        self.assertFalse(noct.due(duty, None, 1000.0, 10, 80.0, 5.0))
        self.assertFalse(noct.due(duty, None, 1000.0, 10, 80.0, 6.5))

    def test_daily_cap_not_reached(self):
        duty = make_duty(window=(9, 18), daily_cap=5.0)
        self.assertTrue(noct.due(duty, None, 1000.0, 10, 80.0, 4.99))

    def test_outside_window(self):
        duty = make_duty(window=(23, 7))
        self.assertFalse(noct.due(duty, None, 1000.0, 12, 80.0, 0.0))

    def test_interval_not_elapsed(self):
        duty = make_duty(window=(9, 18), every_min=60)
        self.assertFalse(noct.due(duty, 1000.0, 1000.0 + 1800, 10, 80.0, 0.0))

    def test_interval_elapsed(self):
        duty = make_duty(window=(9, 18), every_min=60)
        self.assertTrue(noct.due(duty, 1000.0, 1000.0 + 3700, 10, 80.0, 0.0))

    def test_disabled_duty_never_due(self):
        duty = make_duty(window=(9, 18), enabled=False)
        self.assertFalse(noct.due(duty, None, 1000.0, 10, 80.0, 0.0))

    def test_low_quota_stops_duty(self):
        duty = make_duty(window=(9, 18))
        self.assertFalse(noct.due(duty, None, 1000.0, 10, 2.0, 0.0))


class EventTest(unittest.TestCase):
    def ci_trigger(self, **kw):
        trigger = {"kind": "event", "source": "github", "event": "ci_failed"}
        trigger.update(kw)
        return make_duty(triggers=[trigger])

    def test_matching_event(self):
        duty = self.ci_trigger()
        self.assertTrue(
            noct.match_event(duty, {"source": "github", "event": "ci_failed", "repo": "a/b"})
        )

    def test_wrong_source(self):
        duty = self.ci_trigger()
        self.assertFalse(noct.match_event(duty, {"source": "feishu", "event": "ci_failed"}))

    def test_wrong_event_name(self):
        duty = self.ci_trigger()
        self.assertFalse(
            noct.match_event(duty, {"source": "github", "event": "issue_opened"})
        )

    def test_cron_only_duty_never_matches(self):
        duty = make_duty(triggers=[{"kind": "cron", "at": "07:30"}])
        self.assertFalse(
            noct.match_event(duty, {"source": "github", "event": "ci_failed"})
        )

    def test_repo_pinned_trigger(self):
        duty = self.ci_trigger(repo="acme/api")
        self.assertFalse(
            noct.match_event(
                duty, {"source": "github", "event": "ci_failed", "repo": "other/x"}
            )
        )
        self.assertTrue(
            noct.match_event(
                duty, {"source": "github", "event": "ci_failed", "repo": "acme/api"}
            )
        )

    def test_disabled_duty_ignores_events(self):
        duty = make_duty(
            enabled=False,
            triggers=[{"kind": "event", "source": "github", "event": "ci_failed"}],
        )
        self.assertFalse(
            noct.match_event(duty, {"source": "github", "event": "ci_failed"})
        )


class EventTaskTest(unittest.TestCase):
    def test_ci_failed_wording(self):
        duty = make_duty()
        text = noct.event_task(
            duty,
            {"source": "github", "event": "ci_failed", "repo": "acme/api", "run": 42},
        )
        self.assertIn("acme/api", text)
        self.assertIn("#42", text)
        self.assertIn("CI", text)
        self.assertIn(noct.OWNER, text)

    def test_issue_opened_wording(self):
        duty = make_duty()
        text = noct.event_task(
            duty,
            {"source": "github", "event": "issue_opened", "repo": "acme/web", "number": 7},
        )
        self.assertIn("acme/web", text)
        self.assertIn("#7", text)
        self.assertIn("PR", text)

    def test_pr_review_wording(self):
        duty = make_duty()
        text = noct.event_task(
            duty,
            {"source": "github", "event": "pr_review", "repo": "acme/api", "number": 11},
        )
        self.assertIn("acme/api", text)
        self.assertIn("diff", text)

    def test_unknown_event_still_says_something(self):
        duty = make_duty()
        text = noct.event_task(duty, {"source": "feishu", "event": "mention"})
        self.assertIn("feishu", text)
        self.assertTrue(len(text) > 0)

    def test_missing_repo_uses_ref(self):
        duty = make_duty()
        text = noct.event_task(
            duty, {"source": "github", "event": "ci_failed", "run": 3}
        )
        self.assertIn("#3", text)


class CronTest(unittest.TestCase):
    def test_same_day(self):
        # now = 1970-01-01 00:00Z = 本地 08:00 (+8)
        self.assertAlmostEqual(noct.next_cron("09:00", 0.0, 8), 3600.0)

    def test_next_day_when_passed(self):
        self.assertAlmostEqual(noct.next_cron("07:30", 0.0, 8), 84600.0)

    def test_across_midnight_with_zero_offset(self):
        # day 1, 23:00 UTC
        now = 86400.0 + 23 * 3600.0
        self.assertAlmostEqual(noct.next_cron("00:30", now, 0), 2 * 86400.0 + 1800.0)

    def test_timezone_shifts_result(self):
        self.assertAlmostEqual(noct.next_cron("09:00", 0.0, 0), 9 * 3600.0)
        self.assertAlmostEqual(noct.next_cron("09:00", 0.0, 8), 3600.0)

    def test_exact_now_rolls_to_tomorrow(self):
        now = 0.0  # 本地 08:00
        self.assertAlmostEqual(
            noct.next_cron("08:00", now, 8), 86400.0
        )

    def test_bad_format_raises(self):
        for bad in ("7", "abc", "25:00", "12:99", ""):
            with self.assertRaises(ValueError):
                noct.next_cron(bad, 0.0, 8)


class OvertureTest(unittest.TestCase):
    def test_empty_night_is_quiet(self):
        brief = noct.Overture.build([], [], [], {}, "2024-05-20")
        self.assertTrue(brief["quiet"])
        self.assertEqual(brief["title"], "序曲 · 2024-05-20")
        self.assertEqual(brief["pending_count"], 0)
        self.assertEqual(brief["spent"], 0.0)
        self.assertEqual(brief["deliverables"], [])
        self.assertEqual(brief["by_member"], {})
        self.assertEqual(len(brief["lines"]), 1)

    def test_grouping_by_project(self):
        records = [
            {"pid": "p1", "name": "夜曲工程", "member": "夜莺", "what": "修了 3 个 issue", "ok": True, "cost": 1.5},
            {"pid": "p1", "name": "夜曲工程", "member": "夜莺", "what": "CI 仍红", "ok": False, "cost": 0.5},
            {"pid": "p2", "name": "网页改版", "member": "画眉", "what": "出了首页稿", "ok": True, "cost": 2.0},
        ]
        deliverables = [{"kind": "apk", "title": "app-debug.apk", "at": "07:20"}]
        brief = noct.Overture.build(records, [{"id": "c1"}], deliverables, {"total": 4.0}, "2024-05-20")

        self.assertFalse(brief["quiet"])
        text = "\n".join(brief["lines"])
        self.assertIn("夜曲工程", text)
        self.assertIn("网页改版", text)
        self.assertEqual(brief["pending_count"], 1)
        self.assertEqual(brief["spent"], 4.0)
        self.assertIn("app-debug.apk", text)
        self.assertEqual(brief["deliverables"][0]["kind"], "apk")

    def test_by_member_aggregation(self):
        records = [
            {"pid": "p1", "name": "工程", "member": "夜莺", "what": "a", "ok": True, "cost": 1.0},
            {"pid": "p1", "name": "工程", "member": "夜莺", "what": "b", "ok": False, "cost": 0.5},
        ]
        brief = noct.Overture.build(records, [], [], {}, "2024-05-20")
        slot = brief["by_member"]["夜莺"]
        self.assertEqual(slot["runs"], 2)
        self.assertEqual(slot["ok"], 1)
        self.assertAlmostEqual(slot["cost"], 1.5)
        self.assertAlmostEqual(brief["spent"], 1.5)

    def test_spend_dict_wins(self):
        records = [
            {"pid": "p1", "name": "工程", "member": "夜莺", "what": "a", "ok": True, "cost": 1.0}
        ]
        brief = noct.Overture.build(records, [], [], {"total": 9.5, "cap": 20.0}, "2024-05-20")
        self.assertEqual(brief["spent"], 9.5)
        self.assertTrue(any("上限" in line for line in brief["lines"]))

    def test_only_pending_is_not_quiet(self):
        brief = noct.Overture.build([], [{"id": "c1"}, {"id": "c2"}], [], {}, "2024-05-20")
        self.assertFalse(brief["quiet"])
        self.assertEqual(brief["pending_count"], 2)

    def test_only_deliverable_is_not_quiet(self):
        brief = noct.Overture.build(
            [], [], [{"kind": "link", "title": "预览地址", "at": "06:50"}], {}, "2024-05-20"
        )
        self.assertFalse(brief["quiet"])
        self.assertIn("预览地址", "\n".join(brief["lines"]))

    def test_failed_record_marked(self):
        records = [
            {"pid": "p1", "name": "工程", "member": "夜莺", "what": "卡在登录", "ok": False, "cost": 0.0}
        ]
        text = "\n".join(noct.Overture.build(records, [], [], {}, "2024-05-20")["lines"])
        self.assertIn("✘", text)
        self.assertIn("卡在登录", text)


class NotifyTest(unittest.TestCase):
    def test_notify_kinds(self):
        self.assertEqual(noct.NOTIFY_KINDS, ("decide", "stopped", "done"))

    def test_notify_true(self):
        for kind in ("decide", "stopped", "done"):
            self.assertTrue(noct.should_notify(kind), kind)

    def test_notify_false(self):
        for kind in ("idle", "spawn", "progress", ""):
            self.assertFalse(noct.should_notify(kind), kind)


if __name__ == "__main__":
    unittest.main()
