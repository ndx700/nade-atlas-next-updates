"""Scheduler regressions; Base isolates all persistent data in a temporary directory."""
import asyncio
from unittest.mock import patch, AsyncMock
from test_chorus2 import Base, seg
import chorus2 as c
import server as s
import recovery


class TestScheduler(Base):
    async def asyncSetUp(self):
        # Scheduler tests need registration, but no HTTP listener.
        with patch('aiohttp.test_utils.TestClient.start_server', new_callable=AsyncMock):
            await super().asyncSetUp()

    async def test_dispatches_dependency_before_unrelated_segment_finishes(self):
        release = asyncio.Event()
        original = s.run_member
        async def run(pid, who, trig, opts):
            if trig.get('seg') == 's2':
                await release.wait()
            if trig.get('seg') == 's3':
                release.set()
            await original(pid, who, trig, opts)
        s.run_member = run
        self.P()['segments'] = [seg(1), seg(2), seg(3, inputs=['s1'])]
        await self.run_all()
        self.assertTrue(release.is_set())
        self.assertTrue(all(x['stage'] == 'done' for x in self.P()['segments']))

    async def test_skip_blocks_dependents_and_creates_card(self):
        self.P()['segments'] = [seg(1, assignee='甲'), seg(2, inputs=['s1'])]
        self.behaviour['甲'] = [('err', 500, 'error')]
        with patch.object(recovery, 'decide', return_value=recovery.Decision('skip')):
            await self.run_all()
        self.assertEqual([x['stage'] for x in self.P()['segments']], ['skipped', 'blocked'])
        self.assertEqual(self.P()['pending'][0]['kind'], 'dependency_skipped')

    async def test_recovery_instructions_reach_task_cards(self):
        for action, needle in [('trim_retry', '上下文已压缩'), ('rephrase_retry', '合规任务'), ('feedback_retry', '缺测试')]:
            with self.subTest(action=action):
                c.GRAPH = __import__('wakegraph').Graph()
                self.P()['segments'] = [seg(1, assignee='甲', context='x'*5000, review_feedback='缺测试')]
                self.behaviour['甲'] = [('err', 500, 'error'), 'ok']
                with patch.object(recovery, 'decide', return_value=recovery.Decision(action)):
                    await self.run_all()
                cards = [m['text'] for m in s.CHATS['p'] if m.get('seg') == 's1']
                self.assertIn(needle, cards[-1])
                if action == 'trim_retry':
                    self.assertNotIn('x'*1001, cards[-1])

    async def test_output_reference_and_summary_reach_downstream(self):
        self.P()['segments'] = [seg(1), seg(2, inputs=['s1'])]
        await self.run_all()
        self.assertIn('output_ref', self.P()['segments'][0])
        card = next(m['text'] for m in s.CHATS['p'] if m.get('seg') == 's2')
        self.assertIn('output_ref', card)
        self.assertIn('结果', card)

    async def test_exceptions_persist_pending_card(self):
        async def bad(*args):
            raise RuntimeError('boom')
        self.P()['segments'] = [seg(1)]
        with patch.object(c, 'run_segment', bad), patch.object(c, 'save_projects') as save:
            await self.run_all()
            self.assertTrue(save.called)
        self.assertEqual(self.P()['pending'][0]['kind'], 'scheduler_error')

    async def test_consent_waits_without_retry_and_resumes(self):
        self.P()['segments'] = [seg(1, assignee='甲')]
        with patch('collab_api.consent_block', return_value='pending'):
            await self.run_all()
        self.assertEqual(self.P()['segments'][0]['stage'], 'awaiting_consent')
        self.assertFalse(self.calls)
        with patch('collab_api.consent_block', return_value=''):
            c.resume_consent()
            await c.RUNNING['p']
        self.assertEqual(self.P()['segments'][0]['stage'], 'done')

    async def test_budget_is_rechecked_after_failure(self):
        self.P()['segments'] = [seg(1, assignee='甲')]
        self.behaviour['甲'] = [('err', 500, 'error')]
        states = [{'spent': 0, 'cap': 10}, {'spent': 0, 'cap': 10}, {'spent': 10, 'cap': 10}]
        with patch.object(c.orchestra, 'budget_state', side_effect=states), patch.object(recovery, 'decide', return_value=recovery.Decision('retry')):
            await self.run_all()
        self.assertEqual(self.calls.count('甲'), 1)
        self.assertEqual(self.P()['pending'][0]['kind'], 'project_budget')

    async def test_pause_stops_retry(self):
        self.P()['segments'] = [seg(1, assignee='甲')]
        self.behaviour['甲'] = [('err', 500, 'error')]
        async def pause(_):
            self.P()['paused'] = True
        with patch.object(c, 'sleep', pause), patch.object(recovery, 'decide', return_value=recovery.Decision('retry')):
            await self.run_all()
        self.assertEqual(self.calls.count('甲'), 1)
        self.assertEqual(self.P()['segments'][0]['stage'], 'waiting')

    async def test_initial_budget_has_saved_card(self):
        self.P()['segments'] = [seg(1)]
        with patch.object(c.orchestra, 'budget_state', return_value={'spent': 10, 'cap': 10}), patch.object(c, 'save_projects') as save:
            await self.run_all()
            self.assertTrue(save.called)
        self.assertEqual(self.P()['pending'][0]['kind'], 'project_budget')

    async def test_dispatch_and_retry_do_not_call_wake_guard(self):
        self.P()['segments'] = [seg(i, title='same', assignee='甲') for i in range(1, 9)]
        self.behaviour['甲'] = [('err', 500, 'error'), 'ok']
        with patch.object(c.GRAPH, 'can_wake', side_effect=AssertionError('dispatch used wake guard')), patch.object(recovery, 'decide', return_value=recovery.Decision('retry')):
            await self.run_all()
        self.assertTrue(all(x['stage'] == 'done' for x in self.P()['segments']))

    async def test_graph_hops_survive_registration(self):
        import json
        from aiohttp import web
        with patch.object(s, 'save', side_effect=lambda path, value: path.write_text(json.dumps(value))):
            for i in range(6):
                c.GRAPH.record('root', 'p', str(i), str(i + 1), 'mention')
        c.register(web.Application(), s)
        self.assertFalse(c.GRAPH.can_wake('root', 'A', 'B', 'mention', '').ok)
        self.assertEqual(c.GRAPH.to_json()['hops']['root'], 6)

    async def test_exhausted_wake_guards_do_not_block_rate_limit_reassignment(self):
        self.P()['segments'] = [seg(1, title='same', assignee='甲')]
        s.member('甲')['priority'] = 'low'
        self.behaviour['甲'] = [('err', 429, 'rate limit')]
        # Populate real AI wake limits, then restore as on server restart.
        for i in range(6):
            c.GRAPH.record('p:s1', 'p', str(i), '乙', 'mention')
        c.GRAPH = __import__('wakegraph').Graph.from_json(c.GRAPH.to_json())
        self.assertFalse(c.GRAPH.can_wake('p:s1', '强', '乙', 'mention', 'same').ok)
        with patch.object(c.GRAPH, 'can_wake', side_effect=AssertionError('reassignment used wake guard')):
            await self.run_all()
        self.assertEqual(self.P()['segments'][0]['stage'], 'done')
        self.assertNotEqual(self.P()['segments'][0]['assignee'], '甲')
        self.assertEqual(self.calls.count('甲'), 1)
        self.assertEqual(c.GRAPH.to_json()['hops']['p:s1'], 6)
        self.assertTrue(any(e['reason'] == 'retry' for e in c.GRAPH.flow('p')['edges']))

    async def test_rate_limit_without_alternative_clears_assignee(self):
        self.P()['members'] = ['甲']
        s.member('甲')['priority'] = 'low'
        self.P()['segments'] = [seg(1, assignee='甲')]
        self.behaviour['甲'] = [('err', 429, 'rate limit')]
        await self.run_all()
        self.assertEqual(self.P()['segments'][0]['assignee'], '')
        self.assertEqual(self.P()['segments'][0]['stage'], 'waiting')

    async def test_trim_excludes_previous_conversation(self):
        old = s.add_msg('p', '甲', 'OLD_CONTEXT_SECRET')
        trig = s.add_msg('p', '系统', 'compact task')
        trig['compact_context'] = True
        _, prompt, _ = s.build_prompt('p', '甲', trig, False)
        self.assertIn('compact task', prompt)
        self.assertNotIn(old['text'], prompt)

    async def test_skip_propagates_through_reverse_order_dependencies(self):
        self.P()['segments'] = [seg(3, inputs=['s2']), seg(2, inputs=['s1']), seg(1, stage='skipped')]
        await self.run_all()
        self.assertEqual([x['stage'] for x in self.P()['segments']], ['blocked', 'blocked', 'skipped'])
        self.assertEqual(len(self.P()['pending']), 2)

    async def test_machine_checkboxes_are_published_after_merge(self):
        self.P()['segments'] = [seg(1)]
        await self.run_all()
        result = c.view('p')['segments'][0]
        self.assertTrue(result['verification']['passed'])
        self.assertEqual(result['verification']['by'], 'server')
        self.assertEqual(result['acceptance_checked'], [True])
        self.assertEqual(self.P()['segments'][0]['stage'], 'done')

    async def test_text_acceptance_blocks_without_machine_proof(self):
        card = seg(1)
        card.pop('checks')
        self.P()['segments'] = [card]
        await self.run_all()
        self.assertEqual(card['stage'], 'blocked')
        self.assertEqual(card['acceptance_checked'], [False])
        self.assertFalse(card['verification']['passed'])
