"""协作接口（N11/N12/统计回传）：把 profiles / artifacts / telemetry 接到服务端 HTTP。
所有路由都在 /api/collab/ 下，走服务端统一的登录校验。设置存在 CFG["collab"]。"""
from __future__ import annotations

import time
from aiohttp import web

TIERS = {"save": "轻奏", "standard": "正奏", "max": "华彩"}
DEFAULTS = {"tier": "standard", "profile_mode": "shadow", "telemetry": True, "consent": True}
S = None


def _json(data, status=200):
    return web.json_response(data, status=status, dumps=lambda o: __import__("json").dumps(o, ensure_ascii=False))


def settings() -> dict:
    cur = dict(DEFAULTS)
    cur.update((S.CFG.get("collab") or {}) if S else {})
    return cur


async def h_settings(request):
    if request.method == "PUT":
        body = await request.json()
        cur = settings()
        if body.get("tier") in TIERS:
            cur["tier"] = body["tier"]
        if body.get("profile_mode") in ("off", "shadow", "on"):
            cur["profile_mode"] = body["profile_mode"]
        if isinstance(body.get("consent"), bool):
            cur["consent"] = body["consent"]
        if isinstance(body.get("telemetry"), bool):
            cur["telemetry"] = body["telemetry"]
        S.CFG["collab"] = cur
        S.save_cfg()
        import os, orchestra
        os.environ["CHORUS_PROFILE_MODE"] = cur["profile_mode"]
    cur = settings()
    return _json({**cur, "tier_name": TIERS[cur["tier"]], "tiers": TIERS})


def _store(pid):
    import artifacts
    return artifacts.default_store(S.DATA, pid, enabled=True)


async def h_artifacts(request):
    pid = request.match_info["pid"]
    items = await _store(pid).list_by_project(pid, kind=request.query.get("kind"))
    return _json({"artifacts": items})


async def h_artifact_content(request):
    import artifacts, base64
    store = _store(request.match_info["pid"])
    try:
        art = await store.get(request.match_info["aid"])
        if art.bytes > 20 * 1024 * 1024:
            return _json({"error": "文件超过20MB，请在服务器端查看"}, 413)
        data = await store.read_blob(art.id)
    except artifacts.ArtifactNotFoundError:
        raise web.HTTPNotFound(text="找不到产物")
    except artifacts.ArtifactError:
        raise web.HTTPForbidden(text="此产物内容不允许远程读取")
    from pathlib import Path
    name = Path(art.origin_path).name or art.id
    return _json({"name": name, "mime": art.mime, "base64": base64.b64encode(data).decode("ascii")})


async def h_continue(request):
    pid, aid = request.match_info["pid"], request.match_info["aid"]
    body = await request.json()
    member = str(body.get("member") or "").strip()
    if not member:
        return _json({"error": "请选择让谁基于它继续改"}, 400)
    import artifacts
    try:
        task = await _store(pid).continue_from(aid, member, str(body.get("instruction") or ""))
    except artifacts.ArtifactNotFoundError:
        return _json({"error": "找不到这个产物"}, 404)
    return _json({"task": task})


async def h_assign_log(request):
    import orchestra
    pid = request.query.get("project_id")
    if pid and not S.project(pid):
        raise web.HTTPNotFound(text="项目不存在")
    records = [{**row, "project_id": p["id"]} for p in S.PROJECTS
               if not pid or p["id"] == pid for row in p.get("assign_log", [])]
    legacy = orchestra.PROFILE_SHADOW_LOG[-50:]
    if pid:
        legacy = [x for x in legacy if x.get("project_id") == pid]
    return _json({"mode": orchestra.profile_mode(), "log": legacy + records})


async def h_rank(request):
    import profiles
    skill = request.query.get("skill", "code")
    members = [{"id": m.get("name"), "name": m.get("name"), "model": m.get("model")}
               for m in S.CFG.get("members", [])]
    return _json({"skill": skill, "rank": [{"member": m["name"], "score": s} for s, m in profiles.rank(members, skill)]})


async def h_telemetry_preview(request):
    import telemetry
    rep = telemetry.build_daily_report([], str(getattr(S, "VERSION", "brass")))
    clean, dropped = telemetry.sanitize(rep)
    return _json({"enabled": settings()["telemetry"], "report": clean, "dropped": len(dropped),
                  "note": "只上传按模型汇总的统计数字，不含聊天内容、文件、密钥和 IP"})


async def record_segment_artifacts(pid: str, producer: str, paths, title: str = ""):
    """段落验收通过后，把交付的文件登记进产物线（只收 DATA/files 下已存在的文件；失败不影响主流程）。"""
    try:
        import pathlib
        root = (S.DATA / "files").resolve()
        store = _store(pid)
        out = []
        for raw in paths or []:
            raw = str(raw).strip()
            if "/files/" not in raw:
                continue  # 只收 DATA/files 下的文件，其他路径一律不碰
            name = raw.split("/files/", 1)[1].split("?", 1)[0]
            f = (root / name).resolve()
            if not f.is_relative_to(root) or not f.is_file():
                continue
            prev = [a for a in await store.list_by_project(pid) if a["head"].get("origin_path") == str(f)]
            kw = dict(content=f, kind=__import__("artifacts").guess_kind(f), producer=producer, title=title or f.name, origin_path=str(f))
            if prev:
                h = prev[0]["head"]
                kw.update(line=h["line"], parent=h["id"], op="edit", version=h["version"] + 1)
            out.append((await store.add_artifact(**kw)).id)
        return out
    except Exception as e:
        print("record_segment_artifacts:", type(e).__name__, e)
        return []


async def h_profiles(request):
    """每个已接入声部的能力分（先验，随实测校正）和当前排名依据。"""
    import profiles
    db = profiles.load_defaults()
    members = [{"name": m.get("name"), "model": m.get("model")} for m in S.CFG.get("members", [])]
    out = []
    for m in members:
        p = profiles.find_profile(m["model"], db) or {}
        sk = {k: profiles.skill_score(m["model"], k, db) for k in db.get("skill_keys", [])}
        best = sorted(sk.items(), key=lambda kv: -kv[1])[:3]
        out.append({"name": m["name"], "model": m["model"], "label": p.get("label") or p.get("name") or m["model"],
                    "skills": sk, "best": best})
    return _json({"members": out, "as_of": db.get("as_of")})


def consent_block(member: dict) -> str:
    """定音：api 声部第一次用某把 key 前必须手动允许；返回空串表示放行，否则是给用户看的原因。CLI 声部没有 key，不拦。"""
    import os
    if not S or os.environ.get("CHORUS_CONSENT", "").lower() == "off" or not settings().get("consent", True) or member.get("kind") in ("cli", "dsh"):
        return ""
    import consent
    prov = next((p for p in S.CFG.get("providers", []) if p.get("id") == member.get("provider")), {})
    key, model = str(prov.get("key") or ""), str(member.get("model") or "")
    if consent.status(S.DATA, model, key) == "allowed":
        return ""
    try:
        c = consent.request(S.DATA, member.get("name", ""), model, key, "第一次使用这把 key")
    except OSError as e:
        print("consent_block:", e)
        return "pending"  # 写不进台账时宁可先拦下，也不放行未授权的 key
    return "denied" if c["state"] == "denied" else "pending"


def consent_id(member: dict) -> str:
    import consent
    prov = next((p for p in S.CFG.get("providers", []) if p.get("id") == member.get("provider")), {})
    return consent.fingerprint(str(member.get("model") or ""), str(prov.get("key") or ""))


def consent_card(pid, member: dict, text: str):
    """定音卡直接发进群聊：带允许/拒绝按钮，点一下就生效；同一把 key 还没定时不重复发。"""
    import consent
    fp = consent_id(member)
    if consent.load(S.DATA).get(fp, {}).get("state", "pending") != "pending":
        return None
    if any((m.get("consent") or {}).get("id") == fp for m in (S.CHATS.get(pid) or [])[-60:]):
        return None
    return S.add_msg(pid, "系统", text, consent={"id": fp, "member": member.get("name", ""), "model": str(member.get("model") or "")})


async def h_consent(request):
    import consent
    if request.method == "POST":
        body = await request.json()
        fp, act = str(body.get("id") or ""), str(body.get("action") or "")
        ok = consent.revoke(S.DATA, fp) if act == "revoke" else consent.decide(S.DATA, fp, act == "allow")
        if not ok:
            return _json({"error": "找不到这条定音"}, 404)
    if request.method == "POST" and act == "allow":
        import chorus2
        chorus2.resume_consent()
    st = consent.load(S.DATA)
    return _json({"items": [{"id": k, **v} for k, v in st.items()], "enabled": settings().get("consent", True)})


async def h_skills(request):
    import skills
    installed = S.skills_list()
    if request.method == "PUT":
        body = await request.json()
        sid = request.match_info["sid"]
        local = next((x for x in installed if x["dir"] == sid), None)
        if local:
            state = S.load(S.DATA / "skills" / "state.json", {})
            state.setdefault(sid, {})["on"] = bool(body.get("enabled"))
            S.save(S.DATA / "skills" / "state.json", state)
            S.bump()
            installed = S.skills_list()
        elif not skills.set_enabled(S.DATA, sid, bool(body.get("enabled"))):
            return _json({"error": "没有这个乐谱"}, 404)
    rows = skills.listing(S.DATA)
    names = {x["name"] for x in installed}
    rows = [x for x in rows if x["id"] not in names]
    for x in installed:
        rows.append({"id": x["dir"], "name": x["name"], "description": x["description"],
                     "category": "已安装", "enabled": x["on"], "installed": True,
                     "installable": True, "source": x.get("source", "")})
    q = request.query.get("q", "").lower()
    category = request.query.get("category", "")
    return _json({"skills": [x for x in rows if (not category or x.get("category") == category)
                            and (not q or q in str(x).lower())]})


_INGEST_HITS = {}


def _collector_on():
    import os
    return os.environ.get("CHORUS_COLLECTOR", "") == "1" or bool((S.CFG.get("collab") or {}).get("collector"))


async def h_ingest(request):
    """官方收集端：只收已脱敏的日报。默认关闭（404），在官方服务器上用 CHORUS_COLLECTOR=1 打开。公开接口，所以限大小、限频、再脱敏一遍。"""
    import json, secrets, time, telemetry
    if not _collector_on():
        raise web.HTTPNotFound()
    import os
    trusted = os.environ.get("CHORUS_TRUST_PROXY", "") == "1" or bool((S.CFG.get("collab") or {}).get("trust_proxy"))
    ip = (request.headers.get("X-Real-IP") if trusted else None) or request.remote or ""
    now = time.time()
    for k in [k for k, v in _INGEST_HITS.items() if not v or now - v[-1] >= 3600]:
        del _INGEST_HITS[k]
    hits = [t for t in _INGEST_HITS.get(ip, []) if now - t < 3600]
    if len(hits) >= 10:
        return _json({"error": "上传太频繁"}, 429)
    _INGEST_HITS[ip] = hits + [now]
    raw = await request.content.read(65537)
    if len(raw) > 65536:
        return _json({"error": "报告过大"}, 413)
    try:
        body = json.loads(raw)
    except ValueError:
        return _json({"error": "不是 JSON"}, 400)
    if not isinstance(body, dict):
        return _json({"error": "须为 JSON 对象"}, 400)
    clean, _ = telemetry.sanitize(body)
    d = S.DATA / "telemetry_in"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{time.strftime('%Y%m%d')}-{secrets.token_hex(4)}.json").write_text(json.dumps(clean, ensure_ascii=False), encoding="utf-8")
    for old in sorted(d.glob("*.json"))[:-5000]:
        old.unlink(missing_ok=True)
    return _json({"ok": True})


async def h_profiles_latest(request):
    import profiles
    return _json(profiles.load_defaults())


def register(app, server_module):
    global S
    S = server_module
    import os
    os.environ.setdefault("CHORUS_PROFILE_MODE", settings()["profile_mode"])
    r = app.router
    r.add_get("/api/collab/settings", h_settings)
    r.add_put("/api/collab/settings", h_settings)
    r.add_get("/api/collab/{pid}/artifacts", h_artifacts)
    r.add_get("/api/collab/{pid}/artifacts/{aid}/content", h_artifact_content)
    r.add_post("/api/collab/{pid}/artifacts/{aid}/continue", h_continue)
    r.add_get("/api/collab/assign_log", h_assign_log)
    r.add_get("/api/collab/rank", h_rank)
    r.add_get("/api/collab/profiles", h_profiles)
    r.add_get("/api/collab/consent", h_consent)
    r.add_post("/api/collab/consent", h_consent)
    r.add_get("/api/collab/skills", h_skills)
    r.add_put("/api/collab/skills/{sid}", h_skills)
    r.add_get("/api/collab/telemetry/preview", h_telemetry_preview)
    r.add_post("/api/telemetry/ingest", h_ingest)
    r.add_get("/api/profiles/latest", h_profiles_latest)
