"""
quota_probes.py — provider quota/balance adapter registry for Chorus.

Every AI member shows its quota/balance with a source label:
  "official" (官方)  — from a vendor API/CLI
  "estimate" (估算)  — our own token accounting or user-entered numbers
  "unknown"  (未知)  — nothing available

QUOTA_SCHEMA (documentation only):

QUOTA_SCHEMA = {
    "kind":   "balance" | "plan" | "window" | "none",
    "source": "official" | "estimate" | "unknown",
    "method": "api" | "headers" | "cli" | "ledger" | "error" | "wallet" | "none",
    "accounts": [{"cur": "¥" | "$" | "tokens" | "credits", "amount": float}],
    "pct":        float | None,   # REMAINING % of 5h window or plan, 0..100
    "reset":      str,            # ISO8601 or ""
    "week":       float | None,   # REMAINING % weekly
    "week_reset": str,
    "used":       float | None,
    "limit":      float | None,
    "state":      "ok" | "low" | "arrears" | "unknown",
    "short":      str,            # e.g. "¥12.30", "剩 63%", "额度未知"
    "checked_at": float,
}

Probe chain per provider (first success wins):
  1. official balance/usage API
  2. rate-limit response headers from the last real call
  3. CLI status/session files
  4. self-accounting estimate (plan total − recorded tokens)
  5. error-code signals (402 / insufficient balance → balance 0, "arrears")
  6. user-entered balance (wallet) minus spend since entry
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, Callable, Optional

__all__ = [
    "QUOTA_SCHEMA",
    "probe",
    "from_headers",
    "from_error",
    "codex_rate_limits",
    "detect",
    "ADAPTERS",
    "Ctx",
    "latest_codex_rate_limits",
]

# --------------------------------------------------------------------------- #
# schema (doc only)
# --------------------------------------------------------------------------- #

QUOTA_SCHEMA: dict = {
    "kind": "balance|plan|window|none",
    "source": "official|estimate|unknown",
    "method": "api|headers|cli|ledger|error|wallet|none",
    "accounts": [{"cur": "¥|$|tokens|credits", "amount": 0.0}],
    "pct": None,
    "reset": "",
    "week": None,
    "week_reset": "",
    "used": None,
    "limit": None,
    "state": "ok|low|arrears|unknown",
    "short": "额度未知",
    "checked_at": 0.0,
}

_TIMEOUT = 15.0
_LOW_PCT = 15.0
_LOW_BAL = 1.0

_CUR_MAP = {"CNY": "¥", "RMB": "¥", "USD": "$", "USDT": "$", "TOKENS": "tokens", "CREDITS": "credits"}


# --------------------------------------------------------------------------- #
# context injection
# --------------------------------------------------------------------------- #

class Ctx:
    """Injected by the server so tests can mock IO."""

    def __init__(
        self,
        session,
        spent_tokens: Callable[[str], float] = lambda member_name: 0,
        spent_money: Callable[[str, str], float] = lambda provider_id, cur: 0.0,
        last_headers: Callable[[str], Any] = lambda member_name: None,
        last_error: Callable[[str], Any] = lambda member_name: None,
        read_file: Callable[[str], Any] = lambda path: None,
        now: Callable[[], float] = time.time,
    ) -> None:
        self.session = session
        self.spent_tokens = spent_tokens
        self.spent_money = spent_money
        self.last_headers = last_headers
        self.last_error = last_error
        self.read_file = read_file
        self.now = now


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #

def _iso(ts: Any) -> str:
    """Convert seconds / ms / ISO string to ISO8601 string, '' on failure."""
    if ts is None:
        return ""
    if isinstance(ts, str):
        s = ts.strip()
        if not s:
            return ""
        try:
            val = float(s)
        except ValueError:
            return s
        return _iso(val)
    try:
        v = float(ts)
    except (TypeError, ValueError):
        return ""
    if v <= 0:
        return ""
    if v > 1e11:  # milliseconds
        v = v / 1000.0
    try:
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(v))
    except (OverflowError, OSError, ValueError):
        return ""


def _num(v: Any) -> Optional[float]:
    try:
        if v is None or isinstance(v, bool):
            return None
        return float(v)
    except (TypeError, ValueError):
        return None


def _clamp(v: Any) -> Optional[float]:
    f = _num(v)
    if f is None:
        return None
    return max(0.0, min(100.0, f))


def _pct_from_used(used: Any) -> Optional[float]:
    """used_percent 37 -> 63 remaining; utilization 0.42 or 42 -> 58 remaining."""
    u = _num(used)
    if u is None:
        return None
    if 0.0 <= u <= 1.0:
        u = u * 100.0
    return _clamp(100.0 - u)


def _cur(currency: Any) -> str:
    if isinstance(currency, str):
        c = currency.strip().upper()
        if c in _CUR_MAP:
            return _CUR_MAP[c]
        if currency.strip() in ("¥", "$", "tokens", "credits"):
            return currency.strip()
    return "$"


_CN_HOSTS = ("deepseek.com", "moonshot.cn", "siliconflow.cn", "bigmodel.cn", "minimaxi.com", "minimax.chat", "xiaomimimo.com",
             "volces.com", "volcengine", "dashscope", "aliyuncs.com", "stepfun.com", "baichuan", "hunyuan", "tencent", "kimi.com",
             "lingyiwanwu.com", "baidubce.com", "qianfan", "xf-yun.com", "sensenova", "zhipu", "doubao")


def provider_cur(provider: dict) -> str:
    """国内厂商按 ¥，其余按 $（欠费、已花金额的币种用它，不再一律写 $）。"""
    p = provider or {}
    blob = f"{p.get('base') or ''} {p.get('id') or ''}".lower()
    return "¥" if any(h in blob for h in _CN_HOSTS) else "$"


def is_plan(provider: dict) -> bool:
    """套餐类（包月/Token Plan）自动判断：用户不用开任何开关。"""
    p = provider or {}
    base = str(p.get("base") or "").lower()
    return bool(p.get("plan") or str(p.get("key") or "").startswith("tp-") or "token-plan" in base
                or "/coding" in base or p.get("plan_tokens"))


def _v1(base: str) -> str:
    """去掉结尾的 /v1 再补一个：用户填不填 /v1 都对。"""
    b = str(base or "").rstrip("/")
    if b.endswith("/v1"):
        b = b[:-3].rstrip("/")
    return b + "/v1"


def _tokens_text(n: float) -> str:
    if n >= 1e8:
        return f"{n / 1e8:.2f} 亿"
    if n >= 1e4:
        return f"{n / 1e4:.1f} 万"
    return f"{n:,.0f}"


def _short(accounts: list, pct: Optional[float], state: str) -> str:
    if accounts:
        a = accounts[0]
        cur = a.get("cur", "$")
        amt = a.get("amount", 0.0)
        if cur == "tokens":
            return f"tokens {amt:,.0f}"
        if cur == "credits":
            return f"credits {amt:,.2f}"
        return f"{cur}{amt:,.2f}"
    if pct is not None:
        return f"剩 {pct:.0f}%"
    if state == "arrears":
        return "欠费"
    return "额度未知"


def _result(
    *,
    kind: str = "none",
    source: str = "unknown",
    method: str = "none",
    accounts: Optional[list] = None,
    pct: Any = None,
    reset: str = "",
    week: Any = None,
    week_reset: str = "",
    used: Any = None,
    limit: Any = None,
    state: Optional[str] = None,
    short: Optional[str] = None,
    checked_at: float = 0.0,
    unset: bool = False,
    note: str = "",
) -> dict:
    accounts = list(accounts or [])
    pct = _clamp(pct)
    week = _clamp(week)
    if state is None:
        state = "unknown"
        if kind != "none" or accounts or pct is not None:
            state = "ok"
        if pct is not None and pct < _LOW_PCT:
            state = "low"
        for a in accounts:
            amt = _num(a.get("amount"))
            if a.get("cur") in ("¥", "$") and amt is not None and amt < _LOW_BAL:
                state = "low"
    if short is None:
        short = _short(accounts, pct, state)
    out = {
        "kind": kind,
        "source": source,
        "method": method,
        "accounts": accounts,
        "pct": pct,
        "reset": reset or "",
        "week": week,
        "week_reset": week_reset or "",
        "used": used,
        "limit": limit,
        "state": state,
        "short": short,
        "checked_at": float(checked_at),
    }
    if unset:
        out["unset"] = True  # App 的额度环据此提示「填一次余额」
    if note:
        out["note"] = note
    return out


def _unknown(checked_at: float = 0.0) -> dict:
    return _result(kind="none", source="unknown", method="none", state="unknown",
                   short="额度未知", checked_at=checked_at)


# --------------------------------------------------------------------------- #
# header parsing
# --------------------------------------------------------------------------- #

def _parse_reset(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    try:
        f = float(s)
    except ValueError:
        f = None
    if f is not None:
        if f > 1e11:
            f = f / 1000.0
        if f > 1e9:  # absolute epoch
            return _iso(f)
        return _iso(time.time() + f)
    # duration like "6m0s", "1h2m3s", "30s"
    total = 0.0
    num = ""
    matched = False
    for ch in s:
        if ch.isdigit() or ch == ".":
            num += ch
            continue
        if num:
            try:
                val = float(num)
            except ValueError:
                val = 0.0
            if ch == "h":
                total += val * 3600
                matched = True
            elif ch == "m":
                total += val * 60
                matched = True
            elif ch == "s":
                total += val
                matched = True
            num = ""
    if matched:
        return _iso(time.time() + total)
    return s


def from_headers(headers: dict) -> Optional[dict]:
    """Parse x-ratelimit-* (OpenAI/xAI/DeepSeek) and anthropic-ratelimit-* headers."""
    if not headers:
        return None
    h = {str(k).lower(): v for k, v in headers.items()}

    def g(*names: str) -> Any:
        for n in names:
            if n in h and h[n] not in (None, ""):
                return h[n]
        return None

    remaining = g("x-ratelimit-remaining-tokens", "x-ratelimit-remaining-credits",
                  "x-ratelimit-remaining", "anthropic-ratelimit-tokens-remaining")
    limit = g("x-ratelimit-limit-tokens", "x-ratelimit-limit-credits",
              "x-ratelimit-limit", "anthropic-ratelimit-tokens-limit")
    reset = g("x-ratelimit-reset-tokens", "x-ratelimit-reset-credits",
              "x-ratelimit-reset", "anthropic-ratelimit-tokens-reset")

    rem = _num(remaining)
    lim = _num(limit)
    if rem is None and lim is None:
        return None

    pct = None
    if rem is not None and lim is not None and lim > 0:
        pct = _clamp(rem / lim * 100.0)

    return {
        "kind": "window",
        "source": "official",
        "method": "headers",
        "accounts": [],
        "pct": pct,
        "reset": _parse_reset(reset),
        "week": None,
        "week_reset": "",
        "used": (lim - rem) if (rem is not None and lim is not None) else None,
        "limit": lim,
    }


# --------------------------------------------------------------------------- #
# error signals
# --------------------------------------------------------------------------- #

_ARREARS_NEEDLES = ("insufficient_quota", "insufficient balance", "insufficient_balance", "余额不足", "arrearage",
                    "exceeded your current quota", "quota exhausted", "insufficient_user_quota",
                    "credit balance is too low", "额度已用完", "额度用完", "额度已耗尽")


def from_error(status: int, body: str, cur: str = "$", plan: bool = False) -> Optional[dict]:
    """402 / insufficient balance / quota exhausted → arrears with balance 0。cur 为该厂商币种；plan=True 是套餐，显示「本期用完」。"""
    try:
        st = int(status)
    except (TypeError, ValueError):
        st = 0
    text = body if isinstance(body, str) else ("" if body is None else str(body))
    low = text.lower()
    hit = st == 402
    # 只认明确的欠费信号：402，或带「余额/配额不足」这类原文。403 等其他状态里偶然出现 quota 字样不算
    if not hit:
        hit = any(n in low or n in text for n in _ARREARS_NEEDLES)
    if not hit:
        return None
    return {
        "kind": "plan" if plan else "balance",
        "source": "official",
        "method": "error",
        "accounts": [] if plan else [{"cur": cur or "$", "amount": 0.0}],
        "pct": 0.0,
        "reset": "",
        "week": None,
        "week_reset": "",
        "used": None,
        "limit": None,
        "state": "arrears",
        "short": "本期用完" if plan else "欠费",
    }


# --------------------------------------------------------------------------- #
# CLI parsers
# --------------------------------------------------------------------------- #

def codex_rate_limits(obj: dict) -> dict:
    """Codex CLI session jsonl 'rate_limits' → pct/week (remaining %)."""
    out = {"pct": None, "week": None, "reset": "", "week_reset": ""}
    if not isinstance(obj, dict):
        return out

    def take(key: str):
        node = obj.get(key)
        if not isinstance(node, dict):
            return None, ""
        pct = _pct_from_used(node.get("used_percent", node.get("usedPercent")))
        reset = node.get("resets_at") or node.get("resetsAt") or ""
        if not reset:
            secs = node.get("resets_in_seconds")
            if secs is not None:
                reset = _iso(time.time() + (_num(secs) or 0.0))
        return pct, _iso(reset) if reset else ""

    pct, reset = take("primary")
    week, week_reset = take("secondary")
    out["pct"] = pct
    out["reset"] = reset
    out["week"] = week
    out["week_reset"] = week_reset
    return out


def latest_codex_rate_limits(lines: list) -> dict:
    """Scan jsonl lines from the end for a 'rate_limits' payload."""
    empty = {"pct": None, "week": None, "reset": "", "week_reset": ""}
    if not lines:
        return empty
    for raw in reversed(list(lines)):
        if raw is None:
            continue
        if isinstance(raw, dict):
            obj = raw
        else:
            s = str(raw).strip()
            if not s or "rate_limits" not in s:
                continue
            try:
                obj = json.loads(s)
            except (ValueError, TypeError):
                continue
        if not isinstance(obj, dict):
            continue
        rl = obj.get("rate_limits")
        if rl is None and "primary" in obj:
            rl = obj
        if isinstance(rl, dict):
            res = codex_rate_limits(rl)
            if res.get("pct") is not None or res.get("week") is not None:
                return res
    return empty


# --------------------------------------------------------------------------- #
# HTTP helper
# --------------------------------------------------------------------------- #

async def _get(session, url: str, headers: Optional[dict] = None, **kw) -> Optional[dict]:
    """GET url, return {"status":int,"json":Any,"text":str} or None on any failure."""
    try:
        cm = session.get(url, headers=headers or {}, **kw)
        if asyncio.iscoroutine(cm):
            cm = await cm
        async with cm as resp:
            status = getattr(resp, "status", 0)
            data = None
            text = ""
            try:
                data = await resp.json(content_type=None)
            except Exception:
                data = None
            if data is None:
                try:
                    text = await resp.text()
                except Exception:
                    text = ""
            else:
                try:
                    text = json.dumps(data, ensure_ascii=False)
                except Exception:
                    text = ""
            return {"status": int(status), "json": data, "text": text}
    except Exception:
        return None


def _ok(resp: Optional[dict]) -> bool:
    return bool(resp) and 200 <= int(resp.get("status") or 0) < 300


# --------------------------------------------------------------------------- #
# detection
# --------------------------------------------------------------------------- #

def detect(provider: dict) -> str:
    p = provider or {}
    pid = str(p.get("id") or p.get("key") or p.get("name") or "").lower()
    kind = str(p.get("kind") or "").lower()
    base = str(p.get("base") or "").lower().rstrip("/")
    blob = f"{base} {pid} {kind}"

    if kind == "cli" or p.get("cli"):
        cli = str(p.get("cli") or p.get("cmd") or pid or "").lower()
        if "codex" in cli:
            return "codex"
        if "claude" in cli:
            return "claude"
        if "gemini" in cli:
            return "gemini_cli"
        if "qwen" in cli:
            return "qwen_code"
        if "kimi" in cli:
            return "kimi_cli"
        if "antigravity" in cli:
            return "antigravity"
        return "codex" if "codex" in blob else "claude"

    if "api.deepseek.com" in blob or "deepseek" in pid:
        return "deepseek"
    if "api.kimi.com/coding" in blob or "kimi_coding" in blob or "kimi-coding" in blob:
        return "kimi_coding"
    if "moonshot" in blob:
        return "moonshot"
    if "siliconflow" in blob:
        return "siliconflow"
    if "openrouter" in blob:
        return "openrouter"
    if "stepfun" in blob:
        return "stepfun"
    if "minimax" in blob:
        return "minimax"
    if "open.bigmodel.cn" in blob or "api.z.ai" in blob or "zhipu" in blob or "glm" in pid or "bigmodel" in blob:
        return "glm"
    if "api.x.ai" in blob or "grok" in pid:
        return "xai"
    if "api.openai.com" in blob or pid in ("openai", "gpt", "chatgpt"):
        return "openai"
    if "api.anthropic.com" in blob or "anthropic" in blob or "claude" in pid:
        return "anthropic"
    if "generativelanguage.googleapis.com" in blob or "aiplatform" in blob or "gemini" in pid:
        return "gemini"
    if "dashscope" in blob or "qwen" in pid or "百炼" in blob:
        return "dashscope"
    if "volces.com" in blob or "volcengine" in blob or "ark." in blob or "豆包" in blob or "doubao" in pid:
        return "volcengine"
    if "xiaomimimo" in blob or "mimo" in pid:
        if "token-plan" in blob or p.get("plan_tokens"):
            return "mimo_plan"
        return "mimo_payg"
    if "baichuan" in blob:
        return "baichuan"
    if "hunyuan" in blob or "tencent" in blob:
        return "hunyuan"
    return "relay"


# --------------------------------------------------------------------------- #
# adapters
# --------------------------------------------------------------------------- #

class Adapter:
    def __init__(self, id: str, name: str, methods: list, official) -> None:
        self.id = id
        self.name = name
        self.methods = list(methods)
        self.official = official  # async (session, provider) -> dict | None


def _mk(id: str, name: str, methods: list, official) -> Adapter:
    return Adapter(id, name, methods, official)


# --- deepseek -------------------------------------------------------------- #

async def _deepseek(session, provider: dict):
    key = provider.get("key")
    if not key:
        return None
    resp = await _get(session, "https://api.deepseek.com/user/balance",
                      headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = resp.get("json") or {}
    infos = data.get("balance_infos") or []
    accounts = []
    for it in infos:
        if not isinstance(it, dict):
            continue
        amt = _num(it.get("total_balance"))
        if amt is None:
            continue
        accounts.append({"cur": _cur(it.get("currency")), "amount": amt})
    if not accounts:
        return None
    if not all(a["amount"] == 0 for a in accounts):
        accounts = [a for a in accounts if a["amount"] != 0] or accounts
    return {"kind": "balance", "source": "official", "method": "api", "accounts": accounts}


# --- moonshot -------------------------------------------------------------- #

async def _moonshot(session, provider: dict):
    key, base = provider.get("key"), _v1(provider.get("base") or "https://api.moonshot.cn")
    if not key:
        return None
    resp = await _get(session, f"{base}/users/me/balance",
                      headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = (resp.get("json") or {}).get("data") or {}
    amt = _num(data.get("available_balance"))
    if amt is None:
        return None
    cur = "$" if ".ai" in base else "¥"
    return {"kind": "balance", "source": "official", "method": "api",
            "accounts": [{"cur": cur, "amount": amt}]}


# --- kimi_coding ----------------------------------------------------------- #

async def _kimi_coding(session, provider: dict):
    key = provider.get("key")
    if not key:
        return None
    resp = await _get(session, "https://api.kimi.com/coding/v1/usages",
                      headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = resp.get("json") or {}
    limits = data.get("limits") or []
    usage = data.get("usage") or {}
    out = {"kind": "window", "source": "official", "method": "api", "accounts": []}
    if limits and isinstance(limits[0], dict):
        d = limits[0].get("detail") or {}
        lim, rem = _num(d.get("limit")), _num(d.get("remaining"))
        out["limit"] = lim
        out["used"] = (lim - rem) if (lim is not None and rem is not None) else None
        out["pct"] = _clamp(rem / lim * 100.0) if (rem is not None and lim) else None
        out["reset"] = _iso(d.get("resetTime"))
    if isinstance(usage, dict):
        ulim, urem = _num(usage.get("limit")), _num(usage.get("remaining"))
        out["week"] = _clamp(urem / ulim * 100.0) if (urem is not None and ulim) else None
        out["week_reset"] = _iso(usage.get("resetTime"))
    return out


# --- siliconflow ----------------------------------------------------------- #

async def _siliconflow(session, provider: dict):
    key, base = provider.get("key"), _v1(provider.get("base") or "https://api.siliconflow.cn")
    if not key:
        return None
    resp = await _get(session, f"{base}/user/info", headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = (resp.get("json") or {}).get("data") or {}
    amt = _num(data.get("totalBalance"))
    if amt is None:
        return None
    cur = "$" if ".com" in base else "¥"
    return {"kind": "balance", "source": "official", "method": "api",
            "accounts": [{"cur": cur, "amount": amt}]}


# --- openrouter ------------------------------------------------------------ #

async def _openrouter(session, provider: dict):
    key, base = provider.get("key"), _v1(provider.get("base") or "https://openrouter.ai/api")
    if not key:
        return None
    resp = await _get(session, f"{base}/credits", headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = (resp.get("json") or {}).get("data") or {}
    total, used = _num(data.get("total_credits")), _num(data.get("total_usage"))
    if total is None:
        return None
    left = total - (used or 0.0)
    return {"kind": "balance", "source": "official", "method": "api",
            "accounts": [{"cur": "$", "amount": left}]}


# --- stepfun --------------------------------------------------------------- #

async def _stepfun(session, provider: dict):
    key = provider.get("key")
    if not key:
        return None
    resp = await _get(session, "https://api.stepfun.com/v1/accounts",
                      headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = resp.get("json") or {}
    amt = _num(data.get("balance"))
    if amt is None:
        return None
    return {"kind": "balance", "source": "official", "method": "api",
            "accounts": [{"cur": "¥", "amount": amt}]}


# --- minimax --------------------------------------------------------------- #

async def _minimax_plan(session, provider: dict):
    key = provider.get("key")
    host = "https://api.minimax.io" if "minimax.io" in str(provider.get("base") or "") else "https://api.minimaxi.com"
    hdr = {"Authorization": f"Bearer {key}"} if key else {}
    resp = await _get(session, f"{host}/v1/token_plan/remains", headers=hdr)  # documented: platform.minimax.io/docs/m-plan/faq
    if not _ok(resp):
        resp = await _get(session, "https://api.minimaxi.com/v1/api/openplatform/coding_plan/remains", headers=hdr)
    if not _ok(resp):
        return None
    data = resp.get("json") or {}
    code = (data.get("base_resp") or {}).get("status_code")
    mrs = data.get("model_remains") or []
    if code not in (None, 0) or not mrs or not isinstance(mrs[0], dict):
        return None  # 不是套餐 key（或接口报错）：当按量处理
    m = mrs[0]
    out = {"kind": "window", "source": "official", "method": "api", "accounts": []}
    out["pct"] = _clamp(_num(m.get("current_interval_remaining_percent")))
    out["week"] = _clamp(_num(m.get("current_weekly_remaining_percent")))
    out["reset"] = _iso(m.get("end_time"))
    out["week_reset"] = _iso(m.get("weekly_end_time"))
    return out


async def _minimax(session, provider: dict):
    # 套餐自动判断：先试套餐接口，有数据就是套餐；否则按量。MiniMax 按量没有公开余额接口，走手填余额 + 账本。
    if not provider.get("key"):
        return None
    return await _minimax_plan(session, provider)


# --- glm ------------------------------------------------------------------- #

async def _glm_plan(session, provider: dict, cn: bool):
    key = provider.get("key")
    host = "https://open.bigmodel.cn" if cn else "https://api.z.ai"
    resp = await _get(session, f"{host}/api/monitor/usage/quota/limit",
                      headers={"Authorization": str(key)})  # NO Bearer
    if not _ok(resp):
        return None
    data = (resp.get("json") or {}).get("data") or {}
    out = {"kind": "window", "source": "official", "method": "api", "accounts": []}
    for node in data.get("limits") or []:
        if not isinstance(node, dict) or str(node.get("type", "")).upper() != "TOKENS_LIMIT":
            continue
        used_pct = _num(node.get("percentage"))
        out["pct"] = _clamp(100.0 - used_pct) if used_pct is not None else None
        out["reset"] = _iso(node.get("nextResetTime"))
        return out
    return None


async def _glm(session, provider: dict):
    key = provider.get("key")
    if not key:
        return None
    cn = "bigmodel.cn" in str(provider.get("base") or "") or not provider.get("base")
    # 套餐自动判断：先试套餐额度接口，有数据就是套餐（base 含 /coding/ 或手动标过 plan 的更不用猜）
    plan = await _glm_plan(session, provider, cn)
    if plan is not None:
        return plan
    if not cn:
        return None  # api.z.ai pay-go: no verified balance endpoint
    # pay-go balance with the API key itself (Bearer, no cookie): data.availableBalance (CNY)
    resp = await _get(session, "https://open.bigmodel.cn/api/biz/account/query-customer-account-report",
                      headers={"Authorization": f"Bearer {key}"})
    if not _ok(resp):
        return None
    data = (resp.get("json") or {}).get("data") or {}
    amt = _num(data.get("availableBalance"))
    if amt is None:
        amt = _num(data.get("balance"))
    if amt is None:
        return None
    return {"kind": "balance", "source": "official", "method": "api", "accounts": [{"cur": "¥", "amount": amt}]}


# --- xai ------------------------------------------------------------------- #

async def _xai(session, provider: dict):
    mgmt = provider.get("mgmt_key")
    team = provider.get("team_id")
    if not mgmt or not team:
        return None
    resp = await _get(session, f"https://management-api.x.ai/v1/billing/teams/{team}/prepaid/balance",
                      headers={"Authorization": f"Bearer {mgmt}"})
    if not _ok(resp):
        return None
    data = resp.get("json") or {}
    total = data.get("total") or {}
    val = _num(total.get("val"))
    if val is None:
        return None
    amount = -val / 100.0  # negative cents mean credit
    return {"kind": "balance", "source": "official", "method": "api",
            "accounts": [{"cur": "$", "amount": amount}]}


# --- no-API adapters ------------------------------------------------------- #

async def _no_api(session, provider: dict):
    return None


async def _volcengine(session, provider: dict):
    return None  # needs ctx.volc_balance — handled in probe()


async def _mimo_plan(session, provider: dict):
    return None  # handled in ledger step


# --- relay (one-api / new-api) --------------------------------------------- #

async def _relay(session, provider: dict):
    key, base = provider.get("key"), (provider.get("base") or "").rstrip("/")
    if not key or not base:
        return None
    root = base[:-3] if base.endswith("/v1") else base
    root = root.rstrip("/")
    sub = await _get(session, f"{root}/v1/dashboard/billing/subscription",
                     headers={"Authorization": f"Bearer {key}"})
    if not _ok(sub):
        return None
    sdata = sub.get("json") or {}
    hard = _num(sdata.get("hard_limit_usd"))
    if hard is None:
        return None
    if hard >= 1e8:
        hard = None  # unlimited
    used = await _get(session, f"{root}/v1/dashboard/billing/usage",
                      headers={"Authorization": f"Bearer {key}"})
    total_usage_cents = 0.0
    if _ok(used):
        total_usage_cents = _num((used.get("json") or {}).get("total_usage")) or 0.0
    usage_usd = total_usage_cents / 100.0
    out = {"kind": "balance", "source": "official", "method": "api", "accounts": []}
    if hard is not None:
        out["accounts"] = [{"cur": "$", "amount": hard - usage_usd}]
        out["limit"] = hard
        out["used"] = usage_usd
    else:
        # key 没设额度上限（中转站常见）：查不到剩多少，就如实显示已经用了多少
        out["kind"] = "spend"
        out["used"] = usage_usd
        out["state"] = "ok"
        out["short"] = f"已用 ${usage_usd:,.2f}"
        out["unset"] = True
        out["note"] = "这把 key 没设额度上限，中转站只告诉已用金额；在中转站后台给 key 设上限后这里会显示剩余"
    return out


ADAPTERS: dict[str, Adapter] = {
    "deepseek": _mk("deepseek", "DeepSeek", ["api"], _deepseek),
    "moonshot": _mk("moonshot", "Moonshot", ["api"], _moonshot),
    "kimi_coding": _mk("kimi_coding", "Kimi Coding", ["api"], _kimi_coding),
    "siliconflow": _mk("siliconflow", "SiliconFlow", ["api"], _siliconflow),
    "openrouter": _mk("openrouter", "OpenRouter", ["api"], _openrouter),
    "stepfun": _mk("stepfun", "StepFun", ["api"], _stepfun),
    "minimax": _mk("minimax", "MiniMax", ["api"], _minimax),
    "glm": _mk("glm", "GLM/智谱", ["api"], _glm),
    "xai": _mk("xai", "xAI", ["api"], _xai),
    "openai": _mk("openai", "OpenAI", ["headers"], _no_api),
    "anthropic": _mk("anthropic", "Anthropic", ["headers"], _no_api),
    "gemini": _mk("gemini", "Gemini", ["headers", "ledger"], _no_api),
    "dashscope": _mk("dashscope", "百炼/DashScope", ["ledger", "wallet"], _no_api),
    "volcengine": _mk("volcengine", "火山方舟", ["api", "ledger"], _volcengine),
    "mimo_payg": _mk("mimo_payg", "MiMo 按量", ["ledger", "wallet"], _no_api),
    "mimo_plan": _mk("mimo_plan", "MiMo 套餐", ["ledger"], _mimo_plan),
    "relay": _mk("relay", "OpenAI 兼容中转", ["api", "ledger", "wallet"], _relay),
    "baichuan": _mk("baichuan", "百川", ["ledger", "wallet"], _no_api),
    "hunyuan": _mk("hunyuan", "混元", ["ledger", "wallet"], _no_api),
    "codex": _mk("codex", "Codex CLI", ["cli"], _no_api),
    "claude": _mk("claude", "Claude CLI", ["cli"], _no_api),
    "gemini_cli": _mk("gemini_cli", "Gemini CLI", ["cli"], _no_api),
    "qwen_code": _mk("qwen_code", "Qwen Code", ["cli"], _no_api),
    "kimi_cli": _mk("kimi_cli", "Kimi CLI", ["cli"], _no_api),
    "antigravity": _mk("antigravity", "Antigravity", ["cli"], _no_api),
}


# --------------------------------------------------------------------------- #
# generic chain steps
# --------------------------------------------------------------------------- #

def _member_name(member: dict) -> str:
    return str(member.get("name") or member.get("id") or "")


def _step_headers(ctx: Ctx, member: dict) -> Optional[dict]:
    try:
        raw = ctx.last_headers(_member_name(member))
    except Exception:
        raw = None
    if not raw:
        return None
    return from_headers(raw)


def _step_cli(ctx: Ctx, provider: dict, member: dict) -> Optional[dict]:
    quota = member.get("quota") or {}
    kind = str(member.get("kind") or "").lower()
    cli = str(member.get("cli") or quota.get("cmd") or "").lower()

    # Codex session jsonl
    if kind == "cli" and not member.get("remote") and ("codex" in cli or detect(provider) == "codex"):  # remote: its connector reports
        acp = getattr(ctx, "acp_limits", None)
        live = acp(member.get("name", "")) if callable(acp) else None
        if isinstance(live, dict) and time.time() - float(live.get("at", 0)) < 900:   # ACP event wins while fresh
            res = codex_rate_limits(live.get("rate_limits") or {})
            if res.get("pct") is not None or res.get("week") is not None:
                return {"kind": "window", "source": "official", "method": "cli", "accounts": [],
                        "pct": res.get("pct"), "reset": res.get("reset") or "",
                        "week": res.get("week"), "week_reset": res.get("week_reset") or ""}
        home = quota.get("home") or "~/.codex"
        try:
            home = os.path.expanduser(str(home))
        except Exception:
            pass
        lines = _read_codex_lines(ctx, home)
        if lines:
            res = latest_codex_rate_limits(lines)
            if res.get("pct") is not None or res.get("week") is not None:
                return {"kind": "window", "source": "official", "method": "cli",
                        "accounts": [], "pct": res.get("pct"), "reset": res.get("reset") or "",
                        "week": res.get("week"), "week_reset": res.get("week_reset") or ""}

    # Claude / Gemini / Antigravity: read through the vendor's own CLI (cli_quota), delivered via ctx.cmd_json
    # generic cmd hook supplied by server
    cmd_json = getattr(ctx, "cmd_json", None)
    if callable(cmd_json):
        try:
            obj = cmd_json(member)
        except Exception:
            obj = None
        if asyncio.iscoroutine(obj):
            obj = None
        if isinstance(obj, dict):
            accounts = []
            bal = _num(obj.get("balance"))
            if bal is not None:
                accounts.append({"cur": str(obj.get("cur") or "$"), "amount": bal})
            pct = _clamp(obj.get("pct"))
            if pct is None:
                pct = _pct_from_used(obj.get("used_percent"))
            if accounts or pct is not None or obj.get("week") is not None:
                return {"kind": "balance" if accounts else "window",
                        "source": "official", "method": "cli", "accounts": accounts,
                        "pct": pct, "reset": _iso(obj.get("reset")),
                        "week": _clamp(obj.get("week")), "week_reset": _iso(obj.get("week_reset"))}
    return None


def _read_codex_lines(ctx: Ctx, home: str) -> list:
    """Read newest ~/.codex/sessions/**/*.jsonl via ctx.read_file."""
    try:
        base = os.path.join(home, "sessions")
        candidates = []
        for root, _dirs, files in os.walk(base):
            for f in files:
                if f.endswith(".jsonl"):
                    p = os.path.join(root, f)
                    try:
                        candidates.append((os.path.getmtime(p), p))
                    except OSError:
                        candidates.append((0.0, p))
        candidates.sort(key=lambda t: t[0], reverse=True)
        for _mt, path in candidates[:5]:
            try:
                raw = ctx.read_file(path)
            except Exception:
                raw = None
            if not raw:
                continue
            if isinstance(raw, list):
                return raw
            if isinstance(raw, str):
                return raw.splitlines()
    except Exception:
        pass
    return []


def _step_ledger(ctx: Ctx, provider: dict, member: dict) -> Optional[dict]:
    pid = str(provider.get("id") or provider.get("key") or "")
    name = _member_name(member)

    plan_tokens = _num(provider.get("plan_tokens"))
    if plan_tokens and plan_tokens > 0:
        try:
            spent = _num(ctx.spent_tokens(name)) or 0.0
        except Exception:
            spent = 0.0
        left = max(0.0, plan_tokens - spent)
        pct = _clamp(left / plan_tokens * 100.0)
        return {"kind": "plan", "source": "estimate", "method": "ledger",
                "accounts": [{"cur": "tokens", "amount": left}],
                "pct": pct, "used": spent, "limit": plan_tokens}

    if detect(provider) == "mimo_plan" or (is_plan(provider) and detect(provider) == "relay"):
        # 套餐总量官方没有接口、也没填：至少显示已经用了多少，用完由错误信号识别
        try:
            spent = _num(ctx.spent_tokens(name)) or 0.0
        except Exception:
            spent = 0.0
        return {"kind": "plan", "source": "estimate", "method": "ledger", "accounts": [],
                "used": spent, "state": "ok", "short": f"已用 {_tokens_text(spent)} tokens", "unset": True}

    plan_money = provider.get("plan_money")
    if isinstance(plan_money, dict) and _num(plan_money.get("amount")) is not None:
        total = _num(plan_money["amount"]) or 0.0
        cur = str(plan_money.get("cur") or "¥")
        try:
            spent = _num(ctx.spent_money(pid, cur)) or 0.0
        except Exception:
            spent = 0.0
        left = total - spent
        pct = _clamp(left / total * 100.0) if total > 0 else None
        return {"kind": "plan", "source": "estimate", "method": "ledger",
                "accounts": [{"cur": cur, "amount": left}],
                "pct": pct, "used": spent, "limit": total}
    return None


def _step_error(ctx: Ctx, member: dict, provider: Optional[dict] = None) -> Optional[dict]:
    name = _member_name(member)
    try:
        err = ctx.last_error(name)
    except Exception:
        err = None
    if not isinstance(err, dict):
        return None
    at = _num(err.get("at")) or 0.0
    try:
        now = float(ctx.now())
    except Exception:
        now = time.time()
    if now - at > 600:  # older than 10 minutes → ignore
        return None
    status = err.get("status")
    body = err.get("body") or err.get("message") or ""
    return from_error(status if status is not None else 0, str(body), provider_cur(provider or {}), is_plan(provider or {}))


def _step_wallet(ctx: Ctx, provider: dict, member: dict) -> Optional[dict]:
    wallet = provider.get("wallet")
    if not isinstance(wallet, dict):
        return None
    amt = _num(wallet.get("amount"))
    if amt is None:
        return None
    cur = str(wallet.get("cur") or "¥")
    spent0 = _num(wallet.get("spent0")) or 0.0
    pid = str(provider.get("id") or provider.get("key") or "")
    try:
        spent_now = _num(ctx.spent_money(pid, cur)) or 0.0
    except Exception:
        spent_now = 0.0
    left = amt - (spent_now - spent0)
    return {"kind": "balance", "source": "estimate", "method": "wallet",
            "accounts": [{"cur": cur, "amount": left}]}


# --------------------------------------------------------------------------- #
# main entry
# --------------------------------------------------------------------------- #

async def probe(provider: dict, member: dict, ctx: "Ctx") -> dict:
    provider = provider or {}
    member = member or {}
    try:
        now = float(ctx.now())
    except Exception:
        now = time.time()

    def finish(res: Optional[dict]) -> dict:
        if not isinstance(res, dict):
            return _unknown(now)
        merged = {
            "kind": res.get("kind", "none"),
            "source": res.get("source", "unknown"),
            "method": res.get("method", "none"),
            "accounts": res.get("accounts") or [],
            "pct": res.get("pct"),
            "reset": res.get("reset") or "",
            "week": res.get("week"),
            "week_reset": res.get("week_reset") or "",
            "used": res.get("used"),
            "limit": res.get("limit"),
            "state": res.get("state"),
            "short": res.get("short"),
            "checked_at": now,
            "unset": bool(res.get("unset")),
            "note": res.get("note") or "",
        }
        return _result(**merged)

    # 0) arrears error override (fresh within 10 minutes)
    err_res = _step_error(ctx, member, provider)
    if err_res and err_res.get("state") == "arrears":
        err_res["checked_at"] = now
        return _result(**err_res)

    # 1) official API
    aid = detect(provider)
    adapter = ADAPTERS.get(aid)
    official_res: Optional[dict] = None
    if adapter is not None:
        try:
            official_res = await adapter.official(ctx.session, provider)
        except Exception:
            official_res = None
    if official_res is None and aid == "volcengine":
        volc_balance = getattr(ctx, "volc_balance", None)
        if callable(volc_balance) and provider.get("volc_ak") and provider.get("volc_sk"):
            try:
                r = volc_balance(provider.get("volc_ak"), provider.get("volc_sk"))
                if asyncio.iscoroutine(r):
                    r = await r
                if isinstance(r, dict):
                    official_res = r
            except Exception:
                official_res = None
    if isinstance(official_res, dict):
        official_res.setdefault("source", "official")
        official_res.setdefault("method", "api")
        return finish(official_res)

    # 2) 响应头里的 x-ratelimit-* 是每分钟限速，不是余额：不进额度，只在最后一步当作备注
    # 3) CLI
    c = _step_cli(ctx, provider, member)
    if c:
        return finish(c)

    # 4) ledger estimate
    l = _step_ledger(ctx, provider, member)
    if l:
        return finish(l)

    # 5) error signal (non-arrears or stale)
    if err_res:
        return finish(err_res)

    # 6) wallet
    w = _step_wallet(ctx, provider, member)
    if w:
        return finish(w)

    # 6.5) 命令行 / DSH 成员：工具本身不提供额度查询时，至少显示今天用了几次（订阅制按次数/窗口，不按钱）
    if str(member.get("kind") or "") in ("cli", "dsh"):
        try:
            n = int(ctx.calls_today(_member_name(member)))
        except Exception:
            n = 0
        return _result(kind="count", source="estimate", method="ledger", accounts=[], used=n, state="ok",
                       short=f"今日 {n} 次", checked_at=now,
                       note="这个命令行工具没有提供额度查询，先显示今天调用了几次；用完时会按报错自动标出")

    # 7) 官方没有余额接口的厂商（OpenAI、Anthropic、Gemini、百炼、MiMo 按量、xAI/火山的普通 key 等）：
    #    显示本期已经花了多少，并标 unset，让 App 提示「填一次余额」，之后按账本自动扣
    return _spend_only(ctx, provider, member, now)


def _spend_only(ctx: Ctx, provider: dict, member: dict, now: float) -> dict:
    cur = provider_cur(provider)
    pid = str(provider.get("id") or provider.get("key") or "")
    try:
        spent = _num(ctx.spent_money(pid, cur)) or 0.0
    except Exception:
        spent = 0.0
    note = "官方没有开放余额接口，填一次余额后自动按用量扣"
    hint = _step_headers(ctx, member)
    if hint and hint.get("pct") is not None:
        note += f"；当前每分钟限速剩 {hint['pct']:.0f}%"
    if not provider.get("key") and not provider.get("base"):
        return _unknown(now)
    return _result(kind="spend", source="estimate", method="ledger", accounts=[], used=spent, state="ok",
                   short=f"已花 {cur}{spent:,.2f}", checked_at=now, unset=True, note=note)
