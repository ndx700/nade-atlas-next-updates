"""Review precedence and opt-in autopilot wiring, without sockets or persistent DATA."""
import copy
import asyncio
import functools
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest
import autopilot as a
import chorus2 as c
import orchestra as o
import server as s
import test_orchestra_batch2 as review_tests
from test_chorus2 import Base, seg


def run_async(fn):
    @functools.wraps(fn)
    def run(*args, **kw):
        return asyncio.run(fn(*args, **kw))
    return run


@pytest.mark.parametrize('mode', ['normal', 'frugal', 'minimal'])
def test_sample_is_not_vetoed_by_budget(mode):
    sampled = next(str(i) for i in range(100) if o.review_needed({'id': str(i), 'difficulty': 1}))
    seg = {'id': sampled, 'difficulty': 1, 'assignee': 'a'}
    assert not a.review_policy(mode, seg, .99)
    assert c.review_required({}, seg, mode, {'a': {'pass': .99}})
    with patch.object(o, 'review_needed', return_value=False):
        assert not c.review_required({}, seg, mode, {'a': {'pass': .99}})
        assert c.review_required({'quality': 'max'}, seg, mode, {})
        assert c.review_required({}, seg, mode, {}, dual=True)


def test_either_policy_can_require_review():
    with patch.object(o, 'review_needed', return_value=False):
        assert c.review_required({}, {'difficulty': 3}, 'normal', {})
    assert a.review_policy('minimal', {'quality': 'max', 'difficulty': 1}, .99)


def small(i, **kw):
    return dict(id=i, title=i, goal='goal', deliverable=i, context='context', acceptance=[i],
                checks=[{'type': 'file_exists', 'path': i}], assignee='a', stage='waiting',
                inputs=[], difficulty=1, est_tokens=100, **kw)


def test_merge_preserves_contracts_dependencies_and_originals():
    one, two = small('a'), small('b')
    original = copy.deepcopy([one, two])
    p = {'segments': [one, two, small('down')]}
    p['segments'][2]['inputs'] = ['a', 'b']
    with patch.object(a, 'batch', wraps=a.batch) as batch:
        assert a.merge_ready(p)
    batch.assert_called_once()
    assert len(p['segments']) == 2
    merged = p['segments'][0]
    assert merged['batch_segments'] == original
    assert merged['checks'] == original[0]['checks'] + original[1]['checks']
    assert merged['acceptance'] == ['a', 'b']
    assert merged['est_tokens'] == 200
    assert '[b] b' in merged['deliverable']
    assert p['segments'][1]['inputs'] == ['a']
    assert not a.merge_ready(p)


@pytest.mark.parametrize('change', [dict(started=1), dict(est_tokens=0), dict(est_tokens=6001),
    dict(difficulty=3), dict(spend={'cost': 1}), dict(quality='max'), dict(retry_at=1), dict(assignee='other'),
    dict(inputs=['done']), dict(retry_action='trim_retry'), dict(custom_policy=True)])
def test_unsafe_work_is_not_merged(change):
    p = {'segments': [small('a'), small('b')]}
    p['segments'][1].update(change)
    before = copy.deepcopy(p)
    assert not a.merge_ready(p)
    assert p == before


@pytest.mark.parametrize('value', [None, True, {'batch': 1}, {'cache_plan': 'true'}, {'unknown': True}])
def test_strict_switches(value):
    with pytest.raises(ValueError):
        a.validate_options(value)
    assert not a.enabled({'autopilot': value}, 'batch')


@run_async
async def test_settings_persist_and_default_off(tmp_path):
    assert s.SETTING_KEYS['autopilot'] == {'batch': False, 'cache_plan': False}
    assert not a.enabled({}, 'batch')
    with patch.multiple(s, CFG={}, DATA=tmp_path), patch.object(s, 'save_cfg'), patch.object(s, 'bump'):
        response = await s.h_settings(SimpleNamespace(json=AsyncMock(return_value={'autopilot': {'batch': True}})))
        assert response.status == 200
        assert s.CFG['autopilot'] == {'batch': True, 'cache_plan': False}
        response = await s.h_settings(SimpleNamespace(json=AsyncMock(return_value={'autopilot': {'batch': 1}})))
        assert response.status == 400
        assert s.CFG['autopilot']['batch'] is True


@run_async
@pytest.mark.parametrize('kind', ['openai', 'anthropic'])
@pytest.mark.parametrize('enabled', [False, True])
@pytest.mark.parametrize('prompt', ['changing task', [{'type': 'text', 'text': 'task'}, {'type': 'image_url', 'image_url': {'url': 'data:image/png;base64,YQ=='}}]])
async def test_api_cache_plan_wiring(kind, enabled, prompt, tmp_path):
    captured = []
    class Response:
        status = 200
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
    class Session(Response):
        def __init__(self, **kw): pass
        def post(self, url, **kw):
            captured.append(kw['json'])
            return Response()
    async def stream(r):
        if False: yield {}
    with patch.multiple(s, CFG={'autopilot': {'cache_plan': enabled}}, DATA=tmp_path, ClientSession=Session, sse=stream), \
         patch.object(s, 'provider', return_value={'kind': kind, 'base': 'https://example.invalid'}), \
         patch.object(a, 'cache_plan', wraps=a.cache_plan) as plan:
        await s.call_api(None, {}, {}, 'stable system', prompt, 'model', '')
    assert plan.call_count == int(enabled)
    body = captured[0]
    assert body['messages'][-1] == {'role': 'user', 'content': prompt}
    if kind == 'anthropic':
        assert body['system'][0]['text'] == 'stable system'
        assert body['system'][0]['cache_control'] == {'type': 'ephemeral'}
    else:
        assert body['messages'][0] == {'role': 'system', 'content': 'stable system'}


class TestNearBudgetMax(review_tests.TestMaxReviews):
    async def test_max_reviews_near_budget(self):
        self.P()['budget'] = {'cap': 100}
        self.P()['cost_split'] = {'execute': {'cost': {'¥': 99}}}
        budget = o.budget_state(self.P())
        assert a.budget_mode(budget['spent'], budget['cap']) == 'minimal'
        await self.test_two_distinct_reviews_even_when_executor_is_lead()


class TestBatchExecution(Base):
    no_http_tests = {'test_batch_dispatch', 'test_default_separate_dispatch'}

    async def execute(self, enabled):
        s.CFG['autopilot'] = {'batch': enabled}
        self.P()['segments'] = [seg(i, assignee='甲', est_tokens=100) for i in (1, 2)]
        original_run = s.run_member
        async def run(pid, name, trig, opts):
            if not trig.get('review'):
                for item in self.P()['segments']:
                    if item['id'] == trig.get('seg'):
                        for check in item['checks']:
                            Path(c.SEGMENT_CWD.get(), check['path']).write_text('output')
            await original_run(pid, name, trig, opts)
        s.run_member = run
        await self.run_all()
        assert all(item['stage'] == 'done' for item in self.P()['segments'])
        assert self.calls.count('甲') == (1 if enabled else 2)
        assert len(self.P()['segments']) == (1 if enabled else 2)

    async def test_batch_dispatch(self):
        await self.execute(True)
        assert len(self.P()['segments'][0]['verification']['results']) == 2

    async def test_default_separate_dispatch(self):
        await self.execute(False)
