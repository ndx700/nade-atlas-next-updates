"""B2 API contracts, exercised through real aiohttp routing without TCP sockets."""
import asyncio
import json
import re
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch
from urllib.parse import urlencode

from aiohttp import web
from aiohttp.test_utils import make_mocked_request

import api_errors as errors
import chorus2 as c
import concierge
import connect
import plugins
import server as s


class BootAPI(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(self.tmp.cleanup)
        data = Path(self.tmp.name)
        for name in ("chats", "skills", "files", "tmp"):
            (data / name).mkdir()
        self.chain = AsyncMock()
        self.concierge = SimpleNamespace(claims=Mock(return_value=False), on_user=AsyncMock())
        values = {
            "DATA": data, "CFG": {"password": "private-password", "name": "合唱", "owner": "阿离",
                "providers": [{"id": "pr", "base": "https://invalid.example/v1", "key": "private-api-key"}],
                "members": [{"name": "甲", "provider": "pr", "model": "small", "env": {"TOKEN": "private-env"}}]},
            "PROJECTS": [{"id": "p", "name": "项目", "members": ["甲"], "segments": []}],
            "CHATS": {}, "PVER": {}, "VER": 0, "EPOCH": "boot-test-epoch", "CHANGED": asyncio.Event(),
            "STATUS": {}, "TASK_STATUS": {}, "QUEUED": {}, "RESULTS": [], "JOBS": {}, "APP_SEEN": {},
            "QUOTA": {"甲": {"amount": 12}}, "QUOTA_AT": "刚刚", "run_chain": self.chain,
            "CONCIERGE": self.concierge,
        }
        for key, value in values.items():
            self.enterContext(patch.object(s, key, value))
        for module, key, value in ((c, "QUOTA2", {"甲": {"state": "ok"}}), (c, "INVITES", {}),
                                   (connect, "INV", {}), (connect, "REMOTE", {})):
            self.enterContext(patch.object(module, key, value))
        self.enterContext(patch.object(s, "PLUGINS", plugins.Plugins(s, hostinfo=lambda: {
            "cores": 2, "ram_mb": 1024, "ram_free_mb": 600, "gpu_gb": 0})))
        self.app = s.make_app()

    async def request(self, method, path, body=None, *, headers=None, authenticated=True, raw=None):
        h = {"Authorization": "Bearer " + s.token()} if authenticated else {}
        h.update(headers or {})
        h["Content-Type"] = "application/json"
        req = make_mocked_request(method, path, headers=h, app=self.app)
        req._read_bytes = raw if raw is not None else json.dumps(body if body is not None else {}).encode()
        match = await self.app.router.resolve(req)
        match.add_app(self.app)
        req._match_info = match
        return await s.auth(req, match.handler)

    @staticmethod
    def data(response):
        return json.loads(response.body)

    def error(self, response, status, fix=None):
        self.assertEqual(response.status, status, response.body)
        self.assertEqual(response.content_type, "application/json")
        data = self.data(response)
        self.assertTrue(re.search(r"[\u4e00-\u9fff]", data["error"]))
        self.assertIn(data["fix"], errors.FIXES)
        if fix:
            self.assertEqual(data["fix"], fix)
        for secret in ("private-password", "private-api-key", "private-env", "upstream-secret"):
            self.assertNotIn(secret, data["error"])
        return data

    async def test_boot_views_match_existing_apis_without_remote_or_host_probes(self):
        s.add_msg("p", "甲", "私信", "甲")
        with patch.object(c, "refresh_all", side_effect=AssertionError("network")), \
                patch.object(s, "fetch_models", side_effect=AssertionError("network")), \
                patch.object(s.PLUGINS, "hostinfo", side_effect=AssertionError("host probe")):
            response = await self.request("GET", "/api/boot")
        self.assertEqual(response.status, 200)
        data = self.data(response)
        self.assertEqual(data["index"], s.index_view())
        self.assertEqual(data["config"], self.data(await self.request("GET", "/api/config")))
        self.assertEqual(data["dms"], self.data(await self.request("GET", "/api/dms"))["dms"])
        self.assertEqual(data["members"], [s.member_view(s.CFG["members"][0])])
        self.assertEqual(data["features"], s.PLUGINS.features())
        self.assertEqual(data["quota"], {"members": c.QUOTA2, "quota": s.QUOTA, "quota_at": s.QUOTA_AT})
        self.assertEqual((data["epoch"], data["v"]), (s.EPOCH, s.VER))
        for secret in ("private-password", "private-api-key", "private-env"):
            self.assertNotIn(secret, response.text)
        self.assertEqual(data["config"]["members"][0]["env"], ["TOKEN"])

    async def test_boot_conditional_cache_and_authentication(self):
        first = await self.request("GET", "/api/boot")
        etag = first.headers["ETag"]
        self.assertIn("private", first.headers["Cache-Control"])
        self.assertEqual(first.headers["Vary"], "Authorization")
        for match in (etag, "W/" + etag, '"stale", W/' + etag, "*"):
            response = await self.request("GET", "/api/boot", headers={"If-None-Match": match})
            self.assertEqual(response.status, 304)
            self.assertFalse(response.body)
            self.assertEqual(response.headers["ETag"], etag)
        self.error(await self.request("GET", "/api/boot", headers={"If-None-Match": etag}, authenticated=False), 401, "relogin")
        self.assertEqual((await self.request("GET", "/api/boot", headers={"If-None-Match": '"stale"'})).status, 200)

    async def test_etag_changes_for_each_component_even_without_bump(self):
        (s.DATA / "skills" / "read").mkdir()
        response = await self.request("GET", "/api/boot")
        mutations = (
            lambda: s.add_msg("p", "甲", "私信", "甲"),
            lambda: s.CFG.update(name="新名字"),
            lambda: s.CFG["members"][0].update(role="顾问"),
            lambda: s.CFG.update(plugins={"tts_android": {"state": "installed"}}),
            lambda: c.QUOTA2["甲"].update(state="arrears"),
            lambda: s.QUOTA["甲"].update(amount=0),
            lambda: (s.DATA / "skills" / "read" / "SKILL.md").write_text("# 阅读"),
        )
        for mutate in mutations:
            previous = response.headers["ETag"]
            mutate()
            response = await self.request("GET", "/api/boot", headers={"If-None-Match": previous})
            self.assertEqual(response.status, 200)
            self.assertNotEqual(response.headers["ETag"], previous)
        with patch.object(s, "EPOCH", "restarted"):
            self.assertNotEqual((await self.request("GET", "/api/boot")).headers["ETag"], response.headers["ETag"])

    async def test_boot_read_cursors_are_part_of_representation(self):
        m = s.add_msg("p", "甲", "私信", "甲")
        before = await self.request("GET", "/api/boot")
        query = urlencode({"seen": json.dumps({"p": {"甲": m["seq"]}})})
        after = await self.request("GET", "/api/boot?" + query, headers={"If-None-Match": before.headers["ETag"]})
        self.assertEqual(self.data(after)["dms"][0]["unread"], 0)
        self.assertTrue(self.data(after)["read_state_supplied"])
        for raw in ("{", "[]", '{"p":{"甲":-1}}'):
            self.error(await self.request("GET", "/api/boot?" + urlencode({"seen": raw})), 400)

    async def test_small_snapshot_latency(self):
        for i in range(25):
            s.add_msg("p", "甲", "消息" * 20, "甲" if i % 3 == 0 else "")
        # Handler budget excludes construction of mocked requests, includes all
        # views, disk reads, JSON serialization, hashing and response creation.
        req = make_mocked_request("GET", "/api/boot")
        start = time.perf_counter()
        for _ in range(20):
            await s.h_boot(req)
        average_ms = (time.perf_counter() - start) * 1000 / 20
        self.assertLess(average_ms, 30, f"boot average {average_ms:.2f} ms")

    async def test_sequence_delta_is_immediate_and_can_merge_revision_changes(self):
        old = s.add_msg("p", "Ali", "旧消息")
        cursor = s.VER
        new = s.add_msg("p", "甲", "新消息")
        await self.request("POST", "/api/msg", {"project": "p", "seq": old["seq"], "op": "recall"})
        with patch.object(s, "wait_change", side_effect=AssertionError("must not poll")):
            delta = self.data(await self.request("GET", f"/api/chat/p?since={old['seq']}"))
            merged = self.data(await self.request("GET", f"/api/chat/p?since={old['seq']}&v={cursor}&epoch={s.EPOCH}"))
            empty = self.data(await self.request("GET", f"/api/chat/p?since={new['seq']}"))
        self.assertFalse(delta["full"])
        self.assertEqual([m["seq"] for m in delta["messages"]], [new["seq"]])
        self.assertEqual(delta["seq"], new["seq"])
        self.assertEqual([m["seq"] for m in merged["messages"]], [old["seq"], new["seq"]])
        self.assertTrue(merged["messages"][0]["recalled"])
        self.assertEqual(empty["messages"], [])
        legacy = self.data(await self.request("GET", f"/api/chat/p?v={cursor}"))
        self.assertFalse(legacy["full"])
        self.assertEqual(legacy["messages"], merged["messages"])

    async def test_delta_reset_restart_empty_and_invalid_cursors(self):
        self.assertEqual(self.data(await self.request("GET", "/api/chat/p?since=0"))["seq"], 0)
        s.add_msg("p", "Ali", "持久历史")
        s.CHATS["p"] = s.load_chat("p")
        for query in ("since=0", "since=99", "since=1&epoch=old", "since=1&v=999"):
            data = self.data(await self.request("GET", "/api/chat/p?" + query))
            self.assertTrue(data["full"])
            self.assertEqual(data["messages"][0]["text"], "持久历史")
        for key in ("since", "v"):
            for value in ("-1", "abc", "1.5"):
                self.error(await self.request("GET", f"/api/chat/p?{key}={value}"), 400, "retry")
        self.error(await self.request("GET", "/api/chat/missing?since=1"), 404)

    async def test_say_retries_concurrently_and_after_reload_dispatch_once(self):
        body = {"project": "p", "text": "@甲 你好", "client_id": "send-1"}
        replies = await asyncio.gather(*(self.request("POST", "/api/say", body) for _ in range(4)))
        await asyncio.sleep(0)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.assertEqual(self.chain.await_count, 1)
        first = self.data(replies[0])
        self.assertEqual(first["message"]["text"], body["text"])
        self.assertNotIn("request_hash", first["message"])
        s.CHATS["p"] = s.load_chat("p")
        self.assertEqual(self.data(await self.request("POST", "/api/say", body)), first)
        self.error(await self.request("POST", "/api/say", {**body, "text": "不同"}), 409)
        for _ in range(2):
            await self.request("POST", "/api/say", {"project": "p", "text": "旧客户端"})
        self.assertEqual(len(s.CHATS["p"]), 3)
        await asyncio.sleep(0)

    async def test_intent_retries_preserve_ack_without_second_concierge_call(self):
        self.concierge.claims.return_value = True
        body = {"project": "p", "to": "甲", "text": "帮我做个网站", "client_id": "intent-1"}
        first = self.data(await self.request("POST", "/api/say", body))
        await asyncio.sleep(0)
        s.CHATS["p"] = s.load_chat("p")
        self.assertEqual(self.data(await self.request("POST", "/api/say", body)), first)
        self.assertTrue(first["intent"])
        self.concierge.on_user.assert_awaited_once()
        self.chain.assert_not_called()

    async def test_msg_operations_replay_original_receipt_after_reload_and_later_edits(self):
        m = s.add_msg("p", "Ali", "原文")
        for op, extra in (("pin", {}), ("react", {"emoji": "赞"}), ("edit", {"text": "修改"}), ("recall", {})):
            with self.subTest(op=op):
                body = {"project": "p", "seq": m["seq"], "op": op, "client_id": op, **extra}
                first, retry = await asyncio.gather(self.request("POST", "/api/msg", body), self.request("POST", "/api/msg", body))
                self.assertEqual(self.data(first), self.data(retry))
                version = s.VER
                s.CHATS["p"] = s.load_chat("p")
                self.assertEqual(self.data(await self.request("POST", "/api/msg", body)), self.data(first))
                self.assertEqual(s.VER, version)
                self.assertNotIn("client_ops", self.data(first)["message"])
        # The first reaction receipt retains its nested data even after toggling.
        await self.request("POST", "/api/msg", {"project": "p", "seq": m["seq"], "op": "react", "emoji": "赞"})
        replay = self.data(await self.request("POST", "/api/msg", {"project": "p", "seq": m["seq"], "op": "react", "emoji": "赞", "client_id": "react"}))
        self.assertEqual(replay["message"]["reactions"], {"赞": ["Ali"]})
        conflict = await self.request("POST", "/api/msg", {"project": "p", "seq": m["seq"], "op": "edit", "text": "其他", "client_id": "edit"})
        self.error(conflict, 409)

    async def test_msg_client_id_is_scoped_to_project_and_conflicts_across_messages(self):
        one = s.add_msg("p", "Ali", "一")
        two = s.add_msg("p", "Ali", "二")
        body = {"project": "p", "seq": one["seq"], "op": "pin", "client_id": "same"}
        await self.request("POST", "/api/msg", body)
        self.error(await self.request("POST", "/api/msg", {**body, "seq": two["seq"]}), 409)
        s.PROJECTS.append({"id": "q", "name": "另一项目", "members": []})
        s.add_msg("q", "Ali", "另一条")
        self.assertEqual((await self.request("POST", "/api/msg", {**body, "project": "q"})).status, 200)

    async def test_failed_persistence_can_be_retried_without_phantom_receipt(self):
        body = {"project": "p", "text": "待发送", "client_id": "retry"}
        with patch.object(s, "persist", side_effect=OSError("upstream-secret")):
            self.error(await self.request("POST", "/api/say", body), 500, "retry")
        self.assertEqual(s.CHATS["p"], [])
        self.assertEqual((await self.request("POST", "/api/say", body)).status, 200)
        await asyncio.sleep(0)
        mutation = {"project": "p", "seq": 1, "op": "pin", "client_id": "retry-op"}
        with patch.object(s, "persist", side_effect=OSError("upstream-secret")):
            self.error(await self.request("POST", "/api/msg", mutation), 500, "retry")
        self.assertNotIn("pinned", s.CHATS["p"][0])
        self.assertNotIn("client_ops", s.CHATS["p"][0])
        self.assertEqual((await self.request("POST", "/api/msg", mutation)).status, 200)
        self.assertTrue(s.CHATS["p"][0]["pinned"])

    async def test_invalid_send_and_mutation_never_persist(self):
        s.add_msg("p", "甲", "只属于成员")
        for endpoint, body in (("say", {"project": "missing"}),
                ("msg", {"project": "p", "seq": 999, "op": "pin"}),
                ("msg", {"project": "p", "seq": 1, "op": "edit", "text": "不能改"})):
            self.error(await self.request("POST", "/api/" + endpoint, body), 403 if body.get("op") == "edit" else 404)
        for endpoint, base in (("say", {"project": "p", "text": "有效"}),
                               ("msg", {"project": "p", "seq": 1, "op": "pin"})):
            for client_id in (None, False, [], {}, "x" * 201):
                self.error(await self.request("POST", "/api/" + endpoint, {**base, "client_id": client_id}), 400)
            for raw in (b"{", b"[]", b"null"):
                self.error(await self.request("POST", "/api/" + endpoint, raw=raw), 400)
        self.error(await self.request("POST", "/api/say", {"project": "p", "files": [1]}), 400)
        self.error(await self.request("POST", "/api/msg", {"project": "p", "seq": 1, "op": "unknown"}), 400)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.chain.assert_not_called()

    async def test_error_contract_across_modules_and_public_routes(self):
        cases = (
            ("GET", "/api/missing", {}, 404, "retry"),
            ("POST", "/api/boot", {}, 405, "retry"),
            ("PUT", "/api/settings", {"member_timeout_ms": -1}, 400, "settings"),
            ("PUT", "/api/providers", {}, 400, "edit_base"),
            ("POST", "/api/quick_add", {}, 400, "repaste"),
            ("GET", "/api/voice/ws", {}, 409, "settings"),
            ("POST", "/api/intent/missing/confirm", {}, 409, "retry"),
            ("POST", "/api/plugins/missing", {}, 404, "retry"),
            ("POST", "/api/plugins/tts_cosyvoice", {}, 400, "settings"),
            ("GET", "/api/orchestra/missing", {}, 404, "retry"),
            ("PUT", "/api/orchestra/p/night", {"window": [25, 1]}, 400, "settings"),
            ("PUT", "/api/account/caps", {"hour": -1}, 400, "settings"),
            ("POST", "/api/invite/redeem", {"code": "bad"}, 403, "retry"),
            ("GET", "/api/connect/pub/install", {}, 403, "retry"),
            ("GET", "/api/connect/pub/jobs", {}, 403, "relogin"),
        )
        self.concierge.confirm = AsyncMock(return_value=None)
        for method, path, body, status, fix in cases:
            with self.subTest(path=path):
                self.error(await self.request(method, path, body), status, fix)
        # Public routes have the same malformed-body protection as private APIs.
        self.error(await self.request("POST", "/api/invite/redeem", raw=b"[", authenticated=False), 400)
        self.error(await self.request("POST", "/api/connect/paste", {"text": "没有密钥"}), 200, "repaste")
        plan = concierge.draft("做个网站", [], [], lambda m: None, {}, lambda n: False)
        self.assertEqual(plan["fix"], "settings")

    async def test_upstream_failures_are_chinese_actionable_and_do_not_log_secrets(self):
        for evidence, fix in (("HTTP 401 invalid key", "repaste"), ("HTTP 402 insufficient balance", "topup"),
                ("HTTP 429 rate limit", "retry"), ("HTTP 404", "edit_base"), ("network down", "retry"),
                ("unrecognized response", "settings")):
            with self.subTest(evidence=evidence), patch.object(s, "fetch_models", AsyncMock(side_effect=RuntimeError(evidence + " upstream-secret"))), \
                    patch("builtins.print") as printed:
                response = await self.request("PUT", "/api/providers", {"id": "pr", "base": "https://invalid.example/v1"})
                self.error(response, 200, fix)
                self.error(await self.request("GET", "/api/providers/pr/models"), 502, fix)
                self.error(await self.request("POST", "/api/connect/paste", {"text": "sk-ant-" + "a" * 32}), 200, fix)
                printed.assert_not_called()
        with patch.object(s, "config_view", side_effect=RuntimeError("upstream-secret")), patch("builtins.print") as printed:
            self.error(await self.request("GET", "/api/boot"), 500, "retry")
            printed.assert_not_called()

    async def test_plugin_failure_state_has_safe_error_and_fix(self):
        async def fail(step, dest):
            raise RuntimeError("network down upstream-secret")
        plugin = plugins.Plugins(s, runner=fail, hostinfo=lambda: {"cores": 8, "ram_mb": 16000, "gpu_gb": 0})
        plugin.install("tts_edge")
        await plugin.jobs["tts_edge"]
        row = next(row for row in plugin.view()["plugins"] if row["id"] == "tts_edge")
        self.assertEqual(row["state"], "failed")
        self.assertEqual(row["fix"], "retry")
        self.assertNotIn("upstream-secret", row["error"])
        self.assertRegex(row["error"], r"[\u4e00-\u9fff]")

    async def test_connector_registration_expiry_limits_and_probe_failure(self):
        invite = self.data(await self.request("POST", "/api/connect/invite"))
        headers = {"X-Chorus-Invite": invite["token"]}
        self.error(await self.request("POST", "/api/connect/pub/register", {"clis": []}, headers=headers,
                                      authenticated=False), 400, "settings")
        self.error(await self.request("GET", invite["status"]), 200, "settings")
        connect.INV[invite["token"]]["expires"] = 0
        self.error(await self.request("GET", "/api/connect/pub/install", headers=headers, authenticated=False), 403, "retry")
        self.error(await self.request("GET", "/api/connect/status/missing"), 404, "retry")
        connect.INV.clear()
        for _ in range(20):
            connect.new_invite("http://localhost")
        self.error(await self.request("POST", "/api/connect/invite"), 429, "retry")
        connect.INV.clear()
        invite = connect.new_invite("http://localhost")
        inv = connect.INV[invite["token"]]
        for exception, fix in ((RuntimeError("HTTP 401 upstream-secret"), "repaste"),
                               (asyncio.TimeoutError(), "retry")):
            with patch.object(connect, "remote_call", AsyncMock(side_effect=exception)):
                await connect._test(invite["token"], "甲")
            self.error(await self.request("GET", invite["status"]), 200, fix)
        with patch.object(s, "fetch_models", AsyncMock(side_effect=asyncio.TimeoutError())):
            self.error(await self.request("POST", "/api/connect/paste", {"text": "sk-ant-" + "a" * 32}), 200, "retry")

    async def test_chorus_validation_errors_keep_extra_fields_and_fix(self):
        cases = (("PUT", "/api/members/甲/policy", {"spend_auto": -1}, 400, "settings"),
                 ("PUT", "/api/orchestra/p/night", {"enabled": True}, 409, "none"))
        for method, path, body, status, fix in cases:
            response = await self.request(method, path, body)
            data = self.error(response, status, fix)
            if status == 409:
                self.assertIn("confirm", data)
        for name, status in (("../bad", 400), ("甲", 409)):
            c.INVITES["VALID"] = {"expires": time.time() + 60}
            self.error(await self.request("POST", "/api/invite/redeem", {"code": "VALID", "name": name}), status, "none")
        c.INVITES.update({str(i): {"expires": time.time() + 60} for i in range(20)})
        self.error(await self.request("POST", "/api/invite"), 429, "retry")
        s.PROJECTS[0]["segments"] = [{"id": "s1", "stage": "running"}]
        self.error(await self.request("POST", "/api/orchestra/p/segments/s1/restart"), 409, "retry")
        self.error(await self.request("POST", "/api/plugins/tts_minimax"), 400, "settings")

    async def test_nested_job_errors_and_legacy_http_exceptions_are_safe(self):
        s.JOBS["j"] = {"project": "p", "state": "failed", "t": time.time(), "error": "HTTP 402 upstream-secret"}
        job = self.data(await self.request("GET", "/api/chat/p"))["jobs"][0]
        self.assertEqual(job["fix"], "topup")
        self.assertNotIn("upstream-secret", job["error"])
        price = s.price_job_view({"id": "j", "error": "HTTP 401 upstream-secret", "task": object()})
        self.assertEqual(price["fix"], "repaste")
        self.assertNotIn("upstream-secret", price["error"])
        exception = web.HTTPTooManyRequests(text="upstream-secret", headers={"Retry-After": "30"})
        with patch.object(s, "config_view", side_effect=exception):
            response = await self.request("GET", "/api/boot")
            self.error(response, 429, "retry")
            self.assertEqual(response.headers["Retry-After"], "30")
