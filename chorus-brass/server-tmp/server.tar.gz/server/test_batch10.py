"""Batch ten regressions: durable indexes, subprocess pipes, asynchronous quota."""
import asyncio
import json
import os
from pathlib import Path
import shlex
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

import adapters
import artifacts
import server as s


class IndexWrites(unittest.TestCase):
    def test_sync_before_replace_and_directory_sync(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'artifacts.json'
            artifacts._atomic_write_json(path, {'old': True})
            events = []
            sync, replace = os.fsync, os.replace

            def synced(fd):
                events.append('sync')
                sync(fd)

            def replaced(src, dst):
                self.assertEqual(json.loads(path.read_text()), {'old': True})
                self.assertEqual(json.loads(Path(src).read_text()), {'new': True})
                events.append('replace')
                replace(src, dst)

            with patch.object(artifacts.os, 'fsync', side_effect=synced), patch.object(artifacts.os, 'replace', side_effect=replaced):
                artifacts._atomic_write_json(path, {'new': True})
            self.assertEqual(events, ['sync', 'replace', 'sync'])
            self.assertEqual(json.loads(path.read_text()), {'new': True})
            self.assertEqual(list(Path(root).iterdir()), [path])

    def test_failed_write_or_replace_retains_old_index_and_cleans_temp(self):
        with tempfile.TemporaryDirectory() as root:
            store = artifacts.ArtifactStore(root, 'p', enabled=True)
            store._save_sync({})
            original = store.index_path.read_bytes()
            for method in ('fsync', 'replace'):
                with self.subTest(method=method), patch.object(artifacts.os, method, side_effect=OSError('interrupted')):
                    with self.assertRaises(OSError):
                        store._save_sync({})
                self.assertEqual(store.index_path.read_bytes(), original)
                self.assertEqual(list(store.ledger_dir.iterdir()), [store.index_path])


class Processes(unittest.IsolatedAsyncioTestCase):
    def command(self, path):
        return shlex.quote(sys.executable) + ' ' + shlex.quote(str(path))

    def test_timeout_configuration(self):
        for cls in (adapters.CliAdapter, adapters.AcpAdapter):
            guard = lambda cmd: (cmd, [])
            self.assertEqual(cls({'name': 'a'}, guard).timeout, 600)
            self.assertEqual(cls({'name': 'a', 'timeout': 1234}, guard).timeout, 1234)
            self.assertEqual(cls({'name': 'a', 'timeout': 1234}, guard, timeout=12).timeout, 12)

    async def test_cli_large_stderr_before_reading_large_stdin(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'cli.py'
            path.write_text("import sys\nsys.stdout.write('progress\\n' * 20000)\nsys.stdout.flush()\nsys.stderr.write('e' * 2000000)\nsys.stderr.flush()\nsys.stdin.read()\nprint('delivered')\n")
            adapter = adapters.CliAdapter({'name': 'a', 'cmd': self.command(path)}, lambda cmd: (cmd, []), timeout=5)
            result = await asyncio.wait_for(adapter.run('x' * 2000000, lambda step: None, AsyncMock(), cwd=root), 10)
            self.assertTrue(result.ok, result.error)
            self.assertTrue(result.text.endswith('delivered'))

    async def test_cli_failure_keeps_only_stderr_tail(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'cli.py'
            path.write_text("import sys\nsys.stdin.read()\nsys.stderr.write('x' * 2000000 + 'THE END')\nsys.exit(2)\n")
            adapter = adapters.CliAdapter({'name': 'a', 'cmd': self.command(path)}, lambda cmd: (cmd, []), timeout=5)
            result = await adapter.run('packet', lambda step: None, AsyncMock(), cwd=root)
            self.assertFalse(result.ok)
            self.assertEqual(len(result.error), 400)
            self.assertTrue(result.error.endswith('THE END'))

    async def test_timeout_includes_stdin_and_exit_after_stdout_eof(self):
        for body in ("import time; time.sleep(30)", "import os,time; os.close(1); time.sleep(30)"):
            with self.subTest(body=body), tempfile.TemporaryDirectory() as root:
                path = Path(root) / 'cli.py'
                path.write_text(body)
                adapter = adapters.CliAdapter({'name': 'a', 'cmd': self.command(path)}, lambda cmd: (cmd, []), timeout=.1)
                result = await asyncio.wait_for(adapter.run('x' * 2000000, lambda step: None, AsyncMock(), cwd=root), 3)
                self.assertEqual(result.error, 'timeout')

    async def test_acp_drains_stderr_while_exchanging_rpc(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'acp.py'
            path.write_text("""import sys,json
sys.stderr.write('e' * 2000000)
sys.stderr.flush()
for line in sys.stdin:
    request = json.loads(line)
    result = {'sessionId': 'test'} if request['method'] == 'session/new' else {}
    if request['method'] == 'session/prompt':
        result = {'stopReason': 'end_turn'}
    print(json.dumps({'jsonrpc': '2.0', 'id': request['id'], 'result': result}), flush=True)
""")
            adapter = adapters.AcpAdapter({'name': 'a', 'cmd': self.command(path)}, lambda cmd: (cmd, []), timeout=5)
            result = await asyncio.wait_for(adapter.run('packet', lambda step: None, AsyncMock(), cwd=root), 10)
            self.assertTrue(result.ok, result.error)

    async def test_timeout_and_cancel_reap_processes(self):
        for cls in (adapters.CliAdapter, adapters.AcpAdapter):
            for cancel in (False, True):
                with self.subTest(adapter=cls.__name__, cancel=cancel), tempfile.TemporaryDirectory() as root:
                    path = Path(root) / 'agent.py'
                    path.write_text("import time; time.sleep(30)")
                    adapter = cls({'name': 'a', 'cmd': self.command(path)}, lambda cmd: (cmd, []), timeout=.1)
                    real_spawn = asyncio.create_subprocess_shell
                    spawned = []
                    async def spawn(*args, **kwargs):
                        proc = await real_spawn(*args, **kwargs)
                        spawned.append(proc)
                        return proc
                    with patch.object(adapters.asyncio, 'create_subprocess_shell', side_effect=spawn):
                        task = asyncio.create_task(adapter.run('packet', lambda step: None, AsyncMock(), cwd=root))
                        if cancel:
                            while not spawned:
                                await asyncio.sleep(0)
                            task.cancel()
                            with self.assertRaises(asyncio.CancelledError):
                                await asyncio.wait_for(task, 3)
                        else:
                            result = await asyncio.wait_for(task, 3)
                            self.assertEqual(result.error, 'timeout')
                    self.assertIsNotNone(spawned[0].returncode)


class QuotaRefresh(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.enterContext(patch.object(s, 'QUOTA_REFRESH_TASK', None))
        self.enterContext(patch.object(s, 'QUOTA_REFRESH_STATUS', {'state': 'idle', 'error': ''}))
        self.enterContext(patch.object(s, 'QUOTA', {}))
        self.enterContext(patch.object(s, 'CFG', {'members': []}))
        self.enterContext(patch.object(s, 'bump'))
        self.enterContext(patch.object(s, 'QUOTA_AT', 'previous'))

    async def asyncTearDown(self):
        if s.QUOTA_REFRESH_TASK:
            s.QUOTA_REFRESH_TASK.cancel()
            await asyncio.gather(s.QUOTA_REFRESH_TASK, return_exceptions=True)

    async def test_immediate_response_dedup_poll_completion_and_retry(self):
        gate = asyncio.Event()

        async def refresh():
            await gate.wait()
            s.QUOTA_AT = 'new'
        with patch.object(s, 'refresh_quota', side_effect=refresh) as probe:
            response = await asyncio.wait_for(s.h_quota_refresh(None), .2)
            self.assertEqual(response.status, 202)
            routes = {(route.method, route.resource.canonical) for route in s.make_app().router.routes()}
            self.assertIn(('GET', '/api/quota/refresh'), routes)
            self.assertIn(('POST', '/api/quota/refresh'), routes)
            task = s.QUOTA_REFRESH_TASK
            await s.h_quota_refresh(None)
            self.assertIs(s.QUOTA_REFRESH_TASK, task)
            await asyncio.sleep(0)
            self.assertEqual(probe.call_count, 1)
            self.assertEqual(json.loads((await s.h_quota_refresh_status(None)).text)['state'], 'running')
            gate.set()
            await task
            state = json.loads((await s.h_quota_refresh_status(None)).text)
            self.assertEqual((state['state'], state['quota_at']), ('done', 'new'))
            self.assertIn('quota', state)
            await s.h_quota_refresh(None)
            self.assertIsNot(s.QUOTA_REFRESH_TASK, task)
            await s.QUOTA_REFRESH_TASK
            self.assertEqual(probe.call_count, 2)

    async def test_failure_and_cancellation_are_pollable(self):
        with patch.object(s, 'refresh_quota', AsyncMock(side_effect=RuntimeError('secret'))):
            await s.h_quota_refresh(None)
            await s.QUOTA_REFRESH_TASK
            state = json.loads((await s.h_quota_refresh_status(None)).text)
            self.assertEqual(state['state'], 'failed')
            self.assertNotIn('secret', state['error'])
        started = asyncio.Event()

        async def wait():
            started.set()
            await asyncio.Event().wait()
        with patch.object(s, 'refresh_quota', wait):
            await s.h_quota_refresh(None)
            await started.wait()
            s.QUOTA_REFRESH_TASK.cancel()
            await asyncio.gather(s.QUOTA_REFRESH_TASK, return_exceptions=True)
            self.assertEqual(s.QUOTA_REFRESH_STATUS['state'], 'cancelled')

    async def test_codex_probe_runs_off_event_loop(self):
        probe = AsyncMock(return_value={'short': 'available'})
        with patch.object(s, 'CFG', {'members': [{'name': 'cli', 'kind': 'cli', 'quota': {'type': 'codex', 'home': '/unused'}}]}), patch.object(s.asyncio, 'to_thread', probe):
            await s.refresh_quota()
        probe.assert_awaited_once_with(s.codex_quota, '/unused')
        self.assertEqual(s.QUOTA['cli']['short'], 'available')

    async def test_wallet_returns_without_waiting_for_refresh(self):
        from types import SimpleNamespace
        started, gate = asyncio.Event(), asyncio.Event()
        async def refresh(names):
            self.assertEqual(names, ['a'])
            started.set()
            await gate.wait()
        member = {'name': 'a', 'provider': 'pr', 'model': 'm'}
        provider = {'id': 'pr'}
        tasks = []
        def spawn(coro):
            task = asyncio.create_task(coro)
            tasks.append(task)
            return task
        with patch.object(s, 'CFG', {'members': [member]}), patch.object(s, 'member', return_value=member), patch.object(s, 'provider', return_value=provider), patch.object(s, 'price', return_value={}), patch.object(s, 'save_cfg'), patch.object(s, 'refresh_quota', refresh), patch.object(s.background, 'spawn', side_effect=spawn):
            try:
                response = await asyncio.wait_for(s.h_wallet(SimpleNamespace(json=AsyncMock(return_value={'member': 'a', 'price_in': 3}))), .2)
                self.assertEqual(response.status, 200)
                await asyncio.wait_for(started.wait(), .2)
                self.assertFalse(tasks[0].done())
            finally:
                gate.set()
                await asyncio.gather(*tasks)
