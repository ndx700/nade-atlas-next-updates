import types, unittest, connect


class AddModels(unittest.TestCase):
    def test_add(self):
        cfg = {"providers": [{"id": "rl", "models": [("gpt-a", ""), ("m/b c", "")]}], "members": []}
        S = types.SimpleNamespace(CFG=cfg, PROJECTS=[{"members": []}], save_cfg=lambda: None, bump=lambda: None)
        S.provider = lambda i: next((p for p in cfg["providers"] if p["id"] == i), None)
        S.member = lambda n: next((m for m in cfg["members"] if m["name"] == n), None)
        S.join_member = lambda n: [p["members"].append(n) for p in S.PROJECTS if not p.get("parent") and n not in p["members"]]
        S.save_projects = lambda: None
        connect.S = S
        r = connect.add_models("rl", ["gpt-a", "m/b c", "nope"])
        self.assertEqual(len(r["added"]), 2)
        self.assertEqual(r["skipped"], ["nope"])
        self.assertEqual(S.PROJECTS[0]["members"], r["added"])   # 加的模型都进了乐章
        self.assertEqual(connect.add_models("rl", ["gpt-a"])["added"], [])
        self.assertFalse(connect.add_models("zz", [])["ok"])


if __name__ == "__main__":
    unittest.main()
