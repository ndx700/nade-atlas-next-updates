"""Shell redline regressions: classification only, never execute commands."""
import pytest
from redline import check


@pytest.mark.parametrize('command', [
    'rm -r -f /', 'rm -f -r /', 'rm -fr /', 'rm --force --recursive /',
    '/bin/rm -f -R /', 'env X=1 rm -r -f /',
    'rm -r -f /w/../outside', 'rm -r -f /tmp/../home/data',
    'rm -rf "/home/data with spaces"',
    'cd /home/data && rm -r -f files',
    'cd /home && rm -rf data',
    'cd /home/data; rm -rf ./files',
    '(cd /home/data && rm -rf files)',
    "bash -c 'cd /home/data && rm -rf files'",
    'mv /home/data /tmp/backup', 'mv /tmp/x /home/data',
    'rsync -a --delete /empty/ /home/data/',
    'rsync --delete-excluded /empty/ /home/data/',
    'rsync --remove-source-files /home/data/ /tmp/backup/',
    'git clean -fd', 'git -C /home/data clean -fxd',
    r'find /home/data -exec rm -f {} \;',
    'find /home/data -execdir /bin/rm {} +',
])
def test_destructive_commands_ask(command):
    v = check('Bash', {'command': command}, {'data_dir': '/home/data', 'workspaces': ['/w']})
    assert (v.action, v.line) == ('ask', 'delete')


@pytest.mark.parametrize('command', [
    "python -c 'print(1)'", "python3 -c'print(1)'", "python3 -Ic 'print(1)'", 'python3 -c "import shutil; shutil.rmtree(\'/home/data\')"',
    '/usr/bin/python3.11 -I -c "print(1)"', 'env X=1 python3 -c "print(1)"',
    'echo cm0= | base64 -d | sh', 'base64 --decode payload | /bin/bash',
    'echo cm0= | base64 -d | sudo sh',
])
def test_dynamic_code_always_asks(command):
    assert check('Bash', {'command': command}).action == 'ask'


@pytest.mark.parametrize('command', ['rm -r -f build', 'rm -f -r /w/build',
                                        'rm --recursive /tmp/scratch', 'rm -rf -- /w/-rf',
                                        'python3 --version', 'base64 -d payload', 'git status'])
def test_safe_commands_still_allow(command):
    assert check('Bash', {'command': command}, {'workspaces': ['/w']}).allow


def test_relative_target_uses_context_cwd(tmp_path):
    data = tmp_path / 'data'
    ctx = {'cwd': str(tmp_path), 'data_dir': str(data), 'workspaces': [str(tmp_path)]}
    assert check('Bash', {'command': 'rm -r -f data'}, ctx).line == 'delete'
    assert check('Bash', {'command': 'rm -r -f build'}, ctx).allow
    assert check('Bash', {'command': f'rm -rf {tmp_path}'}, ctx).line == 'delete'


def test_deny_still_wins():
    assert check('Bash', {'command': 'python -c "print(1)"; sqlmap -u https://x'}).action == 'deny'
