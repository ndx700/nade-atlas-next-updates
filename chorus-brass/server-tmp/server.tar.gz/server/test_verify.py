"""
server/test_verify.py — Task card N1 单元测试（离线可跑）。

运行::

    python -m unittest server.test_verify -v
    # 或
    pytest -q server/test_verify.py

覆盖：5 种 check 类型（command / file_exists / json_schema / regex / count）+
 manual 不计入通过 + 超时 + 白名单拒绝 + 路径越界 + 向后兼容 acceptance。
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

# 允许直接 `python server/test_verify.py` 运行
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from verify import (  # noqa: E402
    ALLOWED_COMMANDS,
    MAX_OUTPUT_BYTES,
    run_checks,
)


def run(coro):
    return asyncio.run(coro)


class VerifyBase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory(prefix="chorus-verify-")
        self.workdir = Path(self._tmp.name).resolve()
        (self.workdir / "deliverable").mkdir()
        (self.workdir / "work").mkdir()

    def tearDown(self) -> None:
        self._tmp.cleanup()

    # helpers -------------------------------------------------------------
    def write(self, rel: str, content: str | bytes) -> Path:
        p = self.workdir / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            p.write_bytes(content)
        else:
            p.write_text(content, encoding="utf-8")
        return p


# --------------------------------------------------------------------------- #
# file_exists
# --------------------------------------------------------------------------- #


class TestFileExists(VerifyBase):
    def test_pass_when_present_and_big_enough(self) -> None:
        self.write("deliverable/report.md", "# ok\n" + "x" * 600)
        seg = {"checks": [{"type": "file_exists", "path": "deliverable/report.md", "min_bytes": 500}]}
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])
        self.assertEqual(out["results"][0]["state"], "pass")
        self.assertEqual(out["by"], "server")
        self.assertIsInstance(out["at"], float)

    def test_fail_when_missing(self) -> None:
        seg = {"checks": [{"type": "file_exists", "path": "deliverable/missing.md", "min_bytes": 10}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertEqual(out["results"][0]["state"], "fail")

    def test_fail_when_too_small(self) -> None:
        self.write("deliverable/report.md", "tiny")
        seg = {"checks": [{"type": "file_exists", "path": "deliverable/report.md", "min_bytes": 500}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("too small", out["results"][0]["detail"])

    def test_fail_when_path_escapes_workdir(self) -> None:
        seg = {"checks": [{"type": "file_exists", "path": "../../etc/passwd"}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("escapes", out["results"][0]["detail"])


# --------------------------------------------------------------------------- #
# json_schema
# --------------------------------------------------------------------------- #


class TestJsonSchema(VerifyBase):
    def test_pass_on_valid(self) -> None:
        self.write("deliverable/result.json", json.dumps({"items": [1, 2], "name": "a"}))
        seg = {
            "checks": [
                {
                    "type": "json_schema",
                    "path": "deliverable/result.json",
                    "schema": {"type": "object", "required": ["items"]},
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])

    def test_fail_on_missing_required(self) -> None:
        self.write("deliverable/result.json", json.dumps({"name": "a"}))
        seg = {
            "checks": [
                {
                    "type": "json_schema",
                    "path": "deliverable/result.json",
                    "schema": {"type": "object", "required": ["items"]},
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("missing required", out["results"][0]["detail"])

    def test_fail_on_invalid_json(self) -> None:
        self.write("deliverable/result.json", "{not json")
        seg = {
            "checks": [
                {
                    "type": "json_schema",
                    "path": "deliverable/result.json",
                    "schema": {"type": "object"},
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("invalid JSON", out["results"][0]["detail"])

    def test_nested_properties(self) -> None:
        self.write("deliverable/result.json", json.dumps({"data": {"count": "not-int"}}))
        seg = {
            "checks": [
                {
                    "type": "json_schema",
                    "path": "deliverable/result.json",
                    "schema": {
                        "type": "object",
                        "properties": {"data": {"type": "object", "properties": {"count": {"type": "integer"}}}},
                    },
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("expected type", out["results"][0]["detail"])


# --------------------------------------------------------------------------- #
# regex
# --------------------------------------------------------------------------- #


class TestRegex(VerifyBase):
    def test_pass_with_multiline_flag(self) -> None:
        self.write("deliverable/report.md", "前言\n## 结论\n内容")
        seg = {
            "checks": [
                {
                    "type": "regex",
                    "path": "deliverable/report.md",
                    "pattern": "^## 结论",
                    "flags": "m",
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])

    def test_fail_when_pattern_absent(self) -> None:
        self.write("deliverable/report.md", "前言\n结论")
        seg = {
            "checks": [
                {
                    "type": "regex",
                    "path": "deliverable/report.md",
                    "pattern": "^## 结论",
                    "flags": "m",
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])

    def test_fail_on_bad_flag(self) -> None:
        self.write("deliverable/report.md", "x")
        seg = {
            "checks": [
                {"type": "regex", "path": "deliverable/report.md", "pattern": "x", "flags": "z"}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("unsupported regex flag", out["results"][0]["detail"])


# --------------------------------------------------------------------------- #
# count
# --------------------------------------------------------------------------- #


class TestCount(VerifyBase):
    def test_pass_within_bounds(self) -> None:
        self.write("deliverable/list.txt", "\n".join(f"item-{i}" for i in range(10)))
        seg = {
            "checks": [
                {"type": "count", "path": "deliverable/list.txt", "min": 5, "max": 50, "unit": "line"}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])
        self.assertEqual(out["results"][0]["count"], 10)

    def test_fail_below_min(self) -> None:
        self.write("deliverable/list.txt", "a\nb\n")
        seg = {
            "checks": [
                {"type": "count", "path": "deliverable/list.txt", "min": 5, "max": 50, "unit": "line"}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("< min", out["results"][0]["detail"])

    def test_fail_above_max(self) -> None:
        self.write("deliverable/list.txt", "\n".join(str(i) for i in range(100)))
        seg = {
            "checks": [
                {"type": "count", "path": "deliverable/list.txt", "min": 5, "max": 50, "unit": "line"}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("> max", out["results"][0]["detail"])

    def test_match_unit(self) -> None:
        self.write("deliverable/list.txt", "TODO: a\nTODO: b\nTODO: c\n")
        seg = {
            "checks": [
                {
                    "type": "count",
                    "path": "deliverable/list.txt",
                    "unit": "match",
                    "pattern": r"TODO: \w+",
                    "min": 3,
                    "max": 3,
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])
        self.assertEqual(out["results"][0]["count"], 3)


# --------------------------------------------------------------------------- #
# command
# --------------------------------------------------------------------------- #


class TestCommand(VerifyBase):
    def test_pass_on_zero_exit(self) -> None:
        seg = {
            "checks": [
                {
                    "type": "command",
                    "cmd": f"{sys.executable} -c \"print('ok')\"",
                    "timeout": 30,
                    "cwd": ".",
                }
            ]
        }
        # sys.executable 可能不在白名单（basename 是 python3.x），改用 python3
        seg["checks"][0]["cmd"] = "python3 -c \"print('ok')\""
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"], out)
        self.assertEqual(out["results"][0]["state"], "pass")
        self.assertEqual(out["results"][0]["code"], 0)

    def test_fail_on_nonzero_exit(self) -> None:
        seg = {
            "checks": [
                {"type": "command", "cmd": "python3 -c \"raise SystemExit(3)\"", "timeout": 30}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertEqual(out["results"][0]["code"], 3)

    def test_output_truncated_to_4kb(self) -> None:
        seg = {
            "checks": [
                {
                    "type": "command",
                    "cmd": "python3 -c \"print('x' * 20000)\"",
                    "timeout": 30,
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertTrue(out["passed"])
        stdout = out["results"][0]["stdout"]
        self.assertLessEqual(len(stdout.encode("utf-8")), MAX_OUTPUT_BYTES + 64)
        self.assertTrue(out["results"][0]["truncated"])

    def test_timeout_is_enforced(self) -> None:
        seg = {
            "checks": [
                {
                    "type": "command",
                    "cmd": "python3 -c \"import time; time.sleep(10)\"",
                    "timeout": 1,
                }
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("timed out", out["results"][0]["detail"])

    def test_whitelist_rejects_unknown_command(self) -> None:
        seg = {"checks": [{"type": "command", "cmd": "rm -rf /", "timeout": 5}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("not allowed", out["results"][0]["detail"])

    def test_network_command_blocked_by_default(self) -> None:
        seg = {"checks": [{"type": "command", "cmd": "npm test", "timeout": 5}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("network command blocked", out["results"][0]["detail"])

    def test_network_command_allowed_when_guard_set(self) -> None:
        seg = {"checks": [{"type": "command", "cmd": "npm --version", "timeout": 5}]}
        out = run(run_checks(seg, self.workdir, guards={"allow_network": True}))
        # npm 可能不存在 -> fail，但不应是 "network command blocked"
        self.assertNotIn("network command blocked", out["results"][0]["detail"])

    def test_cwd_must_stay_inside_workdir(self) -> None:
        seg = {
            "checks": [
                {"type": "command", "cmd": "python3 -c \"pass\"", "cwd": "../..", "timeout": 5}
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("escapes", out["results"][0]["detail"])

    def test_custom_whitelist(self) -> None:
        seg = {"checks": [{"type": "command", "cmd": "python3 -V", "timeout": 5}]}
        out = run(run_checks(seg, self.workdir, guards={"allowed_commands": ["pytest"]}))
        self.assertFalse(out["passed"])
        self.assertIn("not allowed", out["results"][0]["detail"])


# --------------------------------------------------------------------------- #
# manual / 向后兼容 / 聚合
# --------------------------------------------------------------------------- #


class TestManualAndAggregation(VerifyBase):
    def test_manual_does_not_count_toward_pass(self) -> None:
        seg = {
            "checks": [
                {"type": "manual", "text": "人工确认视觉稿与需求一致"},
                {"type": "file_exists", "path": "deliverable/report.md", "min_bytes": 1},
            ]
        }
        self.write("deliverable/report.md", "ok")
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertTrue(out["manual"])
        self.assertEqual(out["results"][0]["state"], "manual")
        self.assertEqual(out["results"][0]["detail"], "人工确认视觉稿与需求一致")

    def test_manual_alone_never_passes(self) -> None:
        seg = {"checks": [{"type": "manual", "text": "人工确认"}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertTrue(out["manual"])

    def test_forged_self_report_cannot_pass(self) -> None:
        """伪造自检文本（manual）不能让失败的机器检查通过。"""
        self.write("deliverable/report.md", "short")
        seg = {
            "checks": [
                {"type": "manual", "text": "自检通过：所有测试均通过 ✅"},
                {"type": "file_exists", "path": "deliverable/report.md", "min_bytes": 500},
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertTrue(out["manual"])

    def test_legacy_acceptance_string_becomes_manual(self) -> None:
        seg = {"acceptance": "人工确认视觉稿与需求一致"}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertTrue(out["manual"])
        self.assertEqual(out["results"][0]["type"], "manual")

    def test_unknown_check_type_fails(self) -> None:
        seg = {"checks": [{"type": "nonsense", "path": "x"}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertIn("unknown check type", out["results"][0]["detail"])

    def test_empty_checks_passes(self) -> None:
        out = run(run_checks({}, self.workdir))
        self.assertTrue(out["passed"])
        self.assertFalse(out["manual"])
        self.assertEqual(out["results"], [])

    def test_audit_callback_receives_record(self) -> None:
        records: list[dict] = []
        seg = {"checks": [{"type": "manual", "text": "x"}]}
        out = run(run_checks(seg, self.workdir, guards={"audit": records.append}))
        self.assertFalse(out["passed"])
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["event"], "verify")
        self.assertEqual(records[0]["by"], "server")

    def test_bad_check_entry_is_isolated(self) -> None:
        seg = {"checks": ["not-a-dict", {"type": "manual", "text": "ok"}]}
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"])
        self.assertEqual(out["results"][0]["state"], "fail")
        self.assertEqual(out["results"][1]["state"], "manual")

    def test_all_five_types_combined(self) -> None:
        self.write("deliverable/report.md", "## 结论\n" + "body\n" * 20)
        self.write("deliverable/result.json", json.dumps({"items": [1]}))
        self.write("deliverable/list.txt", "\n".join(f"i{n}" for n in range(8)))
        seg = {
            "checks": [
                {"type": "command", "cmd": "python3 -c \"print('ok')\"", "timeout": 30},
                {"type": "file_exists", "path": "deliverable/report.md", "min_bytes": 10},
                {
                    "type": "json_schema",
                    "path": "deliverable/result.json",
                    "schema": {"type": "object", "required": ["items"]},
                },
                {"type": "regex", "path": "deliverable/report.md", "pattern": "^## 结论", "flags": "m"},
                {"type": "count", "path": "deliverable/list.txt", "min": 5, "max": 50, "unit": "line"},
                {"type": "manual", "text": "人工确认"},
            ]
        }
        out = run(run_checks(seg, self.workdir))
        self.assertFalse(out["passed"], out)
        self.assertTrue(out["manual"])
        self.assertEqual(len(out["results"]), 6)
        self.assertEqual(
            [r["type"] for r in out["results"]],
            ["command", "file_exists", "json_schema", "regex", "count", "manual"],
        )


if __name__ == "__main__":
    unittest.main()
