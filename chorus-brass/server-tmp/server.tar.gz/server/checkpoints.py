"""Durable checkpoints (SQLite, WAL): every card transition and side effect is recorded before the next step, so a
restarted server resumes where it stopped and never repeats a side effect (idempotency keys)."""
from __future__ import annotations

import json
import sqlite3
import threading
import time


class Checkpoints:
    def __init__(self, path, retention_days=30):
        self.db = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS cards (pid TEXT, id TEXT, data TEXT, at REAL, PRIMARY KEY (pid, id))")
        self.db.execute("CREATE TABLE IF NOT EXISTS effects (key TEXT PRIMARY KEY, result TEXT, at REAL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, pid TEXT, data TEXT, at REAL)")
        self.db.execute("CREATE INDEX IF NOT EXISTS events_at ON events(at)")
        self.lock = threading.Lock()
        self.retention_days = max(1, retention_days)
        self._next_cleanup = 0
        self.cleanup_events()

    def cleanup_events(self, now=None):
        """Events are a replay feed; expired entries age out, cards/effect receipts remain durable."""
        now = time.time() if now is None else now
        with self.lock:
            self.db.execute("DELETE FROM events WHERE at < ?", (now - self.retention_days * 86400,))
            self._next_cleanup = now + 3600

    def save_card(self, pid: str, card: dict):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO cards VALUES (?,?,?,?)", (pid, card["id"], json.dumps(card, ensure_ascii=False), time.time()))

    def cards(self, pid: str) -> dict:
        with self.lock:
            rows = self.db.execute("SELECT id, data FROM cards WHERE pid=?", (pid,)).fetchall()
        return {i: json.loads(d) for i, d in rows}

    def effect(self, key: str):
        """The stored result of an already-performed side effect, or None."""
        with self.lock:
            r = self.db.execute("SELECT result FROM effects WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else None

    def done_effect(self, key: str, result):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO effects VALUES (?,?,?)", (key, json.dumps(result, ensure_ascii=False), time.time()))

    def event(self, pid: str, data: dict):
        if time.time() >= self._next_cleanup:
            self.cleanup_events()
        with self.lock:
            self.db.execute("INSERT INTO events (pid, data, at) VALUES (?,?,?)", (pid, json.dumps(data, ensure_ascii=False), time.time()))

    def events(self, pid: str, after: int = 0, limit: int = 500) -> list:
        with self.lock:
            rows = self.db.execute("SELECT seq, data FROM events WHERE pid=? AND seq>? ORDER BY seq LIMIT ?", (pid, after, limit)).fetchall()
        return [{"seq": s, **json.loads(d)} for s, d in rows]

    def close(self):
        self.db.close()
