"""Daily opt-in reporting. No endpoint means a local sanitized report only."""
import asyncio
import datetime

from aiohttp import ClientSession, ClientTimeout

import os

from telemetry import build_daily_report, sanitize

# 收集端地址：配置 telemetry_url 优先，其次环境变量 CHORUS_TELEMETRY_URL（install.sh 写入官方收集端），都没有则只保存本地
DEFAULT_URL = os.environ.get("CHORUS_TELEMETRY_URL", "")


async def run_daily(server, now=None):
    """Report the completed previous local day once, including after restart."""
    collab = server.CFG.get("collab")
    if not isinstance(collab, dict) or collab.get("telemetry") is not True:
        return "disabled"
    now = datetime.datetime.now(datetime.timezone.utc).timestamp() if now is None else now
    zone = datetime.timezone(datetime.timedelta(hours=server.CFG.get("tz", 8)))
    date = (datetime.datetime.fromtimestamp(now, zone).date() - datetime.timedelta(days=1)).isoformat()
    state_path = server.DATA / "telemetry_job.json"
    state = server.load(state_path, {})
    if state.get("last_report_date") == date:
        return "already_attempted"
    # RESULTS is the existing bounded completion history; never forward identities/text.
    events = []
    for result in server.RESULTS:
        at = result.get("at")
        if not isinstance(at, (int, float)) or datetime.datetime.fromtimestamp(at, zone).date().isoformat() != date:
            continue
        member = server.member(result.get("member")) or {}
        events.append({"model": member.get("model", "unknown"), "task_type": "reply",
                       "outcome": "pass" if result.get("ok") else None})
    import telemetry_events
    day0 = datetime.datetime.fromisoformat(date).replace(tzinfo=zone).timestamp()
    events += telemetry_events.read(server.DATA, day0, day0 + 86400)
    report, _ = sanitize(build_daily_report(events, str(getattr(server, "VERSION", "brass")),
                                          report_date=date, now=now))
    server.DATA.mkdir(parents=True, exist_ok=True)
    server.save(server.DATA / "telemetry_out.json", report)
    # Persist before awaiting network: concurrent ticks/restarts cannot duplicate attempts.
    server.save(state_path, {"last_report_date": date})
    url = server.CFG.get("telemetry_url") or DEFAULT_URL
    if not isinstance(url, str) or not url.strip():
        return "local_only"
    try:
        async with ClientSession(timeout=ClientTimeout(total=30), trust_env=True) as session:
            async with session.post(url.strip(), json=report, allow_redirects=False) as response:
                if not 200 <= response.status < 300:
                    return "send_failed"
    except Exception:
        # Do not expose endpoint, response body, or credentials in logs.
        return "send_failed"
    await pull_profiles(server, url.strip())
    return "sent"


async def pull_profiles(server, ingest_url):
    """顺手把官方能力分库的新版拉下来（只有比内置的新才会被 profiles.load_defaults 采用）。失败静默。"""
    try:
        import json
        import profiles
        latest = ingest_url.replace("/api/telemetry/ingest", "/api/profiles/latest")
        if latest == ingest_url or not latest.startswith("https://"):
            return  # 能力分库会影响派活，只从 https 拉；明文地址一律不信
        async with ClientSession(timeout=ClientTimeout(total=30), trust_env=True) as session:
            async with session.get(latest, allow_redirects=False) as response:
                if response.status != 200:
                    return
                data = json.loads(await response.text())
        if isinstance(data, dict) and isinstance(data.get("profiles"), list) and data.get("as_of"):
            server.save(server.DATA / "profiles_latest.json", data)
            profiles._cache = None
    except Exception:
        return


async def telemetry_job(server):
    while True:
        try:
            await run_daily(server)
        except Exception as exc:
            print("telemetry_job", type(exc).__name__)
        await asyncio.sleep(60)


async def context(app):
    import server
    task = asyncio.create_task(telemetry_job(server))
    try:
        yield
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
