"""Offline regressions for the 2026-11-01 server medium/low audit."""
import asyncio
import datetime as dt
import json
from pathlib import Path
import stat
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import checkpoints
import concierge
import context
import dm_index
import plugins
import server as s
import chorus2 as c
import task_cards
import telemetry_job
import voice
import workspace_tools
from test_review_fixes import Request


class AuditTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.root = Path(self.enterContext(tempfile.TemporaryDirectory()))
        values = dict(DATA=self.root, CFG={"members": [{"name": "A", "kind": "cli", "cmd": "unused"}],
            "owner": "Ali", "providers": [], "password": "test"},
            PROJECTS=[{"id": "p", "name": "p", "members": ["A"]}, {"id": "q", "name": "q", "members": ["A"]}],
            CHATS={"p": [], "q": []}, PVER={}, VER=0, CHANGED=asyncio.Event(), RESULTS=[],
            ROOTS={}, STOPPED_ROOTS={}, TASKS={}, STATUS={}, TASK_STATUS={}, QUEUED={}, LOCKS={}, RUNNING={})
        for k, v in values.items():
            self.enterContext(patch.object(s, k, v))
        self.enterContext(patch.object(c, "S", s))
        self.enterContext(patch.object(c, "PLANNING", {}))
        for directory in ("chats", "tmp", "memory", "summaries", "skills"):
            (self.root / directory).mkdir()

    async def test_dm_deletion_uses_each_project_cursor(self):
        s.CHATS["p"] = [{"seq": 900, "dm": "A", "who": "A", "text": "old"}]
        s.CHATS["q"] = [{"seq": 1, "dm": "A", "who": "A", "text": "old"}]
        await dm_index.prefs(Request({"hidden": True}, name="A"), s)
        self.assertEqual(s.CFG["dm_prefs"]["A"]["hidden_cursors"], {"p": 900, "q": 1})
        self.assertEqual(dm_index.cards(s, {}), [])
        s.CHATS["q"].append({"seq": 2, "dm": "A", "who": "A", "text": "new"})
        self.assertEqual(dm_index.cards(s, {})[0]["name"], "A")
        await dm_index.prefs(Request({"hidden": False}, name="A"), s)
        self.assertNotIn("hidden_cursors", s.CFG["dm_prefs"]["A"])

    def test_context_pins_and_latest_both_truncated_within_budget(self):
        msgs = [{"seq": 1, "text": "置顶" * 1000, "pinned": True}, {"seq": 2, "text": "最新要求" * 1000}]
        original = json.dumps(msgs)
        out, fallen, used = context.window(msgs, 200, lambda m, short: m["text"])
        self.assertEqual([m["seq"] for m, _ in out], [1, 2])
        self.assertIn("最新要求", out[-1][0]["text"])
        self.assertIn("截断", out[-1][0]["text"])
        self.assertLessEqual(used, 200)
        self.assertEqual(fallen, [])
        self.assertEqual(json.dumps(msgs), original)

    def test_money_skips_people_and_prefers_budget_over_incidental_price(self):
        for text, expected in [("2个人用，预算100元", (100, "¥")), ("2 people, budget $30", (30, "$")),
                               ("2个人，花费3元，预算100元", (100, "¥")), ("2个人，上限50", (50, "¥")),
                               ("2个人用，100美元", (100, "$")), ("2个人用", None)]:
            with self.subTest(text=text):
                self.assertEqual(concierge.money_in(text), expected)

    def intent(self):
        plan = {"name": "new", "brief": "brief", "members": ["A"], "lead": "A", "mode": "concerto", "budget": {"cap": 10, "cur": "¥"}}
        s.CFG["intents"] = {"i": {"id": "i", "pid": "p", "member": "A", "stage": "card", "plan": plan}}
        return concierge.Concierge(s, c)

    async def test_confirm_returns_202_persists_and_retries_same_project(self):
        cg = self.intent()
        gate = asyncio.Event()
        async def plan(pid, brief):
            await gate.wait()
            raise RuntimeError("upstream")
        with patch.object(s, "CONCIERGE", cg), patch.object(c, "plan", plan), patch.object(c, "start"):
            req = Request({}, id="i", op="confirm")
            req.can_read_body = True
            response = await asyncio.wait_for(s.h_intent(req), 1)
            self.assertEqual(response.status, 202)
            pid = json.loads(response.body)["project"]
            task = c.PLANNING[pid]
            self.assertEqual(s.load(s.DATA / "projects.json", [])[-1]["planning"], "queued")
            self.assertEqual(s.load(s.cfg_path(), {})["intents"]["i"]["project"], pid)
            self.assertEqual(await cg.confirm("i"), pid)
            self.assertIs(c.PLANNING[pid], task)
            gate.set()
            with self.assertRaises(RuntimeError):
                await task
            self.assertEqual(s.project(pid)["planning"], "failed")
            with patch.object(c, "plan", AsyncMock(return_value=["segment"])), patch.object(c, "start") as start:
                self.assertEqual(await cg.confirm("i"), pid)
                await c.PLANNING[pid]
                start.assert_called_once_with(pid)
            self.assertEqual(len(s.PROJECTS), 3)

    async def test_queued_planning_resumes_on_lifecycle_start(self):
        s.PROJECTS[0].update(planning="queued", planning_brief="saved brief")
        app = s.make_app()
        bg_factory = next(ctx for ctx in app.cleanup_ctx if ctx.__module__ == "chorus2")
        bg = bg_factory(app)
        with patch.object(c, "queue_plan") as queue:
            await anext(bg)
            queue.assert_called_once_with("p", "saved brief")
            with self.assertRaises(StopAsyncIteration):
                await anext(bg)

    async def test_voice_cancellation_only_stops_its_round(self):
        gate = asyncio.Event()
        other = asyncio.create_task(gate.wait())
        self.addAsyncCleanup(self.cancel, other)
        s.ROOTS["other"] = {"pid": "q", "budget": {}, "tasks": {other: "A"}}
        ws = SimpleNamespace(closed=False, send_str=AsyncMock())
        started, cancelled = asyncio.Event(), asyncio.Event()
        async def send(pid, name, trig, text):
            try:
                started.set()
                await gate.wait()
            finally:
                cancelled.set()
        with patch.object(s, "voice_asr", AsyncMock(return_value="hi")), patch.object(s, "stop_member", AsyncMock()) as stop:
            turn = voice.Turn(s, ws, "p", "A", send, poll=0.001)
            job = asyncio.create_task(turn.run(b"audio", "wav"))
            await started.wait()
            job.cancel()
            await asyncio.gather(job, return_exceptions=True)
            self.assertTrue(cancelled.is_set())
            self.assertFalse(other.done())
            self.assertIn("p:1", s.STOPPED_ROOTS)
            stop.assert_not_called()

    @staticmethod
    async def cancel(task):
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)

    async def test_voice_cancellation_reaps_cli_owned_process(self):
        proc = MagicMock(pid=1234, returncode=None)
        proc.stdin.drain = AsyncMock()
        proc.stdout = asyncio.StreamReader()
        proc.stderr = asyncio.StreamReader()
        async def wait():
            await asyncio.Event().wait()
        proc.wait = wait
        entered = asyncio.Event()
        async def create(*args, **kwargs):
            entered.set()
            return proc
        with patch.object(s.asyncio, "create_subprocess_shell", create), patch.object(s, "kill_process_group", AsyncMock()) as kill:
            task = asyncio.create_task(s.call_cli("p", {"cmd": "fake", "name": "A"}, {"who": "A"}, "", "", "", ""))
            await entered.wait()
            await asyncio.sleep(0)
            await self.cancel(task)
            kill.assert_awaited_once_with(proc)

    async def test_asr_retries_with_fresh_body_and_short_deadlines(self):
        response = MagicMock(status=200)
        response.__aenter__ = AsyncMock(return_value=response)
        response.__aexit__ = AsyncMock(return_value=False)
        response.json = AsyncMock(return_value={"text": " heard "})
        session = MagicMock()
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=False)
        session.post.side_effect = [TimeoutError(), response]
        with patch.object(s, "provider", return_value={"key": "test", "base": "https://invalid"}), \
             patch.object(voice, "ClientSession", return_value=session) as client:
            self.assertEqual(await voice.asr(s, b"data"), "heard")
        self.assertEqual(session.post.call_count, 2)
        self.assertIsNot(session.post.call_args_list[0].kwargs["data"], session.post.call_args_list[1].kwargs["data"])
        self.assertTrue(all(call.kwargs["timeout"].total <= 4 for call in client.call_args_list))

    async def test_asr_cancellation_never_retries(self):
        session = MagicMock()
        session.__aenter__ = AsyncMock(side_effect=asyncio.CancelledError)
        session.__aexit__ = AsyncMock(return_value=False)
        with patch.object(s, "provider", return_value={"key": "test", "base": "https://invalid"}), \
             patch.object(voice, "ClientSession", return_value=session) as client:
            with self.assertRaises(asyncio.CancelledError):
                await voice.asr(s, b"data")
        self.assertEqual(client.call_count, 1)

    async def test_plugin_cancel_reaps_group_before_removing_files(self):
        pl = plugins.Plugins(s)
        proc = MagicMock(pid=1234)
        started, reaped = asyncio.Event(), asyncio.Event()
        async def communicate():
            started.set()
            await asyncio.Event().wait()
        proc.communicate = communicate
        async def kill(p):
            self.assertIs(p, proc)
            self.assertTrue(pl.dir("tts_edge").exists())
            with self.assertRaises(ValueError):
                pl.install("tts_edge")
            reaped.set()
        with patch.object(plugins.asyncio, "create_subprocess_exec", AsyncMock(return_value=proc)) as spawn, \
             patch.object(s, "kill_process_group", kill):
            pl.jobs["tts_edge"] = asyncio.create_task(pl._run(["pip", "fake"], pl.dir("tts_edge")))
            await started.wait()
            await pl.uninstall("tts_edge")
            self.assertTrue(reaped.is_set())
            self.assertFalse(pl.dir("tts_edge").exists())
            self.assertTrue(spawn.call_args.kwargs["start_new_session"])

    def test_workspace_replacement_preserves_executable_and_private_modes(self):
        root = self.root / "copy"
        root.mkdir()
        with patch.object(workspace_tools, "ALLOWED_ROOT", self.root):
            work = workspace_tools.Workspace({"enabled": True, "root": str(root), "writable": True})
            for mode in (0o755, 0o640, 0o700):
                path = root / "script"
                path.write_text("before")
                path.chmod(mode)
                _, digest = work.read("script")
                result = work.write("script", "after", digest)
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), mode)
                self.assertEqual((result["mode_before"], result["mode_after"]), (mode, mode))
                changes = work.review_diff()["changes"]
                self.assertEqual(changes[0]["mode_after"], mode)

    async def test_telemetry_previous_day_in_local_timezone_and_dedup(self):
        s.CFG.update(tz=8, collab={"telemetry": True})
        now = dt.datetime(2026, 11, 2, 16, tzinfo=dt.timezone.utc).timestamp()
        s.RESULTS = [{"at": now - 1, "member": "A", "ok": True}, {"at": now, "member": "A", "ok": False},
                     {"at": now - 86401, "member": "A", "ok": False}]
        self.assertEqual(await telemetry_job.run_daily(s, now), "local_only")
        report = s.load(s.DATA / "telemetry_out.json", {})
        self.assertEqual(s.load(s.DATA / "telemetry_job.json", {})["last_report_date"], "2026-11-02")
        self.assertEqual(report["stats"][0]["passed"], 1)
        self.assertEqual(report["stats"][0]["redo"], 0)
        self.assertEqual(await telemetry_job.run_daily(s, now + 3600), "already_attempted")

    async def test_task_audit_separate_bounded_paginated_and_migrates(self):
        cards = task_cards.TaskCards(s)
        data = {"items": [], "proposals": [], "audit": [
            {"action": "old", "at": 0}, *[{"action": str(n), "at": __import__('time').time()} for n in range(1100)]]}
        cards.write("p", data)
        self.assertNotIn("audit", s.load(cards.path("p"), {}))
        rows = s.load(cards.audit_path("p"), [])
        self.assertEqual(len(rows), 1000)
        self.assertEqual(len(cards.read_audit("p", 0, 10000)), 100)
        self.assertEqual(cards.read_audit("p", 100, 1)[0]["action"], "200")
        self.assertEqual(cards.read("p"), {"items": [], "proposals": []})
        # Legacy embedded history is drained on read, and replayed drains don't duplicate it.
        legacy = {"items": [], "proposals": [], "audit": [rows[-1]]}
        s.save(cards.path("p"), legacy)
        cards.read("p")
        self.assertEqual(len(s.load(cards.audit_path("p"), [])), 1000)

    async def test_task_audit_outbox_survives_failed_drain(self):
        cards = task_cards.TaskCards(s)
        save = s.save
        def fail(path, value):
            if path == cards.audit_path("p"):
                raise OSError("disk")
            save(path, value)
        with patch.object(s, "save", fail):
            with self.assertRaises(OSError):
                cards.write("p", {"items": [], "proposals": [], "audit": [{"at": __import__('time').time(), "action": "create"}]})
        self.assertEqual(len(s.load(cards.path("p"), {})["audit"]), 1)
        cards.read("p")
        self.assertEqual(len(cards.read_audit("p")), 1)
        self.assertNotIn("audit", s.load(cards.path("p"), {}))

    def test_checkpoint_retention_on_start_and_periodic_append(self):
        path = self.root / "checkpoints.db"
        cp = checkpoints.Checkpoints(path, retention_days=30)
        now = __import__('time').time()
        cp.db.execute("INSERT INTO events(pid,data,at) VALUES ('p','{}',?)", (now - 31 * 86400,))
        cp.db.execute("INSERT INTO events(pid,data,at) VALUES ('p','{}',?)", (now - 86400,))
        cp.save_card("p", {"id": "keep"})
        cp.done_effect("keep", {"ok": True})
        cp.close()
        cp = checkpoints.Checkpoints(path)
        self.addCleanup(cp.close)
        self.assertEqual(len(cp.events("p")), 1)
        cp.db.execute("INSERT INTO events(pid,data,at) VALUES ('p','{}',?)", (now - 40 * 86400,))
        cp._next_cleanup = 0
        cp.event("p", {"new": True})
        self.assertEqual(len(cp.events("p")), 2)
        self.assertIn("keep", cp.cards("p"))
        self.assertEqual(cp.effect("keep"), {"ok": True})

    def test_installer_python_and_venv_ownership_preserve_existing_fixes(self):
        script = (Path(__file__).parent / "deploy/install.sh").read_text()
        self.assertIn('sys.version_info < (3, 10)', script)
        self.assertIn('chown -R chorus:chorus /opt/chorus2/venv', script)
        self.assertLess(script.index('chown -R root:root /opt/chorus2'), script.index('chown -R chorus:chorus /opt/chorus2/venv'))
        self.assertNotIn('. "$ENV"', script)
        self.assertIn('grep -m1 "^AICHAT_PASSWORD="', script)

    async def test_confirmation_recovers_project_after_config_write_failure(self):
        cg = self.intent()
        old_intent = json.loads(json.dumps(s.CFG["intents"]["i"]))
        with patch.object(s, "save_cfg", side_effect=OSError("disk")):
            with self.assertRaises(OSError):
                await cg.confirm("i")
        self.assertEqual(len(s.PROJECTS), 3)
        pid = s.PROJECTS[-1]["id"]
        s.CFG["intents"]["i"] = old_intent
        with patch.object(c, "plan", AsyncMock(return_value=[])):
            self.assertEqual(await concierge.Concierge(s, c).confirm("i"), pid)
            await c.PLANNING[pid]
        self.assertEqual(len(s.PROJECTS), 3)

    async def test_voice_cancels_followup_even_after_initial_job_finished(self):
        ws = SimpleNamespace(closed=False, send_str=AsyncMock())
        started = asyncio.Event()
        async def send(*args):
            return
        async def speak(trig, job):
            await job
            started.set()
            await asyncio.Event().wait()
        with patch.object(s, "voice_asr", AsyncMock(return_value="hi")), patch.object(s, "stop_round", AsyncMock()) as stop:
            turn = voice.Turn(s, ws, "p", "A", send)
            turn.speak_reply = speak
            job = asyncio.create_task(turn.run(b"audio", "wav"))
            await started.wait()
            await self.cancel(job)
            stop.assert_awaited_once_with("p", "p:1")

    async def test_real_plugin_process_group_descendant_is_terminated(self):
        import sys
        pidfile = self.root / "child.pid"
        code = ('import subprocess,time,pathlib; '
                'p=subprocess.Popen(["sleep","60"]); '
                f'pathlib.Path({str(pidfile)!r}).write_text(str(p.pid)); time.sleep(60)')
        real_spawn = asyncio.create_subprocess_exec
        spawned = []
        async def spawn(*args, **kwargs):
            proc = await real_spawn(sys.executable, "-c", code, **kwargs)
            spawned.append(proc)
            return proc
        pl = plugins.Plugins(s)
        with patch.object(plugins.asyncio, "create_subprocess_exec", spawn):
            task = asyncio.create_task(pl._run(["pip", "unused"], self.root / "plugin"))
            self.addAsyncCleanup(self.cancel, task)
            async with asyncio.timeout(3):
                while not pidfile.exists():
                    await asyncio.sleep(0.01)
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        self.assertIsNotNone(spawned[0].returncode)
        child = int(pidfile.read_text())
        async with asyncio.timeout(3):
            while True:
                try:
                    state = Path(f"/proc/{child}/stat").read_text().split(') ', 1)[1].split()[0]
                except FileNotFoundError:
                    break
                if state == "Z":  # init owns the already terminated orphan's final reap
                    break
                await asyncio.sleep(0.01)
