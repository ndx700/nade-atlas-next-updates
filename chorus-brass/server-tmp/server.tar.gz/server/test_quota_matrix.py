"""主人 11-02：国内外所有主流模型、所有接入方式（API、中转站、各家 CLI、DSH），额度都要有数，不能显示「额度未知」。
没有官方余额接口的，也要显示已花多少 / 今日次数，并标出来源（官方 / 估算）。这里不联网：官方接口全部失败时的兜底也必须有数。"""
import asyncio
import unittest

import quota_probes as qp

API = {   # 厂商: (base, 期望的探测器)
    "OpenAI": ("https://api.openai.com/v1", "openai"),
    "Anthropic": ("https://api.anthropic.com", "anthropic"),
    "Gemini API": ("https://generativelanguage.googleapis.com/v1beta/openai", "gemini"),
    "xAI Grok": ("https://api.x.ai/v1", "xai"),
    "Mistral": ("https://api.mistral.ai/v1", "relay"),
    "Groq": ("https://api.groq.com/openai/v1", "relay"),
    "OpenRouter": ("https://openrouter.ai/api/v1", "openrouter"),
    "DeepSeek": ("https://api.deepseek.com", "deepseek"),
    "Kimi": ("https://api.moonshot.cn/v1", "moonshot"),
    "Kimi Coding": ("https://api.kimi.com/coding/v1", "kimi_coding"),
    "智谱 GLM": ("https://open.bigmodel.cn/api/paas/v4", "glm"),
    "智谱 Coding 套餐": ("https://open.bigmodel.cn/api/coding/paas/v4", "glm"),
    "MiniMax": ("https://api.minimaxi.com/v1", "minimax"),
    "MiMo 按量": ("https://api.xiaomimimo.com/v1", "mimo_payg"),
    "MiMo 套餐": ("https://token-plan-cn.xiaomimimo.com/v1", "mimo_plan"),
    "通义千问 百炼": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "dashscope"),
    "豆包 火山方舟": ("https://ark.cn-beijing.volces.com/api/v3", "volcengine"),
    "混元": ("https://api.hunyuan.cloud.tencent.com/v1", "hunyuan"),
    "百川": ("https://api.baichuan-ai.com/v1", "baichuan"),
    "阶跃星辰": ("https://api.stepfun.com/v1", "stepfun"),
    "硅基流动": ("https://api.siliconflow.cn/v1", "siliconflow"),
    "零一万物": ("https://api.lingyiwanwu.com/v1", "relay"),
    "文心 千帆": ("https://qianfan.baidubce.com/v2", "relay"),
    "讯飞星火": ("https://spark-api-open.xf-yun.com/v1", "relay"),
    "中转站 new-api": ("https://relay.example.com/v1", "relay"),
}
CN = {"DeepSeek", "Kimi", "Kimi Coding", "智谱 GLM", "智谱 Coding 套餐", "MiniMax", "MiMo 按量", "MiMo 套餐", "通义千问 百炼",
      "豆包 火山方舟", "混元", "百川", "阶跃星辰", "硅基流动", "零一万物", "文心 千帆", "讯飞星火"}
CLI = {"Codex CLI": {"cli": "codex"}, "Claude Code": {"cli": "claude", "cmd": "claude -p"}, "Gemini CLI": {"cli": "gemini", "cmd": "gemini -p"},
       "Qwen Code": {"cli": "qwen", "cmd": "qwen -p"}, "Antigravity": {"cli": "agy", "cmd": "agy"}, "DSH": {"kind": "dsh", "cmd": "dsh --profile headless"}}


class Ctx:
    session = None            # 不联网：官方接口全部失败
    def __init__(self, spent=1.25, calls=7):
        self.spent, self.calls = spent, calls
    def now(self): return 1000.0
    def last_headers(self, n): return None
    def last_error(self, n): return None
    def spent_tokens(self, n): return 12345
    def spent_money(self, pid, cur): return self.spent
    def read_file(self, p): return None
    def cmd_json(self, m): return None
    def calls_today(self, n): return self.calls


def run(coro):
    return asyncio.run(coro)


class Matrix(unittest.TestCase):
    def test_every_api_vendor_has_a_number(self):
        for name, (base, want) in API.items():
            with self.subTest(name):
                pr = {"id": name, "base": base, "key": "sk-test"}
                self.assertEqual(qp.detect(pr), want)
                q = run(qp.probe(pr, {"name": name, "kind": "api", "provider": name}, Ctx()))
                self.assertNotEqual(q["short"], "额度未知", q)
                self.assertNotEqual(q["source"], "unknown", q)
                self.assertTrue(q["short"])
                cur = "¥" if name in CN else "$"
                if q["kind"] == "spend":
                    self.assertIn(cur, q["short"], q)   # 币种跟厂商走

    def test_every_cli_has_a_number(self):
        for name, extra in CLI.items():
            with self.subTest(name):
                m = {"name": name, "kind": "cli", **extra}
                q = run(qp.probe({"kind": "cli", **extra}, m, Ctx()))
                self.assertNotEqual(q["short"], "额度未知", q)
                self.assertIn("今日 7 次", q["short"])

    def test_cli_window_when_tool_reports(self):
        class C(Ctx):
            def cmd_json(self, m): return {"pct": 64.0, "reset": "2026-11-02T15:00:00+00:00", "week": 80.0}
        q = run(qp.probe({"kind": "cli", "cli": "claude"}, {"name": "c", "kind": "cli", "cli": "claude"}, C()))
        self.assertEqual((q["pct"], q["week"], q["source"]), (64.0, 80.0, "official"))

    def test_dsh_balance_from_connector(self):
        class C(Ctx):
            def cmd_json(self, m): return {"balance": 23.5, "cur": "¥"}
        q = run(qp.probe({}, {"name": "d", "kind": "dsh"}, C()))
        self.assertEqual(q["accounts"], [{"cur": "¥", "amount": 23.5}])

    def test_plan_exhausted_shows_used_up(self):
        for base in ("https://token-plan-cn.xiaomimimo.com/v1", "https://open.bigmodel.cn/api/coding/paas/v4"):
            with self.subTest(base):
                class C(Ctx):
                    def last_error(self, n): return {"status": 429, "body": '{"error":{"message":"quota exhausted"}}', "at": 999.0}
                q = run(qp.probe({"base": base, "key": "tp-x"}, {"name": "m", "kind": "api"}, C()))
                self.assertEqual((q["state"], q["short"]), ("arrears", "本期用完"))

    def test_wallet_wins_over_spend_only(self):
        pr = {"id": "o", "base": "https://api.openai.com/v1", "key": "sk", "wallet": {"amount": 10, "cur": "$", "spent0": 0}}
        q = run(qp.probe(pr, {"name": "o", "kind": "api"}, Ctx(spent=2.5)))
        self.assertEqual(q["accounts"], [{"cur": "$", "amount": 7.5}])


if __name__ == "__main__":
    unittest.main()
