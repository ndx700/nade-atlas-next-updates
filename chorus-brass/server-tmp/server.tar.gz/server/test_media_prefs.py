import subprocess
import unittest

import server as s
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

import dm_index
from test_chorus2 import Base as _B


class Base(_B):
    """chorus2 test harness plus the server.py routes under test."""
    async def asyncSetUp(self):
        await super().asyncSetUp()
        app = web.Application(middlewares=[s.auth])
        app.router.add_get("/files/{name}", s.h_file)
        app.router.add_get("/files/{name}/{kind}", s.h_file_derived)
        app.router.add_post("/api/projects/read_all", s.h_read_all)
        app.router.add_patch("/api/projects/{pid}", s.h_edit_project)
        app.router.add_put("/api/dms/{name}", lambda q: dm_index.prefs(q, s))
        self.client = TestClient(TestServer(app))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)


class TestMedia(Base):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        (s.DATA / "files").mkdir(parents=True, exist_ok=True)
        self.f = s.DATA / "files" / "a.bin"
        self.f.write_bytes(bytes(range(256)) * 40)

    async def test_range_206_and_seek(self):
        r = await self.client.get("/files/a.bin", headers={**self.h, "Range": "bytes=100-199"})
        self.assertEqual(r.status, 206)
        self.assertEqual(r.headers["Content-Range"], f"bytes 100-199/{256 * 40}")
        self.assertEqual(await r.read(), (bytes(range(256)) * 40)[100:200])
        r = await self.client.get("/files/a.bin", headers={**self.h, "Range": "bytes=10000-"})
        self.assertEqual(r.status, 206)
        self.assertEqual(len(await r.read()), 256 * 40 - 10000)
        r = await self.client.get("/files/a.bin", headers=self.h)
        self.assertEqual((r.status, r.headers["Accept-Ranges"]), (200, "bytes"))
        self.assertEqual((await self.client.get("/files/..%2Fconfig.json", headers=self.h)).status, 404)

    @unittest.skipUnless(subprocess.run(["which", "ffmpeg"], capture_output=True).returncode == 0, "ffmpeg")
    async def test_thumb_and_peaks(self):
        v = s.DATA / "files" / "v.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=d=2:s=160x120", "-f", "lavfi",
                        "-i", "sine=d=2", "-shortest", "-pix_fmt", "yuv420p", str(v)], check=True, timeout=60)
        r = await self.client.get("/files/v.mp4/thumb", headers=self.h)
        self.assertEqual(r.status, 200)
        self.assertTrue((await r.read())[:2] == b"\xff\xd8")
        j = await (await self.client.get("/files/v.mp4/peaks", headers=self.h)).json()
        self.assertEqual(len(j["peaks"]), 200)
        self.assertGreater(max(j["peaks"]), 0.1)
        self.assertEqual((await self.client.get("/files/a.bin/peaks", headers=self.h)).status, 404)
        self.assertEqual((await self.client.get("/files/v.mp4/evil", headers=self.h)).status, 404)


class TestListPrefs(Base):
    async def test_project_pin_mute_read_unread_rename(self):
        pid = self.P()["id"]
        r = await self.client.patch(f"/api/projects/{pid}", headers=self.h, json={"pinned": True, "muted": True, "unread": True})
        self.assertEqual(r.status, 200)
        self.assertTrue(self.P()["pinned"] and self.P()["muted"] and self.P()["manual_unread"])
        idx = s.index_view()["projects"][0]
        self.assertTrue(idx["pinned"] and idx["manual_unread"])
        await self.client.post("/api/projects/read_all", headers=self.h, json={})
        self.assertFalse(self.P()["manual_unread"])
        self.assertGreater(self.P()["read_at"], 0)
        self.assertEqual((await self.client.patch(f"/api/projects/{pid}", headers=self.h, json={"name": "  "})).status, 400)

    async def test_dm_delete_undo_pin(self):
        pid = self.P()["id"]
        s.add_msg(pid, "甲", "私信内容", "甲")
        dms = lambda: [d["name"] for d in __import__("dm_index").cards(s, {})]
        self.assertIn("甲", dms())
        await self.client.put("/api/dms/甲", headers=self.h, json={"hidden": True})
        self.assertNotIn("甲", dms())
        await self.client.put("/api/dms/甲", headers=self.h, json={"hidden": False, "pinned": True})
        self.assertIn("甲", dms())
        s.CFG["dm_prefs"]["甲"]["hidden_seq"] = 0
        await self.client.put("/api/dms/甲", headers=self.h, json={"hidden": True})
        s.add_msg(pid, "甲", "新消息", "甲")
        self.assertIn("甲", dms())                        # a newer message brings a deleted thread back
        self.assertEqual((await self.client.put("/api/dms/无人", headers=self.h, json={"hidden": True})).status, 404)
