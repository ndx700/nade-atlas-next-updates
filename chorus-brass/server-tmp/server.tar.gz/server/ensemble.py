"""Ensemble engine: runs a 乐章's cards through member adapters with a shared git workspace.

  card -> per-card branch + worktree -> handoff packet -> adapter.run (steps streamed, every tool request gated)
       -> server checks (artifacts exist, optional test command) -> 指挥 review -> merge into main (or rework).

Progress is computed only from server-observed state: card states todo/doing/review/passed weighted by estimated
effort, plus a heartbeat per running card (no event beyond its expected time -> 'maybe stuck' -> retry/reassign).
"""
from __future__ import annotations

import asyncio
import background
import hashlib
import json
import os
import pathlib
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Optional

import adapters as A

BREAKER_BUSY = "circuit breaker unavailable"

STATES = ("todo", "doing", "review", "passed", "blocked")
A2A = {"todo": "submitted", "doing": "working", "review": "working", "waiting": "input-required",
       "passed": "completed", "blocked": "failed", "canceled": "canceled"}   # A2A task states, for interop/export
STATE_WEIGHT = {"todo": 0.0, "doing": 0.5, "review": 0.85, "passed": 1.0, "blocked": 0.0}


# ---------------------------------------------------------------- shared workspace (git)
async def git(cwd, *args, check=True):
    spawn = asyncio.create_task(asyncio.create_subprocess_exec(
        "git", *args, cwd=str(cwd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE))
    p = None
    try:
        p = await asyncio.shield(spawn)
        out, err = await p.communicate()
    except asyncio.CancelledError:
        if p is None:
            p = await spawn  # cancellation can arrive before the child transport is returned
        if p.returncode is None:
            try:
                p.kill()
            except ProcessLookupError:
                pass
        await p.communicate()
        raise
    if check and p.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {err.decode(errors='replace').strip()[:300]}")
    return p.returncode, out.decode(errors="replace")


AGENTS_MD = """# AGENTS.md — 本乐章所有成员共同遵守（Claude Code / Codex / Gemini CLI 都会读这个文件）
- 只在自己的工作目录（本卡的 worktree）里改文件；不要碰 main，不要 push，不要改 git 配置。
- 每张卡只做卡上写的事；需要别人时写 @名字 和要什么。
- 交付前自己跑一遍测试；最后用 [产物] … [/产物] 每行一个路径列出交付文件。
- 删除、联网下载执行、提权、对外发送、花钱等动作会弹同意卡，等结果，不要绕过。
- 不要在代码或日志里写入任何密钥。
"""


class Workspace:
    """One repo per 乐章; each card works on branch card/<id> in its own worktree; merge after review."""

    def __init__(self, root: pathlib.Path):
        self.root = pathlib.Path(root)
        self.repo = self.root / "main"
        self.trees = self.root / "trees"
        self.agents_md = AGENTS_MD
        self.lock = asyncio.Lock()   # git on main (worktree add, merge) is serialised; cards still work in parallel

    async def init(self, seed=None):
        if (self.repo / ".git").exists():
            return
        self.repo.mkdir(parents=True, exist_ok=True)
        self.trees.mkdir(parents=True, exist_ok=True)
        await git(self.repo, "init", "-q", "-b", "main")
        await git(self.repo, "config", "commit.gpgsign", "false")
        await git(self.repo, "config", "user.name", "Chorus")
        await git(self.repo, "config", "user.email", "chorus@localhost")
        if seed is not None:
            import shutil
            seed = pathlib.Path(seed).resolve()
            for source in seed.rglob("*"):
                relative = source.relative_to(seed)
                if relative.parts[0] == self.root.name or ".git" in relative.parts:
                    continue
                if source.is_symlink() or not source.is_file() or not source.resolve().is_relative_to(seed):
                    continue
                destination = self.repo / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
        (self.repo / "AGENTS.md").write_text(self.agents_md, encoding="utf-8")
        await git(self.repo, "add", "-A")
        await git(self.repo, "commit", "-q", "-m", "乐章开始（AGENTS.md）")

    async def tree_for(self, card_id: str) -> pathlib.Path:
        if not card_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in card_id):
            raise ValueError("invalid card id")
        t = self.trees / card_id
        async with self.lock:
            if not t.exists():
                await git(self.repo, "worktree", "add", "-q", "-B", f"card/{card_id}", str(t), "main")
        return t

    async def commit(self, card_id: str, msg: str) -> bool:
        t = await self.tree_for(card_id)
        await git(t, "add", "-A")
        code, _ = await git(t, "diff", "--cached", "--quiet", check=False)
        if code == 0:
            return False
        await git(t, "-c", "user.name=Chorus", "-c", "user.email=chorus@localhost", "commit", "-q", "-m", msg)
        return True

    async def diff(self, card_id: str) -> str:
        _, out = await git(self.repo, "diff", "--stat", f"main...card/{card_id}", check=False)
        return out.strip()

    async def merge(self, card_id: str) -> tuple[bool, str]:
        async with self.lock:
            code, out = await git(self.repo, "merge", "--no-ff", "-q", "-m", f"合并 {card_id}", f"card/{card_id}", check=False)
            if code != 0:
                await git(self.repo, "merge", "--abort", check=False)
            # either way the card's tree is done: on conflict the rework starts from the latest main (-B resets the branch)
            await git(self.repo, "worktree", "remove", "--force", str(self.trees / card_id), check=False)
            return (True, "") if code == 0 else (False, out.strip()[:300] or "合并冲突")

    async def discard(self, card_id: str):
        """Remove a finished race candidate's worktree and temporary branch."""
        async with self.lock:
            await git(self.repo, "worktree", "remove", "--force", str(self.trees / card_id), check=False)
            await git(self.repo, "branch", "-D", f"card/{card_id}", check=False)

    def files(self, limit=40) -> list[str]:
        out = []
        for p in sorted(self.repo.rglob("*")):
            if ".git" in p.parts or not p.is_file():
                continue
            out.append(str(p.relative_to(self.repo)))
            if len(out) >= limit:
                break
        return out


# ---------------------------------------------------------------- handoff packet
def packet(card: dict, project: dict, done: dict, files: list[str], read: Callable[[str], str], assets: list[str],
           notes: list[str], budget_chars: int = 24000) -> str:
    """Everything one member needs for one card — built by the server, trimmed by rules, never a chat replay."""
    rules = read("AGENTS.md")
    parts = ([f"共同约定（AGENTS.md）：\n{rules[:1500]}"] if rules else []) + [f"# 任务卡 {card['id']}：{card['title']}", f"目标：{card.get('goal', '')}", f"交付：{card.get('deliverable', '')}",
             "验收：\n" + "\n".join(f"- {a}" for a in card.get("acceptance", [])), f"乐章需求：{project.get('brief', '')[:1200]}"]
    if card.get("checks") is not None:
        parts.append("服务端机器验收规则：\n" + json.dumps(card["checks"], ensure_ascii=False))
    ups = [done[i] for i in card.get("inputs", []) if i in done]
    if ups:
        parts.append("上游产物：\n" + "\n".join(f"- {u['id']} {u['title']}：{u.get('summary', '')[:300]}；文件 {', '.join(u.get('artifacts', [])[:8])}" for u in ups))
    files = [f for f in files if f != "AGENTS.md"]
    rel = [f for f in files if any(a in f or f in a for u in ups for a in u.get("artifacts", []))] or files[:12]
    if rel:
        body = []
        for f in rel[:8]:
            txt = read(f)
            if txt is not None:
                body.append(f"--- {f}\n{txt[:4000]}")
        if body:
            parts.append("相关文件（只读，改动请在你的工作目录里做）：\n" + "\n".join(body))
    if assets:
        parts.append("共享资料（其他成员已代为处理）：\n" + "\n".join(f"- {a}" for a in assets))
    if notes:
        parts.append("审核意见（请逐条处理）：\n" + "\n".join(f"- {n}" for n in notes))
    parts.append("完成后在最后用 [产物] 每行一个文件路径 [/产物] 列出交付文件。需要别的成员时用 @名字 说明要什么。")
    text = "\n\n".join(parts)
    return text if len(text) <= budget_chars else text[:budget_chars - 40] + "\n…（已按规则截断）"


# ---------------------------------------------------------------- progress (server-observed only)
def card_pct(card: dict) -> float:
    return STATE_WEIGHT.get(card.get("state", "todo"), 0.0)


def movement_pct(cards: list[dict]) -> float:
    """乐章 % = Σ effort × state weight / Σ effort (effort = estimated difficulty, default 1)."""
    tot = sum(max(0.1, float(c.get("effort", 1))) for c in cards)
    if not tot:
        return 0.0
    return round(100 * sum(max(0.1, float(c.get("effort", 1))) * card_pct(c) for c in cards) / tot, 1)


def project_pct(movements: list[list[dict]]) -> float:
    w = [sum(max(0.1, float(c.get("effort", 1))) for c in m) for m in movements]
    if not sum(w):
        return 0.0
    return round(sum(movement_pct(m) * x for m, x in zip(movements, w)) / sum(w), 1)


class Heartbeat:
    """Last observed event per (card, member). A card is 'maybe stuck' when silent past its expected time."""

    def __init__(self, now=time.time):
        self.now = now
        self.last: dict[str, float] = {}
        self.started: dict[str, float] = {}

    def beat(self, card_id: str):
        t = self.now()
        self.last[card_id] = t
        self.started.setdefault(card_id, t)

    def done(self, card_id: str):
        self.last.pop(card_id, None)
        self.started.pop(card_id, None)

    def stalled(self, eta: dict[str, float], silence: float = 180) -> list[str]:
        """Cards with no event for max(silence, 25% of their ETA) once past their ETA."""
        t = self.now()
        out = []
        for cid, last in self.last.items():
            e = float(eta.get(cid, 600))
            if t - self.started[cid] > e and t - last > max(silence, 0.25 * e):
                out.append(cid)
        return out


# ---------------------------------------------------------------- the engine
@dataclass
class Event:
    pid: str
    kind: str          # step | state | merge | review | stall | wake
    card: str
    member: str
    text: str
    at: float = field(default_factory=time.time)
    pct: float = 0.0


class Breaker:
    """Per-member circuit breaker: `threshold` consecutive failures open it for `cooldown` s; then one trial (half-open)."""

    def __init__(self, threshold=3, cooldown=120.0, now=time.time):
        self.threshold, self.cooldown, self.now = threshold, cooldown, now
        self.fails: dict[str, int] = {}
        self.until: dict[str, float] = {}
        self.probing: set[str] = set()

    def open(self, name) -> bool:
        return name in self.probing or self.until.get(name, 0) > self.now()

    def claim(self, name) -> bool:
        """Only one in-flight trial may use a member after its cooldown."""
        if self.open(name):
            return False
        if name in self.until:
            self.probing.add(name)
        return True

    def fail(self, name) -> bool:
        self.fails[name] = self.fails.get(name, 0) + 1
        if name in self.until or self.fails[name] >= self.threshold:
            self.until[name] = self.now() + self.cooldown
            self.fails[name] = 0
            return True
        return False

    def ok(self, name):
        self.fails.pop(name, None)
        self.until.pop(name, None)


class Ensemble:
    """Runs one 乐章 (cards with dependencies) across adapters. All side effects go through injected callbacks so the
    same engine serves chorus2 (real) and tests (fakes): approve() = red lines + policy, account() = billing,
    publish() = the single WebSocket event stream (chat one-liners, lock-screen card, island, progress page)."""

    def __init__(self, pid: str, project: dict, members: list[dict], make_adapter: Callable[[dict], A.Adapter],
                 ws: Workspace, approve: Callable[[str, str, dict], Awaitable[bool]],
                 account: Callable[[dict, dict, str], None], publish: Callable[[Event], None],
                 price_of: Callable[[dict], Optional[dict]], stats: dict, lead: str,
                 share: Optional[Callable[[dict, dict], Awaitable[list[str]]]] = None,
                 test_cmd: Optional[str] = None, max_rework: int = 2, stall_check: float = 5.0,
                 available: Callable[[dict], bool] = lambda m: True, ckpt=None, card_timeout: Optional[float] = None,
                 breaker: Optional[Breaker] = None, max_restarts: int = 2):
        self.pid, self.project, self.members, self.make = pid, project, members, make_adapter
        self.ws, self.approve, self.account, self.publish = ws, approve, account, publish
        self.price_of, self.stats, self.lead = price_of, stats, lead
        self.share = share
        self.test_cmd, self.max_rework = test_cmd, max_rework
        self.hb = Heartbeat()
        self.stall_check = stall_check
        self.done: dict[str, dict] = {}
        self.running: dict[str, asyncio.Task] = {}
        self.available, self.ckpt, self.card_timeout = available, ckpt, card_timeout
        self.breaker = breaker or Breaker()
        self.max_restarts = max_restarts
        self.restarts: dict[str, int] = {}
        self.errors: deque[str] = deque(maxlen=1000)     # engine-level exceptions caught by the supervisor (logged, never fatal)

    # -- helpers
    def cards(self) -> list[dict]:
        return self.project["cards"]

    def pct(self) -> float:
        return movement_pct(self.cards())

    def emit(self, kind, card, member, text):
        self.publish(Event(self.pid, kind, card, member, text, pct=self.pct()))

    def set_state(self, card, state, why=""):
        card["state"] = state
        card["a2a"] = A2A.get(state, "unknown")
        self.save(card)
        self.emit("state", card["id"], card.get("assignee", ""), f"{card['title']}：{state}" + (f"（{why}）" if why else ""))

    def save(self, card):
        if self.ckpt:
            try:
                self.ckpt.save_card(self.pid, card)
            except Exception as e:  # noqa: BLE001 - a disk hiccup must not kill the card
                self.errors.append(f"checkpoint {card['id']}: {e!r}")

    def metric(self, name, res, secs):
        st = self.stats.setdefault(name, {})
        st["runs"] = st.get("runs", 0) + 1
        st["fails"] = st.get("fails", 0) + (0 if res.ok else 1)
        st["secs"] = round(st.get("secs", 0.0) + secs, 3)
        st["avg_s"] = round(st["secs"] / st["runs"], 3)
        for k in ("in", "out"):
            st[k] = st.get(k, 0) + int((res.usage or {}).get(k, 0) or 0)

    def usable(self, m) -> bool:
        try:
            return not self.breaker.open(m["name"]) and bool(self.available(m))
        except Exception:  # noqa: BLE001
            return False

    def member(self, name):
        return next((m for m in self.members if m["name"] == name), None)

    def choose(self, card, exclude=()) -> Optional[dict]:
        a = self.member(card.get("assignee") or "")
        if a and a["name"] not in exclude and self.usable(a):
            return a
        need = set(card.get("needs", []))
        pool = [m for m in self.members if self.usable(m)]
        workers = [m for m in pool if m["name"] != self.lead] or pool
        return A.pick(workers, need, self.price_of, self.stats, exclude) or A.pick(pool, need, self.price_of, self.stats, exclude)

    async def call(self, ad, pk, on_step, gate, cwd="") -> A.Result:
        """One adapter call, isolated: any exception or timeout becomes a failed Result for this card only."""
        if not self.breaker.claim(ad.name):
            return A.Result(ok=False, error=BREAKER_BUSY)
        probe = ad.name in self.breaker.probing
        async def execute():
            async with background.cwd_lock(cwd):
                return await ad.run(pk, on_step, gate, cwd=cwd)

        try:
            # Queueing is part of the configured call budget too. A stuck cwd
            # owner must not leave a timed call (or a half-open probe) waiting forever.
            if self.card_timeout:
                return await asyncio.wait_for(execute(), self.card_timeout)
            return await execute()
        except asyncio.TimeoutError:
            return A.Result(ok=False, error="timeout")
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001 - adapter crash stays inside this card
            return A.Result(ok=False, error=f"adapter crash: {e!r}"[:300])
        finally:
            if probe:
                self.breaker.probing.discard(ad.name)

    def failover(self) -> Optional[str]:
        """指挥 failed: promote the strongest other usable member (highest pass rate, then price as a proxy)."""
        cands = [m for m in self.members if m["name"] != self.lead and self.usable(m)]
        if not cands:
            return None
        def rank(m):
            pr = self.price_of(m) or {}
            return (self.stats.get(m["name"], {}).get("pass", 0.8), pr.get("out", 0))
        new = max(cands, key=rank)["name"]
        self.emit("handover", "", new, f"指挥 {self.lead} 不可用，{new} 接任指挥（计划与进度已交接）")
        self.lead = new
        return new

    def ready(self):
        return [c for c in self.cards()
                if (c.get("state", "todo") == "todo" or
                    (c.get("state") == "waiting" and c.get("retry_at", 0) <= time.time()
                     and (self.choose(c) if c.get("_execute_pending") else
                          self.reviewer(c.get("assignee", "")))))
                and all(i in self.done for i in c.get("inputs", []))]

    # -- one card
    async def run_card(self, card):
        card.pop("_execute_pending", None)
        tried, busy, notes = set(), set(), list(card.get("notes", []))
        for attempt in range(len(self.members) + self.max_rework + 1):
            m = self.member(card.get("assignee")) if card.get("_review_pending") else self.choose(card, tried | busy)
            if not m:
                self.set_state(card, "blocked", "没有能接手的成员")
                return
            card["assignee"] = m["name"]
            self.set_state(card, "doing")
            pending = card.pop("_review_pending", None)
            if pending:
                res = A.Result(ok=True, **pending)
            else:
                tree = await self.ws.tree_for(card["id"])
                assets = await self.share(card, m) if self.share else []
                pk = packet(card, self.project, self.done, self.ws.files(), lambda f: _read(tree / f), assets, notes)
                ad = self.make(m)

                def on_step(st: A.Step, cid=card["id"]):
                    self.hb.beat(cid)
                    self.emit("step", cid, st.member, f"{st.member} · {st.kind}{(' ' + st.text) if st.text else ''}")

                async def gate(tool, inp, who=m["name"], c=card):
                    c["a2a"] = "input-required"
                    try:
                        return await self.approve(who, tool, inp)
                    finally:
                        c["a2a"] = A2A.get(c.get("state", "doing"), "working")

                self.hb.beat(card["id"])
                t0 = time.time()
                res = await self.call(ad, pk, on_step, gate, cwd=str(tree))
                self.hb.done(card["id"])
                if res.error == BREAKER_BUSY:
                    # Selection precedes worktree/share awaits: another card may
                    # claim the member meanwhile. No adapter execution took place.
                    busy.add(m["name"])
                    if self.choose(card, tried | busy):
                        card["assignee"] = ""
                        continue
                    card["_execute_pending"] = True
                    card["retry_at"] = time.time() + self.breaker.cooldown
                    self.set_state(card, "waiting", "成员暂不可用，等待重试")
                    return
                self.metric(m["name"], res, time.time() - t0)
                if res.ok:
                    self.breaker.ok(m["name"])
                elif res.error != BREAKER_BUSY and self.breaker.fail(m["name"]):
                    self.emit("breaker", card["id"], m["name"], f"{m['name']} 连续失败，暂停派活 {int(self.breaker.cooldown)} 秒")
                if res.ok and ad.kind == "api":  # API members deliver files as === FILE: path === blocks; the server writes them
                    res.artifacts = sorted(set(res.artifacts) | set(await write_files(tree, res.text, gate, on_step, m["name"])))
                if res.usage:
                    self.account(m, res.usage, "execute")
                if not res.ok:
                    tried.add(m["name"])
                    card["assignee"] = ""
                    self.emit("state", card["id"], m["name"], f"{m['name']} 失败：{(res.error or '')[:80]}，换人")
                    continue
                missing = [a for a in res.artifacts if not (tree / a).exists() and not a.startswith(("http://", "https://"))]
                if missing:
                    notes = [f"这些文件不存在：{', '.join(missing)}"]
                    self.emit("review", card["id"], "服务器", notes[0])
                    tried.add(m["name"])            # malformed delivery counts as a failure of this member on this card
                    card["assignee"] = ""
                    self.breaker.fail(m["name"])
                    continue
                if self.test_cmd:
                    p = await asyncio.create_subprocess_shell(self.test_cmd, cwd=str(tree), stdout=asyncio.subprocess.PIPE,
                                                              stderr=asyncio.subprocess.STDOUT)
                    out, _ = await p.communicate()
                    if p.returncode != 0:
                        notes = ["测试没过：" + out.decode(errors="replace")[-600:]]
                        self.emit("review", card["id"], "服务器", "测试没过，返工")
                        continue
                await self.ws.commit(card["id"], f"{card['id']} {card['title']}（{m['name']}）")
            self.set_state(card, "review")
            verdict = await self.review(card, res, await self.ws.diff(card["id"]))
            if verdict is None:
                card["_review_pending"] = {"text": res.text, "artifacts": res.artifacts, "usage": res.usage}
                card["retry_at"] = time.time() + self.breaker.cooldown
                self.set_state(card, "waiting", "审核成员暂不可用，等待重试")
                return
            if not verdict.upper().startswith("PASS"):
                notes = [verdict]
                self.stats.setdefault(m["name"], {})["pass"] = round(0.8 * self.stats.get(m["name"], {}).get("pass", 0.8), 4)
                self.emit("review", card["id"], self.lead, f"返工：{verdict[:80]}")
                if attempt >= self.max_rework:
                    tried.add(m["name"])
                    card["assignee"] = ""
                continue
            if card.get("_candidate"):        # best-of-N candidate: reviewed, the parent picks and merges
                card["_passed_by"], card["summary"], card["artifacts"] = m["name"], res.text[-300:], res.artifacts
                card["_cost"] = sum((res.usage or {}).get(k, 0) * (self.price_of(m) or {}).get(k, 0) for k in ("in", "out"))
                card["state"] = "review"
                return
            card.update(summary=res.text[-300:], artifacts=res.artifacts)
            self.save(card)  # persist delivery before the git/SQLite boundary
            key = f"{self.pid}:merge:{card['id']}"
            if self.ckpt and self.ckpt.effect(key):
                ok, why = True, "already merged"          # idempotent: never merge the same card twice
            else:
                ok, why = await self.ws.merge(card["id"])
                if ok and self.ckpt:
                    self.ckpt.done_effect(key, {"by": m["name"], "summary": card["summary"], "artifacts": card["artifacts"]})
            if not ok:
                notes = [f"合并冲突：{why}，请基于最新 main 重做"]
                self.emit("merge", card["id"], "服务器", "合并冲突，返工")
                continue
            st = self.stats.setdefault(m["name"], {})
            st["pass"] = round(0.8 * st.get("pass", 0.8) + 0.2, 4)
            card["summary"] = res.text[-300:]
            card["artifacts"] = res.artifacts
            self.done[card["id"]] = card
            self.set_state(card, "passed")
            self.emit("merge", card["id"], m["name"], f"已合并 {card['title']}")
            return
        self.set_state(card, "blocked", "试过所有成员")

    def reviewer(self, author: str, exclude=()) -> Optional[dict]:
        """Role split: the 指挥 reviews, except its own work — then the strongest other usable member does."""
        lead = self.member(self.lead)
        if lead and lead["name"] != author and lead["name"] not in exclude and self.usable(lead):
            return lead
        others = [m for m in self.members if m["name"] != author and m["name"] not in exclude and self.usable(m)]
        if not others:
            return None
        return max(others, key=lambda m: (self.stats.get(m["name"], {}).get("pass", 0.8), (self.price_of(m) or {}).get("out", 0)))

    async def review(self, card, res, diff) -> Optional[str]:
        author = card.get("assignee", "")
        lead = self.reviewer(author)
        if not lead:
            return None
        prompt = (f"审核任务卡 {card['id']}「{card['title']}」。\n验收：{card.get('acceptance')}\n改动：\n{diff}\n"
                  f"产物：{res.artifacts}\n摘要：{res.text[-800:]}\n只回答一行：PASS 或 FIX: 原因")
        tried = set()

        async def deny_all(tool, inp):  # a reviewer reads, it never acts
            return False
        for _ in range(len(self.members)):
            r = await self.call(self.make(lead), prompt, lambda st: None, deny_all)
            if r.usage:
                self.account(lead, r.usage, "review")
            if r.ok:
                self.breaker.ok(lead["name"])
                break
            if r.error != BREAKER_BUSY:
                self.breaker.fail(lead["name"])
            tried.add(lead["name"])
            if lead["name"] == self.lead:
                self.failover()
            lead = self.reviewer(author, tried)
            if not lead:
                return None
        else:
            return None
        out = [ln.strip() for ln in r.text.splitlines() if ln.strip().upper().startswith(("PASS", "FIX"))]
        return out[0] if out else "FIX: 审核结论格式不对"

    async def watchdog(self):
        """Stall detection: a silent card past its ETA is cancelled and retried on another member."""
        while True:
            await asyncio.sleep(self.stall_check)
            try:
                self._watch()
            except Exception as e:  # noqa: BLE001
                self.errors.append(f"watchdog: {e!r}")

    def _watch(self):
        if self.cards():
            eta = {c["id"]: float(c.get("eta", 600)) for c in self.cards()}
            for cid in self.hb.stalled(eta, silence=min(180, self.stall_check * 3)):
                t = self.running.get(cid)
                card = next(c for c in self.cards() if c["id"] == cid)
                self.emit("stall", cid, card.get("assignee", ""), f"{card.get('assignee')} 可能卡住了，换人重试")
                self.hb.done(cid)
                if t:
                    t.cancel()

    def resume(self):
        """Restore from checkpoints after a restart: passed cards stay passed, in-flight ones go back to todo."""
        if not self.ckpt:
            return
        saved = self.ckpt.cards(self.pid)
        for c in self.cards():
            old = saved.get(c["id"])
            effect = self.ckpt.effect(f"{self.pid}:merge:{c['id']}")
            if not old and effect is None:
                continue
            old = old or {}
            if old.get("state") == "passed" or effect is not None:
                c.update(old, state="passed", a2a="completed")
                if effect:
                    c.update({k: effect[k] for k in ("summary", "artifacts") if k in effect})
                    if "by" in effect:
                        c["assignee"] = effect["by"]
                self.done[c["id"]] = c
            elif old.get("state") in ("blocked", "waiting"):
                c.update(old)
            else:
                c.update({k: v for k, v in old.items() if k != "state"}, state="todo")

    async def best_of(self, card):
        """best_of=N: N different members try the same card in parallel worktrees; the cheapest PASS is merged."""
        n = max(1, int(card.get("best_of", 1)))
        pool = [m for m in self.members if m["name"] != self.lead and self.usable(m)]
        need = set(card.get("needs", []))
        picks, ex = [], set()
        for _ in range(n):
            m = A.pick(pool, need, self.price_of, self.stats, ex)
            if not m:
                break
            picks.append(m)
            ex.add(m["name"])
        if len(picks) < 2:
            return await self.run_card(card)
        subs = [dict(card, id=f"{card['id']}-bo{i}", assignee=m["name"], _candidate=True, best_of=1) for i, m in enumerate(picks)]
        self.set_state(card, "doing", f"{len(subs)} 位成员同题赛马")
        try:
            await asyncio.gather(*(self._one_candidate(c) for c in subs), return_exceptions=True)
            good = sorted((c for c in subs if c.get("_passed_by")), key=lambda c: c.get("_cost", 0))
            for w in good:
                ok, why = await self.ws.merge(w["id"])
                if ok:
                    card.update(assignee=w["_passed_by"], summary=w["summary"], artifacts=w["artifacts"])
                    if self.ckpt:
                        self.ckpt.done_effect(f"{self.pid}:merge:{card['id']}",
                                              {"by": card["assignee"], "summary": card["summary"], "artifacts": card["artifacts"]})
                    self.done[card["id"]] = card
                    self.set_state(card, "passed")
                    self.emit("merge", card["id"], w["_passed_by"], f"赛马胜出：{w['_passed_by']}（{len(good)}/{len(subs)} 通过）")
                    return
        finally:
            for sub in subs:
                await self.ws.discard(sub["id"])
        card.pop("assignee", None)
        card["best_of"] = 1
        return await self.run_card(card)   # nobody passed: fall back to the normal ladder

    async def _one_candidate(self, c):
        try:
            await asyncio.wait_for(self.run_card(c), self.card_timeout * 3) if self.card_timeout else await self.run_card(c)
        except Exception as e:  # noqa: BLE001
            self.errors.append(f"{c['id']}: {e!r}")

    async def supervised(self, card):
        """Supervisor: an engine bug inside one card is logged and the card restarted (bounded); never fatal."""
        while True:
            try:
                if int(card.get("best_of", 1)) > 1:
                    return await self.best_of(card)
                return await self.run_card(card)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                n = self.restarts[card["id"]] = self.restarts.get(card["id"], 0) + 1
                self.errors.append(f"{card['id']}: {e!r}")
                self.emit("crash", card["id"], card.get("assignee", ""), f"{card['title']} 出错，已重启（第 {n} 次）")
                if n > self.max_restarts:
                    self.set_state(card, "blocked", "反复出错")
                    return
                card["state"] = "todo"

    async def run(self):
        await self.ws.init()
        self.resume()
        dog = background.spawn(self.watchdog())
        try:
            while True:
                busy = set()
                for cid in self.running:
                    busy |= set(next(x for x in self.cards() if x["id"] == cid).get("files", []))
                for c in self.ready():
                    if c["id"] not in self.running:
                        mine = set(c.get("files", []))
                        if mine & busy:          # would touch the same files as a running card: wait, no conflict
                            continue
                        busy |= mine
                        c["state"] = "doing"
                        self.running[c["id"]] = background.spawn(self.supervised(c))
                if not self.running:
                    break
                fin, _ = await asyncio.wait(list(self.running.values()), return_when=asyncio.FIRST_COMPLETED)
                for cid, t in list(self.running.items()):
                    if t not in fin:
                        continue
                    self.running.pop(cid)
                    c = next(x for x in self.cards() if x["id"] == cid)
                    if t.cancelled():   # watchdog: stalled -> trip that member, retry elsewhere
                        bad = c.get("assignee", "")
                        if bad:
                            self.breaker.until[bad] = self.breaker.now() + self.breaker.cooldown   # a hang trips at once
                        c["assignee"], c["state"] = "", "todo"
                        c.setdefault("skip", []).append(bad)
                        self.save(c)
                    elif t.exception():
                        self.errors.append(f"{cid}: {t.exception()!r}")
                        self.set_state(c, "blocked", "出错")
        finally:
            dog.cancel()
            tasks = list(self.running.values())
            for t in tasks:
                t.cancel()
            await asyncio.gather(dog, *tasks, return_exceptions=True)
        self.emit("state", "", "", f"乐章完成 {self.pct()}%")
        return self.pct()


_FILE_RE = __import__("re").compile(r"^=== FILE: (.+?) ===\n(.*?)^=== END ===", __import__("re").M | __import__("re").S)


async def write_files(tree: pathlib.Path, text: str, gate, on_step, who) -> list[str]:
    """Write an API member's file blocks inside its worktree — each write is a gated tool request like any other."""
    out = []
    for path, body in _FILE_RE.findall(text or ""):
        path = path.strip()
        dest = (tree / path).resolve()
        if not str(dest).startswith(str(tree.resolve()) + os.sep):
            on_step(A.Step(who, "error", f"拒绝写到工作区之外：{path}"))
            continue
        if not await gate("Write", {"file_path": str(dest)}):
            on_step(A.Step(who, "permission", f"拒绝 Write {path}"))
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(body)
        on_step(A.Step(who, "edit", path))
        out.append(path)
    return out


def _read(p: pathlib.Path) -> Optional[str]:
    try:
        return p.read_text(errors="replace") if p.is_file() and p.stat().st_size < 200_000 else None
    except OSError:
        return None


def content_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


async def changed_lines(tree):
    """Include new files in the server-observed review risk without committing them."""
    await git(tree, "add", "-N", "--", ".")
    _, output = await git(tree, "diff", "--numstat", "HEAD")
    count = 0
    for line in output.splitlines():
        added, deleted, _ = line.split("\t", 2)
        count += int(added) + int(deleted) if added.isdigit() and deleted.isdigit() else 300
    return count
