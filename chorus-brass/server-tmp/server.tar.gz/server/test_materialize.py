import collab_runtime as cr


def test_heredoc(tmp_path):
    text = "好的\n```bash\ncat > index.html <<'EOF'\n<html>hi</html>\nEOF\n```\n[产物]\nindex.html\n[/产物]"
    assert cr.materialize(tmp_path, text, ["index.html"]) == ["index.html"]
    assert (tmp_path / "index.html").read_text() == "<html>hi</html>\n"
    list(cr.artifact_paths(tmp_path, ["index.html"]))


def test_fence_named_and_single(tmp_path):
    text = "**style.css**\n```css\nbody{}\n```\n```html\n<p>x</p>\n```"
    assert sorted(cr.materialize(tmp_path, text, ["style.css", "index.html"])) == ["style.css"]
    assert cr.materialize(tmp_path, "```html\n<p>x</p>\n```", ["index.html"]) == ["index.html"]


def test_no_overwrite_no_escape(tmp_path):
    (tmp_path / "a.txt").write_text("keep")
    text = "cat > a.txt <<EOF\nnew\nEOF\ncat > ../x.txt <<EOF\nbad\nEOF\ncat > .git/c <<EOF\nbad\nEOF"
    assert cr.materialize(tmp_path, text, ["a.txt", "../x.txt", ".git/c"]) == []
    assert (tmp_path / "a.txt").read_text() == "keep"
    assert not (tmp_path.parent / "x.txt").exists()


def test_preview_text_strips_markup():
    import server as S
    t = S.preview_text("[进度]\n✓ a\n[/进度]\ns2 我看过了\n```html\n<p>\n```\n[产物]\nindex.html\n[/产物]")
    assert t == "s2 我看过了"


def test_server_stats_shape(tmp_path, monkeypatch):
    import server as S
    monkeypatch.setattr(S, "DATA", tmp_path)
    st = S.server_stats()
    assert st["uptime"] >= 0 and "disk_free" in st


def test_regex_check_is_line_based_by_default(tmp_path):
    import asyncio, verify
    (tmp_path / "c.md").write_text("# 标题\n\n介绍一句。\n")
    seg = {"checks": [{"type": "regex", "path": "c.md", "pattern": r"^#\s+.+$"}]}
    assert asyncio.run(verify.run_checks(seg, tmp_path))["passed"]


def test_overwrite_only_own_files(tmp_path):
    (tmp_path / "a.txt").write_text("old")
    assert cr.materialize(tmp_path, "a.txt\n```\nnew\n```", ["a.txt"], overwrite={"a.txt"}) == ["a.txt"]
    assert (tmp_path / "a.txt").read_text() == "new\n"


def test_skill_excerpt_and_installed(tmp_path):
    import json, skills
    e = skills.catalog()["entries"][0]
    d = tmp_path / "skills" / "tdd"
    d.mkdir(parents=True)
    (d / "SKILL.md").write_text("---\nname: tdd\n---\n# 先写测试\n红绿重构", encoding="utf-8")
    (tmp_path / "skills" / "state.json").write_text(json.dumps({"tdd": {"on": True, "source": "https://github.com/" + e["repo"]}}))
    assert skills.excerpt(tmp_path, e["id"], "写代码").startswith("# 先写测试")
    assert next(x for x in skills.listing(tmp_path) if x["id"] == e["id"])["installed"]


def test_concerto_brief_lists_strengths(monkeypatch):
    import server as S
    ms = {"lead": {"name": "lead", "model": "deepseek-v4-pro"}, "g": {"name": "g", "model": "gpt-6.1-sol"}}
    monkeypatch.setattr(S, "member", lambda n: ms.get(n))
    b = S.concerto_brief({"members": ["lead", "g"]}, "lead")
    assert "不要自己写产物" in b and "- g：擅长" in b and "@lead" in b and "- lead" not in b


def test_concerto_levels(monkeypatch):
    import server as S
    ms = {"lead": {"name": "lead", "model": "deepseek-v4-pro"}, "g": {"name": "g", "model": "gpt-6.1-sol"},
          "f": {"name": "f", "model": "glm-5.3-flash"}, "c": {"name": "c", "model": "claude-opus-5-5"}}
    monkeypatch.setattr(S, "member", lambda n: ms.get(n))
    p = {"members": list(ms)}
    assert "看一眼" in S.concerto_brief({**p, "quality": "save"}, "lead")
    hi = S.concerto_brief({**p, "quality": "max"}, "lead")
    assert "复核" in hi and "- f" not in hi


def test_seg_files():
    import chorus2
    assert chorus2.seg_files({"checks": [{"type": "regex", "path": "index.html"}], "deliverable": "index.html（内联样式） 和 app.js"}) == {"index.html", "app.js"}
