"""B9: storage, lock diagnostics, clarification resumption and real usage billing."""
import json
import os
import pathlib
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
from aiohttp import web

import backup
import chorus2 as c
import orchestra as o
import server as s
import test_dogfood_fixes as dogfood
from test_dogfood_fixes import request, segment


class Storage(unittest.TestCase):
    def test_private_atomic_save_and_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / 'config.json'
            path.write_text('{"old": true}')
            path.chmod(0o644)
            original_dump = json.dump
            def private_dump(value, stream, **kwargs):
                self.assertEqual(os.fstat(stream.fileno()).st_mode & 0o777, 0o600)
                return original_dump(value, stream, **kwargs)
            with patch.object(backup.json, 'dump', side_effect=private_dump):
                s.save(path, {'new': True})
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            self.assertEqual(json.loads(path.read_text()), {'new': True})
            with patch.object(pathlib.Path, 'replace', side_effect=OSError('test interruption')):
                with self.assertRaises(OSError):
                    s.save(path, {'replacement': True})
            self.assertEqual(json.loads(path.read_text()), {'new': True})
            self.assertEqual(list(path.parent.iterdir()), [path])
            # Existing predictable temp symlinks are never opened or followed.
            target = path.parent / 'other'
            target.write_text('untouched')
            path.with_name('config.json.tmp').symlink_to(target)
            s.save(path, {'safe': True})
            self.assertEqual(target.read_text(), 'untouched')
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_lock_pid_and_context(self):
        with tempfile.TemporaryDirectory() as directory:
            with backup.writer_lock(directory, startup=True):
                for startup, wording in ((True, '这个数据目录已有服务在跑'), (False, '不能恢复')):
                    with self.assertRaisesRegex(backup.BackupError, wording + '.*pid ' + str(os.getpid())):
                        with backup.writer_lock(directory, startup=startup):
                            self.fail('lock was not held')
            with backup.writer_lock(directory, startup=True), patch.object(s, 'DATA', pathlib.Path(directory)), patch('sys.stderr') as stderr, patch.object(s, 'setup') as setup:
                with self.assertRaises(SystemExit) as exited:
                    s.run_server()
                self.assertEqual(exited.exception.code, 1)
                self.assertIn(f'这个数据目录已有服务在跑（pid {os.getpid()}）', str(stderr.write.call_args_list))
                setup.assert_not_called()
            with backup.writer_lock(directory, startup=True):
                pass


class B9Runtime(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = dogfood.Runtime.asyncSetUp
    cancel_tasks = dogfood.Runtime.cancel_tasks

    async def test_account_cap_card_after_usage_without_project_cap(self):
        s.CFG['account_caps'] = {'hour': 1, 'day': 10}
        c.on_usage(self.ms[0], {'cost': 1.5, 'cur': '¥'}, 'p')
        self.assertIn('每小时', c.account_block())
        self.assertEqual(o.budget_state(self.p)['spent'], 1.5)
        for i, budget in enumerate((None, {'cap': 0, 'cur': '¥'}, {'cap': 10, 'cur': '¥'})):
            with self.subTest(budget=budget):
                self.p.pop('budget', None)
                if budget is not None:
                    self.p['budget'] = budget
                self.p.pop('pending', None)
                c.GRAPH = type(c.GRAPH)()
                sg = segment(id=f's{i}')
                self.p['segments'] = [sg]
                with patch.object(s, 'run_member', new_callable=AsyncMock) as run:
                    await c.run_segment('p', sg)
                run.assert_not_awaited()
                self.assertEqual(sg['stage'], 'blocked')
                self.assertEqual([d['kind'] for d in self.p['pending']], ['account_cap'])

    async def test_usage_without_project_cap_still_dispatches(self):
        c.on_usage(self.ms[0], {'cost': 1.5, 'cur': '¥'}, 'p')
        self.assertEqual(c.account_block(), '')
        for i, budget in enumerate((None, {'cap': 0, 'cur': '¥'})):
            with self.subTest(budget=budget):
                self.p.pop('budget', None)
                if budget is not None:
                    self.p['budget'] = budget
                c.GRAPH = type(c.GRAPH)()
                sg = segment(id=f's{i}')
                self.p['segments'] = [sg]
                with patch.object(s, 'run_member', new_callable=AsyncMock) as run, patch.object(s, 'add_msg', return_value={'seq': 1, 'ts': 0}), patch.object(c, 'reply_to', return_value={'text': 'done'}), patch.object(o, 'review_needed', return_value=False):
                    await c.run_segment('p', sg)
                run.assert_awaited_once()
                self.assertEqual(sg['stage'], 'done')

    async def test_clarifications_keep_answers_and_replan_once(self):
        self.ms[1].update(kind='api', provider='p', model='custom')
        self.p['lead_resolved'] = 'b'
        self.p['plan_start'] = False
        replies = [json.dumps({'questions': [
            {'q': '使用哪种语言？', 'default': 'Python', 'options': ['Python', 'Go']},
            {'q': '输出格式？', 'default': 'JSON', 'options': ['JSON', 'CSV']}]}),
            '[{"title":"实现","difficulty":1}]']
        ask = AsyncMock(side_effect=replies)
        with patch.object(c, 'ask_model', ask), patch.object(c.designopts, 'speculate'), patch.object(c, 'start') as start:
            await c.plan('p', '小工具')
            cards = self.p['pending']
            self.assertEqual(len(cards), 2)
            self.assertEqual(cards[0]['options'], ['Python', 'Go'])
            await c.h_decide(request({'id': cards[0]['id'], 'choice': 1}))
            self.assertNotIn('p', c.PLANNING)
            await c.h_decide(request({'id': cards[1]['id'], 'answer': 'TSV'}))
            task = c.PLANNING['p']
            await c.h_decide(request({'id': cards[1]['id'], 'choice': 0}))
            self.assertIs(task, c.PLANNING['p'])
            await task
            self.assertEqual(ask.await_count, 2)
            prompt = ask.call_args.args[2]
            for expected in ('使用哪种语言？', 'Go', '输出格式？', 'TSV'):
                self.assertIn(expected, prompt)
            self.assertTrue(self.p['segments'])
            start.assert_not_called()

    async def test_usage_catalog_explicit_missing_and_budget_stop(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(s, 'DATA', pathlib.Path(directory)), patch.object(s, 'save', backup.write_json), patch.object(s, 'record_usage', s.record_usage):
            c.register(web.Application(), s)
            m = self.ms[0]
            m.update(kind='api', provider='p', model='deepseek-chat')
            self.p['budget'] = {'cur': '¥', 'cap': 1}
            self.assertEqual(s.price(m, m['model'])['source'], 'catalog')
            # Exercise the real record_usage hook, not a fabricated cost_split.
            u = {'in': 1000000, 'out': 1000000}
            s.record_usage(m, m['model'], u, 'p')
            self.assertEqual(u['cost'], 5)
            self.assertEqual(o.budget_state(self.p)['spent'], 5)
            self.assertEqual(o.budget_state(self.p)['level'], 'stop')
            sg = segment()
            await c.run_segment('p', sg)
            self.assertEqual(sg['stage'], 'blocked')
            m['prices'] = {'deepseek-chat': {'in': 1, 'out': 2, 'cur': '¥'}}
            s.record_usage(m, m['model'], {'in': 1000000, 'out': 1000000}, 'p')
            self.assertEqual(o.budget_state(self.p)['spent'], 8)
            m['model'] = 'unknown-model'
            s.record_usage(m, m['model'], {'in': 100, 'out': 100}, 'p')
            self.assertIn('缺少价格', s.member_view(m)['pricing_warning'])
            self.assertEqual(self.p['pending'][-1]['kind'], 'pricing_missing')
            self.assertEqual(o.budget_state(self.p)['spent'], 8)
            # Other currencies do not silently become yuan or count twice.
            self.p['cost_split']['foreign'] = {'cost': {'$': 200}}
            self.assertEqual(o.budget_state(self.p)['spent'], 8)


if __name__ == '__main__':
    unittest.main()
