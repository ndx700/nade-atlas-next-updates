"""Chorus Hook 引擎：策略匹配、决策、审计与改写。

设计要点：
- 策略（Policy）+ 匹配器（Matcher）+ 优先级（priority）决定决策顺序。
- 决策枚举：ALLOW / DENY / ASK / REWRITE / TRUNCATE。
- 全量审计写入 audit.jsonl（JSONL），敏感值脱敏（redact_args）。
- ASK 生成结构化 AskRequest，可由 relay 通过 resolve_ask 解析。
- 输出过长时截断并附带引用（sha256 摘要）。

本模块可离线运行，不依赖 aiohttp / Android 端。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

__all__ = [
    "HookEvent",
    "Decision",
    "Matcher",
    "Policy",
    "HookContext",
    "HookResult",
    "AskRequest",
    "AuditRecord",
    "AuditLogger",
    "HookEngine",
    "DEFAULT_POLICIES",
    "TRUNCATE_LIMIT_BYTES",
    "redact_args",
    "truncate_text",
]


# --------------------------------------------------------------------------- #
# 基础枚举
# --------------------------------------------------------------------------- #
class HookEvent(str, Enum):
    BEFORE_TOOL = "before_tool"
    AFTER_TOOL = "after_tool"
    BEFORE_LLM = "before_llm"
    AFTER_LLM = "after_llm"
    ON_STOP = "on_stop"
    ON_ERROR = "on_error"


class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"
    REWRITE = "rewrite"
    TRUNCATE = "truncate"


# --------------------------------------------------------------------------- #
# 脱敏
# --------------------------------------------------------------------------- #
_SENSITIVE_KEY_RE = re.compile(
    r"(pass(word|wd)?|secret|token|api[_-]?key|credential|auth|session|cookie|private)",
    re.IGNORECASE,
)

_LONG_VALUE_THRESHOLD = 512


def redact_args(args: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    """脱敏参数：敏感 key -> {"redacted": True}；超长值 -> 摘要。"""
    if not args:
        return {}
    out: Dict[str, Any] = {}
    for key, value in args.items():
        if isinstance(key, str) and _SENSITIVE_KEY_RE.search(key):
            out[key] = {"redacted": True}
            continue
        if isinstance(value, str) and len(value) > _LONG_VALUE_THRESHOLD:
            out[key] = {
                "summary": value[:80] + "...",
                "length": len(value),
            }
            continue
        if isinstance(value, Mapping):
            out[key] = redact_args(value)
            continue
        if isinstance(value, (list, tuple)):
            out[key] = [
                redact_args({str(i): v})[str(i)] if isinstance(v, Mapping) else v
                for i, v in enumerate(value)
            ]
            continue
        out[key] = value
    return out


# --------------------------------------------------------------------------- #
# 截断
# --------------------------------------------------------------------------- #
TRUNCATE_LIMIT_BYTES = 8 * 1024


def truncate_text(
    text: str,
    limit: int = TRUNCATE_LIMIT_BYTES,
    head: int = 2048,
    tail: int = 1024,
) -> Tuple[str, Dict[str, Any]]:
    """截断长文本，保留头尾并附带 sha256 引用。"""
    raw = text or ""
    raw_bytes = raw.encode("utf-8", errors="replace")
    if len(raw_bytes) <= limit:
        return raw, {"truncated": False, "original_bytes": len(raw_bytes)}

    digest = hashlib.sha256(raw_bytes).hexdigest()
    head_text = raw[:head]
    tail_text = raw[-tail:] if tail > 0 else ""
    marker = (
        f"\n\n…[已截断 {len(raw_bytes) - limit} 字节]…\n"
        f"引用 sha256={digest} 原始长度={len(raw_bytes)} 字节\n\n"
    )
    out = head_text + marker + tail_text
    meta = {
        "truncated": True,
        "original_bytes": len(raw_bytes),
        "kept_head": len(head_text),
        "kept_tail": len(tail_text),
        "sha256": digest,
    }
    return out, meta


# --------------------------------------------------------------------------- #
# 匹配器与策略
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Matcher:
    events: frozenset = field(default_factory=frozenset)
    tools: Optional[Tuple[str, ...]] = None
    arg_patterns: Optional[Tuple[str, ...]] = None

    # 默认各维度同时匹配；不可逆策略允许工具名或参数任一命中。
    tool_or_args: bool = False

    def matches(self, event: HookEvent, tool: Optional[str], args: Mapping[str, Any]) -> bool:
        if self.events and event not in self.events:
            return False
        tool_match = self.tools is None or tool in self.tools
        blob = json.dumps(args or {}, ensure_ascii=False, default=str)
        arg_match = not self.arg_patterns or any(
            re.search(pat, blob) for pat in self.arg_patterns
        )
        if self.tool_or_args:
            return ((self.tools is not None and tool_match)
                    or (bool(self.arg_patterns) and arg_match))
        return tool_match and arg_match



@dataclass
class Policy:
    id: str
    name: str
    description: str
    matcher: Matcher
    decision: Decision
    priority: int = 100
    reason: str = ""
    handler_id: Optional[str] = None


# --------------------------------------------------------------------------- #
# Hook 上下文与结果
# --------------------------------------------------------------------------- #
@dataclass
class HookContext:
    event: HookEvent
    tool: Optional[str]
    args: Dict[str, Any]
    output: Optional[str] = None
    session_id: Optional[str] = None
    policy: Optional[Policy] = None


@dataclass
class HookResult:
    decision: Decision
    reason: str = ""
    policy_id: Optional[str] = None
    policy_name: Optional[str] = None
    ask: Optional["AskRequest"] = None
    rewritten_args: Optional[Dict[str, Any]] = None
    truncated_output: Optional[str] = None
    truncate_meta: Optional[Dict[str, Any]] = None
    audit_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "decision": self.decision.value,
            "reason": self.reason,
            "policy_id": self.policy_id,
            "policy_name": self.policy_name,
            "audit_id": self.audit_id,
        }
        if self.ask is not None:
            payload["ask"] = self.ask.to_dict()
        if self.rewritten_args is not None:
            payload["rewritten_args"] = self.rewritten_args
        if self.truncated_output is not None:
            payload["truncated_output"] = self.truncated_output
        if self.truncate_meta is not None:
            payload["truncate_meta"] = self.truncate_meta
        return payload


# --------------------------------------------------------------------------- #
# AskRequest
# --------------------------------------------------------------------------- #
@dataclass
class AskRequest:
    request_id: str
    policy_id: str
    event: str
    summary: str
    reason: str
    options: List[str]
    args_preview: Dict[str, Any]
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "policy_id": self.policy_id,
            "event": self.event,
            "summary": self.summary,
            "reason": self.reason,
            "options": list(self.options),
            "args_preview": self.args_preview,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "AskRequest":
        return cls(
            request_id=str(payload["request_id"]),
            policy_id=str(payload["policy_id"]),
            event=str(payload["event"]),
            summary=str(payload.get("summary", "")),
            reason=str(payload.get("reason", "")),
            options=list(payload.get("options", []) or []),
            args_preview=dict(payload.get("args_preview", {}) or {}),
            created_at=float(payload.get("created_at", time.time())),
        )


# --------------------------------------------------------------------------- #
# 审计
# --------------------------------------------------------------------------- #
@dataclass
class AuditRecord:
    audit_id: str
    ts: float
    event: HookEvent
    decision: Decision
    tool: Optional[str]
    policy_id: Optional[str]
    policy_name: Optional[str]
    reason: str
    session_id: Optional[str] = None
    args: Optional[Dict[str, Any]] = None
    output_bytes: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "audit_id": self.audit_id,
            "ts": self.ts,
            "event": self.event.value if isinstance(self.event, HookEvent) else str(self.event),
            "decision": self.decision.value if isinstance(self.decision, Decision) else str(self.decision),
            "tool": self.tool,
            "policy_id": self.policy_id,
            "policy_name": self.policy_name,
            "reason": self.reason,
            "session_id": self.session_id,
            "args": self.args,
            "output_bytes": self.output_bytes,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "AuditRecord":
        return cls(
            audit_id=str(payload["audit_id"]),
            ts=float(payload.get("ts", 0.0)),
            event=HookEvent(payload.get("event", "before_tool")),
            decision=Decision(payload.get("decision", "allow")),
            tool=payload.get("tool"),
            policy_id=payload.get("policy_id"),
            policy_name=payload.get("policy_name"),
            reason=str(payload.get("reason", "")),
            session_id=payload.get("session_id"),
            args=payload.get("args"),
            output_bytes=payload.get("output_bytes"),
        )


class AuditLogger:
    """JSONL 审计日志，线程安全。"""

    MAX_BYTES = 5 * 1024 * 1024
    BACKUPS = 3
    MAX_RECORDS = 2000

    def __init__(self, path: os.PathLike | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._records: List[AuditRecord] = []
        self._rotate(0)
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            with self.path.open(encoding="utf-8") as fh:
                lines = deque(fh, maxlen=self.MAX_RECORDS)
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    self._records.append(AuditRecord.from_dict(json.loads(line)))
                except Exception:
                    continue
        except Exception:
            pass

    def _rotate(self, incoming):
        if not self.path.exists() or self.path.stat().st_size + incoming <= self.MAX_BYTES:
            return
        for index in range(self.BACKUPS, 0, -1):
            source = self.path if index == 1 else Path(str(self.path) + f".{index - 1}")
            target = Path(str(self.path) + f".{index}")
            if source.exists():
                source.replace(target)

    def write_sync(self, record: AuditRecord) -> None:
        with self._lock:
            line = json.dumps(record.to_dict(), ensure_ascii=False) + "\n"
            self._rotate(len(line.encode("utf-8")))
            self._records.append(record)
            self._records = self._records[-self.MAX_RECORDS:]
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(line)

    async def write(self, record: AuditRecord) -> None:
        self.write_sync(record)

    def read_all(self) -> List[AuditRecord]:
        with self._lock:
            return list(self._records)

    def query(
        self,
        *,
        event: Optional[HookEvent] = None,
        decision: Optional[Decision] = None,
        tool: Optional[str] = None,
        policy_id: Optional[str] = None,
        since: Optional[float] = None,
        limit: Optional[int] = None,
    ) -> List[AuditRecord]:
        with self._lock:
            records = list(self._records)
        if event is not None:
            records = [r for r in records if r.event == event]
        if decision is not None:
            records = [r for r in records if r.decision == decision]
        if tool is not None:
            records = [r for r in records if r.tool == tool]
        if policy_id is not None:
            records = [r for r in records if r.policy_id == policy_id]
        if since is not None:
            records = [r for r in records if r.ts >= since]
        if limit is not None:
            records = records[:limit]
        return records

    def export_jsonl(self, target: os.PathLike | str) -> None:
        target_path = Path(target)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        with target_path.open("w", encoding="utf-8") as fh:
            for record in self.read_all():
                fh.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")

    def export_json(self, target: os.PathLike | str) -> None:
        target_path = Path(target)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        payload = [r.to_dict() for r in self.read_all()]
        target_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


# --------------------------------------------------------------------------- #
# 默认策略
# --------------------------------------------------------------------------- #
def _build_default_policies() -> List[Policy]:
    return [
        Policy(
            id="dangerous-command",
            name="危险命令",
            description="拦截 rm -rf /、mkfs、dd 写设备、shutdown、git push --force 等危险命令。",
            matcher=Matcher(
                events=frozenset({HookEvent.BEFORE_TOOL}),
                arg_patterns=(
                    r"\brm\s+-[a-zA-Z]*r[a-zA-Z]*f",
                    r"\bmkfs(\.\w+)?\b",
                    r"\bdd\s+.*of=/dev/",
                    r"\b(shutdown|reboot|halt)\b",
                    r"\bgit\s+push\s+.*--force",
                    r"\bgit\s+push\s+-f\b",
                ),
            ),
            decision=Decision.DENY,
            priority=10,
            reason="检测到危险命令，已拒绝执行。",
        ),
        Policy(
            id="sensitive-file",
            name="敏感文件",
            description="拒绝读取 .env、私钥、证书、凭据等敏感文件。",
            matcher=Matcher(
                events=frozenset({HookEvent.BEFORE_TOOL}),
                tools=("read_file", "write_file", "edit_file", "cat", "open"),
                arg_patterns=(
                    r"\.env(\.\w+)?",
                    r"\.pem\b",
                    r"id_rsa",
                    r"id_ed25519",
                    r"credentials\.json",
                    r"\.key\b",
                    r"\.p12\b",
                    r"\.pfx\b",
                    r"\.keystore\b",
                    r"shadow\b",
                ),
            ),
            decision=Decision.DENY,
            priority=20,
            reason="检测到敏感文件访问，已拒绝。",
        ),
        Policy(
            id="irreversible-action",
            name="不可逆操作",
            description="发布、支付、发邮件等不可逆操作需要人工确认。",
            matcher=Matcher(
                events=frozenset({HookEvent.BEFORE_TOOL}),
                tools=("publish", "deploy", "payment", "send_email", "send_sms",
                       "delete_account", "delete_project"),
                tool_or_args=True,
                arg_patterns=(
                    r"发布到?\s*生产",
                    r"生产环境",
                    r"上线",
                    r"deploy\s+to\s+prod",
                    r"publish\s+to\s+prod",
                ),
            ),
            decision=Decision.ASK,
            priority=30,
            reason="该操作不可逆，需要人工确认。",
        ),
        Policy(
            id="output-too-long",
            name="输出过长",
            description="工具输出超过阈值时截断并附带引用。",
            matcher=Matcher(events=frozenset({HookEvent.AFTER_TOOL})),
            decision=Decision.TRUNCATE,
            priority=40,
            reason="输出过长，已截断。",
        ),
        Policy(
            id="audit-all",
            name="全量审计",
            description="所有事件均写入审计日志。",
            matcher=Matcher(
                events=frozenset(
                    {
                        HookEvent.BEFORE_TOOL,
                        HookEvent.AFTER_TOOL,
                        HookEvent.BEFORE_LLM,
                        HookEvent.AFTER_LLM,
                        HookEvent.ON_STOP,
                        HookEvent.ON_ERROR,
                    }
                )
            ),
            decision=Decision.ALLOW,
            priority=1000,
            reason="已记录审计。",
        ),
    ]


DEFAULT_POLICIES: List[Policy] = _build_default_policies()


# --------------------------------------------------------------------------- #
# HookEngine
# --------------------------------------------------------------------------- #
class HookEngine:
    def __init__(
        self,
        audit_path: os.PathLike | str = "audit.jsonl",
        session_id: Optional[str] = None,
        policies: Optional[Sequence[Policy]] = None,
    ) -> None:
        self.audit_logger = AuditLogger(audit_path)
        self.session_id = session_id
        self._policies: List[Policy] = list(policies) if policies is not None else list(DEFAULT_POLICIES)
        self._handlers: Dict[str, Callable[[HookContext], HookResult]] = {}
        self._ask_requests: Dict[str, AskRequest] = {}
        self._lock = threading.Lock()

    # ---------------- 策略管理 ---------------- #
    def add_policy(self, policy: Policy) -> None:
        self._policies.append(policy)
        self._policies.sort(key=lambda p: p.priority)

    def register_handler(self, policy_id: str, handler: Callable[[HookContext], HookResult]) -> None:
        self._handlers[policy_id] = handler

    def get_ask_request(self, request_id: str) -> Optional[AskRequest]:
        with self._lock:
            return self._ask_requests.get(request_id)

    def resolve_ask(self, request_id: str, decision: str) -> Dict[str, Any]:
        with self._lock:
            request = self._ask_requests.pop(request_id, None)
        if request is None:
            return {"request_id": request_id, "decision": "deny", "reason": "unknown request"}
        normalized = (decision or "").strip().lower()
        if normalized in ("approve", "allow", "yes", "ok", "accept"):
            final = "allow"
        elif normalized in ("deny", "reject", "no", "block"):
            final = "deny"
        else:
            final = "deny"
        return {"request_id": request_id, "decision": final, "policy_id": request.policy_id}

    # ---------------- 匹配 ---------------- #
    def _match_policies(self, event: HookEvent, tool: Optional[str], args: Mapping[str, Any]) -> List[Policy]:
        matched = [p for p in self._policies if p.matcher.matches(event, tool, args)]
        matched.sort(key=lambda p: p.priority)
        return matched

    # ---------------- 决策 ---------------- #
    async def dispatch(
        self,
        event: HookEvent,
        tool: Optional[str] = None,
        args: Optional[Mapping[str, Any]] = None,
        output: Optional[str] = None,
    ) -> HookResult:
        args_dict: Dict[str, Any] = dict(args or {})
        matched = self._match_policies(event, tool, args_dict)

        # 优先级：DENY > ASK > REWRITE > TRUNCATE > ALLOW
        deny_policies = [p for p in matched if p.decision is Decision.DENY]
        ask_policies = [p for p in matched if p.decision is Decision.ASK]
        rewrite_policies = [p for p in matched if p.decision is Decision.REWRITE]
        truncate_policies = [p for p in matched if p.decision is Decision.TRUNCATE]
        allow_policies = [p for p in matched if p.decision is Decision.ALLOW]

        chosen: Optional[Policy] = None
        if deny_policies:
            chosen = deny_policies[0]
        elif ask_policies:
            chosen = ask_policies[0]
        elif rewrite_policies:
            chosen = rewrite_policies[0]
        elif truncate_policies:
            chosen = truncate_policies[0]
        elif allow_policies:
            chosen = allow_policies[0]

        # 自定义 handler 覆盖
        if chosen is not None and chosen.id in self._handlers:
            handler = self._handlers[chosen.id]
            ctx = HookContext(
                event=event,
                tool=tool,
                args=args_dict,
                output=output,
                session_id=self.session_id,
                policy=chosen,
            )
            result = handler(ctx)
        else:
            result = self._default_result(event, tool, args_dict, output, chosen)

        # 审计（全量）
        audit_id = str(uuid.uuid4())
        record = AuditRecord(
            audit_id=audit_id,
            ts=time.time(),
            event=event,
            decision=result.decision,
            tool=tool,
            policy_id=result.policy_id,
            policy_name=result.policy_name,
            reason=result.reason,
            session_id=self.session_id,
            args=redact_args(args_dict),
            output_bytes=len(output.encode("utf-8")) if output else None,
        )
        self.audit_logger.write_sync(record)
        result.audit_id = audit_id
        return result

    def _default_result(
        self,
        event: HookEvent,
        tool: Optional[str],
        args: Dict[str, Any],
        output: Optional[str],
        policy: Optional[Policy],
    ) -> HookResult:
        if policy is None:
            return HookResult(decision=Decision.ALLOW, reason="无匹配策略", policy_id=None)

        if policy.decision is Decision.DENY:
            return HookResult(
                decision=Decision.DENY,
                reason=policy.reason or policy.description,
                policy_id=policy.id,
                policy_name=policy.name,
            )

        if policy.decision is Decision.ASK:
            request = AskRequest(
                request_id=str(uuid.uuid4()),
                policy_id=policy.id,
                event=event.value,
                summary=f"{policy.name}: {tool or 'unknown'}",
                reason=policy.reason or policy.description,
                options=["approve", "deny"],
                args_preview=redact_args(args),
            )
            with self._lock:
                self._ask_requests[request.request_id] = request
            return HookResult(
                decision=Decision.ASK,
                reason=policy.reason or policy.description,
                policy_id=policy.id,
                policy_name=policy.name,
                ask=request,
            )

        if policy.decision is Decision.REWRITE:
            rewritten = self._rewrite_args(args)
            return HookResult(
                decision=Decision.REWRITE,
                reason=policy.reason or policy.description,
                policy_id=policy.id,
                policy_name=policy.name,
                rewritten_args=rewritten,
            )

        if policy.decision is Decision.TRUNCATE:
            if output is None:
                return HookResult(
                    decision=Decision.ALLOW,
                    reason="无输出",
                    policy_id=policy.id,
                    policy_name=policy.name,
                )
            if len(output.encode("utf-8", errors="replace")) <= TRUNCATE_LIMIT_BYTES:
                return HookResult(
                    decision=Decision.ALLOW,
                    reason="输出长度正常",
                    policy_id=policy.id,
                    policy_name=policy.name,
                )
            truncated, meta = truncate_text(output)
            return HookResult(
                decision=Decision.TRUNCATE,
                reason=policy.reason or policy.description,
                policy_id=policy.id,
                policy_name=policy.name,
                truncated_output=truncated,
                truncate_meta=meta,
            )

        # ALLOW
        return HookResult(
            decision=Decision.ALLOW,
            reason=policy.reason or policy.description,
            policy_id=policy.id,
            policy_name=policy.name,
        )

    def _rewrite_args(self, args: Mapping[str, Any]) -> Dict[str, Any]:
        skip_flags = re.compile(r"(--yes|--no-approve|--force-yes|-y\b|--assume-yes|--silent|--quiet)")
        out: Dict[str, Any] = {}
        for key, value in args.items():
            if isinstance(value, str):
                out[key] = skip_flags.sub("", value)
                out[key] = re.sub(r"\s{2,}", " ", out[key]).strip()
            else:
                out[key] = value
        return out


# --------------------------------------------------------------------------- #
# 便捷入口
# --------------------------------------------------------------------------- #
async def run_hooks(
    engine: HookEngine,
    event: HookEvent,
    tool: Optional[str] = None,
    args: Optional[Mapping[str, Any]] = None,
    output: Optional[str] = None,
) -> HookResult:
    return await engine.dispatch(event, tool=tool, args=args, output=output)
