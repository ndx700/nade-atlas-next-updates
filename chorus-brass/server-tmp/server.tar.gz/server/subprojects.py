"""Independent child projects, source provenance and durable completion receipts."""
from types import SimpleNamespace
import copy
import json
import time
import math

from aiohttp import web
import orchestra
import task_cards
import api_errors


def prepare(s, body):
    parent_id = body.get('parent')
    if not isinstance(parent_id, str) or not (parent := s.project(parent_id)):
        raise api_errors.http_error(web.HTTPBadRequest, '主项不存在')
    if parent.get('filed') or parent.get('archived'):
        raise api_errors.http_error(web.HTTPConflict, '主项已归档')
    if not body.get('members'):
        raise api_errors.http_error(web.HTTPBadRequest, '子项需要明确指定成员')
    source = {}
    if 'source_task_id' in body:
        tid = task_cards.text(body['source_task_id'], 100, 'source_task_id')
        task = next((t for t in s.cards().read(parent_id)['items'] if t['id'] == tid), None)
        if task is None:
            raise api_errors.http_error(web.HTTPBadRequest, '来源任务不存在')
        source['source_task_id'] = tid
        source['source_task_snapshot'] = copy.deepcopy(task)
    if 'source_message_ids' in body:
        source.update(s.cards().fields(parent_id, {'source_message_ids': body['source_message_ids']}))
    source['source_message_snapshots'] = [copy.deepcopy(m) for m in s.load_chat(parent_id) if m.get('seq') in source.get('source_message_ids', []) and not m.get('dm') and not m.get('gone') and not m.get('recalled')]
    if 'brief' not in body:
        parts = [task['title']] if source.get('source_task_id') else []
        ids = source.get('source_message_ids', [])
        parts.extend(m.get('text', '') for m in s.load_chat(parent_id) if m['seq'] in ids)
        source['brief'] = '\n\n'.join(parts)
    for field in ('acceptance_criteria', 'context'):
        if field in body:
            source[field] = task_cards.text(body[field], 20000, field, empty=True)
    if 'estimated_seconds' in body:
        value = body['estimated_seconds']
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise api_errors.http_error(web.HTTPBadRequest, 'estimated_seconds 必须是有限非负秒数')
        source['estimated_seconds'] = value
    source['source_artifact_ids'] = body.get('source_artifact_ids', [])
    reason = task_cards.text(body.get('assignment_reason', '用户手工选择成员'), 2000, 'assignment_reason')
    source['assign_log'] = [{'members': body['members'], 'reason': reason, 'at': time.time(), 'kind': 'manual'}]
    return {'parent': parent_id, **source}


def summary(s, pid):
    p = s.project(pid)
    segs = p.get('segments') or []
    return {'id': pid, 'name': p.get('name', ''), 'parent': p.get('parent'),
            'source_task_id': p.get('source_task_id'), 'source_message_ids': p.get('source_message_ids', []),
            'members': p.get('members', []), 'budget': orchestra.budget_state(p),
            **runtime(s, p),
            'progress': {'done': sum(x.get('stage') == 'done' for x in segs), 'total': len(segs),
                         'pct': round(sum(orchestra.segment_pct(x) for x in segs) / len(segs), 2) if segs else 100 if p.get('resolved') else 0}}


def children(s, pid):
    rows = [summary(s, p['id']) for p in s.PROJECTS if p.get('parent') == pid]
    totals = {}
    for row in rows:
        b = row['budget']
        currency = totals.setdefault(b['cur'], {'spent': 0, 'cap': 0})
        for key in currency:
            currency[key] += b[key]
    total = sum(r['progress']['total'] for r in rows)
    weight = sum(max(1, r['progress']['total']) for r in rows)
    done = sum(r['progress']['done'] for r in rows)
    return {'items': rows, 'budget_by_currency': totals, 'progress': {'done': done, 'total': total,
            'pct': round(sum(r['progress']['pct'] * max(1, r['progress']['total']) for r in rows) / weight, 2) if weight else 0}}


def report_completed(s):
    for p in s.PROJECTS:
        parent = p.get('parent')
        segs = p.get('segments') or []
        if p.get('archived') or not parent or not s.project(parent) or not (p.get('resolved') or segs and all(x.get('stage') == 'done' for x in segs)):
            continue
        # Chat persistence precedes project persistence. Recover safely after a crash
        # between the two writes by looking for the stable receipt key.
        key = 'subproject:' + p['id']
        if p.get('completion_reported'):
            continue
        if not any(m.get('subproject_receipt') == key for m in s.load_chat(parent)):
            s.add_msg(parent, '系统', '子项完成：' + p['name'], subproject_receipt=key,
                      subproject_report={**summary(s, p['id']), 'artifacts': [a for x in segs for a in x.get('artifacts', [])]})
        p['completion_reported'] = True




def consent_cards(s, p):
    """Project membership maps to the existing model/key consent identity."""
    import consent
    cards = consent.load(s.DATA)
    out = []
    for name in p.get('members', []):
        m = s.member(name) or {}
        if m.get('kind') in ('cli', 'dsh'):
            continue
        provider = next((x for x in s.CFG.get('providers', []) if x.get('id') == m.get('provider')), {})
        fp = consent.fingerprint(m.get('model', ''), provider.get('key', ''))
        if fp in cards:
            out.append({'id': fp, **cards[fp], 'member': name, 'project_id': p['id']})
    return out


def runtime(s, p):
    segs = p.get('segments') or []
    cards = consent_cards(s, p)
    waiting = any(x.get('state', 'open') == 'open' for x in p.get('pending', [])) or any(x['state'] == 'pending' for x in cards) or any(
        x.get('stage') in ('awaiting_consent', 'awaiting_user', 'awaiting_decision') for x in segs)
    solved = bool(p.get('resolved') or segs and all(x.get('stage') == 'done' for x in segs))
    busy = active(s, p['id'])
    state = 'resolved' if solved else 'paused' if p.get('paused') else 'awaiting_user' if waiting else 'running' if busy else 'idle'
    messages = s.CHATS.get(p['id'], s.load_chat(p['id']))
    times = [p.get('created', 0), p.get('updated_at', 0)] + [m.get('ts', 0) for m in messages]
    times += [e.get('at', 0) for x in segs for e in x.get('events', [])]
    times += [e.get('at', 0) for e in s.CFG.get('audit', []) if e.get('pid') == p['id']]
    return {'running_status': state, 'waiting_for_user': waiting,
            'dependency_reasons': [{'segment_id': x.get('id'), 'depends_on': x.get('inputs', x.get('depends_on', x.get('deps', []))),
                                    'reason': x.get('blocked_reason', x.get('reason', ''))}
                                   for x in segs if x.get('inputs') or x.get('depends_on') or x.get('deps') or x.get('blocked_reason')],
            'last_activity_at': max((x for x in times if isinstance(x, (int, float))), default=0) or None,
            'estimated_seconds': p.get('estimated_seconds'), 'resolved': solved, 'pending_decisions': p.get('pending', []),
            'resolution': p.get('resolution'), 'completion_reported': bool(p.get('completion_reported')),
            'assign_log': [{**x, 'project_id': p['id']} for x in p.get('assign_log', [])],
            'source_artifact_ids': p.get('source_artifact_ids', []), 'consent_cards': cards}


def active(s, pid):
    p = s.project(pid)
    if any(x.get('stage') in ('running', 'working', 'review', 'rework') for x in p.get('segments', [])):
        return True
    import chorus2
    if any(t and not t.done() for t in (chorus2.RUNNING.get(pid), chorus2.PLANNING.get(pid))):
        return True
    if any(e.get('pid') == pid and any(not t.done() for t in e.get('tasks', {})) for e in getattr(s, 'ROOTS', {}).values()):
        return True
    return any(isinstance(k, tuple) and k[0] == pid and hasattr(t, 'done') and not t.done()
               for k, t in getattr(s, 'TASKS', {}).items())


async def source_artifacts(s, body):
    ids = body.get('source_artifact_ids', [])
    if not isinstance(ids, list) or len(ids) > 100 or any(not isinstance(x, str) or not x for x in ids):
        raise api_errors.http_error(web.HTTPBadRequest, 'source_artifact_ids 必须是产物 ID 列表（最多100项）')
    if not ids:
        return []
    if not isinstance(body.get('parent'), str) or not s.project(body['parent']):
        raise api_errors.http_error(web.HTTPBadRequest, '主项不存在')
    import artifacts
    store = artifacts.default_store(s.DATA, body['parent'], enabled=True)
    out = []
    for aid in dict.fromkeys(ids):
        try:
            art = await store.get(aid)
        except artifacts.ArtifactNotFoundError:
            raise api_errors.http_error(web.HTTPBadRequest, '来源产物不存在：' + aid)
        if art.secret:
            raise api_errors.http_error(web.HTTPBadRequest, '私密产物不能随行交接')
        try:
            await store.verify(aid)
        except (artifacts.ArtifactError, OSError):
            raise api_errors.http_error(web.HTTPBadRequest, '来源产物内容不可用：' + aid)
        out.append({'id': aid, 'project_id': body['parent'], 'artifact': art.public_view(),
                    'transfer_mode': 'reference', 'blob_path': str(store.blob_path(art.sha256)),
                    'content_url': f"/api/collab/{body['parent']}/artifacts/{aid}/content"})
    return out


def context_package(s, p):
    parent = p.get('parent')
    messages = s.CHATS.get(p['id'], s.load_chat(p['id']))
    source = s.CHATS.get(parent, s.load_chat(parent)) if parent else []
    return {'brief': p.get('brief', ''), 'context': p.get('context', ''),
            'acceptance_criteria': p.get('acceptance_criteria', ''),
            'source_task': next((x for x in s.cards().read(parent)['items'] if x['id'] == p.get('source_task_id')), None) if parent else None,
            'source_messages': [x for x in source if x.get('seq') in p.get('source_message_ids', []) and not x.get('dm') and not x.get('gone') and not x.get('recalled')],
            'messages': [x for x in messages if not x.get('dm') and not x.get('live') and not x.get('gone') and not x.get('recalled')],
            'tasks': s.cards().read(p['id']), 'segments': copy.deepcopy(p.get('segments', [])),
            'source_artifacts': p.get('source_artifacts', []),
            'artifacts': [a for x in p.get('segments', []) for a in x.get('artifacts', [])]}




def register_consent(s, p):
    import os
    import consent
    if os.environ.get('CHORUS_CONSENT', '').lower() == 'off' or not s.CFG.get('collab', {}).get('consent', True):
        return []
    for name in p.get('members', []):
        m = s.member(name) or {}
        if m.get('kind') in ('cli', 'dsh') or not m.get('model'):
            continue
        provider = next((x for x in s.CFG.get('providers', []) if x.get('id') == m.get('provider')), {})
        consent.request(s.DATA, name, m['model'], provider.get('key', ''), '子项首次使用，等待用户定音')
    return consent_cards(s, p)


class Subprojects:
    def __init__(self, server):
        self.s = server
    async def handle(self, request):
        pid = request.match_info['pid']
        if not self.s.project(pid):
            raise api_errors.http_error(web.HTTPNotFound, '主项不存在')
        if request.method == 'GET':
            return web.json_response(children(self.s, pid))
        body = await api_errors.json_object(request)
        body = {**body, 'parent': pid}
        tid = request.match_info.get('id')
        if tid:
            body['source_task_id'] = tid
        if not body.get('source_task_id') and not body.get('source_message_ids'):
            raise api_errors.http_error(web.HTTPBadRequest, '请选择来源任务或消息')
        # The normal creation contract validates members, budget, permissions and
        # idempotency and persists provenance before dispatching any work.
        async def payload():
            return body
        return await self.s.h_new_project(SimpleNamespace(json=payload))

    async def detail(self, request):
        p = self.s.project(request.match_info['pid'])
        if not p:
            raise api_errors.http_error(web.HTTPNotFound, '子项不存在')
        import artifacts
        arts = await artifacts.default_store(self.s.DATA, p['id'], enabled=True).list_by_project(p['id'])
        return web.json_response({**summary(self.s, p['id']), **context_package(self.s, p),
                                  'artifact_lines': arts, 'handoffs': p.get('handoffs', []),
                                  'resolution': p.get('resolution')})

    async def mutate(self, request):
        """No awaits inside state validation / replacement. One durable project commit.

        Resolution report is a durable outbox in this same commit. Existing report
        reconciliation delivers it once (stable subproject receipt) after a crash.
        """
        body = await api_errors.json_object(request)
        s = self.s
        pid = request.match_info['pid']
        op = request.match_info['op']
        if op not in ('replace-members', 'resolve'):
            raise web.HTTPNotFound()
        p = s.project(pid)
        if not p or not p.get('parent'):
            raise api_errors.http_error(web.HTTPNotFound, '子项不存在')
        cid = task_cards.text(body.get('client_id'), 128, 'client_id')
        fingerprint = json.dumps(body, sort_keys=True, ensure_ascii=False)
        key = op + ':' + cid
        previous = p.get('operation_receipts', {}).get(key)
        if previous:
            if previous['payload'] != fingerprint:
                raise api_errors.http_error(web.HTTPConflict, '同一请求号内容不同')
            return web.json_response(previous['response'])
        import artifacts
        artifact_lines = await artifacts.default_store(s.DATA, pid, enabled=True).list_by_project(pid) if op == 'replace-members' else []
        p = s.project(pid)
        if not p or not p.get('parent'):
            raise api_errors.http_error(web.HTTPNotFound, '子项不存在')
        previous = p.get('operation_receipts', {}).get(key)
        if previous:
            if previous['payload'] != fingerprint:
                raise api_errors.http_error(web.HTTPConflict, '同一请求号内容不同')
            return web.json_response(previous['response'])
        if p.get('archived') or p.get('filed') or active(s, pid):
            raise api_errors.http_error(web.HTTPConflict, '请先休止并等待在途执行结束')
        if p.get('resolved') or p.get('completion_reported'):
            raise api_errors.http_error(web.HTTPConflict, '子项已解决')
        candidate = copy.deepcopy(p)
        at = time.time()
        response = {'ok': True, 'project_id': pid, 'client_id': cid}
        if op == 'replace-members':
            members = body.get('members')
            if not isinstance(members, list) or not members or any(not isinstance(x, str) or not s.member(x) for x in members):
                raise api_errors.http_error(web.HTTPBadRequest, '请选择有效成员')
            members = list(dict.fromkeys(members))
            if p.get('mode') == 'solo' and len(members) != 1:
                raise api_errors.http_error(web.HTTPBadRequest, '独奏只能选择一名成员')
            reason = task_cards.text(body.get('reason', '用户手工换人'), 2000, 'reason')
            handoff = {'id': cid, 'at': at, 'from_members': p['members'], 'to_members': members,
                       'status': 'stored', 'context': context_package(s, p)}
            # Registered outputs are captured before entering the synchronous commit.
            # Segment paths and source artifact links are included in context as well.
            handoff['context']['artifact_lines'] = artifact_lines
            candidate['members'] = members
            candidate['lead'] = p.get('lead') if p.get('lead') in members else ''
            for seg in candidate.get('segments', []):
                if seg.get('stage') != 'done':
                    seg['assignee'] = members[0]
            candidate.setdefault('handoffs', []).append(handoff)
            candidate.setdefault('assign_log', []).append({'members': members, 'reason': reason, 'at': at, 'kind': 'manual_replace', 'handoff_id': cid})
            response['handoff'] = handoff
        else:
            note = task_cards.text(body.get('note', ''), 20000, 'note', empty=True)
            candidate.update(resolved=True, paused=True, resolution={'id': cid, 'at': at, 'note': note}, completion_reported=False)
            for seg in candidate.get('segments', []):
                seg['stage'] = 'done'
            response.update(resolution=candidate['resolution'], report_receipt='subproject:' + pid)
        candidate['updated_at'] = at
        candidate.setdefault('operation_receipts', {})[key] = {'payload': fingerprint, 'response': response}
        projects = [candidate if x['id'] == pid else x for x in s.PROJECTS]
        s.save(s.DATA / 'projects.json', projects)  # failure leaves live state untouched
        p.clear()
        p.update(candidate)
        s.bump(pid)
        # Report delivery is retried by chorus2.save_projects; mutation already durable.
        if op == 'resolve':
            try:
                report_completed(s)
                s.save(s.DATA / 'projects.json', s.PROJECTS)
            except OSError:
                p['completion_reported'] = False
        return web.json_response(response)

    async def assignment_preview(self, request):
        body = await api_errors.json_object(request)
        pid = request.match_info['pid']
        if not self.s.project(pid):
            raise web.HTTPNotFound()
        tid = body.get('source_task_id')
        task = next((x for x in self.s.cards().read(pid)['items'] if x['id'] == tid), None)
        if tid and not task:
            raise api_errors.http_error(web.HTTPBadRequest, '来源任务不存在')
        import profiles
        brief = task_cards.text(body.get('brief', ''), 20000, 'brief', empty=True)
        explicit_skill = task_cards.text(body['skill'], 100, 'skill') if 'skill' in body else None
        content = (task or {}).get('title', '') + ' ' + brief
        skill = explicit_skill or ('code' if any(x in content.lower() for x in ('代码', '开发', 'bug', 'python', 'api')) else None)
        rows = []
        for m in self.s.CFG.get('members', []):
            score = profiles.skill_score(m.get('model', ''), skill) if skill else None
            busy = any(m['name'] in x.get('members', []) and active(self.s, x['id']) for x in self.s.PROJECTS)
            quota = self.s.QUOTA.get(m['name'])
            price = self.s.price(m, m.get('model', ''))
            stats = self.s.CFG.get('member_stats', {}).get(m['name'], {})
            passed = stats.get('pass') if stats.get('reviews', 0) > 0 else None
            available = orchestra._available(m, self.s.QUOTA)
            factors = {'quota': quota, 'price': price, 'historical_pass_rate': passed}
            rows.append({'member': m['name'], 'skill': skill, 'score': score, 'busy': busy,
                         'available': available, **factors,
                         'reason': (f"来源任务内容匹配 {skill}；能力分 {score}；" if skill else '题材能力未知；')
                                   + ('当前忙碌；' if busy else '当前空闲；')
                                   + f"可派活={available}；价格={price}；历史通过率={passed}；额度={quota}",
                         'unknown_factors': [k for k, v in factors.items() if v is None]})
        # Price comparisons only within the same currency; unknown prices remain unknown.
        def order(row):
            price = row['price'] or {}
            cost = price.get('out')
            return (not row['available'], row['busy'], -(row['score'] or 0),
                    -(row['historical_pass_rate'] or 0), str(price.get('cur', '')),
                    cost if isinstance(cost, (int, float)) else float('inf'))
        rows.sort(key=order)
        return web.json_response({'source_task_id': tid, 'items': rows, 'persisted': False})


def execution_context(p):
    return json.dumps({'handoff': p.get('handoffs', [])[-1:],
                       'source_artifacts': p.get('source_artifacts', []),
                       'source_task': p.get('source_task_snapshot'),
                       'source_messages': p.get('source_message_snapshots', []),
                       'context': p.get('context', ''),
                       'acceptance_criteria': p.get('acceptance_criteria', '')}, ensure_ascii=False)


def record_dispatch(p, seg, who, reason):
    if not p.get('parent'):
        return
    selection = next((x for x in reversed(orchestra.PROFILE_SHADOW_LOG)
                      if x.get('project_id') == p['id'] and x.get('segment_id') == seg['id']), None)
    p.setdefault('assign_log', []).append({'project_id': p['id'], 'segment_id': seg['id'],
        'members': [who], 'reason': reason, 'kind': 'dispatch', 'at': time.time(),
        'selection': copy.deepcopy(selection) if reason != '显式指定负责人' else None})
