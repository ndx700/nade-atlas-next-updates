"""Strong references for asynchronous work, shared across server modules."""
import asyncio
from pathlib import Path

BACKGROUND = set()
CWD_LOCKS = {}


def spawn(awaitable):
    task = asyncio.ensure_future(awaitable)
    BACKGROUND.add(task)
    task.add_done_callback(BACKGROUND.discard)
    return task


def cwd_lock(cwd):
    # Resolve aliases too: two sessions must not write the same physical tree.
    return CWD_LOCKS.setdefault(str(Path(cwd or '.').resolve()), asyncio.Lock())
