"""Un-@ messages get a reply: lead → default → the only member → first auto member (device bug: 1-member group got silence)."""
import unittest
from unittest.mock import patch

import server as s


class DefaultReply(unittest.TestCase):
    def setUp(self):
        self.ms = {"Codex": {"name": "Codex", "kind": "cli", "remote": True, "auto": False},
                   "MiMo": {"name": "MiMo", "auto": True}, "DeepSeek": {"name": "DeepSeek", "auto": True}}
        self.enterContext(patch.object(s, "member", lambda n: self.ms.get(n)))

    def test_single_member_group_answers_even_if_manual(self):
        self.assertEqual(s.default_reply({"members": ["Codex"]}), ["Codex"])

    def test_lead_then_default_then_first_auto(self):
        p = {"members": ["Codex", "MiMo", "DeepSeek"]}
        self.assertEqual(s.default_reply(p), ["MiMo"])
        self.assertEqual(s.default_reply({**p, "default": "DeepSeek"}), ["DeepSeek"])
        self.assertEqual(s.default_reply({**p, "default": "DeepSeek", "lead": "Codex"}), ["Codex"])

    def test_deleted_members_and_empty_groups_get_nobody(self):
        self.assertEqual(s.default_reply({"members": ["Gone"]}), [])
        self.assertEqual(s.default_reply({"members": [], "lead": "Gone"}), [])

    def test_explicit_mention_still_wins(self):
        p = {"members": ["Codex", "MiMo"]}
        with patch.object(s, "member", lambda n: self.ms.get(n)):
            self.assertEqual(s.targets(p, "@MiMo 看下", ""), ["MiMo"])
