"""UI fix contracts: handlers isolated from server startup and persistent data."""
import ast
import asyncio
import datetime
import json
from pathlib import Path
import secrets
import time
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock
from aiohttp import web
import orchestra
import fix3


def handlers(data):
    source = ast.parse(Path(__file__).with_name('server.py').read_text())
    tree = ast.Module(body=[n for n in source.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in ('create_project', 'h_new_project')], type_ignores=[])
    state = dict(PROJECTS=[], CHATS={}, DATA=Path(data), datetime=datetime, secrets=secrets, time=time,
                 save=lambda *args: None, bump=lambda: None, member=lambda n: {'name': n} if n == 'ai' else None,
                 errors=SimpleNamespace(json_object=lambda req: req.json(), http_error=lambda cls, message, **kw: cls(text=message)),
                 web=web, json=json, asyncio=asyncio, fix3=fix3, __name__="isolated_projects")
    state["sys"] = SimpleNamespace(modules={"isolated_projects": SimpleNamespace(CFG={})})
    state['project'] = lambda pid: next(p for p in state['PROJECTS'] if p['id'] == pid)
    exec(compile(tree, '<isolated project handlers>', 'exec'), state)
    return state


class CreateContract(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    async def test_quality_and_idempotent_receipt(self):
        s = handlers(self.tmp.name)
        b = dict(name='项目', brief='', members=['ai'], mode='concerto', quality='max', client_id='same')
        req = SimpleNamespace(json=AsyncMock(return_value=b))
        first = json.loads((await s['h_new_project'](req)).text)
        second = json.loads((await s['h_new_project'](req)).text)
        self.assertEqual(first, second)
        # Persisted project state must retain the original idempotent receipt.
        s['PROJECTS'][:] = json.loads(json.dumps(s['PROJECTS']))
        self.assertEqual(first, json.loads((await s['h_new_project'](req)).text))
        self.assertEqual(first['id'], s['PROJECTS'][0]['id'])
        self.assertEqual(first, s['PROJECTS'][0]['create_receipt'])
        s['sys'].modules['isolated_projects'].CFG['account'] = {'caps': {'search': False}}
        s['PROJECTS'][0]['ask_first'] = True
        third = json.loads((await s['h_new_project'](req)).text)
        self.assertEqual(first, third)
        self.assertEqual(len(s['PROJECTS']), 1)
        self.assertEqual(s['PROJECTS'][0]['quality'], 'max')
        self.assertEqual(s['PROJECTS'][0]['budget']['cap'], 0)
        b['name'] = 'changed'
        with self.assertRaises(web.HTTPConflict):
            await s['h_new_project'](req)

    async def test_invalid_fields_are_400(self):
        cases = [dict(name=12), dict(members=[]), dict(members=['missing']), dict(mode='bad'), dict(quality='bad'),
                 dict(budget=float('nan')), dict(budget=float('inf')), dict(budget=-1), dict(budget=True), dict(brief=[])]
        for change in cases:
            with self.subTest(change=change):
                s = handlers(self.tmp.name)
                b = dict(name='项目', members=['ai'], mode='solo', **{})
                b.update(change)
                with self.assertRaises(web.HTTPBadRequest):
                    await s['h_new_project'](SimpleNamespace(json=AsyncMock(return_value=b)))
                self.assertEqual(s['PROJECTS'], [])


class QualityContract(unittest.TestCase):
    def test_max_picks_strongest_while_save_picks_cheapest(self):
        pool = [{'name': 'cheap', 'tier': 'weak'}, {'name': 'strong', 'tier': 'strong'}]
        self.assertEqual(orchestra.assign({'difficulty': 1, 'quality': 'save'}, pool), 'cheap')
        self.assertEqual(orchestra.assign({'difficulty': 1, 'quality': 'max'}, pool), 'strong')
        self.assertEqual(orchestra.assign({'difficulty': 1, 'quality': 'max'}, pool, {'strong': {'state': 'arrears'}}), 'cheap')


class ArtifactContent(unittest.IsolatedAsyncioTestCase):
    async def test_reads_actual_file_bytes_and_blocks_secret(self):
        import collab_api
        from unittest.mock import patch
        import artifacts
        store = SimpleNamespace(get=AsyncMock(return_value=SimpleNamespace(id='a', bytes=3, origin_path='/files/a.txt', mime='text/plain')),
                                read_blob=AsyncMock(return_value=b'abc'))
        req = SimpleNamespace(match_info={'pid': 'p', 'aid': 'a'})
        with patch.object(collab_api, '_store', return_value=store):
            result = json.loads((await collab_api.h_artifact_content(req)).text)
            self.assertEqual(result['base64'], 'YWJj')
            self.assertEqual(result['name'], 'a.txt')
            store.read_blob.side_effect = artifacts.ArtifactError('secret')
            with self.assertRaises(web.HTTPForbidden):
                await collab_api.h_artifact_content(req)
