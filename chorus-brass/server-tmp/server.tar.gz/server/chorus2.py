"""chorus2 glue: wires the deterministic engines (orchestra, quota_probes, redline, recovery, autopilot, wakegraph,
capabilities, nocturne) into the running server. Everything here is server-side and costs no tokens except the
explicit model calls of the 协奏 engine (plan by 指挥, execute by 声部, review by 指挥)."""
import asyncio
import background
import contextvars
import json
import logging
import re
import secrets
import sys
import time
from asyncio import sleep

import api_errors as errors

from aiohttp import ClientSession, ClientTimeout, web

import autopilot
import capabilities
import collab_runtime
import cli_quota
import designopts
import nocturne
import orchestra
import quota_probes
import recovery
import redline
import wakegraph

S = None  # the server module
GRAPH = wakegraph.Graph()
HISTORY = {}   # pid -> [(ts, pct)]
LAST_HEADERS = {}  # member -> headers of its last API reply
LAST_ERROR = {}    # member -> {"status","body","at"}
INVITES = {}       # code -> {"expires", "name"}
RUNNING = {}       # pid -> asyncio.Task of the 协奏 loop
PLANNING = {}      # pid -> server-owned task, shielded from request cancellation
LOW_CALLS = {}     # member -> monotonic request timestamps
LOW_BACKOFF = {}   # member -> monotonic retry time
STATE_AT = {}  # member -> when MEMBER_STATE was set; broken/resting expire after CFG["recover_after"] seconds
MEMBER_STATE = {}  # member -> "resting" | "cooldown" | "broken" (set by the failure engine, cleared on success)
STATE_REASON = {}  # member -> plain-Chinese reason for its availability state
LEAD_BUSY = {}  # pid -> count of 指挥 calls in flight (hand-back waits for 0)
CONSENT = {}       # approval id -> {"line", "pid", "who"}
POLICY_CHOICES = ("ask", "auto", "deny")


SHARED_IMAGES = contextvars.ContextVar("shared_images", default=())
SEGMENT_CWD = contextvars.ContextVar("segment_cwd", default=None)
WORKSPACES = {}


ROLE = contextvars.ContextVar("chorus_role", default="chat")  # plan | execute | review | chat


# ---------------------------------------------------------------- helpers
def members():
    return S.CFG.get("members", [])


def proj(pid):
    p = S.project(pid)
    if not p:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    p.setdefault("mode", "concerto")
    p.setdefault("segments", [])
    return p


def save_projects():
    __import__("subprojects").report_completed(S)
    S.save(S.DATA / "projects.json", S.PROJECTS)


def price_of(m):
    return S.price(m, m.get("model", "")) if m else None


def stats():
    return S.CFG.setdefault("member_stats", {})


def view(pid):
    p = S.project(pid)
    if not p:
        return None
    p.setdefault("segments", [])
    ms = {}
    for st in GRAPH.steps(pid).items():
        name, v = st
        seg = next((x for x in p["segments"] if x.get("id") == v.get("seg")), None)
        ms[name] = {"stage": v.get("step", ""), "segment": v.get("seg", ""), "pct": orchestra.segment_pct(seg) if seg else 0}
    snap = orchestra.snapshot(p, ms, HISTORY.get(pid, []))
    snap["pending"] = [d if d.get("options") or d.get("kind") not in CARD_OPTIONS else {**d, "options": CARD_OPTIONS[d["kind"]], "recommended": 0}
                       for d in p.get("pending", []) if d.get("state", "open") == "open"]   # 旧卡没有选项：补上，免得点不动
    snap["flow"] = GRAPH.flow(pid, 30)
    snap["cost_split"] = p.get("cost_split", {})
    snap["parent"] = p.get("parent")
    snap["children"] = __import__("subprojects").children(S, pid)
    snap["planning"] = p.get("planning", "idle")
    snap["assignment_events"] = p.get("assignment_events", [])
    for sv, seg in zip(snap["segments"], p["segments"]):
        sv.update(assignment_version=seg.get("assignment_version", 0), skill_load=seg.get("skill_load"), goal=seg.get("goal", ""), deliverable=seg.get("deliverable", ""), acceptance=seg.get("acceptance", []),
                  verification=seg.get("verification"), acceptance_checked=seg.get("acceptance_checked", []),
                  inputs=seg.get("inputs", []), events=[[e.get("at"), e.get("text")] for e in (seg.get("events") or [])[-20:]])
    return snap


def _thread(mid, title, segs, live, paused=False):
    done = sum(1 for x in segs if x.get("stage") == "done")
    outs = [a for x in segs for a in (x.get("artifacts") or [])]
    pending = sum(1 for x in segs if x.get("stage") == "blocked")
    if segs and done == len(segs):
        state = "resolved"
    elif live and not paused and any(x.get("stage") in ("running", "waiting", "review", "rework") for x in segs):
        state = "active"
    else:
        state = "idle"
    return {"id": mid, "title": title, "state": state, "tasks_done": done, "tasks": len(segs), "outputs": len(outs),
            "pending": pending, "pct": round(sum(orchestra.segment_pct(x) for x in segs) / len(segs), 1) if segs else 0,
            "items": [{"id": x["id"], "title": x.get("title", ""), "stage": x.get("stage", ""), "assignee": x.get("assignee", ""),
                       "pct": orchestra.segment_pct(x), "artifacts": x.get("artifacts") or []} for x in segs]}


def overview(pid):
    """讨论串 (乐章 grouped 进行中/空闲/已解决), 资料库 (every artifact), PR (links found in artifacts/results)."""
    p = S.project(pid)
    if not p:
        return None
    threads = [_thread(m["id"], m.get("title", ""), m.get("segments", []), False) for m in p.get("movements", [])]
    if p.get("segments"):
        threads.append(_thread(p.get("movement_id", "m1"), p.get("movement_title") or (p.get("brief") or "")[:24], p["segments"], True, p.get("paused")))
    lib = [{"path": a, "thread": t["id"], "task": it["id"], "by": it["assignee"]} for t in threads for it in t["items"] for a in it["artifacts"]]
    prs = [x for x in lib if re.search(r"github\.com/[^/]+/[^/]+/pull/\d+", x["path"])]
    groups = {k: [t for t in threads if t["state"] == k] for k in ("active", "idle", "resolved")}
    return {"threads": groups, "library": [x for x in lib if x not in prs], "prs": prs}


async def h_overview(request):
    v = overview(request.match_info["pid"])
    if v is None:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    return web.json_response(v)


def reply_to(pid, who, trig):
    """The member's reply to this exact trigger: prefer the server's reply_to link, else the first reply after it."""
    msgs = S.CHATS.get(pid, [])
    mine = [x for x in msgs if x.get("who") == who and x.get("seq", 0) > trig.get("seq", 0)]
    linked = [x for x in mine if x.get("reply_to") == trig.get("seq")]
    return (linked or mine[:1] or [None])[0]


def touch(pid):
    p = S.project(pid)
    if p:
        h = HISTORY.setdefault(pid, [])
        h.append((time.time(), orchestra.project_pct(p)))
        del h[:-200]
    S.bump(pid)


def event(seg, text):
    ev = seg.setdefault("events", [])
    ev.append({"at": time.time(), "kind": "log", "text": text})
    del ev[:-50]


# ---------------------------------------------------------------- quota (all members, every access type)
def ctx_for(session):
    def spent_tokens(name):
        sp = S.load(S.spend_file(), {}).get(name, {})
        return sum(d.get("in", 0) + d.get("out", 0) for d in sp.values())
    def spent_money(pid, cur):
        return S.spent_total(pid, cur)
    def read_file(path):
        import pathlib
        try:
            return pathlib.Path(path).expanduser().read_text(errors="replace")
        except OSError:
            return None
    c = quota_probes.Ctx(session, spent_tokens=spent_tokens, spent_money=spent_money,
                         last_headers=lambda n: LAST_HEADERS.get(n), last_error=lambda n: LAST_ERROR.get(n),
                         read_file=read_file)
    c.cmd_json = cli_quota.cached
    c.calls_today = lambda n: int((S.load(S.spend_file(), {}).get(n, {}).get(S.today()) or {}).get("n", 0))
    c.acp_limits = lambda n: __import__("adapters").LIMITS.get(n)   # Codex rate limits seen over ACP  # subscription windows read through each vendor's own CLI
    return c


QUOTA2 = {}


async def refresh_one(m):
    """Re-probe one member now (a connector just reported its CLI limits)."""
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        q = await quota_probes.probe(S.provider(m.get("provider")) or {}, m, ctx_for(s))
    if S.member_alive(m["name"]):   # 查询途中被删的声部不能再写回来
        QUOTA2[m["name"]] = q
    S.bump()


async def refresh_all():
    import connect
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=20)) as s:
        ctx = ctx_for(s)
        for m in list(members()):
            if m.get("kind") == "cli" and not m.get("remote") and cli_quota.which(m) in ("claude", "gemini", "agy", "dsh"):
                try:
                    await cli_quota.refresh(m)
                except Exception as e:  # noqa: BLE001 - a CLI that fails to report leaves 未知, never blocks others
                    print("cli quota", m.get("name"), type(e).__name__)
            pr = S.provider(m.get("provider")) or {}
            try:
                q = await quota_probes.probe(pr, m, ctx)
                if not S.member_alive(m["name"]):
                    continue
                QUOTA2[m["name"]] = q
                if q and q.get("state") not in ("arrears", "unknown") and MEMBER_STATE.get(m["name"]) == "resting":
                    MEMBER_STATE.pop(m["name"], None)  # balance is back
            except Exception as e:  # noqa: BLE001 - one provider must never hide the others
                print("probe", m.get("name"), type(e).__name__)
            connect.remote_status(m["name"])
    S.bump()
    retry_unavailable()


def note_reply(name, status=None, headers=None, body=""):
    """Called after every model call: headers feed the quota chain; error codes mark 欠费 at once."""
    if headers:
        LAST_HEADERS[name] = dict(headers)
    if status and status >= 400:
        LAST_ERROR[name] = {"status": status, "body": body[:400], "at": time.time()}
        pr = S.provider((S.member(name) or {}).get("provider")) or {}
        q = quota_probes.from_error(status, body, quota_probes.provider_cur(pr), quota_probes.is_plan(pr))
        if q:
            QUOTA2[name] = q
            S.bump()


async def h_quota_all(request):
    if request.method == "POST" or not QUOTA2 or any(m["name"] not in QUOTA2 for m in members()):
        await refresh_all()   # 新接入的成员还没探测过：现在就探，额度页不能空着
    import connect
    quotas = connect.quota_view(QUOTA2, (m["name"] for m in members()))
    return web.json_response({"members": quotas, "at": time.time()})


async def quota_loop():
    while True:
        try:
            await refresh_all()
        except Exception as e:  # noqa: BLE001
            print("quota2", type(e).__name__)
        await asyncio.sleep(S.CFG.get("quota_every", 300))


# ---------------------------------------------------------------- red lines + per-member policy
def policy_of(name):
    m = S.member(name) or {}
    return m.get("policy") or {}


def workspaces(pid, who):
    """Folders a member may freely change: its 乐章 work dir and the project's own folder."""
    out = [str(S.DATA / "work")]
    p = S.project(pid) if pid else None
    if p and p.get("folder"):
        out.append(p["folder"])
    m = S.member(who) or {}
    if m.get("cwd"):
        out.append(m["cwd"])
    return out


def gate(tool, inp, who, pid=""):
    """allow / ask / deny for one tool call, per red line and the member's own policy.
    illegal is always deny; a red line is ask unless the member's policy says auto (logged) or deny."""
    v = redline.check(tool, inp or {}, {"data_dir": str(S.DATA), "workspaces": workspaces(pid, who)})
    if v.action == "deny":
        return "deny", v
    if v.action == "ask" and v.line in ((S.project(pid) or {}).get("grants") or {}).get(who, []):
        log(pid, who, f"按本乐章授权同意（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}")
        return "allow", v
    if v.action == "ask" and night_covers(pid, v.line):
        log(pid, who, f"夜间代批（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}", night=True)
        return "allow", v
    if v.action == "ask":
        choice = policy_of(who).get(v.line, "ask")
        if choice == "auto" and v.line == "money":
            # 花钱只在金额明确且不超过这个声部的 spend_auto 时自动同意，否则问用户
            cap = float((S.member(who) or {}).get("spend_auto") or 0)
            nums = [float(x) for x in re.findall(r"(?:[¥$￥]|amount[=:]?\s*)\s*(\d+(?:\.\d+)?)", S.approval_summary(tool, inp))]
            if cap <= 0 or not nums or max(nums) > cap:
                return "ask", v
        if choice == "auto":
            log(pid, who, f"自动同意（{redline.LINES.get(v.line, v.line)}）：{redline.scrub(S.approval_summary(tool, inp))[:120]}")
            return "allow", v
        return ("deny" if choice == "deny" else "ask"), v
    return "allow", v


def grant(pid, who, line):
    """'Always allow this category for this member within this 乐章' — never the illegal bottom line."""
    p = S.project(pid)
    if not p or line == "illegal" or line not in redline.LINES:
        return False
    g = p.setdefault("grants", {}).setdefault(who, [])
    if line not in g:
        g.append(line)
    log(pid, "你", f"本乐章里 {who} 的「{redline.LINES[line]}」以后都同意")
    save_projects()
    return True


def log(pid, who, text, night=False):
    if pid:
        S.CFG.setdefault("audit", []).append({"at": time.time(), "pid": pid, "who": who, "text": text, **({"night": True} if night else {})})
        del S.CFG["audit"][:-2000]


# ---------------------------------------------------------------- 夜曲 night grant (user-confirmed scope)
def local_hour(now=None):
    return time.gmtime((now or time.time()) + S.CFG.get("tz", 8) * 3600).tm_hour


def night_covers(pid, line, now=None):
    """True when 夜曲 is on for this 乐章 with a confirmed grant, we are inside its window, the line is granted,
    and (for money) the night spend cap still has room. The illegal bottom line is never covered."""
    if not pid or line == "illegal":
        return False
    p = S.project(pid) or {}
    g = p.get("night") or {}
    if not (g.get("enabled") and g.get("confirmed_at")) or line not in g.get("lines", []):
        return False
    start, end = g.get("window", [23, 7])
    h = local_hour(now)
    inside = (start <= h < end) if start < end else (h >= start or h < end)
    if not inside:
        return False
    if line == "money" and g.get("spent", 0) >= g.get("spend_cap", 0):
        return False
    return True


def night_text(g):
    names = "、".join(redline.LINES.get(x, x) for x in g.get("lines", [])) or "（无）"
    w = g.get("window", [23, 7])
    return (f"开启夜曲后，每天 {w[0]:02d}:00–{w[1]:02d}:00 我会替你同意以下类别：{names}；"
            f"夜间花费上限 ¥{float(g.get('spend_cap') or 0):g}。违法和底线动作仍然一律拦下。"
            f"所有代批都记进场记，并写进早上的序曲。")


async def h_night(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    g = p.setdefault("night", {"enabled": False, "lines": [], "spend_cap": 0, "window": [23, 7]})
    if request.method == "PUT":
        b = await errors.json_object(request)
        lines = [x for x in (b.get("lines") or []) if x in redline.LINES and x != "illegal"]
        win = b.get("window", g["window"])
        if not (isinstance(win, list) and len(win) == 2 and all(isinstance(x, int) and 0 <= x < 24 for x in win)):
            return web.json_response({"error": "时间窗不对", "fix": "settings"}, status=400)
        new = {"lines": lines, "spend_cap": max(0.0, float(b.get("spend_cap") or 0)), "window": win}
        if b.get("enabled"):
            if b.get("confirm") != night_text(new):  # the client must echo the exact text the user saw and confirmed
                return web.json_response({"error": "需要先确认", "fix": "none", "confirm": night_text(new)}, status=409)
            keep = float(g.get("spent") or 0) if g.get("enabled") and time.time() - (g.get("confirmed_at") or 0) < 86400 else 0.0
            g.update(new, enabled=True, confirmed_at=time.time(), spent=keep)
            log(pid, "你", "开启夜曲代批：" + night_text(new))
        else:
            g.update(new, enabled=False, confirmed_at=None)
        save_projects()
        touch(pid)
    return web.json_response({**g, "confirm": night_text(g), "lines_all": {k: v for k, v in redline.LINES.items() if k != "illegal"}})


def night_report(pid, since):
    """For the morning 序曲: every auto-approval made overnight."""
    return [a for a in S.CFG.get("audit", []) if a.get("pid") == pid and a.get("night") and a["at"] >= since]


async def h_overture(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    since = float(request.query.get("since") or time.time() - 12 * 3600)
    done = [{"title": x.get("title"), "summary": x.get("summary", ""), "by": x.get("assignee")} for x in p["segments"]
            if x.get("stage") == "done" and (x.get("done_at") or 0) >= since]
    pend = [d for d in p.get("pending", []) if d.get("state", "open") == "open"]
    approvals = night_report(pid, since)
    recs = [{"member": a["who"], "ok": True} for a in approvals]
    o = nocturne.Overture.build(recs, pend, done, {"total": orchestra.budget_state(p)["spent"]}, time.strftime("%m-%d"))
    o["night_approvals"] = [{"at": a["at"], "who": a["who"], "text": a["text"]} for a in approvals]
    return web.json_response(o)


async def h_policy(request):
    name = request.match_info["name"]
    m = S.member(name)
    if not m:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if request.method == "PUT":
        b = await errors.json_object(request)
        pol = m.setdefault("policy", {})
        if b.get("preset") == "all":   # 全部同意（底线除外）
            for line in redline.LINES:
                if line != "illegal":
                    pol[line] = "auto"
            S.CFG.setdefault("audit", []).append({"at": time.time(), "pid": "", "who": "你", "text": f"{name}：全部同意（底线除外）"})
        for line, choice in (b.get("policy") or {}).items():
            if line == "illegal":
                continue  # the bottom line is never configurable
            if line in redline.LINES and choice in POLICY_CHOICES:
                pol[line] = choice
        if "spend_auto" in b:
            v = float(b["spend_auto"] or 0)
            if v < 0:
                return web.json_response({"error": "金额不能是负数", "fix": "settings"}, status=400)
            m["spend_auto"] = v
        S.save_cfg()
        S.bump()
    return web.json_response({"policy": {k: (m.get("policy") or {}).get(k, "ask") for k in redline.LINES if k != "illegal"},
                              "lines": redline.LINES, "spend_auto": m.get("spend_auto", 0)})


async def h_audit(request):
    pid = request.match_info["pid"]
    return web.json_response({"items": [a for a in S.CFG.get("audit", []) if a.get("pid") == pid][-300:]})


# ---------------------------------------------------------------- CLI wrapper
_BYPASS = [
    (r"\s--dangerously-skip-permissions(?:=\S*)?(?=\s|$)", ""),
    (r"\s--dangerously-bypass-approvals-and-sandbox(?:=\S*)?(?=\s|$)", ""),
    (r"\s--yolo(?:=\S*)?(?=\s|$)", ""),
    (r"\s--permission-mode[ =](?:bypassPermissions|acceptEdits)\b", ""),
    (r"\s(?:-a|--ask-for-approval)[ =]never\b", " -a on-request"),
    (r"\s--full-auto(?:=\S*)?(?=\s|$)", ""),
    (r"\s-c\s+approval_policy=\S+", ""),
]


def cli_guard(cmd):
    """CLI members must route every tool request to /approve/ask (red lines + their own permission settings).
    Flags that would let a CLI approve itself are removed; what the member may auto-approve lives in its policy."""
    import re
    out = " " + cmd
    hits = []
    for pat, rep in _BYPASS:
        out, n = re.subn(pat, rep, out)
        if n:
            hits.append(pat)
    return out[1:], bool(hits)


# ---------------------------------------------------------------- invites (一次性邀请码，10 分钟)
async def h_invite(request):
    now = time.time()
    for k in [k for k, v in INVITES.items() if v["expires"] < now]:
        INVITES.pop(k, None)
    if len(INVITES) >= 20:
        return web.json_response({"error": "未用的邀请码太多了，等几分钟再发", "fix": "retry"}, status=429)
    code = "".join(secrets.choice("23456789ABCDEFGHJKMNPQRSTUVWXYZ") for _ in range(6))
    INVITES[code] = {"expires": time.time() + 600}
    base = request.headers.get("X-Forwarded-Prefix", "")
    url = f"{request.scheme}://{request.host}{base}/api/invite/redeem"
    return web.json_response({"code": code, "expires_in": 600, "http": url,
                              "cmd": f"curl -s -X POST {url} -H 'Content-Type: application/json' -d '{{\"code\":\"{code}\",\"name\":\"你的名字\",\"provider\":\"服务器上已有的接口 id\",\"model\":\"模型名\"}}'",
                              "mcp": {"server": url, "code": code}})


async def h_redeem(request):
    if S.auth_throttled(request):
        return web.json_response({"error": "试得太频繁了，请一分钟后再试", "fix": "retry"}, status=429)
    b = await errors.json_object(request)
    inv = INVITES.pop(str(b.get("code", "")).upper(), None)
    if not inv or inv["expires"] < time.time():
        S.auth_throttled(request, record=True)
        return web.json_response({"error": "邀请码无效或已过期", "fix": "retry"}, status=403)
    if b.get("cmd") or b.get("kind") in ("cli", "dsh"):
        # 邀请码不登录就能用：不许对方提交要在本机执行的命令，命令行 AI 请走「接入口令」（它在对方机器上跑）
        INVITES[str(b.get("code", "")).upper()] = inv
        return web.json_response({"error": "邀请码只能接入 API 声部；命令行 AI 请在 App 里生成「接入口令」", "fix": "none"}, status=400)
    name = (b.get("name") or "").strip()[:24]
    import re
    if not re.fullmatch(r"[\w\u4e00-\u9fff .·-]{1,24}", name or ""):
        return web.json_response({"error": "名字只能用文字、数字、空格和 .·-", "fix": "none"}, status=400)
    if not name or S.member(name):
        return web.json_response({"error": "名字为空或已被占用", "fix": "none"}, status=409)
    m = {"name": name, "kind": "api", "auto": True}
    for k in ("model", "provider"):
        if b.get(k):
            m[k] = str(b[k])[:400]
    S.CFG["members"].append(m)
    S.join_member(name)
    S.save(S.DATA / "projects.json", S.PROJECTS)
    S.save_cfg()
    S.bump()
    retry_unavailable()
    return web.json_response({"ok": True, "member": name})


# ---------------------------------------------------------------- 最近删除
async def h_trash(request):
    if request.method == "GET":
        return web.json_response({"items": [{"id": p["id"], "name": p["name"], "deleted": p.get("deleted_at", 0)}
                                            for p in S.PROJECTS if p.get("archived") and not p.get("deleted_with")]})  # 随主项删的子项不单独列
    pid = request.match_info["pid"]
    p = S.project(pid)
    if not p or not p.get("archived"):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    kids = S.descendants(pid)
    if request.method == "POST":
        for q in [p, *(k for k in kids if k.get("deleted_with") == pid)]:   # 恢复主项时，跟它一起删的子项也回来
            q.pop("archived", None)
            q.pop("deleted_at", None)
            q.pop("deleted_with", None)
    else:  # DELETE: gone for good, only by the user from 最近删除；子项跟着一起彻底删
        for q in [p, *kids]:
            if q in S.PROJECTS:
                S.PROJECTS.remove(q)
            HISTORY.pop(q["id"], None)
            S.CHATS.pop(q["id"], None)
            t = RUNNING.pop(q["id"], None)
            if t:
                t.cancel()
    save_projects()
    S.bump()
    return web.json_response({"ok": True, "index": S.index_view()})


# ---------------------------------------------------------------- 协奏 engine
class NeedsConsent(RuntimeError):
    """这个模型第一次用这把 key，还没被允许：不是坏了，只是先换人。"""


async def ask_model(m, system, prompt, pid=None):
    import collab_api
    if collab_api.consent_block(m):   # 指挥直连也要过定音，不能绕开允许卡片
        e = NeedsConsent(f"{m.get('name')} 第一次使用这把 key，等你允许")
        e.member = m
        raise e
    if pid and (child := S.project(pid)) and child.get("parent"):
        system += "\n子项交接上下文：" + __import__("subprojects").execution_context(child)
    why = account_block()
    if why:
        raise RuntimeError(why)
    reserve_low(m)
    r = {"who": m["name"], "text": "", "note": ""}
    await S.call_api(None, m, r, system, prompt, m.get("model", ""), "")
    if r.get("usage"):
        S.record_usage(m, m.get("model", ""), r["usage"], pid)  # direct 指挥 calls are billed like any reply
    return r["text"]


# ---------------------------------------------------------------- spend: role split + account caps
def on_usage(m, u, pid):
    cost = float(u.get("cost") or 0)
    cur = u.get("cur", "¥")
    name = m.get("name", "") if isinstance(m, dict) else str(m or "")
    if name:   # per-member metrics (calls, tokens, spend by currency, role mix)
        mt = stats().setdefault(name, {})
        mt["calls"] = mt.get("calls", 0) + 1
        mt["in"] = mt.get("in", 0) + int(u.get("in", 0) or 0)
        mt["out"] = mt.get("out", 0) + int(u.get("out", 0) or 0)
        if cost:
            mt.setdefault("cost", {})[cur] = round(mt.get("cost", {}).get(cur, 0) + cost, 5)
        mt.setdefault("roles", {})[ROLE.get()] = mt.get("roles", {}).get(ROLE.get(), 0) + 1
        mt["last"] = time.time()
    if cost:  # persisted per-minute buckets: caps survive restarts and never lose old entries
        bk = S.CFG.setdefault("spend_buckets", {})
        mk = str(int(time.time() // 60))
        bk.setdefault(mk, {})
        bk[mk][cur] = round(bk[mk].get(cur, 0) + cost, 6)
        if len(bk) > 1600:
            for k in sorted(bk, key=int)[:len(bk) - 1500]:
                bk.pop(k)
    p = S.project(pid) if pid else None
    if p is not None:
        warnings = {"pricing_missing": u.get("pricing_warning")}
        budget_cur = (p.get("budget") or {}).get("cur", "¥")
        if cost and cur != budget_cur:
            warnings["currency_mismatch"] = f"此 API 声部按 {cur} 计费，与项目预算币种 {budget_cur} 不同；请统一币种后使用预算上限，当前费用仅记入对应币种账本。"
        miss = next((d for d in p.get("pending", []) if d.get("kind") == "pricing_missing" and d.get("state") == "open"), None)
        if warnings.get("pricing_missing") and miss is not None:
            # 缺价格合成一张卡，列出所有缺价格的声部，不一个模型弹一张
            names = miss.setdefault("members", [miss.get("member", "")])
            if name not in names:
                names.append(name)
                miss["question"] = f"{len(names)} 个 API 声部缺少价格（{'、'.join(names[:6])}{'…' if len(names) > 6 else ''}），当前只统计用量，预算无法准确扣费；请在接口设置里填写输入、输出单价。"
            warnings["pricing_missing"] = ""
        for kind, warning in warnings.items():
            if warning and not any(d.get("kind") == kind and d.get("member") == name and d.get("state") == "open" for d in p.get("pending", [])):
                p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": kind, "member": name,
                    "question": warning, "options": CARD_OPTIONS[kind], "recommended": 0, "deadline": None, "state": "open"})
        g = p.get("night") or {}
        if cost and g.get("enabled") and night_covers(pid, "money"):
            g["spent"] = round(float(g.get("spent") or 0) + cost, 5)  # night spend counts against the grant's cap
        role = ROLE.get()
        row = p.setdefault("cost_split", {}).setdefault(role, {"in": 0, "out": 0, "cost": {}})
        row["in"] += u.get("in", 0)
        row["out"] += u.get("out", 0)
        if cost:
            row["cost"][cur] = round(row["cost"].get(cur, 0) + cost, 5)


def account_spent(window, cur="¥", now=None):
    """Spend in the last window seconds (1-minute resolution), from persisted buckets."""
    now = now or time.time()
    lo, hi = int((now - window) // 60), int(now // 60)
    return sum(v.get(cur, 0) for k, v in (S.CFG.get("spend_buckets") or {}).items() if lo < int(k) <= hi)


def account_block(now=None):
    """'' when under the account caps, else the reason. Caps: CFG.account_caps = {hour, day, cur}; 0 = no cap."""
    caps = S.CFG.get("account_caps") or {}
    cur = caps.get("cur", "¥")
    for key, window, label in (("hour", 3600, "每小时"), ("day", 86400, "每天")):
        cap = float(caps.get(key) or 0)
        if cap > 0 and account_spent(window, cur, now) >= cap:
            return f"账号{label}花费已到上限 {cur}{cap:g}"
    return ""


async def h_caps_account(request):
    if request.method == "PUT":
        b = await errors.json_object(request)
        caps = S.CFG.setdefault("account_caps", {})
        for k in ("hour", "day"):
            if k in b:
                v = float(b[k] or 0)
                if v < 0:
                    return web.json_response({"error": "上限不能是负数", "fix": "settings"}, status=400)
                caps[k] = v
        if b.get("cur"):
            caps["cur"] = str(b["cur"])[:3]
        S.save_cfg()
        S.bump()
    caps = S.CFG.get("account_caps") or {}
    cur = caps.get("cur", "¥")
    return web.json_response({**caps, "spent_hour": round(account_spent(3600, cur), 4), "spent_day": round(account_spent(86400, cur), 4),
                              "blocked": account_block(), **__import__("fix3").week_spend(S, cur)})


def guard_run_member(orig):
    """Every wake (user @, AI @, 协奏 dispatch, 节拍器) passes the account cap first."""
    async def run(pid, name, trigger, opts):
        why = account_block()
        if why:
            S.add_msg(pid, "系统", f"没有叫醒 {name}：{why}，调高上限或等下一个时段", folded=True)
            log(pid, "调度", f"拦下唤醒 {name}：{why}")
            return None
        mem = next((m for m in members() if m.get("name") == name), {})
        import collab_api
        blocked = collab_api.consent_block(mem)
        if blocked:
            if blocked == "pending":
                collab_api.consent_card(pid, mem, f"{name} 第一次用这把 key，要你允许一次。点「允许」后它马上接着回。")
            else:
                S.add_msg(pid, "系统", f"{name} 的模型被你拒绝了，没有叫醒它", folded=True)
            log(pid, "定音", f"拦下唤醒 {name}：{blocked}")
            if blocked == "pending":   # 记下这次唤醒：一点允许就接着跑，不用用户再发一遍
                seq = (trigger or {}).get("seq") if isinstance(trigger, dict) else None
                CONSENT_WAITS[:] = [w for w in CONSENT_WAITS if not (w[0] == pid and w[1] == name and w[5] == seq) and time.time() - w[4] < 3600]
                CONSENT_WAITS.append((pid, name, trigger, opts, time.time(), seq, run))
            return None
        reserve_low(mem)
        return await orig(pid, name, trigger, opts)
    run.guarded = True
    return run


def mark(name, state, reason=""):
    MEMBER_STATE[name] = state
    STATE_AT[name] = time.time()
    if reason:
        STATE_REASON[name] = reason
    else:
        STATE_REASON.pop(name, None)


def healthy(name):
    """Quota not in arrears, and not inside a broken/resting window (which expires so members can recover)."""
    import connect
    if connect.remote_status(name):
        return False
    if (QUOTA2.get(name) or {}).get("state") == "arrears":
        return False
    st = MEMBER_STATE.get(name)
    if st in ("broken", "resting", "cooldown"):
        if time.time() - STATE_AT.get(name, 0) < S.CFG.get("recover_after", 900):
            return False
        MEMBER_STATE.pop(name, None)
    return True


def lead_ok(name):
    return bool(S.member(name)) and healthy(name)


def handover_context(p):
    """What the next 指挥 needs: the plan, where every 段落 stands, and the last 场记 lines."""
    rows = [f"{x['id']} {x.get('title','')}｜{x.get('stage')}｜{x.get('assignee') or '-'}｜{(x.get('summary') or '')[:60]}" for x in p.get("segments", [])]
    logs = [a["text"] for a in S.CFG.get("audit", []) if a.get("pid") == p["id"]][-8:]
    return "【交接】需求：" + (p.get("brief") or "")[:400] + "\n谱稿：\n" + "\n".join(rows) + ("\n场记：\n" + "\n".join(logs) if logs else "")


def promote(pid, why, exclude=()):
    """Members are peers; the 指挥 seat moves to the next strongest available member. Returns the new lead or None."""
    p = proj(pid)
    old = p.get("lead_resolved", "")
    out = set(p.setdefault("lead_out", []))
    if old:
        out.add(old)
    cand = [m for m in (candidates(p) or members()) if m["name"] not in out and m["name"] not in exclude and lead_ok(m["name"])]
    if not cand:
        p["lead_resolved"] = ""
        log(pid, "调度", f"指挥 {old or '-'} 失效（{why}），没有可接任的成员")
        return None
    new = orchestra.pick_lead({**p, "lead": ""}, cand, QUOTA2, stats())
    if not new or new in out:
        new = cand[0]["name"]
    p["lead_out"] = sorted(out)
    if old and not p.get("lead_home"):
        p["lead_home"] = old  # the original seat holder gets it back once healthy
    p["lead_resolved"] = new
    p["handover"] = {"from": old, "to": new, "why": why, "at": time.time(), "context": handover_context(p)}
    S.add_msg(pid, "系统", f"指挥交接：{old or '-'} → {new}（{why}）", handover=True)
    if old:
        GRAPH.record(f"{pid}:lead", pid, old, new, "handover", "", why)
    log(pid, "调度", f"指挥交接 {old or '-'} → {new}：{why}")
    save_projects()
    touch(pid)
    return S.member(new)


def maybe_handback(pid):
    """At a safe point (no 指挥 call in flight, a card just finished): return the seat to the original 指挥 once it is healthy."""
    p = proj(pid)
    home, cur = p.get("lead_home"), p.get("lead_resolved")
    if not home or home == cur or not lead_ok(home) or LEAD_BUSY.get(pid):
        return False
    p["lead_out"] = [x for x in p.get("lead_out", []) if x != home]
    p.pop("lead_home", None)
    p["lead_resolved"] = home
    p["handover"] = {"from": cur, "to": home, "why": "原指挥已恢复", "at": time.time(), "context": handover_context(p)}
    S.add_msg(pid, "系统", f"指挥交还：{cur or '-'} → {home}（原指挥已恢复）", handover=True)
    GRAPH.record(f"{pid}:lead", pid, cur or "调度", home, "handover", "", "原指挥已恢复")
    log(pid, "调度", f"指挥交还 {cur or '-'} → {home}")
    save_projects()
    touch(pid)
    return True


_FAMILIES = ("claude", "gpt", "o1", "o3", "codex", "gemini", "deepseek", "glm", "kimi", "qwen", "mimo", "doubao", "grok", "llama", "mistral", "minimax")


def model_family(m):
    """模型家族：用模型名（CLI 声部用命令）里的厂商词判断，判断不了就用成员名，保证至少不会和自己归为一家。"""
    text = " ".join(str((m or {}).get(k) or "") for k in ("model", "cmd", "provider")).lower()
    for f in _FAMILIES:
        if f in text:
            return {"o1": "gpt", "o3": "gpt", "codex": "gpt"}.get(f, f)
    return "name:" + str((m or {}).get("name") or "")


def prefer_other_family(pool, who_member):
    """审核人优先挑和执行者不同家族的；没有再退回同家族（独立成员）。"""
    fam = model_family(who_member)
    return sorted(pool, key=lambda m: model_family(m) == fam)


def lead_member(p):
    name = p.get("lead_resolved", "")
    if name and lead_ok(name):
        return S.member(name)
    if name:  # seat holder went bad between calls (arrears / broken / removed)
        return promote(p["id"], "额度不足" if (QUOTA2.get(name) or {}).get("state") == "arrears" else "不可用")
    cand = [m for m in (candidates(p) or members()) if lead_ok(m["name"]) and m["name"] not in p.get("lead_out", [])]
    if not cand:
        return None
    pick = p.get("lead") if p.get("lead") in [m["name"] for m in cand] else orchestra.pick_lead(p, cand, QUOTA2, stats())
    p["lead_resolved"] = pick
    return S.member(pick)


async def lead_call(pid, fn, what):
    """Run fn(lead) with automatic handover on failure (error, timeout, no quota). At most every peer once."""
    p = proj(pid)
    for _ in range(len(members()) + 1):
        lead = lead_member(p)
        if not lead:
            raise RuntimeError("没有可用的指挥")
        LEAD_BUSY[pid] = LEAD_BUSY.get(pid, 0) + 1
        try:
            default_timeout = None if lead.get("kind") in ("cli", "dsh") else 240   # N20：API 指挥 4 分钟没交就换人
            return lead, await asyncio.wait_for(fn(lead), S.CFG.get("lead_timeout", default_timeout) or None)
        except asyncio.TimeoutError:
            why = f"{what}超时"
        except NeedsConsent as e:
            # 不是坏了：先换一个已经允许过的首席；都没允许就整体等你允许（允许后自动接着做）
            import collab_api
            ok = [m for m in (candidates(p) or members()) if m["name"] != lead["name"] and lead_ok(m["name"]) and not collab_api.consent_block(m)]
            if not ok:
                raise
            new = orchestra.pick_lead({**p, "lead": ""}, ok, QUOTA2, stats()) or ok[0]["name"]
            p["lead_resolved"] = new
            log(pid, "调度", f"{str(e)[:40]}，先由 {new} 当首席")
            continue
        except Exception as e:  # noqa: BLE001 - any failure moves the seat
            why = f"{what}失败：{str(e)[:60]}"
        finally:
            LEAD_BUSY[pid] -= 1
            if LEAD_BUSY[pid] <= 0:
                LEAD_BUSY.pop(pid, None)
        mark(lead["name"], "broken")
        promote(pid, why)
    raise RuntimeError("没有可用的指挥")


REVIEW_SYSTEM = "你是指挥，审核声部交上来的产物。只回答一行：PASS，或 FIX: 具体原因。"


async def review(pid, lead, seg):
    """指挥 review. API leads get a direct call; CLI leads get the same card through run_member."""
    ROLE.set("review")
    prompt = f"段落：{seg.get('title')}\n验收：{seg.get('acceptance')}\n产物摘要：{seg.get('summary', '')}"
    prompt += "\n服务端验收：" + json.dumps(seg.get("verification", {}), ensure_ascii=False) + "\n工作目录：" + str(SEGMENT_CWD.get() or "")
    if SEGMENT_CWD.get():
        import ensemble
        prompt += "\n待审核文件内容：\n" + "\n".join(
            str(path.name) + "\n" + (ensemble._read(path) or "（二进制文件）")[:6000]
            for path in list(collab_runtime.artifact_paths(SEGMENT_CWD.get(), [a for a in seg.get("artifacts", []) if "://" not in a]))[:8])
    ho = proj(pid).get("handover") or {}
    if ho.get("to") == lead["name"]:
        prompt = ho.get("context", "") + "\n\n" + prompt
    if lead.get("kind", "api") == "api" and lead.get("provider"):
        return await ask_model(lead, REVIEW_SYSTEM, prompt, pid)
    trig = S.add_msg(pid, "系统", REVIEW_SYSTEM + "\n\n" + prompt, folded=True, seg=seg["id"], review=True)
    await S.run_member(pid, lead["name"], trig, {"priority": "now"})
    r = reply_to(pid, lead["name"], trig)
    if not r or not r.get("text", "").strip():
        raise RuntimeError("指挥没有给出审核结论")
    line = next((ln.strip() for ln in r["text"].splitlines() if ln.strip().upper().startswith(("PASS", "FIX"))), "")
    return line or "FIX: 审核结论格式不对"


def note_pass(name, passed):
    """Exponential moving pass rate per member (feeds assign/review_policy)."""
    st = stats().setdefault(name, {})
    st["pass"] = round(0.8 * st.get("pass", 0.8) + 0.2 * (1.0 if passed else 0.0), 4)
    st["reviews"] = st.get("reviews", 0) + 1


async def plan(pid, brief):
    p = proj(pid)
    p["brief"] = brief or p.get("brief", "")
    designopts.speculate(S, pid, p["brief"], p.get("mode", "concerto"))

    answers = "\n\n用户已回答的澄清（请据此重新规划）：\n" + "\n".join(
        f"问题：{d['question']}\n答案：{d['answer']}" for d in p.get("pending", [])
        if d.get("kind") == "clarify" and d.get("state") == "done" and "answer" in d)

    async def do(lead):
        ROLE.set("plan")
        GRAPH.set_step(pid, lead["name"], "planning", "", "写谱稿")
        touch(pid)
        if lead.get("kind", "api") == "api" and lead.get("provider"):
            return await ask_model(lead, prompt, p["brief"] + answers + design_context(pid), pid)
        trig = S.add_msg(pid, "系统", prompt + "\n\n需求：" + p["brief"] + answers + design_context(pid), folded=True, seg="plan")
        await S.run_member(pid, lead["name"], trig, {"priority": "now"})
        r = reply_to(pid, lead["name"], trig)
        if not r or not r.get("text", "").strip():
            raise RuntimeError("没有交谱稿")
        return r["text"]
    prompt = orchestra.PLAN_PROMPT + f"\n本次最多 24 个段落；按独立交付物和依赖拆分，附属文档可并入相关实现。" + revision_context(pid)
    lead, text = await lead_call(pid, do, "写谱稿")
    segs = orchestra.parse_plan(text, p["brief"], candidates(p))
    q0 = orchestra._extract_json(text) if not segs else None
    if not segs and not (isinstance(q0, dict) and q0.get("questions")):
        # 格式不对先让它按格式重写一次，不直接报失败
        p["plan_raw"] = (text or "")[:4000]
        log(pid, "规划", "谱稿格式不对，自动让指挥按格式重写一次")
        prompt += "\n\n【重要】上次的回复无法解析。这次只输出一个 JSON 对象，不要任何解释文字、不要 Markdown 代码块以外的内容。"
        lead, text = await lead_call(pid, do, "重写谱稿")
        segs = orchestra.parse_plan(text, p["brief"], candidates(p))
    if not segs:
        q = orchestra._extract_json(text)
        if isinstance(q, dict) and q.get("questions"):
            for question in q["questions"][:3]:
                if not isinstance(question, dict) or not question.get("q"):
                    continue
                options = [x for x in question.get("options", []) if isinstance(x, str) and x.strip()]
                default = question.get("default") or "按指挥建议继续"
                if default not in options:
                    options.insert(0, default)
                p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "clarify",
                    "question": question["q"], "options": options, "recommended": options.index(default),
                    "deadline": None, "state": "open"})
        else:
            raise RuntimeError("谱稿格式不对，请重试")
    if p.get("segments") and segs:   # a new 乐章 in the same project: the previous one becomes a past 讨论串
        p.setdefault("movements", []).append({"id": p.get("movement_id") or f"m{len(p.get('movements', [])) + 1}",
                                               "title": p.get("movement_title") or (p.get("brief") or "")[:24],
                                               "segments": p["segments"], "ended": time.time()})
        # 修订：上一版每段的机器验收留着，这一版做完后全部重跑一遍，防止改 A 坏 B
        old_checks = [c for x in p["segments"] if x.get("stage") == "done" for c in (x.get("checks") or []) if isinstance(c, dict)]
        p["regression_checks"] = (p.get("regression_checks") or []) + old_checks
        p["regress_pending"] = bool(p["regression_checks"])
    if segs:
        p["movement_id"] = f"m{len(p.get('movements', [])) + 1}"
        p["movement_title"] = (brief or p.get("brief") or "")[:24]
        p["movement_at"] = time.time()
    if segs:  # 指挥只回了澄清问题时，别把已有的段落清空
        p["segments"] = collab_runtime.plan_gate(S, p, segs)
    GRAPH.set_step(pid, lead["name"], "waiting", "", "谱稿已出")
    GRAPH.record(f"{pid}:plan", pid, lead["name"], lead["name"], "lead_plan", note=f"{len(segs)} 个段落")
    save_projects()
    touch(pid)
    return segs


def candidates(p):
    names = set(p.get("members", [])) or {m["name"] for m in members()}
    return [m for m in members() if m["name"] in names and m.get("auto", True)]


def seg_files(seg):
    """这一段要交的文件：验收规则里的路径 + 交付说明里像文件名的词。"""
    out = {str(c.get("path")).strip("./") for c in seg.get("checks") or [] if isinstance(c, dict) and c.get("path")}
    out |= {d.strip("./") for d in re.split(r"[\s,，、（）()]+", str(seg.get("deliverable") or "")) if re.fullmatch(r"[\w.\-/]+\.\w+", d)}
    return out


def revision_context(pid):
    """在已有成品上再提需求时：告诉首席这是修订，只为要改的部分出段落，其余文件别动。"""
    p = proj(pid)
    done = [x for x in p.get("segments") or [] if x.get("stage") == "done"]
    if not done:
        return ""
    main = S.DATA / "work" / str(pid) / "ensemble" / "main"
    files = [str(f.relative_to(main)) for f in main.rglob("*") if f.is_file() and ".git" not in f.relative_to(main).parts][:60] if main.is_dir() else []
    return ("\n\n【这是修订，不是从零开始】项目里已经有第 " + str(len(p.get("movements", [])) + 1) + " 版成品。"
            "只为这次需求真正要改或要加的部分出段落，没提到的文件不要动；原来每段的机器验收会在改完后自动重跑。\n"
            "已有文件：" + ("、".join(files) if files else "（无）") + "\n"
            "上一版的段落：" + "；".join(f"{x.get('id')} {x.get('title', '')}" for x in done[:24]))


async def maybe_regress(pid):
    """一版修订的所有段落都做完后，把以前各版的机器验收在主线上重跑；没过就出卡片问要不要修。"""
    p = proj(pid)
    segs = p.get("segments") or []
    if not p.get("regress_pending") or not segs or any(x.get("stage") not in ("done", "skipped") for x in segs):
        return
    p["regress_pending"] = False
    import verify
    main = S.DATA / "work" / str(pid) / "ensemble" / "main"
    res = await verify.run_checks({"checks": p.get("regression_checks") or []}, main)
    p["version"] = len(p.get("movements", [])) + 1
    fails = [f'{r.get("path") or r.get("type")}：{r.get("detail")}' for r in res.get("results", []) if r.get("state") == "fail"]
    if fails:
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "regression", "state": "open",
            "question": f"第 {p['version']} 版改完后，原来的验收有 {len(fails)} 条没过：" + "；".join(fails[:3])[:300],
            "options": ["开一轮修复", "先不管"], "recommended": 0, "deadline": None, "detail": fails[:20]})
        S.add_msg(pid, "系统", f"第 {p['version']} 版完成，但回归检查有 {len(fails)} 条没过，等你定要不要修。")
    else:
        S.add_msg(pid, "系统", f"第 {p['version']} 版完成，以前的 {len(res.get('results', []))} 条验收也全部重跑通过。")
    save_projects()
    touch(pid)


def design_context(pid):
    service = getattr(S, "design_options", None)
    session = service.sessions.get((S.project(pid) or {}).get("design_sid")) if service else None
    if not session or session["picked"] is None:
        return ""
    option = session["options"][session["picked"]]
    render = session.get("render") or {}
    if option.get("state") == "cancelled" or render.get("state") == "cancelled":
        return ""
    spec = render.get("spec") or option.get("spec")
    return "\n\n已选界面方向（按此实现）：\n" + json.dumps(spec, ensure_ascii=False)


def execution_pool(p, seg, exclude=()):
    return [m for m in candidates(p) if m["name"] not in exclude and healthy(m["name"])
            and orchestra._available(m, QUOTA2)
            and orchestra._tier_rank(orchestra.tier_of(m)) >= orchestra._tier_rank(orchestra.need_tier(seg.get("difficulty")))
            and (m.get("priority") != "low" or (seg.get("difficulty", 3) <= 2 and low_wait(m) <= 0))]


def low_wait(m):
    if m.get("priority") != "low":
        return 0
    now = time.monotonic()
    calls = LOW_CALLS.setdefault(m["name"], [])
    calls[:] = [t for t in calls if now - t < 60]
    rpm = max(1, int(S.CFG.get("low_priority_rpm", 4)))
    return max(0, LOW_BACKOFF.get(m["name"], 0) - now,
               calls[-rpm] + 60 - now if len(calls) >= rpm else 0)


class LowPriorityLimited(RuntimeError):
    pass


def reserve_low(m):
    # No await between checking and reserving: concurrent dispatches share one window.
    if m.get("priority") == "low":
        if low_wait(m) > 0:
            raise LowPriorityLimited("低优先级声部限流，稍后自动重试")
        LOW_CALLS[m["name"]].append(time.monotonic())


def unavailable(pid, seg):
    p = proj(pid)
    seg.update(stage="blocked", blocked_reason="no_member", assignee="")
    event(seg, "没有能接手的声部")
    if not any(d.get("kind") == "no_member" and d.get("seg") == seg["id"] and d.get("state") == "open" for d in p.get("pending", [])):
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "no_member", "seg": seg["id"],
            "question": "没有能接手的声部，调整成员或额度后会自动重试", "options": ["重试", "跳过这一段", "先停着"],
            "recommended": 0, "deadline": None, "state": "open"})
    save_projects()
    touch(pid)


def retry_unavailable(pid=None):
    """Called on member/quota changes and conduct ticks; never revives other blocks."""
    for p in S.PROJECTS:
        if (pid and p["id"] != pid) or p.get("paused") or p.get("archived"):
            continue
        changed = False
        for seg in p.get("segments", []):
            legacy = (seg.get("events") or [{}])[-1].get("text") == "没有能接手的声部"
            if seg.get("stage") != "blocked" or not (seg.get("blocked_reason") == "no_member" or legacy):
                continue
            if legacy and seg.get("blocked_reason") != "no_member":
                unavailable(p["id"], seg)
            if not execution_pool(p, seg):
                continue
            seg.update(stage="waiting", assignee="")
            seg.pop("blocked_reason", None)
            for d in p.get("pending", []):
                if d.get("kind") == "no_member" and d.get("seg") == seg["id"] and d.get("state") == "open":
                    d["state"] = "done"
            event(seg, "成员或额度已恢复，自动重试")
            changed = True
        if changed:
            save_projects()
            touch(p["id"])
            if pid is None:
                start(p["id"])


def learned_context(who, seg):
    """乐谱自动加载 + 这个模型在这类活上常犯的错（最多 3 条、每条 ≤30 字）。出错不影响派活。"""
    out = []
    try:
        import learn, skills
        m = S.member(who) or {}
        task = orchestra.segment_skill(seg)
        notes = learn.notes_for(m.get("model") or who, task)[:3]
        if notes:
            out.append("【这类活要留意】" + "；".join(notes))
        ids = skills.matches(S.DATA, task, (seg.get("title", "") + " " + seg.get("goal", ""))) if S.DATA else []
        if ids:
            text = seg.get("title", "") + " " + seg.get("goal", "")
            body = skills.excerpt(S.DATA, ids[0], text)
            out.append("【可用乐谱】" + "、".join(ids[:2]) + ("" if body else "（未安装，只按名字参考）"))
            if body:   # 已装的直接把要点发过去：API 声部读不到服务器上的文件
                out.append(f"【乐谱要点：{ids[0]}】\n{body}")
                skills.record_use(S.DATA, ids[0], True)
        seg["skill_load"] = {"state": "matched", "ids": ids[:2]}
    except Exception as exc:  # noqa: BLE001
        seg["skill_load"] = {"state": "failed", "ids": [], "error": type(exc).__name__}
    return ("\n\n" + "\n".join(out)) if out else ""


def block_segment(pid, seg, kind, why):
    p = proj(pid)
    seg.update(stage="blocked", blocked_reason=kind)
    event(seg, why)
    if not any(d.get("seg") == seg["id"] and d.get("kind") == kind and d.get("state") == "open" for d in p.get("pending", [])):
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": kind, "seg": seg["id"],
            "question": why, "options": ["重试", "跳过这一段", "先停着"], "recommended": 2, "deadline": None, "state": "open"})
    save_projects()
    touch(pid)


CONSENT_WAITS = []   # (pid, member, trigger, opts, at, trigger seq, guarded run)：等定音的唤醒


PLAN_WAITS = {}   # pid -> brief：首席候选都等允许时挂起的规划


def resume_consent():
    import collab_api
    for pid, brief in list(PLAN_WAITS.items()):
        p = S.project(pid)
        if not p or p.get("archived"):
            PLAN_WAITS.pop(pid, None)
        elif any(not collab_api.consent_block(m) for m in (candidates(p) or members())):
            PLAN_WAITS.pop(pid, None)
            queue_plan(pid, brief)
    ready = [w for w in CONSENT_WAITS if time.time() - w[4] < 3600 and not collab_api.consent_block(S.member(w[1]) or {})]
    CONSENT_WAITS[:] = [w for w in CONSENT_WAITS if w not in ready and time.time() - w[4] < 3600]
    for pid, name, trigger, opts, _at, _seq, run in ready:
        if S.project(pid) and name in (S.project(pid) or {}).get("members", []):
            S.background.spawn(run(pid, name, trigger, opts))
    for p in S.PROJECTS:
        changed = False
        for seg in p.get("segments", []):
            if seg.get("stage") == "awaiting_consent" and not collab_api.consent_block(S.member(seg.get("assignee")) or {}):
                seg["stage"] = "waiting"
                changed = True
        if changed:
            save_projects()
            touch(p["id"])
            if not p.get("paused"):
                start(p["id"])


async def run_segment(pid, seg):
    """Keep CLI cwd task-local, including concurrent segments and review calls."""
    import ensemble
    import hashlib
    project_root = (S.DATA / "work" / str(pid)).resolve()
    if not project_root.is_relative_to((S.DATA / "work").resolve()):
        raise ValueError("invalid project id")
    root = project_root / "ensemble"
    ws = WORKSPACES.setdefault(str(root), ensemble.Workspace(root))
    async with ws.lock:
        await ws.init(seed=project_root)
    key = hashlib.sha256((str(proj(pid).get("movement_id", "")) + ":" + str(seg["id"]) + (f":{seg['attempt']}" if seg.get("attempt") else "")).encode()).hexdigest()[:24]
    tree = await ws.tree_for(key)
    token = SEGMENT_CWD.set(str(tree))
    image_token = SHARED_IMAGES.set(())
    seg["workspace"] = str(tree)
    try:
        await _run_segment(pid, seg)
        if seg.get("stage") == "done":
            seg["stage"] = "merging"
            await ws.commit(key, f"segment {seg['id']}")
            ok, reason = await ws.merge(key)
            if not ok:
                files = sorted(set(re.findall(r"Merge conflict in (\S+)", reason or "")))
                why = "合并时和别的段落改了同一个文件" + (f"：{'、'.join(files[:4])}" if files else "") + "，需要你定用哪一版或重做这段"
                seg.update(stage="blocked", blocked_reason="merge_conflict", merge_error=reason)
                event(seg, why)
                proj(pid).setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "merge_conflict", "seg": seg["id"],
                    "question": why, "options": ["重试", "跳过这一段", "先停着"], "recommended": 0, "deadline": None, "state": "open"})
            else:
                seg["workspace"] = str(ws.repo)
                await collab_runtime.record(S, pid, seg, ws.repo)
                seg["stage"] = "done"
                await maybe_regress(pid)
            save_projects()
    finally:
        SEGMENT_CWD.reset(token)
        SHARED_IMAGES.reset(image_token)


def review_required(project, seg, mode, member_stats, dual=False):
    """Quality and independent risk/sample policies outrank budget savings."""
    return (project.get("quality") == "max" or dual
            or orchestra.review_needed(seg, member_stats)
            or autopilot.review_policy(mode, seg, member_stats.get(seg.get("assignee"), {}).get("pass", 0.8)))


async def _run_segment(pid, seg):
    p = proj(pid)
    queue = {n: S.QUEUED.get(n, 0) for n in [m["name"] for m in members()]}
    budget = orchestra.budget_state(p)
    # Project caps are optional; autopilot treats zero as an exhausted allowance.
    mode = autopilot.budget_mode(budget["spent"], budget["cap"]) if budget["cap"] > 0 else "normal"
    if mode == "stop":
        block_segment(pid, seg, "project_budget", "预算用完，等你定")
        return
    pool = execution_pool(p, seg)
    explicit = S.member(seg.get("assignee")) or {}
    explicit_ok = explicit and explicit in candidates(p) and healthy(explicit["name"]) and orchestra._available(explicit, QUOTA2)
    if explicit.get("priority") == "low":
        explicit_ok = explicit_ok and explicit in pool
    who = explicit["name"] if explicit_ok else orchestra.assign({**seg, "project_id": pid, "quality": p.get("quality", "standard")}, pool, QUOTA2, stats(), queue)
    if not who:
        if any(m.get("priority") == "low" and seg.get("difficulty", 3) <= 2 and low_wait(m) > 0
               for m in candidates(p)):
            seg.update(stage="waiting", assignee="", retry_at=time.time() + 1)
            touch(pid)
            return
        unavailable(pid, seg)
        return
    if seg.get("assignee") != who:
        __import__("fix3").assignment_event(p, seg, who)
    seg["assignee"], seg["stage"], seg["started"] = who, "running", seg.get("started") or time.time()
    import collab_api
    if collab_api.consent_block(S.member(who) or {}):
        seg["stage"] = "awaiting_consent"
        event(seg, "等授权：请在定音中允许")
        save_projects()
        touch(pid)
        return
    lead = lead_member(p)
    src = lead["name"] if lead and lead["name"] != who else "指挥"
    # Orchestration dispatch is not an AI @ wake; availability is checked above.
    __import__("subprojects").record_dispatch(p, seg, who, "显式指定负责人" if explicit_ok else "调度器按能力、费用、额度和队列选择")
    GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "dispatch", seg["id"])
    GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
    event(seg, f"派给 {who}")
    touch(pid)
    from pathlib import Path
    upstream = collab_runtime.upstream(S, p, seg, Path(SEGMENT_CWD.get()).parent.parent / "main")
    ROLE.set("execute")
    why = account_block()
    if why:
        seg["stage"] = "blocked"
        event(seg, why)
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "account_cap", "seg": seg["id"], "question": why + "，要继续吗？",
                                            "options": ["调高上限后继续", "跳过这一段", "先停着"], "recommended": 2, "deadline": None, "state": "open"})
        save_projects()
        touch(pid)
        return
    attempts = {}
    tried = set()  # members this segment already gave up on; reassign never cycles back
    rounds, t0 = 0, time.time()
    while True:
        if p.get("paused"):
            seg["stage"] = "waiting"
            save_projects()
            return
        import collab_api
        if collab_api.consent_block(S.member(who) or {}):
            seg["stage"] = "awaiting_consent"
            event(seg, "等授权：请在定音中允许")
            save_projects()
            touch(pid)
            return
        budget = orchestra.budget_state(p)
        mode = autopilot.budget_mode(budget["spent"], budget["cap"]) if budget["cap"] > 0 else "normal"
        if mode == "stop":
            block_segment(pid, seg, "project_budget", "预算用完，等你定")
            return
        rounds += 1
        why = account_block()
        if rounds > S.CFG.get("max_rounds", 12) or time.time() - t0 > S.CFG.get("max_segment_s", 4 * 3600) or why:
            seg["stage"] = "blocked"
            why = why or "这一段试了太多次"
            event(seg, why)
            p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "ladder_exhausted", "seg": seg["id"],
                                                "question": f"「{seg.get('title')}」{why}，怎么办？", "options": ["换个思路重来", "跳过这一段", "我来处理"],
                                                "recommended": 0, "deadline": None, "state": "open"})
            save_projects()
            touch(pid)
            return
        card_seg = dict(seg)
        card_upstream = upstream
        if seg.get("retry_action") == "trim_retry":
            card_seg["context"] = str(seg.get("context", ""))[:1000]
            card_upstream = {k: {"summary": v["summary"][:200], "artifacts": v["artifacts"], "output_ref": v["output_ref"]} for k, v in upstream.items()}
        import ensemble
        from pathlib import Path
        tree = Path(SEGMENT_CWD.get())
        asset_notes, image_refs = await collab_runtime.share(S, pid, p, seg, tree, who)
        SHARED_IMAGES.set(tuple(image_refs))
        handoff = ensemble.packet({**card_seg, "title": card_seg.get("title", seg["id"])}, p,
                                  {k: {"id": k, "title": k, **v} for k, v in card_upstream.items()},
                                  [str(f.relative_to(tree)) for f in tree.rglob("*") if f.is_file() and ".git" not in f.parts][:40],
                                  lambda f: collab_runtime.read_text(tree, f), asset_notes, [seg["review_feedback"]] if seg.get("review_feedback") else [])
        member = next((x for x in S.CFG.get("members", []) if x.get("name") == who), {})
        if not __import__("adapters").capabilities(member).get("code_exec"):
            # API 声部不能执行命令：文件必须原样写进回复，服务端负责落盘；不要只说「我去写」
            handoff += ("\n【交付方式】你不能执行命令，也不能自己写文件。请在这一条回复里直接给出每个交付文件的完整内容，"
                        "格式是先单独一行写文件名，再用代码块写全文，例如：\nintro.txt\n```\n文件全文\n```\n"
                        "服务端会按文件名替你存好并跑验收。不要回复「我先去写」这类还没做完的话。")
        trig = S.add_msg(pid, "系统", handoff + "\n" + orchestra.task_card_text(card_seg, card_upstream) + ("\n【恢复要求】" + seg["retry_instruction"] if seg.get("retry_instruction") else "") + ("" if seg.get("retry_action") == "trim_retry" else design_context(pid) + learned_context(who, seg)), folded=True, seg=seg["id"])
        if seg.get("retry_action") == "trim_retry":
            trig["compact_context"] = True
        LAST_ERROR.pop(who, None)
        try:
            await S.run_member(pid, who, trig, {"priority": "now"})
        except LowPriorityLimited:
            GRAPH.set_step(pid, who, "resting")
            event(seg, f"{who} 限流，自动改派")
            tried.add(who)
            who = orchestra.assign({**seg, "project_id": pid, "quality": p.get("quality", "standard")}, execution_pool(p, seg, tried), QUOTA2, stats(), queue)
            if not who:
                seg.update(stage="waiting", assignee="", retry_at=time.time() + 60)
                touch(pid)
                return
            __import__("fix3").assignment_event(p, seg, who)
            __import__("subprojects").record_dispatch(p, seg, who, "限流改派")
            GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], "限流改派")
            GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
            touch(pid)
            continue
        reply = reply_to(pid, who, trig)
        mine = [v for v in S.TASK_STATUS.get(who, {}).values() if v.get("pid") == pid and v.get("trigger_seq", trig.get("seq")) == trig.get("seq") and v.get("since", 0) >= trig["ts"] - 1]
        st = max(mine, key=lambda v: v.get("since", 0)) if mine else {}
        if st.get("todo"):
            orchestra.on_checklist(seg, st["todo"])
        err = st.get("error_code", "")
        text = (reply or {}).get("text", "")
        fail_kind = ""
        if text and not err and st.get("outcome", "succeeded") == "succeeded":
            seg["output_ref"] = {"pid": pid, "message_id": (reply or {}).get("id"), "ts": (reply or {}).get("ts"), "member": who}
            seg["summary"] = (text.split("[产物]")[-1].split("[/产物]")[0] if "[产物]" in text else text[:200]).strip()[:200]
            # 只收像路径或链接的行：校验类段落常在[产物]里写一句说明，不能当文件名去验
            seg["artifacts"] = [a for a in __import__("adapters").artifacts_in(text) if len(a) < 300 and re.fullmatch(r"(https?://\S+|[\w.\-/]+)", a.strip("`* -"))][:40]   # → 资料库
            seg["artifacts"] = [a.strip("`* -") for a in seg["artifacts"]]
            if seg["artifacts"]:
                import collab_api
                _t = background.spawn(collab_api.record_segment_artifacts(pid, who, seg["artifacts"], seg.get("title", "")))
                _t.add_done_callback(lambda t: t.cancelled() or t.exception())  # 吞掉未取回的异常警告；错误已在函数内打印
            planned = [c.get("path") for c in seg.get("checks") or [] if isinstance(c, dict) and c.get("path")]
            planned += [d for d in re.split(r"[\s,，、]+", str(seg.get("deliverable") or "")) if re.fullmatch(r"[\w.\-/]+\.\w+", d)]
            # 只替它落盘本段自己要交的文件；回复里顺带贴出的别段文件不写，免得合并时撞车
            own = list(dict.fromkeys(planned)) or seg["artifacts"]
            wrote = collab_runtime.materialize(SEGMENT_CWD.get(), text, own, overwrite=set(seg.get("materialized") or []))
            seg["materialized"] = sorted(set(seg.get("materialized") or []) | set(wrote))
            if wrote and not seg["artifacts"]:
                seg["artifacts"] = wrote
            if wrote:
                event(seg, "从回复里落盘：" + "、".join(wrote))
            # 清单里列了但没真给出的文件不直接报错停下：从清单拿掉，交给机器验收判断，没过会自动返工
            root_ = Path(SEGMENT_CWD.get())
            seg["artifacts"] = [a for a in seg["artifacts"] if "://" in a or (root_ / a).is_file()]
            list(collab_runtime.artifact_paths(SEGMENT_CWD.get(), [a for a in seg["artifacts"] if "://" not in a]))
            import verify
            seg["verification"] = await verify.run_checks(seg, SEGMENT_CWD.get())
            seg["acceptance_checked"] = [r.get("state") == "pass" for r in seg["verification"]["results"]]
            if not seg["verification"]["passed"] or not seg["verification"]["results"] or seg["verification"]["manual"]:
                fails = [f'{r_.get("path") or r_.get("type")}：{r_.get("detail")}' for r_ in seg["verification"]["results"] if r_.get("state") == "fail"]
                if fails and not seg["verification"]["manual"] and seg.get("auto_fix", 0) < 1:
                    # 机器验收没过先自动让它按失败原因改一次，不直接把卡片甩给用户
                    seg["auto_fix"] = seg.get("auto_fix", 0) + 1
                    seg["review_feedback"] = "机器验收没过：" + "；".join(fails)[:600] + "。请按验收规则改好，重新给出完整文件。"
                    event(seg, "机器验收没过，自动让它改一次")
                    touch(pid)
                    continue
                block_segment(pid, seg, "acceptance", "验收未通过机器检查，需补充 checks 或人工确认")
                return
            seg["stage"] = "selfcheck"
            event(seg, "自检通过")
            touch(pid)
            lead = lead_member(p)
            seg["diff_lines"] = await ensemble.changed_lines(SEGMENT_CWD.get())
            seg["review_plan"] = collab_runtime.review(S, seg, stats().get(who, {}))
            max_quality = p.get("quality") == "max" or seg["review_plan"].get("dual", False)
            if SEGMENT_CWD.get() or review_required(p, seg, mode, stats(), max_quality):
                seg["stage"] = "review"
                GRAPH.set_step(pid, (lead or {}).get("name", who), "review", seg["id"], seg.get("title", ""))
                touch(pid)
                try:
                    if max_quality:
                        pool = [m for m in candidates(p) if m["name"] != who
                                and healthy(m["name"]) and orchestra._available(m, QUOTA2)]
                        pool.sort(key=lambda m: (-orchestra._planning_score(m), m["name"]))
                        pool = prefer_other_family(pool, S.member(who))
                        if len(pool) < 2:
                            block_segment(pid, seg, "review_unavailable", "华彩需要两位独立审核成员，请补充可用声部后重试。")
                            return
                        results = []
                        for reviewer in pool[:2]:
                            result = await review(pid, reviewer, seg)
                            results.append({"member": reviewer["name"], "verdict": result})
                        seg["reviews"] = results
                        verdict = next(("FIX: " + r["verdict"] for r in results if r["verdict"].strip().upper() != "PASS"), "PASS")
                    else:
                        reviewers = [m for m in candidates(p) if m["name"] != who and healthy(m["name"]) and orchestra._available(m, QUOTA2)]
                        if not reviewers:
                            block_segment(pid, seg, "review_unavailable", "需要一位独立审核成员")
                            return
                        reviewers = prefer_other_family(reviewers, S.member(who))
                        other = [m for m in reviewers if model_family(m) != model_family(S.member(who))] or reviewers
                        reviewer = next((m for m in other if m["name"] == (lead or {}).get("name")), other[0])
                        while True:
                            try:
                                verdict = await review(pid, reviewer, seg)
                                break
                            except Exception:
                                mark(reviewer["name"], "broken")
                                if reviewer["name"] == p.get("lead_resolved"):
                                    promote(pid, "审核调用失败", exclude={who})
                                available = [m for m in reviewers if healthy(m["name"])]
                                if not available:
                                    raise
                                reviewer = next((m for m in available if m["name"] == p.get("lead_resolved")), available[0])
                        seg["reviews"] = [{"member": reviewer["name"], "verdict": verdict}]
                except Exception as e:  # noqa: BLE001 - review failure must not pass silently
                    verdict = "FIX: 审核调用失败"
                    event(seg, f"审核调用失败：{e}")
                passed = verdict.strip().upper() == "PASS"
                note_pass(who, passed)
                try:  # 自学习：验收结果记到「这个模型 × 这类任务」上；失败不影响主流程
                    import learn
                    wm = next((m for m in members() if m.get("name") == who), {})
                    learn.update({"model": wm.get("model") or who, "task_type": orchestra.segment_skill(seg),
                                  "outcome": "pass" if passed else "fail", "fail_reason_code": None if passed else "REVIEW_ISSUES",
                                  "tokens": seg.get("est_tokens")}, pid=pid, root=S.DATA / "ledger")
                    import telemetry_events
                    telemetry_events.record(S.DATA, {"model": wm.get("model") or "unknown", "task_type": orchestra.segment_skill(seg),
                                                     "outcome": "pass" if passed else "rework", "tokens": seg.get("est_tokens"),
                                                     "issue_code": None if passed else "REVIEW_ISSUES"})
                except Exception as e:
                    log(pid, "学习", f"记录验收结果失败：{type(e).__name__}")
                if not passed:
                    seg["stage"] = "rework"
                    event(seg, f"返工：{verdict[:80]}")
                    seg["review_feedback"] = verdict
                    fail_kind = "acceptance"
            if not fail_kind:
                MEMBER_STATE.pop(who, None)
                seg["stage"], seg["done_at"] = "done", time.time()
                stats().setdefault(who, {}).update(n=stats().get(who, {}).get("n", 0) + 1)
                GRAPH.set_step(pid, who, "idle", "", "")
                event(seg, "完成")
                touch(pid)
                maybe_handback(pid)
                return
        kind = fail_kind or recovery.classify(LAST_ERROR.get(who, {}).get("status"), LAST_ERROR.get(who, {}).get("body", "") + " " + err, err)
        alts = [m["name"] for m in execution_pool(p, seg, tried | {who})]
        if (S.member(who) or {}).get("priority") == "low" and LAST_ERROR.get(who, {}).get("status") in (429, 503):
            LOW_BACKOFF[who] = time.monotonic() + 60
            event(seg, f"{who} 限流，退避并改派")
            GRAPH.set_step(pid, who, "resting")
            tried.add(who)
            who = orchestra.assign({**seg, "project_id": pid, "quality": p.get("quality", "standard")}, execution_pool(p, seg, tried), QUOTA2, stats(), queue)
            __import__("fix3").assignment_event(p, seg, who or "")
            touch(pid)
            if who:
                __import__("subprojects").record_dispatch(p, seg, who, "限流改派")
                GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], "限流改派")
                GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
                continue
            seg.update(stage="waiting", retry_at=time.time() + 60)
            return
        d = recovery.decide(kind, seg, who, attempts, alts, critical=seg.get("difficulty", 3) >= 3)
        attempts = recovery.bump(attempts, d.action)
        seg.setdefault("ladder", []).append({"step": d.action, "at": time.time(), "why": d.note})
        event(seg, d.note or d.action)
        log(pid, "调度", d.note or d.action)
        touch(pid)
        if d.action in ("retry", "backoff", "trim_retry", "rephrase_retry", "feedback_retry", "advisor"):
            seg["retry_action"] = d.action
            if d.action == "feedback_retry":
                seg["retry_instruction"] = "按审核意见逐项返工：" + seg.get("review_feedback", d.note)
            elif d.action == "trim_retry":
                seg["retry_instruction"] = "上下文已压缩；依据任务目标、验收标准和产物引用执行，按需读取引用。"
            elif d.action == "rephrase_retry":
                seg["retry_instruction"] = "请重新理解为可执行的合规任务：先说明限制，再完成允许的部分；目标：" + str(seg.get("goal", "")) + "；交付物：" + str(seg.get("deliverable", ""))
            await sleep(min(d.delay, 60))
            continue
        if d.member_state:
            mark(who, d.member_state)
        if d.action in ("reassign", "upgrade") and alts:
            tried.add(who)
            nxt = autopilot.escalate(who, candidates(p), QUOTA2, lambda m: orchestra._price_of(m, S), orchestra.tier_of) if d.action == "upgrade" else None
            GRAPH.set_step(pid, who, "resting" if d.member_state == "resting" else "idle")
            who = nxt if nxt in alts else alts[0]
            __import__("fix3").assignment_event(p, seg, who)
            GRAPH.record(f"{pid}:{seg['id']}", pid, src, who, "retry", seg["id"], d.note)
            GRAPH.set_step(pid, who, "working", seg["id"], seg.get("title", ""))
            continue
        if d.action == "skip":
            seg["stage"] = "skipped"
            event(seg, "非关键段落已跳过")
            save_projects()
            touch(pid)
            return
        seg["stage"] = "blocked"
        p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "ladder_exhausted", "seg": seg["id"],
                                            "question": f"「{seg.get('title')}」没人能做下去了，怎么办？", "options": ["换个思路重来", "跳过这一段", "我来处理"],
                                            "recommended": 0, "deadline": None, "state": "open"})
        save_projects()
        touch(pid)
        return


async def conduct(pid):
    """The 协奏 loop: run every ready 段落 in parallel until all are done or blocked."""
    active = {}
    try:
        while True:
            p = proj(pid)
            if not p.get("paused"):
                retry_unavailable(pid)
                unavailable_inputs = {s["id"] for s in p["segments"] if s.get("stage") == "skipped" or s.get("blocked_reason") == "dependency_skipped"}
                while True:
                    newly_blocked = [seg for seg in p["segments"] if seg.get("stage") == "waiting" and unavailable_inputs.intersection(seg.get("inputs", []))]
                    if not newly_blocked:
                        break
                    for seg in newly_blocked:
                        block_segment(pid, seg, "dependency_skipped", "上游已跳过，缺少产物，请调整依赖或重试")
                        unavailable_inputs.add(seg["id"])
                if not active and autopilot.enabled(S.CFG, "batch"):
                    if autopilot.merge_ready(p):
                        save_projects()
                running_ids = {s["id"] for s in active.values()}
                for seg in orchestra.ready(p["segments"]):
                    if p.get("collab_serial") and active:
                        break
                    if seg["id"] not in running_ids and seg.get("retry_at", 0) <= time.time():
                        # 要改同一个文件的段落不同时跑：等前一个合并完再开，免得合并撞车
                        busy = set().union(*(seg_files(x) for x in active.values())) if active else set()
                        if seg_files(seg) & busy:
                            continue
                        active[asyncio.create_task(run_segment(pid, seg))] = seg
            if not active:
                return
            done, _ = await asyncio.wait(active, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                sg = active.pop(task)
                try:
                    task.result()
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    block_segment(pid, sg, "scheduler_error", f"出错停下：{str(e)[:80]}")
                    log(pid, "调度", f"段落 {sg['id']} 出错：{e!r}"[:200])
            save_projects()
    finally:
        for task in active:
            task.cancel()
        if active:
            await asyncio.gather(*active, return_exceptions=True)
        RUNNING.pop(pid, None)
        if S.project(pid):
            maybe_handback(pid)
            save_projects()
            touch(pid)


# 只是提醒、没有选项的卡也要能点：第一个选项去处理，第二个先收起
CARD_OPTIONS = {"pricing_missing": ["去填价格", "先不管"], "currency_mismatch": ["去改币种", "先不管"], "plan_failed": ["重新拆活", "先不管"]}


def recover():
    """服务重启后：上次跑到一半的段落重新排队，没暂停的项目自动接着跑（不用用户再点）。"""
    for p in list(S.PROJECTS):
        segs = p.get("segments") or []
        if not segs or p.get("filed") or p.get("archived") or p.get("deleted_with"):
            continue
        hit = False
        for seg in segs:
            if seg.get("stage") == "running":
                seg["stage"] = "waiting"
                event(seg, "服务重启，这一段重新开始")
                hit = True
        if hit:
            save_projects()
        if not p.get("paused") and any(x.get("stage") == "waiting" for x in segs):
            start(p["id"])


def start(pid):
    if not proj(pid).get("filed") and not proj(pid).get("archived") and not proj(pid).get("paused") and pid not in RUNNING:
        RUNNING[pid] = background.spawn(conduct(pid))


async def h_orch(request):
    pid = request.match_info["pid"]
    proj(pid)
    return web.json_response(view(pid))


def queue_plan(pid, brief):
    if pid in PLANNING:
        return PLANNING[pid]
    p = proj(pid)
    if p.get("filed") or p.get("archived"):
        raise errors.http_error(web.HTTPConflict, "项目已归档", fix="retry")
    async def work():
        p["planning"] = "planning"
        touch(pid)
        try:
            segs = await plan(pid, brief)
            p["planning"] = "done"
            if p.get("plan_start", True) and segs:
                start(pid)
        except NeedsConsent as e:
            p["planning"] = "awaiting_consent"
            PLAN_WAITS[pid] = brief
            import collab_api
            m = getattr(e, "member", None)
            if m:
                collab_api.consent_card(pid, m, f"首席 {m.get('name')} 第一次用这把 key，点「允许」后会自动开始拆活。")
            else:
                S.add_msg(pid, "系统", "要先允许首席用这把 key，允许后会自动开始拆活。")
        except Exception:
            logging.getLogger(__name__).exception("Planning failed for project %s", pid)
            p["planning"] = "failed"
            p.setdefault("pending", []).append({"id": secrets.token_hex(4), "kind": "plan_failed", "state": "open",
                "question": "写谱稿失败，请检查指挥和额度后重试", "options": CARD_OPTIONS["plan_failed"], "recommended": 0, "deadline": None})
            raise
        finally:
            PLANNING.pop(pid, None)
            save_projects()
            touch(pid)

    p.update(planning="queued", planning_brief=brief)
    save_projects()
    touch(pid)
    task = asyncio.create_task(work())
    PLANNING[pid] = task
    task.add_done_callback(lambda t: t.exception() if not t.cancelled() else None)
    return task


async def h_plan(request):
    pid = request.match_info["pid"]
    b = await errors.json_object(request)
    p = proj(pid)
    if pid in PLANNING:
        return web.json_response({"state": "planning"}, status=202)
    if b.get("mode") in capabilities.MODES:
        p["mode"] = b["mode"]
    if b.get("budget") is not None:
        p["budget"] = {"cap": float(b["budget"] or 0), "cur": b.get("cur", "¥")}
    p["plan_start"] = b.get("start", True)
    task = queue_plan(pid, b.get("brief") or p.get("brief", ""))
    if request.query.get("async") == "1" or "respond-async" in request.headers.get("Prefer", "").lower():
        return web.json_response({"state": "planning"}, status=202)
    await asyncio.shield(task)
    return web.json_response(view(pid))


async def h_segment(request):
    pid, sid = request.match_info["pid"], request.match_info["sid"]
    p = proj(pid)
    if request.method == "POST":   # 自己加一节
        b = await errors.json_object(request)
        seg = orchestra.parse_plan(json.dumps([b]), members=candidates(p))[0]
        used = {x["id"] for x in p["segments"]}
        n = len(p["segments"]) + 1
        while f"s{n}" in used:
            n += 1
        seg["id"] = f"s{n}"
        p["segments"].append(seg)
    else:
        seg = next((x for x in p["segments"] if x["id"] == sid), None)
        if not seg:
            raise errors.http_error(web.HTTPNotFound, fix="retry")
        b = await errors.json_object(request)
        if "assignee" in b and b["assignee"] and (not isinstance(b["assignee"], str) or not S.member(b["assignee"]) or b["assignee"] not in p["members"]):
            raise errors.http_error(web.HTTPBadRequest, "只能改派给本乐章在席的声部", fix="retry")
        if b.get("assignee"):
            # 只要这一节没在跑、没做完，就能直接改派；不必整章休止（App 的改派按钮不会先休止）
            if p.get("filed") or seg.get("stage") in ("working", "running", "done"):
                raise errors.http_error(web.HTTPConflict, "这一节正在演奏或已完成，先休止这一节再改派", fix="retry")
            __import__("fix3").assignment_event(p, seg, b["assignee"])
            event(seg, f"改派给 {b['assignee']}")
            if seg.get("stage") in ("blocked", "rework"):
                seg["stage"] = "waiting"
        if b.get("stage") in ("waiting", "done", "blocked"):
            seg["stage"] = b["stage"]
    save_projects()
    touch(pid)
    if any(x.get("stage") == "waiting" for x in p["segments"]):
        start(pid)
    return web.json_response(view(pid))


async def h_restart(request):
    """重来 button: a 段落 starts over from scratch (fresh ladder, no tried members, attempts reset)."""
    pid, sid = request.match_info["pid"], request.match_info["sid"]
    p = proj(pid)
    seg = next((x for x in p["segments"] if x["id"] == sid), None)
    if not seg:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if seg.get("stage") == "running":
        raise errors.http_error(web.HTTPConflict, "这一节正在跑，先休止再重来", fix="retry")
    for k in ("ladder", "attempts", "output", "verdict", "tried", "skipped", "error"):
        seg.pop(k, None)
    seg["stage"] = "waiting"
    event(seg, "重来")
    save_projects()
    touch(pid)
    if not p.get("paused"):
        start(pid)
    return web.json_response(view(pid))


async def h_metrics(request):
    name = request.match_info["name"]
    if not S.member(name):
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    st = dict(stats().get(name, {}))
    import connect
    reason = connect.remote_status(name)
    st["state"] = MEMBER_STATE.get(name, "ok")
    if reason:
        st.update(label="离席", reason=reason)
    return web.json_response(st)


async def h_decide(request):
    pid = request.match_info["pid"]
    b = await errors.json_object(request)
    p = proj(pid)
    d = next((x for x in p.get("pending", []) if x["id"] == b.get("id")), None)
    if not d:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    if d.get("state") == "done":
        return web.json_response(view(pid))
    if d.get("kind") == "plan_failed":
        d["state"], d["choice"] = "done", int(b.get("choice", 0))
        if d["choice"] == 0:
            queue_plan(pid, p.get("brief", ""))
        save_projects()
        touch(pid)
        return web.json_response(view(pid))
    if d.get("kind") == "regression":
        d["state"], d["choice"] = "done", int(b.get("choice", 0))
        if d["choice"] == 0:
            queue_plan(pid, "修复回归：改完后这些原有验收没过，请只修这些问题，别动其他部分。\n" + "\n".join(d.get("detail") or []))
        save_projects()
        touch(pid)
        return web.json_response(view(pid))
    if d.get("kind") == "clarify" or "answer" in b:
        options = d.get("options", [])
        choice = b.get("choice", d.get("recommended", 0))
        answer = b.get("answer")
        if answer is None and type(choice) is int and 0 <= choice < len(options):
            answer = options[choice]
        if not isinstance(answer, str) or not answer.strip():
            raise errors.http_error(web.HTTPBadRequest, "请选择或填写这道澄清题的答案", fix="retry")
        d.update(state="done", answer=answer.strip(), choice=choice)
        save_projects()
        touch(pid)
        if not any(x.get("kind") == "clarify" and x.get("state") == "open" for x in p.get("pending", [])):
            queue_plan(pid, p.get("brief", ""))
        return web.json_response(view(pid))
    d["state"], d["choice"] = "done", int(b.get("choice", d.get("recommended", 0)))
    seg = next((x for x in p["segments"] if x["id"] == d.get("seg")), None)
    if seg and d["kind"] in ("ladder_exhausted", "account_cap", "no_member", "project_budget", "wake_block", "scheduler_error", "dependency_skipped", "review_unavailable", "acceptance", "merge_conflict"):
        if d["kind"] == "merge_conflict" and d["choice"] == 0:
            seg["attempt"] = seg.get("attempt", 0) + 1   # 重试换一个干净的工作区，从最新主线重做
        if d["kind"] in ("acceptance", "merge_conflict") and d["choice"] == 0:
            seg.pop("auto_fix", None); seg.pop("materialized", None)
        seg.pop("blocked_reason", None)
        if d["kind"] == "no_member":
            event(seg, "你已选择处理方式")
        seg["stage"] = {0: "waiting", 1: "skipped", 2: "blocked"}.get(d["choice"], "blocked")
        if d["choice"] == 0:
            seg["ladder"] = []
        if d["choice"] == 1:
            seg["skipped"] = True
            event(seg, "你选了跳过")
    save_projects()
    touch(pid)
    start(pid)
    return web.json_response(view(pid))


async def h_pause(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    p["paused"] = request.path.endswith("/pause")
    save_projects()
    touch(pid)
    if not p["paused"]:
        start(pid)
    return web.json_response(view(pid))


async def h_caps(request):
    pid = request.match_info["pid"]
    p = proj(pid)
    if request.method == "PUT":
        b = await errors.json_object(request)
        p.update(__import__("fix3").initial_config(b))
        save_projects()
        touch(pid)
    acct = S.CFG.get("account", {})
    return web.json_response({"effective": capabilities.effective(acct, p), "warnings": capabilities.validate_combo(p.get("mode", "concerto"), p.get("caps", {})),
                              "combos": capabilities.COMBOS})


def register(app, server_module):
    global S, GRAPH
    S = server_module
    GRAPH = wakegraph.Graph.from_json(S.load(S.DATA / "wakegraph.json", {}))
    GRAPH.on_record = lambda: S.save(S.DATA / "wakegraph.json", GRAPH.to_json())
    designopts.register(app, S, sys.modules[__name__])
    import collab_api
    collab_api.register(app, S)
    S.orchestra_view = view
    if not getattr(S.run_member, "guarded", False):
        S.run_member = guard_run_member(S.run_member)
    if not getattr(S.record_usage, "hooked", False):
        orig_rec = S.record_usage

        def rec(m, model, u, pid=None):
            out = orig_rec(m, model, u, pid)
            on_usage(m, u, pid)
            return out
        rec.hooked = True
        S.record_usage = rec
    r = app.router
    r.add_get("/api/orchestra/{pid}", h_orch)
    r.add_get("/api/orchestra/{pid}/overview", h_overview)
    r.add_post("/api/orchestra/{pid}/plan", h_plan)
    r.add_post("/api/orchestra/{pid}/segments/{sid}", h_segment)
    r.add_patch("/api/orchestra/{pid}/segments/{sid}", h_segment)
    r.add_post("/api/orchestra/{pid}/segments/{sid}/restart", h_restart)
    r.add_get("/api/members/{name}/metrics", h_metrics)
    r.add_post("/api/orchestra/{pid}/decide", h_decide)
    r.add_post("/api/orchestra/{pid}/pause", h_pause)
    r.add_post("/api/orchestra/{pid}/resume", h_pause)
    r.add_get("/api/orchestra/{pid}/caps", h_caps)
    r.add_put("/api/orchestra/{pid}/caps", h_caps)
    r.add_get("/api/orchestra/{pid}/audit", h_audit)
    r.add_get("/api/orchestra/{pid}/night", h_night)
    r.add_put("/api/orchestra/{pid}/night", h_night)
    r.add_get("/api/orchestra/{pid}/overture", h_overture)
    r.add_get("/api/account/caps", h_caps_account)
    r.add_put("/api/account/caps", h_caps_account)
    r.add_get("/api/quota/all", h_quota_all)
    r.add_post("/api/quota/all", h_quota_all)
    r.add_get("/api/members/{name}/policy", h_policy)
    r.add_put("/api/members/{name}/policy", h_policy)
    r.add_post("/api/invite", h_invite)
    r.add_post("/api/invite/redeem", h_redeem)
    r.add_get("/api/trash", h_trash)
    r.add_post("/api/trash/{pid}", h_trash)
    r.add_delete("/api/trash/{pid}", h_trash)

    async def bg(app_):
        for p in S.PROJECTS:
            if p.get("planning") in ("queued", "planning") and not p.get("archived") and not p.get("filed"):
                queue_plan(p["id"], p.get("planning_brief", p.get("brief", "")))
        t = background.spawn(quota_loop())
        async def ticks():
            while True:
                if any(p.get("resolved") and not p.get("completion_reported") and not p.get("archived") for p in S.PROJECTS):
                    try:
                        save_projects()
                    except OSError:
                        pass  # durable resolution outbox retries next tick
                retry_unavailable()
                for p in S.PROJECTS:
                    if not p.get("paused") and not p.get("archived") and not p.get("filed") and any(
                        seg.get("stage") == "waiting" and seg.get("retry_at", float("inf")) <= time.time()
                        for seg in p.get("segments", [])):
                        start(p["id"])
                await asyncio.sleep(1)
        tick = asyncio.create_task(ticks())
        try:
            yield
        finally:
            tasks = [t, tick, *PLANNING.values(), *RUNNING.values()]
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
    app.cleanup_ctx.append(bg)
