"""Offline regression tests. No real AI requests or game assets."""
import asyncio
import json
import pathlib
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
import server as s


class Request:
    def __init__(self, body=None, query=None, **match):
        self.body = body or {}
        self.query = query or {}
        self.match_info = {"pid": "p", **match}
        self.method = "PATCH"

    async def json(self):
        return self.body


class ReviewFixes(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        s.DATA = pathlib.Path(self.tmp.name)
        for name in ("chats", "tmp", "memory", "summaries", "skills"):
            (s.DATA / name).mkdir()
        s.CFG = {"password": "testpass", "providers": [{"id": "pr", "base": "http://invalid", "key": "fake"}],
                 "members": [{"name": n, "provider": "pr", "model": "model"} for n in ("Lead", "A", "B", "C")]}
        s.PROJECTS = [{"id": "p", "name": "Test", "members": ["Lead", "A", "B", "C"], "lead": "Lead"}]
        for name in ("CHATS", "STATUS", "QUOTA", "PVER", "LOCKS", "QUEUED", "TASKS", "TASK_STATUS", "RUNNING", "LAST_RESULT", "PRICE_JOBS"):
            setattr(s, name, {})
        s.RESULTS = []
        s.VER = 0
        s.CHANGED = asyncio.Event()

    async def test_idempotency_survives_reload_and_old_clients(self):
        calls = []
        async def chain(*args):
            calls.append(args)
        with patch.object(s, "run_chain", chain):
            req = Request({"project": "p", "text": "@A hi", "client_id": "stable"})
            a = json.loads((await s.h_say(req)).body)
            self.assertEqual(a["epoch"], s.EPOCH)
            s.CHATS["p"] = s.load_chat("p")
            b = json.loads((await s.h_say(req)).body)
            self.assertEqual(a["seq"], b["seq"])
            self.assertEqual(a, b)
            await s.h_say(Request({"project": "p", "text": "old"}))
            await s.h_say(Request({"project": "p", "text": "old"}))
            await asyncio.sleep(0)
        self.assertEqual(len(s.CHATS["p"]), 3)
        self.assertEqual(len(calls), 3)

    async def test_id_conflicts_do_not_persist_or_dispatch(self):
        calls = []
        async def chain(*args):
            calls.append(args)
        body = {"project": "p", "text": "hello", "client_id": "stable",
                "files": [{"name": "x", "url": "/files/x"}]}
        changes = [{"text": "different"}, {"to": "A"}, {"model": "different"},
                   {"effort": "high"}, {"priority": "now"}, {"reply_to": 9},
                   {"files": [{"name": "x", "url": "/files/y"}]}]
        with patch.object(s, "run_chain", chain):
            await s.h_say(Request(body))
            for change in changes:
                with self.subTest(change=change):
                    res = await s.h_say(Request({**body, **change}))
                    self.assertEqual(res.status, 409)
                    self.assertEqual(json.loads(res.body)["code"], "client_id_conflict")
            await asyncio.sleep(0)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.assertEqual(len(s.load_chat("p")), 1)
        self.assertEqual(len(calls), 1)

    async def test_retry_after_edit_recall_and_restart_uses_original_request(self):
        async def chain(*args):
            pass
        body = {"project": "p", "text": "original", "client_id": "stable"}
        with patch.object(s, "run_chain", chain):
            first = json.loads((await s.h_say(Request(body))).body)
            for op in ("edit", "recall"):
                await s.h_msg(Request({"project": "p", "seq": first["seq"], "op": op, "text": "edited"}))
                s.CHATS["p"] = s.load_chat("p")
                with patch.object(s, "EPOCH", "new-process"):
                    retry = json.loads((await s.h_say(Request(body))).body)
                self.assertEqual(retry["seq"], first["seq"])
                self.assertEqual(retry["epoch"], "new-process")
            await asyncio.sleep(0)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.assertNotIn("request_hash", s.msg_view(s.CHATS["p"][0]))

    async def test_legacy_id_and_project_scoping(self):
        async def chain(*args):
            pass
        s.add_msg("p", "Ali", "legacy", client_id="old", accepted_to=["A"])
        s.PROJECTS.append({"id": "q", "name": "Other", "members": ["A"]})
        with patch.object(s, "run_chain", chain):
            retry = await s.h_say(Request({"project": "p", "text": "legacy", "client_id": "old"}))
            self.assertEqual(json.loads(retry.body)["to"], ["A"])
            conflict = await s.h_say(Request({"project": "p", "text": "other", "client_id": "old"}))
            self.assertEqual(conflict.status, 409)
            other = await s.h_say(Request({"project": "q", "text": "other", "client_id": "old"}))
            self.assertEqual(other.status, 200)
            await asyncio.sleep(0)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.assertEqual(len(s.CHATS["q"]), 1)

    async def test_offline_catchup_includes_edits_and_recalls(self):
        old = s.add_msg("p", "Ali", "old")
        cursor = s.PVER["p"]
        new = s.add_msg("p", "Ali", "new")
        await s.h_msg(Request({"project": "p", "seq": old["seq"], "op": "edit", "text": "changed"}))
        delta = json.loads((await s.h_chat(Request(query={"v": str(cursor), "epoch": s.EPOCH}))).body)
        self.assertFalse(delta["full"])
        self.assertEqual([m["seq"] for m in delta["messages"]], [old["seq"], new["seq"]])
        self.assertEqual(delta["messages"][0]["text"], "changed")
        await s.h_msg(Request({"project": "p", "seq": old["seq"], "op": "recall"}))
        delta = json.loads((await s.h_chat(Request(query={"v": str(delta["v"]), "epoch": s.EPOCH}))).body)
        self.assertTrue(delta["messages"][0]["recalled"])

    async def test_epoch_bypasses_old_version(self):
        s.add_msg("p", "Ali", "history")
        for m in s.CHATS["p"]:
            m["rev"] = 0
        req = Request(query={"v": "1000", "epoch": "previous-process"})
        index = json.loads((await asyncio.wait_for(s.h_index(req), .1)).body)
        chat = json.loads((await asyncio.wait_for(s.h_chat(req), .1)).body)
        self.assertEqual(index["epoch"], s.EPOCH)
        self.assertTrue(chat["full"])
        self.assertEqual(len(chat["messages"]), 1)

    async def test_shared_root_budget_and_parallel_status(self):
        count = []
        async def api(pid, member, reply, *args):
            count.append(member["name"])
            reply["text"] = "@A @B @C go" if member["name"] == "Lead" else "@Lead report"
        async def no_refresh(*args):
            pass
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", no_refresh), patch.dict(s.CFG, {"max_hops": 8}), patch("collab_api.consent_block", return_value=None):
            trigger = s.add_msg("p", "Ali", "start")
            await s.run_chain("p", ["Lead"], trigger, {})
            for _ in range(100):
                await asyncio.sleep(.001)
        self.assertEqual(len(count), 8)
        self.assertTrue(any("调用上限" in m["text"] for m in s.CHATS["p"]))

    async def test_overlap_remains_working(self):
        entered, release = asyncio.Event(), asyncio.Event()
        async def api(pid, member, reply, *args):
            if not entered.is_set():
                entered.set()
                await asyncio.wait_for(release.wait(), 5)
            reply["text"] = "done"
        async def no_refresh(*args):
            pass
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", no_refresh):
            trigger = s.add_msg("p", "Ali", "hi")
            first = asyncio.create_task(s.answer("p", "A", trigger, {}))
            await asyncio.wait_for(entered.wait(), 5)
            await s.answer("p", "A", trigger, {})
            self.assertEqual(s.STATUS["A"]["state"], "working")
            release.set()
            await asyncio.wait_for(first, 5)
        self.assertEqual(s.STATUS["A"]["state"], "idle")

    async def test_stop_all_cli_groups(self):
        m = {"name": "A", "cmd": "sleep 60"}
        # Independent worktrees may run concurrently; one physical cwd now queues.
        roots = [s.DATA / f"tree-{i}" for i in range(2)]
        for root in roots:
            root.mkdir()
        jobs = [asyncio.create_task(s.call_cli("p", {**m, "cwd": str(root)}, {"who": "A"}, "", "", "", "")) for root in roots]
        try:
            for _ in range(100):
                if len(s.RUNNING.get("A", ())) == 2:
                    break
                await asyncio.sleep(.01)
            procs = list(s.RUNNING["A"])
            await s.h_stop(Request(name="A"))
            await asyncio.wait_for(asyncio.gather(*jobs, return_exceptions=True), 5)
            self.assertEqual(len(procs), 2)
            self.assertTrue(all(p.returncode is not None for p in procs))
            self.assertFalse(s.RUNNING["A"])
        finally:
            for job in jobs:
                job.cancel()
            await asyncio.wait_for(asyncio.gather(*jobs, return_exceptions=True), 5)

    async def test_negative_balance_and_unknown_checks(self):
        pr = s.provider("pr")
        q = s.wallet_quota(pr, "$-2.50")
        self.assertEqual(q["amount"], -2.5)
        self.assertEqual(q["fill"], 0)
        s.QUOTA["A"] = q
        s.QUOTA["B"] = {"unset": True, "balance": "今日 ¥0.00"}
        async def models(*args):
            return [["model", "model"]]
        with patch.object(s, "fetch_models", models):
            checks = {i["id"]: i for i in await s.run_checks()}
        self.assertEqual(checks["q-A"]["state"], "failed")
        self.assertEqual(checks["q-B"]["state"], "unknown")
        self.assertFalse(checks["q-B"]["ok"])
        multi = s.wallet_quota(pr, {"accounts": [{"amount": -2, "cur": "$"}, {"amount": 10, "cur": "¥"}]})
        self.assertIsNone(multi["fill"])
        self.assertEqual(len(multi["accounts"]), 2)

    async def test_price_patch_model_and_currency_isolation(self):
        m = s.member("A")
        m["price"] = {"in": 2, "out": 8, "cached": .2, "periods": [{"from": "00:00", "to": "06:00"}], "cur": "$"}
        self.assertIsNone(s.price(m, "another-model"))
        m.update(price_model="model", price_provider="pr")
        m["model"] = "another-model"
        self.assertIsNone(s.price(m, "another-model"))
        m["model"] = "model"
        m["provider"] = "another-provider"
        self.assertIsNone(s.price(m, "model"))
        m["provider"] = "pr"
        with patch.object(s, "balance", AsyncMock(return_value=None)):
            await s.h_wallet(Request({"member": "A", "price_in": 3}))
        self.assertEqual(s.price(m, "model")["out"], 8)
        self.assertEqual(s.price(m, "model")["cached"], .2)
        self.assertTrue(s.price(m, "model")["periods"])
        s.record_usage(m, "model", {"in": 1_000_000, "out": 0})
        self.assertEqual(s.spent_total("pr", "$"), 3)
        self.assertEqual(s.spent_total("pr", "¥"), 0)
        pr = s.provider("pr")
        pr["wallet"] = {"amount": 100, "cur": "¥", "spent0": 0, "ledger": 2}
        self.assertEqual(s.wallet_quota(pr)["amount"], 100)
        # Legacy single-currency balances are migrated, preserving the old
        # baseline instead of forcing the owner to enter a balance again.
        legacy_provider = {"id": "pr", "wallet": {"amount": 100, "spent0": 1, "cur": "$"}}
        with patch.object(s, "save_cfg") as persist:
            legacy = s.wallet_quota(legacy_provider)
            self.assertEqual(legacy["amount"], 98)  # 100 - (3 spent - 1 baseline)
            self.assertEqual(legacy["source"], "estimate")
            self.assertEqual(legacy_provider["wallet"]["ledger"], 2)
            self.assertEqual(legacy_provider["wallet"]["spent0"], 3)
            persist.assert_called_once()
            self.assertEqual(s.wallet_quota(legacy_provider)["amount"], 98)
            persist.assert_called_once()  # Migration is not repeated.
        await s.refresh_quota(["A"])
        self.assertEqual(s.QUOTA["A"]["amount"], s.QUOTA["B"]["amount"])

    async def test_ai_failure_has_structured_evidence(self):
        async def api(*args):
            raise s.api_error(402, "balance exhausted")
        async def no_refresh(*args):
            pass
        trigger = s.add_msg("p", "Ali", "hi")
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", no_refresh):
            await s.answer("p", "A", trigger, {"root_id": "root"})
        reply = s.CHATS["p"][-1]
        self.assertTrue(reply["failed"])
        self.assertEqual(reply["error_code"], "quota_exhausted")
        self.assertEqual(reply["provider"], "pr")
        self.assertEqual(reply["root_id"], "root")
        self.assertEqual(s.api_error(429, "too many requests").code, "rate_limit")
        self.assertEqual(s.api_error(401, "bad key").code, "provider_auth")

    async def test_price_lookup_is_async_deduplicated_and_never_applies_unproven_data(self):
        m = s.member("A")
        original = {"in": 2, "out": 8, "cur": "$"}
        m["price"] = dict(original)
        entered, release = asyncio.Event(), asyncio.Event()

        async def helper(pid, helper_member, reply, *args):
            self.assertIsNone(pid)
            entered.set()
            await asyncio.wait_for(release.wait(), 5)
            reply["text"] = json.dumps({"models": {"model": {"in": 3, "out": 9, "cur": "$"}},
                                       "source": "https://model-claimed.invalid/pricing"})

        request = Request({"member": "A"})
        request.method = "POST"
        with patch.object(s, "call_api", AsyncMock(side_effect=helper)) as api, \
                patch.object(s, "ClientSession", side_effect=AssertionError("offline test")):
            first = json.loads((await s.h_price_lookup(request)).body)
            job = s.PRICE_JOBS[first["id"]]
            try:
                await asyncio.wait_for(entered.wait(), 1)
                second = json.loads((await s.h_price_lookup(request)).body)
                self.assertEqual(first["id"], second["id"])
                self.assertEqual(job["state"], "running")
                self.assertEqual(m["price"], original)
                release.set()
                await job["task"]
                api.assert_awaited_once()
                self.assertEqual(job["state"], "review")
                self.assertIn("未核验", job["source"])
                self.assertNotEqual(job["source"], "https://model-claimed.invalid/pricing")
                self.assertEqual(job["models"]["model"]["in"], 3)
                self.assertEqual(m["price"], original)
                self.assertNotIn("prices", s.provider("pr"))
                review = json.loads((await s.h_price_lookup(request)).body)
                self.assertEqual(review["id"], first["id"])
                api.assert_awaited_once()
                # Only the explicit human apply operation persists the candidate.
                applied = json.loads((await s.h_price_lookup(
                    Request({"id": first["id"], "op": "apply"}))).body)
                self.assertEqual(applied["state"], "applied")
                self.assertEqual(m["price"]["out"], 9)
            finally:
                release.set()
                if not job["task"].done():
                    job["task"].cancel()
                await asyncio.wait_for(asyncio.gather(job["task"], return_exceptions=True), 5)

    async def test_price_lookup_helper_failure_preserves_existing_prices(self):
        m = s.member("A")
        original = {"in": 2, "out": 8, "cur": "$"}
        m["price"] = dict(original)
        with patch.object(s, "call_api", AsyncMock(side_effect=RuntimeError("helper unavailable"))), \
                patch.object(s, "ClientSession", side_effect=AssertionError("offline test")):
            first = json.loads((await s.h_price_lookup(Request({"member": "A"}))).body)
            job = s.PRICE_JOBS[first["id"]]
            await job["task"]
        self.assertEqual(job["state"], "failed")
        self.assertIn("helper unavailable", job["error"])
        self.assertEqual(m["price"], original)
        self.assertNotIn("prices", s.provider("pr"))

    async def test_incremental_members_and_manual_wakeup_rules(self):
        s.member("A")["auto"] = False
        calls = []
        async def chain(pid, names, *args):
            calls.append(names)
        with patch.object(s, "run_chain", chain):
            await s.h_say(Request({"project": "p", "text": "@A explicit"}))
            await s.h_say(Request({"project": "p", "text": "@全体 all"}))
            await asyncio.sleep(0)
        self.assertEqual(calls[0], ["A"])
        self.assertNotIn("A", calls[1])
        with self.assertRaises(s.web.HTTPBadRequest):
            await s.h_edit_project(Request({"lead": "A"}))
        await s.h_edit_project(Request({"remove_members": ["A"]}))
        res = json.loads((await s.h_edit_project(Request({"remove_members": ["B"]}))).body)
        self.assertEqual([m["name"] for m in res["chat"]["members"]], ["Lead", "C"])
        self.assertIn("index", res)

    async def test_progress_failure_and_cancel_preserve_unfinished_steps(self):
        async def api(pid, member, reply, *args):
            s.live(pid, reply, text="[进度]\n✱ 未完成\n[/进度]")
            raise s.api_error(500, "upstream failed")
        async def no_refresh(*args):
            pass
        trigger = s.add_msg("p", "Ali", "hi")
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", no_refresh):
            await s.answer("p", "A", trigger, {})
        task = s.status_view(["A"], "p")["A"]["tasks"][0]
        self.assertEqual(task["outcome"], "failed")
        self.assertEqual(task["todo"][0]["s"], "doing")
        self.assertEqual(task["error_code"], "provider_error")
        self.assertEqual(s.index_view()["results"][-1]["code"], "provider_error")
        entered = asyncio.Event()
        async def waiting(pid, member, reply, *args):
            s.live(pid, reply, text="[进度]\n✱ 未完成\n[/进度]")
            entered.set()
            await asyncio.wait_for(asyncio.Event().wait(), 5)
        with patch.object(s, "call_api", waiting), patch.object(s, "refresh_quota", no_refresh), patch("collab_api.consent_block", return_value=None):
            run = asyncio.create_task(s.run_member("p", "A", trigger, {}))
            await asyncio.wait_for(entered.wait(), 5)
            await s.h_stop(Request(name="A"))
            await asyncio.wait_for(asyncio.gather(run, return_exceptions=True), 5)
        task = s.status_view(["A"], "p")["A"]["tasks"][-1]
        self.assertEqual(task["outcome"], "cancelled")
        self.assertEqual(task["todo"][0]["s"], "doing")

    async def test_multiple_project_statuses_are_independent(self):
        s.PROJECTS.append({"id": "q", "name": "Other", "members": ["A"]})
        entered, release = asyncio.Event(), asyncio.Event()
        async def api(pid, member, reply, *args):
            s.live(pid, reply, text="[进度]\n✱ " + pid + "\n[/进度]")
            if pid == "p":
                entered.set()
                await asyncio.wait_for(release.wait(), 5)
        async def no_refresh(*args):
            pass
        with patch.object(s, "call_api", api), patch.object(s, "refresh_quota", no_refresh):
            trigger = s.add_msg("p", "Ali", "hi")
            running = asyncio.create_task(s.answer("p", "A", trigger, {}))
            await asyncio.wait_for(entered.wait(), 5)
            await s.answer("q", "A", s.add_msg("q", "Ali", "hi"), {})
            self.assertEqual(s.status_view(["A"], "p")["A"]["state"], "working")
            self.assertEqual(s.status_view(["A"], "q")["A"]["state"], "idle")
            release.set(); await asyncio.wait_for(running, 5)

    async def test_real_http_and_stream_error_classification(self):
        from aiohttp.test_utils import TestServer
        cases = [(402, {"error": {"code": "insufficient_balance"}}, "quota_exhausted"),
                 (429, {"error": {"code": "insufficient_quota"}}, "quota_exhausted"),
                 (429, {"error": {"code": "rate_limit"}}, "rate_limit"),
                 (401, {"error": {"code": "bad_key"}}, "provider_auth"),
                 (500, {"error": {"message": "oops"}}, "provider_error"),
                 (200, {"error": {"code": "insufficient_quota"}}, "quota_exhausted")]
        for status, payload, expected in cases:
            async def reply(request):
                return s.web.json_response(payload, status=status)
            app = s.web.Application(); app.router.add_post("/chat/completions", reply)
            async with TestServer(app) as server:
                s.provider("pr")["base"] = str(server.make_url("/")).rstrip("/")
                with self.assertRaises(s.AIError) as caught:
                    await s.call_api("p", s.member("A"), {"who": "A", "text": ""}, "", "hi", "model", "")
                self.assertEqual(caught.exception.code, expected)

    async def test_cli_partial_output_and_quota_exit_are_failed(self):
        s.member("A").update(kind="cli", cmd="printf 'partial'; printf 'insufficient_quota' >&2; exit 1")
        async def no_refresh(*args):
            pass
        trigger = s.add_msg("p", "Ali", "hi")
        with patch.object(s, "refresh_quota", no_refresh):
            await s.answer("p", "A", trigger, {})
        reply = s.CHATS["p"][-1]
        self.assertTrue(reply["failed"])
        self.assertEqual(reply["error_code"], "quota_exhausted")
        self.assertIn("partial", reply["text"])


if __name__ == "__main__":
    unittest.main()
