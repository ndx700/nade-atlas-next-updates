"""End-to-end: API + relay + CLI members finish one project through handoff -> review -> merge, on a real git repo,
a real subprocess CLI and a real HTTP OpenAI-compatible server (local)."""
import asyncio
import json
import pathlib
import sys
import tempfile
import unittest

from aiohttp import web
from aiohttp.test_utils import TestServer

import adapters as A
import assets as AS
import chorus2
import ensemble as E
import redline

HERE = pathlib.Path(__file__).parent


def fake_llm(replies):
    """OpenAI-compatible streaming server; replies: model -> callable(prompt) -> text."""
    seen = []

    async def h(request):
        b = await request.json()
        prompt = b["messages"][-1]["content"]
        seen.append((b["model"], prompt))
        text = replies[b["model"]](prompt)
        resp = web.StreamResponse(headers={"Content-Type": "text/event-stream"})
        await resp.prepare(request)
        await resp.write(b'data: {"choices":[{"delta":{"reasoning_content":"..."}}]}\n\n')
        for i in range(0, len(text), 40):
            await resp.write(("data: " + json.dumps({"choices": [{"delta": {"content": text[i:i + 40]}}]}) + "\n\n").encode())
        await resp.write(("data: " + json.dumps({"choices": [], "usage": {"prompt_tokens": len(prompt), "completion_tokens": len(text)}}) + "\n\n").encode())
        await resp.write(b"data: [DONE]\n\n")
        return resp
    app = web.Application()
    app.router.add_post("/v1/chat/completions", h)
    return app, seen


class TestMixedProject(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.reviews = []

        def lead(prompt):
            self.reviews.append(prompt)
            first_c2 = "c2" in prompt.split("「")[0] and sum("c2" in r.split("「")[0] for r in self.reviews) == 1
            return "FIX: 缺少测试文件" if first_c2 else "PASS"
        app, self.seen = fake_llm({
            "flash": lambda p: "写好了。\n=== FILE: test_app.py ===\nfrom app import add\n\ndef test_add():\n    assert add(2, 3) == 5\n=== END ===\n[产物]\ntest_app.py\n[/产物]",
            "big-pro": lead,
            "vision-cheap": lambda p: "一张流程图；文字：开始 → 结束",
        })
        self.server = TestServer(app)
        await self.server.start_server()
        self.addAsyncCleanup(self.server.close)
        base = str(self.server.make_url("/v1"))
        self.providers = {"official": {"id": "official", "base": base, "key": "k1"},
                          "relay": {"id": "relay", "base": base, "key": "k2", "relay": True}}
        self.members = [
            {"name": "CLI甲", "kind": "cli", "protocol": "acp", "cmd": f"{sys.executable} {HERE / 'testdata/mock_acp.py'} --dangerously-skip-permissions"},
            {"name": "API乙", "kind": "api", "provider": "official", "model": "flash"},
            {"name": "中转丙", "kind": "api", "provider": "relay", "model": "big-pro"},
            {"name": "看图丁", "kind": "api", "provider": "official", "model": "vision-cheap", "caps": {"vision": True}},
        ]
        self.prices = {"CLI甲": {"out": 0.5}, "API乙": {"out": 1.0}, "中转丙": {"out": 20.0}, "看图丁": {"out": 0.8}}
        self.billed = []
        self.events = []
        self.asked = []

    def make(self, m):
        if m["kind"] == "cli":
            return (A.AcpAdapter if m.get("protocol") == "acp" else A.CliAdapter)(m, chorus2.cli_guard)
        return A.ApiAdapter(m, self.providers[m["provider"]])

    async def approve(self, who, tool, inp):
        self.asked.append((who, tool, inp))
        v = redline.check(tool, inp, {"workspaces": [str(self.root)]})
        return v.action == "allow"   # no human in the test: red lines are refused, like an expired consent card

    def account(self, m, usage, role):
        p = self.prices[m["name"]]
        self.billed.append((m["name"], role, usage, round(usage.get("out", 0) * p["out"] / 1e6, 8)))

    async def test_api_relay_cli_project(self):
        img = self.root / "flow.png"
        img.write_bytes(b"\x89PNG fake bytes")
        hub = AS.AssetHub(self.root / "assets.json", self.members, self.make, self.approve, self.account,
                          lambda m: self.prices[m["name"]], {})
        project = {"brief": "做一个 add 函数并测试", "cards": [
            {"id": "c1", "title": "实现 add", "goal": "app.py 里的 add", "deliverable": "app.py", "acceptance": ["add(2,3)==5"],
             "needs": ["code_exec"], "effort": 2},
            {"id": "c2", "title": "补测试", "goal": "pytest", "deliverable": "test_app.py", "acceptance": ["pytest 通过"],
             "inputs": ["c1"], "assignee": "API乙", "effort": 1, "assets": [{"kind": "image", "ref": str(img)}]},
        ]}
        ws = E.Workspace(self.root / "ws")
        ens = E.Ensemble("p", project, self.members, self.make, ws, self.approve, self.account, self.events.append,
                         lambda m: self.prices[m["name"]], {}, lead="中转丙", share=hub.for_card)
        pct = await asyncio.wait_for(ens.run(), 60)

        self.assertEqual(pct, 100.0)
        self.assertEqual([c["state"] for c in project["cards"]], ["passed", "passed"])
        self.assertEqual(project["cards"][0]["assignee"], "CLI甲")       # cheapest with code_exec
        import adapters as AD, quota_probes as QP
        self.assertEqual(AD.LIMITS["CLI甲"]["rate_limits"]["primary"]["used_percent"], 30)   # Codex limits over ACP
        ctx = QP.Ctx(None)
        ctx.acp_limits = lambda n: AD.LIMITS.get(n)
        q = await QP.probe({}, {"name": "CLI甲", "kind": "cli", "cli": "codex"}, ctx)
        self.assertEqual((q["pct"], q["week"], q["source"]), (70.0, 45.0, "official"))
        main = ws.repo
        self.assertTrue((main / "app.py").exists() and (main / "test_app.py").exists())   # merged into main
        _, log = await E.git(main, "log", "--oneline")
        self.assertEqual(log.count("合并"), 2)
        # forced consent interception: the CLI's force push was asked and refused; its bypass flag was stripped
        self.assertTrue(any(t == "Bash" and "force" in i.get("command", "") for _, t, i in self.asked))
        self.assertTrue(any(e.kind == "step" and "拒绝 Bash" in e.text for e in self.events))
        self.assertTrue(any(e.kind == "step" and "· test" in e.text for e in self.events))   # test run observed as a step
        # handoff packet: c2's packet carries c1's artifact and file, the image digest and (after FIX) review notes
        c2_packets = [p for mdl, p in self.seen if mdl == "flash"]
        self.assertTrue(all("app.py" in p and "def add" in p for p in c2_packets))
        self.assertIn("由 看图丁 代为处理", c2_packets[0])
        self.assertIn("缺少测试文件", c2_packets[-1])
        self.assertEqual(len(c2_packets), 2)                                 # one rework after FIX
        # review by the relay 指挥 for both cards; billing by server from usage, split by role
        roles = {(n, r) for n, r, _, _ in self.billed}
        self.assertIn(("中转丙", "review"), roles)
        self.assertIn(("CLI甲", "execute"), roles)
        self.assertIn(("看图丁", "share"), roles)
        # progress from server-observed state, streamed as one event feed
        self.assertEqual(self.events[-1].pct, 100.0)
        self.assertTrue(any(e.kind == "merge" for e in self.events))

    async def test_asset_digest_cached_once(self):
        img = self.root / "a.png"
        img.write_bytes(b"same")
        hub = AS.AssetHub(self.root / "assets.json", self.members, self.make, self.approve, self.account,
                          lambda m: self.prices[m["name"]], {})
        card = {"assets": [{"kind": "image", "ref": str(img)}]}
        a, b = await asyncio.gather(hub.for_card(card, self.members[1]), hub.for_card(card, self.members[0]))
        self.assertEqual(hub.calls, 1)
        hub2 = AS.AssetHub(self.root / "assets.json", self.members, self.make, self.approve, self.account,
                           lambda m: self.prices[m["name"]], {})
        await hub2.for_card(card, self.members[1])
        self.assertEqual(hub2.calls, 0)                                       # persisted cache
        own = await hub.for_card(card, self.members[3])
        self.assertIn("你可以直接看", own[0])                                 # vision member gets the original

    async def test_web_digest_public_only(self):
        async def fetch(u):
            return "<html><script>x</script><h1>标题</h1><p>正文</p></html>"
        hub = AS.AssetHub(self.root / "assets.json", self.members, self.make, self.approve, self.account,
                          lambda m: self.prices[m["name"]], {}, fetch=fetch, public_url=lambda u: u.startswith("https://pub"))
        self.assertEqual(await hub.digest("web", "https://pub.example/x"), "标题\n正文")
        self.assertIn("不是公开网页", await hub.digest("web", "http://127.0.0.1/admin"))

    async def test_cli_failure_reassigns(self):
        self.members[0]["cmd"] = f"MOCK_MODE=fail {sys.executable} {HERE / 'testdata/mock_acp.py'}"
        self.members.append({"name": "CLI戊", "kind": "cli", "cmd": f"{sys.executable} {HERE / 'testdata/mock_stdout_cli.py'}"})
        self.prices["CLI戊"] = {"out": 0.6}
        project = {"brief": "x", "cards": [{"id": "c1", "title": "实现", "acceptance": ["ok"], "needs": ["code_exec"]}]}
        self.reviews.append("skip-first-fix")
        ens = E.Ensemble("p", project, self.members, self.make, E.Workspace(self.root / "ws2"), self.approve, self.account,
                         self.events.append, lambda m: self.prices[m["name"]], {}, lead="中转丙")
        await asyncio.wait_for(ens.run(), 60)
        self.assertEqual(project["cards"][0]["state"], "passed")
        self.assertEqual(project["cards"][0]["assignee"], "CLI戊")   # ACP agent died -> stdout-fallback CLI took over
        self.assertTrue(any(n == "CLI戊" and u.get("out") == 100 for n, _, u, _ in self.billed))


class TestPieces(unittest.TestCase):
    def test_parse_cli_events(self):
        st = A.parse_cli_line('{"type":"item.started","item":{"type":"command_execution","command":"pytest -q"}}', "x")
        self.assertEqual(st.kind, "test")
        st = A.parse_cli_line('{"type":"item.completed","item":{"type":"file_change","changes":[{"path":"a.py"}]}}', "x")
        self.assertEqual((st.kind, st.text), ("edit", "a.py"))
        self.assertEqual(A.parse_cli_line("plain words", "x").kind, "text")

    def test_progress_weights(self):
        cards = [{"state": "passed", "effort": 3}, {"state": "review", "effort": 1}, {"state": "todo", "effort": 1}]
        self.assertEqual(E.movement_pct(cards), round(100 * (3 + 0.85) / 5, 1))
        self.assertEqual(E.project_pct([cards, [{"state": "passed"}]]), round((E.movement_pct(cards) * 5 + 100) / 6, 1))

    def test_heartbeat_stall(self):
        t = [0.0]
        hb = E.Heartbeat(now=lambda: t[0])
        hb.beat("c1")
        t[0] = 100
        self.assertEqual(hb.stalled({"c1": 60}, silence=30), ["c1"])
        hb.beat("c1")
        self.assertEqual(hb.stalled({"c1": 60}, silence=30), [])

    def test_pick_by_caps_and_price(self):
        ms = [{"name": "a", "model": "flash"}, {"name": "b", "model": "qwen-vl"}, {"name": "c", "model": "gpt-4o"}]
        price = {"a": {"out": 1}, "b": {"out": 3}, "c": {"out": 2}}
        self.assertEqual(A.pick(ms, {"vision"}, lambda m: price[m["name"]], {})["name"], "c")
        self.assertIsNone(A.pick(ms, {"code_exec"}, lambda m: price[m["name"]], {}))


if __name__ == "__main__":
    unittest.main()
