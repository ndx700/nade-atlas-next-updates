import pathlib, tempfile, types, unittest
import instruments


class Pick(unittest.TestCase):
    def S(self, models):
        return types.SimpleNamespace(CFG={"providers": [{"id": "a", "base": "http://x", "models": models}]},
                                     DATA=pathlib.Path(tempfile.mkdtemp()))

    def test_picks_image_model_only(self):
        S = self.S([["gpt-5", "gpt-5"], ["gpt-image-1", "x"], ["text-embedding-3", "e"]])
        pr, mid = instruments.pick_image_model(S)
        self.assertEqual(mid, "gpt-image-1")

    def test_none_when_absent(self):
        self.assertIsNone(instruments.pick_image_model(self.S([["gpt-5", "gpt-5"]])))


class Gate(unittest.TestCase):
    def test_first_use_needs_consent_then_allowed(self):
        import consent, collab_api, asyncio, os
        from unittest import mock
        self.enterContext(mock.patch.dict(os.environ, {"CHORUS_CONSENT": "on"}))
        d = pathlib.Path(tempfile.mkdtemp())
        S = types.SimpleNamespace(CFG={"providers": [{"id": "a", "base": "http://x", "key": "k1", "models": [["gpt-image-1", "x"]]}]},
                                  DATA=d, project=lambda pid: {"budget": {"cap": 10}, "segments": []})
        collab_api.S = S
        pr = S.CFG["providers"][0]
        with self.assertRaises(instruments.Blocked):
            instruments.check_allowed(S, "p", pr, "gpt-image-1")
        fp = next(iter(consent.load(d)))
        consent.decide(d, fp, True)
        instruments.check_allowed(S, "p", pr, "gpt-image-1")

    def test_sniff(self):
        self.assertEqual(instruments._sniff(b"\x89PNG\r\n\x1a\n0000"), "png")
        self.assertEqual(instruments._sniff(b"<html>"), "")
