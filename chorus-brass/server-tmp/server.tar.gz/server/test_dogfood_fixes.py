"""B4 regressions, including socket-free request cancellation coverage."""
import asyncio
import errno
import json
import unittest
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch
from aiohttp.test_utils import make_mocked_request
import chorus2 as c
import orchestra as o
import server as s
import wakegraph


def segment(**kw):
    seg = o.parse_plan('[{"id":"s1","title":"实现","difficulty":1}]')[0]
    seg["checks"] = [{"type": "file_exists", "path": "AGENTS.md"}]
    seg.update(kw)
    return seg


def request(body=None, query=None, headers=None):
    return SimpleNamespace(match_info={"pid": "p"}, json=AsyncMock(return_value=body or {}), query=query or {}, headers=headers or {})


class Assignment(unittest.TestCase):
    def test_generalists_unknown_skills_and_bonus(self):
        for skills in ([], ["other"]):
            self.assertEqual(o.assign({"difficulty": 3, "skills": ["python"]}, [{"name": "a", "tier": "mid", "skills": skills}]), "a")
        pool = [{"name": "a", "tier": "mid"}, {"name": "b", "tier": "mid", "skills": ["PYTHON"]}]
        self.assertEqual(o.assign({"difficulty": 3, "skills": ["python"]}, pool), "b")
        self.assertEqual(o.assign({"difficulty": 3}, pool, {"a": {"state": "arrears"}, "b": {"pct": 0}}), "")

    def test_low_difficulty(self):
        m = {"name": "a", "tier": "strong", "priority": "low"}
        self.assertEqual(o.assign({"difficulty": 2}, [m]), "a")
        for d in (3, 4, 5):
            self.assertEqual(o.assign({"difficulty": d}, [m]), "")

    def test_compact_preserves_work_and_dependency_order(self):
        raw = [{"id": f"s{i}", "title": f"实现{i}", "deliverable": f"file{i}", "acceptance": [f"check{i}"],
                "inputs": [f"s{i-1}"] if i else [], "est_tokens": 100, "difficulty": 2, "skills": [f"skill{i}"]} for i in range(12)]
        for i, title in ((0, "README"), (1, "examples"), (6, "examples"), (11, "packaging")):
            raw[i]["title"] = title
        out = o.parse_plan(json.dumps(raw), "150行小工具")
        self.assertEqual(len(out), 8)
        self.assertEqual(sum(x["est_tokens"] for x in out), 1200)
        self.assertEqual({a for x in out for a in x["acceptance"]}, {f"check{i}" for i in range(12)})
        for i in range(12):
            self.assertIn(f"file{i}", " ".join(x["deliverable"] for x in out))
            self.assertIn(f"skill{i}", [a for x in out for a in x["skills"]])
        seen = set()
        for x in out:
            self.assertTrue(set(x["inputs"]) <= seen)
            seen.add(x["id"])
        self.assertEqual(o.segment_target("x" * 3000), 24)
        self.assertEqual(o.segment_target("distributed" + "x" * 3000), 24)
        self.assertEqual(o.segment_target("x" * 9000), 24)

    def test_compact_normalizes_duplicate_ids_and_token_strings(self):
        raw = [{"id": "same", "title": f"impl{i}", "est_tokens": "100", "inputs": ["same"] if i else []}
               for i in range(8)]
        collision = o.parse_plan('[{"id":"s2"},{"id":"s2"},{"id":"s3"},{}]')
        self.assertEqual([seg["id"] for seg in collision], ["s2", "s3", "s4", "s5"])
        normalized = o.parse_plan(json.dumps(raw))
        self.assertEqual(len({seg["id"] for seg in normalized}), 8)
        self.assertTrue(all(isinstance(seg["est_tokens"], int) for seg in normalized))
        out = o.parse_plan(json.dumps(raw), "small tool")
        self.assertEqual(sum(seg["est_tokens"] for seg in out), 800)
        seen = set()
        for seg in out:
            self.assertTrue(set(seg["inputs"]) <= seen)
            seen.add(seg["id"])

    def test_port_hint_and_other_errors(self):
        with patch.object(s, "make_app", return_value=None), patch.object(s.web, "run_app", side_effect=OSError(errno.EADDRINUSE, "taken")), patch("sys.stderr") as err:
            with self.assertRaises(SystemExit):
                s.run_http()
            self.assertIn(f"端口 {s.PORT} 被占用，换 AICHAT_PORT=", str(err.write.call_args_list))
        with patch.object(s, "make_app", return_value=None), patch.object(s.web, "run_app", side_effect=OSError(errno.EACCES, "denied")):
            with self.assertRaises(OSError):
                s.run_http()


class Runtime(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        data_patch = patch.object(s, "DATA", Path(directory.name))
        data_patch.start()
        self.addCleanup(data_patch.stop)
        review_patch = patch.object(c, "review", AsyncMock(return_value="PASS"))
        review_patch.start()
        self.addCleanup(review_patch.stop)
        self.p = {"id": "p", "name": "P", "mode": "concerto", "members": ["a", "b"], "segments": [], "brief": "小工具"}
        self.ms = [{"name": "a", "tier": "weak"}, {"name": "b", "tier": "strong"}]
        patches = [patch.multiple(s, CFG={"members": self.ms, "password": "pw", "providers": []}, PROJECTS=[self.p], CHATS={}, TASK_STATUS={}, QUEUED={}, save=Mock(), save_cfg=Mock(), bump=Mock(), add_msg=Mock(return_value={"text": "brief"})),
                   patch.multiple(c, GRAPH=wakegraph.Graph(), S=s, QUOTA2={}, LAST_ERROR={}, RUNNING={}, PLANNING={}, LOW_CALLS={}, LOW_BACKOFF={}, MEMBER_STATE={}, STATE_AT={}, LEAD_BUSY={}, HISTORY={})]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.addAsyncCleanup(self.cancel_tasks)

    async def cancel_tasks(self):
        tasks = list(c.RUNNING.values()) + list(c.PLANNING.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def test_no_member_card_and_next_tick(self):
        self.ms[1]["available"] = False
        seg = segment(difficulty=5)
        self.p["segments"] = [seg]
        await c.run_segment("p", seg)
        await c.run_segment("p", seg)
        self.assertEqual(seg["stage"], "blocked")
        self.assertEqual(len(self.p["pending"]), 1)
        self.assertEqual(c.view("p")["pending"][0]["kind"], "no_member")
        self.ms[1]["available"] = True
        async def run(pid, sg):
            sg["stage"] = "done"
        with patch.object(c, "run_segment", run):
            await c.conduct("p")
        self.assertEqual(seg["stage"], "done")
        self.assertEqual(self.p["pending"][0]["state"], "done")

    async def test_quota_changes_restart_only_availability_blocks(self):
        seg = segment(difficulty=5)
        other = segment(id="s2", stage="blocked")
        self.p["segments"] = [seg, other]
        c.QUOTA2["b"] = {"state": "arrears"}
        await c.run_segment("p", seg)
        with patch.object(c, "start") as start:
            c.retry_unavailable()
            start.assert_not_called()
            c.QUOTA2["b"] = {"state": "ok"}
            c.retry_unavailable()
            start.assert_called_once_with("p")
        self.assertEqual(seg["stage"], "waiting")
        self.assertEqual(other["stage"], "blocked")

    async def test_project_modes(self):
        for mode in ("concerto", "symphony", "solo", "parallel"):
            with patch.object(s, "create_project", return_value="p"), patch.object(s, "project", return_value={**self.p, "mode": mode}), patch.object(s, "run_chain", new_callable=AsyncMock) as chain, patch.object(s, "targets", return_value=["a", "b"]):
                await s.h_new_project(request({"name": "P"}))
                await asyncio.sleep(0)
                self.assertEqual(chain.await_count, int(mode in ("solo", "parallel")))

    async def test_async_plan_and_duplicate(self):
        for query, headers in (({"async": "1"}, {}), ({}, {"Prefer": "respond-async"})):
            started, release = asyncio.Event(), asyncio.Event()
            async def plan(pid, brief):
                started.set()
                await release.wait()
                return []
            with patch.object(c, "plan", plan):
                response = await c.h_plan(request(query=query, headers=headers))
                self.assertEqual(response.status, 202)
                self.assertEqual(json.loads(response.body), {"state": "planning"})
                await started.wait()
                task = c.PLANNING["p"]
                self.assertEqual((await c.h_plan(request())).status, 202)
                release.set()
                await task
                self.assertEqual(self.p["planning"], "done")

    async def test_disconnect_does_not_cancel_planning(self):
        started, release = asyncio.Event(), asyncio.Event()
        async def plan(pid, brief):
            started.set()
            await release.wait()
            self.p["segments"] = [segment()]
            return self.p["segments"]
        with patch.object(c, "plan", plan), patch.object(c, "start") as start:
            handler = asyncio.create_task(c.h_plan(request()))
            await started.wait()
            task = c.PLANNING["p"]
            handler.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await handler
            self.assertFalse(task.cancelled())
            release.set()
            await task
            self.assertEqual(self.p["segments"][0]["id"], "s1")
            start.assert_called_once_with("p")

    async def test_plan_failure(self):
        with patch.object(c, "plan", side_effect=RuntimeError("bad")):
            with self.assertRaises(RuntimeError):
                await c.h_plan(request())
        self.assertEqual(self.p["planning"], "failed")
        self.assertNotIn("p", c.PLANNING)
        self.assertEqual(c.view("p")["pending"][0]["kind"], "plan_failed")
        s.bump.assert_called()

    async def test_password_hint(self):
        for password in ("pw", "测试密码"):
            s.CFG["password"] = password
            req = make_mocked_request("GET", "/api/projects", headers={"Authorization": "Bearer " + password})
            response = await s.auth(req, AsyncMock())
            self.assertEqual(response.status, 401)
            self.assertEqual(json.loads(response.body)["hint"], "用 app 配对得到的 token")
        req = make_mocked_request("GET", "/api/projects", headers={"Authorization": "Bearer " + s.token()})
        handler = AsyncMock(return_value="ok")
        self.assertEqual(await s.auth(req, handler), "ok")

    async def test_low_rate_limit_concurrency_and_expiry(self):
        self.ms[0]["priority"] = "low"
        s.CFG["low_priority_rpm"] = 2
        orig = AsyncMock()
        run = c.guard_run_member(orig)
        results = await asyncio.gather(*(run("p", "a", {}, {}) for _ in range(8)), return_exceptions=True)
        self.assertEqual(orig.await_count, 2)
        self.assertEqual(sum(isinstance(x, c.LowPriorityLimited) for x in results), 6)
        with patch.object(c.time, "monotonic", return_value=c.LOW_CALLS["a"][-1] + 61):
            await run("p", "a", {}, {})
        self.assertEqual(orig.await_count, 3)

    async def test_low_429_503_reassign_without_sleep(self):
        for status in (429, 503):
            c.GRAPH = wakegraph.Graph()
            c.LOW_BACKOFF.clear()
            self.ms[0]["priority"] = "low"
            seg = segment(assignee="a")
            self.p["segments"] = [seg]
            calls = []
            async def run(pid, name, trig, opts):
                calls.append(name)
                if name == "a":
                    c.note_reply(name, status, body="busy")
            with patch.object(s, "run_member", run), patch.object(s, "add_msg", return_value={"seq": 1, "ts": 0}), patch.object(c, "reply_to", side_effect=lambda pid, name, trig: {"text": "done"} if name == "b" else None), patch.object(o, "review_needed", return_value=False), patch.object(c, "lead_member", return_value=None), patch.object(c, "sleep", new_callable=AsyncMock) as sleep:
                await c.run_segment("p", seg)
            self.assertEqual(calls, ["a", "b"])
            self.assertEqual(seg["stage"], "done")
            self.assertGreater(c.low_wait(self.ms[0]), 0)
            sleep.assert_not_called()

    async def test_low_failure_without_alternative_waits(self):
        self.ms[0]["priority"] = "low"
        self.p["members"] = ["a"]
        seg = segment(assignee="a")
        self.p["segments"] = [seg]
        async def run(*args):
            c.note_reply("a", 503, body="busy")
        with patch.object(s, "run_member", run), patch.object(s, "add_msg", return_value={"seq": 1, "ts": 0}), patch.object(c, "reply_to", return_value=None), patch.object(c, "lead_member", return_value=None):
            await c.run_segment("p", seg)
        self.assertEqual(seg["stage"], "waiting")
        self.assertIn("retry_at", seg)
        self.assertFalse(self.p.get("pending"))

    async def test_low_member_never_gets_hard_segment_even_if_assigned(self):
        self.ms[0].update(priority="low", tier="strong")
        self.ms[1]["available"] = False
        seg = segment(difficulty=4, assignee="a")
        self.p["segments"] = [seg]
        with patch.object(s, "run_member", new_callable=AsyncMock) as run:
            await c.run_segment("p", seg)
        run.assert_not_called()
        self.assertEqual(seg["stage"], "blocked")

    async def test_default_rate_limit_also_covers_direct_lead_calls(self):
        self.ms[0]["priority"] = "low"
        async def api(*args):
            args[2]["text"] = "ok"
        with patch.object(s, "call_api", api):
            for _ in range(4):
                self.assertEqual(await c.ask_model(self.ms[0], "", ""), "ok")
            with self.assertRaises(c.LowPriorityLimited):
                await c.ask_model(self.ms[0], "", "")

    async def test_actual_plan_parsing_guardrail_and_invalid_failure(self):
        raw = json.dumps([{"title": f"impl{i}"} for i in range(12)])
        with patch.object(c, "ask_model", new_callable=AsyncMock, return_value=raw) as ask:
            self.ms[1].update(kind="api", provider="test")
            segs = await c.plan("p", "150行小工具")
            self.assertEqual(len(segs), 12)
            self.assertIn("最多 24 个段落", ask.call_args.args[1])
            ask.return_value = "bad plan"
            with self.assertRaisesRegex(RuntimeError, "谱稿格式"):
                await c.plan("p", "小工具")
        self.assertEqual(self.p["segments"], segs)

    async def test_reassignment_graph_uses_old_and_new_member_and_never_empty(self):
        for limited in (True, False):
            for alternative in (True, False):
                c.GRAPH = wakegraph.Graph()
                c.LOW_BACKOFF.clear()
                self.ms[0]["priority"] = "low"
                self.p["members"] = ["a", "b"] if alternative else ["a"]
                seg = segment(assignee="a")
                self.p["segments"] = [seg]
                async def run(pid, who, *args):
                    if who == "a":
                        if limited:
                            raise c.LowPriorityLimited()
                        c.note_reply(who, 429, body="busy")
                with patch.object(s, "run_member", run), patch.object(s, "add_msg", return_value={"seq": 1, "ts": 0}), patch.object(c, "reply_to", side_effect=lambda pid, who, trig: {"text": "done"} if who == "b" else None), patch.object(o, "review_needed", return_value=False), patch.object(c, "lead_member", return_value=None), patch.object(c.GRAPH, "set_step", wraps=c.GRAPH.set_step) as step, patch.object(c.GRAPH, "record", wraps=c.GRAPH.record) as record:
                    await c.run_segment("p", seg)
                self.assertEqual(seg["stage"], "done" if alternative else "waiting")
                self.assertEqual(seg["assignee"], "b" if alternative else "")
                step.assert_any_call("p", "a", "resting")
                self.assertTrue(all(x.args[1] for x in step.call_args_list))
                self.assertTrue(all(x.args[3] for x in record.call_args_list))
                if alternative:
                    step.assert_any_call("p", "b", "working", seg["id"], seg["title"])
                else:
                    self.assertIn("retry_at", seg)

    async def test_async_plan_failure_logs_traceback(self):
        with patch.object(c, "plan", side_effect=RuntimeError("bad")), self.assertLogs("chorus2", level="ERROR") as logs:
            await c.h_plan(request(query={"async": "1"}))
            task = c.PLANNING["p"]
            with self.assertRaises(RuntimeError):
                await task
        self.assertTrue(logs.records[0].exc_info)
        self.assertIn("project p", logs.output[0])

    async def test_invalid_utf8_authorization_header_returns_401(self):
        from aiohttp.http_parser import HeadersParser
        headers, _ = HeadersParser().parse_headers([b"Authorization: Bearer \xff", b""])
        req = SimpleNamespace(path="/api/projects", headers=headers, query={})
        handler = AsyncMock()
        response = await s.auth(req, handler)
        self.assertEqual(response.status, 401)
        handler.assert_not_awaited()
