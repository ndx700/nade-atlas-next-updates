import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

import dm_index
import server as s


class DMs(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        for key, value in {"DATA": Path(self.tmp.name), "CFG": {"password": "test", "owner": "阿离",
            "members": [{"name": "龙娘", "avatar": "data:image/png;base64,forbidden"}, {"name": "Kimi"}], "providers": []},
            "PROJECTS": [{"id": "p", "name": "群一", "members": []}, {"id": "q", "name": "群二", "members": [], "archived": True}],
            "CHATS": {"p": [], "q": []}, "VER": 0, "PVER": {}, "CHANGED": asyncio.Event()}.items():
            self.enterContext(patch.object(s, key, value))
        app = s.make_app()
        app.on_startup.clear()
        app.cleanup_ctx.clear()
        self.client = TestClient(TestServer(app))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)
        self.headers = {"Authorization": "Bearer " + s.token()}

    def msg(self, name="龙娘", who="龙娘", ts=10, pid="p", **extra):
        message = {"seq": len(s.CHATS[pid]) + 1, "who": who, "dm": name, "ts": ts, "at": "10-26 19:24", "text": "你好", **extra}
        s.CHATS[pid].append(message)
        return message

    async def get(self, seen=None):
        response = await self.client.get("/api/dms", headers=self.headers,
            params={} if seen is None else {"seen": json.dumps(seen)})
        self.assertEqual(response.status, 200, await response.text())
        self.assertEqual(response.headers["Cache-Control"], "no-store")
        return await response.json()

    async def test_auth_required(self):
        self.assertEqual((await self.client.get("/api/dms")).status, 401)

    async def test_empty_owner_and_read_state(self):
        data = await self.get()
        self.assertEqual([x["name"] for x in data["dms"]], ["Kimi", "龙娘"])  # N17：在席声部都有私信入口，没聊过也显示
        self.assertTrue(all(x["last"]["seq"] == 0 and x["unread"] == 0 for x in data["dms"]))
        self.assertEqual(data["owner"], "阿离")
        self.assertFalse(data["read_state_supplied"])

    async def test_only_private_finished_visible_messages(self):
        for extra in ({"name": ""}, {"live": True}, {"gone": True}, {"recalled": True}):
            self.msg(**extra)
        self.assertTrue(all(x["last"]["seq"] == 0 for x in (await self.get())["dms"]))
        self.msg(who="Ali")
        card = (await self.get())["dms"][0]
        self.assertEqual(card["unread"], 0)
        self.assertEqual(card["name"], "龙娘")

    async def test_member_cards_sorted_by_last_timestamp(self):
        self.msg(ts=40)
        self.msg(name="Kimi", who="Kimi", ts=50)
        self.assertEqual([x["name"] for x in (await self.get())["dms"]], ["Kimi", "龙娘"])

    async def test_cross_project_aggregation_and_navigation(self):
        self.msg(ts=10)
        self.msg(ts=20, pid="q")
        cards = [c for c in (await self.get())["dms"] if c["name"] == "龙娘"]
        self.assertEqual(len(cards), 1)
        self.assertEqual(cards[0]["last"]["pid"], "q")
        self.assertEqual(cards[0]["unread"], 2)
        self.assertEqual([t["pid"] for t in cards[0]["threads"]], ["p", "q"])
        self.assertTrue(cards[0]["threads"][1]["archived"])

    async def test_read_cursors_are_private_thread_specific(self):
        self.msg()
        self.msg(who="Ali")
        self.msg(who="系统")
        self.msg(name="Kimi", who="Kimi")
        self.msg(pid="q")
        result = await self.get({"p": {"龙娘": 3}})
        self.assertTrue(result["read_state_supplied"])
        self.assertEqual({x["name"]: x["unread"] for x in result["dms"]}, {"Kimi": 1, "龙娘": 1})
        self.assertEqual((await self.get())["dms"][1]["unread"], 2)

    async def test_invalid_cursors_rejected(self):
        for raw in ("[]", "null", "{", '{"p":1}', '{"p":{"龙娘":true}}', '{"p":{"龙娘":-1}}', '{"p":{"龙娘":1.2}}', 'x' * 4097):
            response = await self.client.get("/api/dms", headers=self.headers, params={"seen": raw})
            self.assertIn(response.status, (400, 414))

    async def test_deleted_member_keeps_history_but_is_unavailable(self):
        self.msg(name="旧成员", who="旧成员")
        self.assertNotIn("旧成员", [x["name"] for x in (await self.get())["dms"]])  # 已移除的声部隐藏，历史保留

    async def test_no_legacy_avatar_leaks(self):
        self.msg()
        self.assertEqual((await self.get())["dms"][0]["avatar"], "")

    async def test_manual_avatar_uses_avatar_module_policy(self):
        self.msg()
        with patch.object(s, "member_avatars", SimpleNamespace(view=lambda data, member: {"avatar": "/files/manual.png?v=1", "avatar_version": "1"}), create=True):
            self.assertEqual((await self.get())["dms"][0]["avatar_version"], "1")

    async def test_preview_is_bounded_and_progress_removed(self):
        self.msg(text="[进度]\n✱ 工作\n[/进度]\n" + "你好\n" * 300)
        last = (await self.get())["dms"][0]["last"]
        self.assertLessEqual(len(last["text"]), 200)
        self.assertNotIn("进度", last["text"])
        self.assertNotIn("\n", last["text"])

    async def test_nonfinite_and_missing_timestamp_are_safe(self):
        self.msg(ts=float("nan"))
        self.assertEqual((await self.get())["dms"][0]["last"]["ts"], 0)

    async def test_message_timestamp_and_configured_owner_exposed(self):
        message = self.msg(live=True, request_hash="private", rev=1)
        self.assertEqual(s.msg_view(message)["ts"], 10)
        self.assertNotIn("request_hash", s.msg_view(message))
        self.assertEqual(s.index_view()["owner"], "阿离")
        self.assertEqual(s.chat_view("p", 0)["owner"], "阿离")
