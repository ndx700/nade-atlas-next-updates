"""本机的匿名统计事件：只记 模型 / 任务类型 / 结果 / token / 耗时，不记任何文本、路径、成员名。
按天追加到 DATA/telemetry_events.jsonl，每天上传日报时读取前一天；超过 14 天的自动清掉。"""
import json
import pathlib
import time

KEEP_DAYS = 14


def _file(data):
    return pathlib.Path(data) / "telemetry_events.jsonl"


def record(data, event: dict) -> None:
    allowed = {"model": str, "task_type": str, "outcome": str, "tokens": (int, float), "latency_ms": (int, float), "issue_code": str, "error_type": str}
    row = {k: event[k] for k, t in allowed.items() if isinstance(event.get(k), t)}
    if not row.get("model") or not row.get("task_type"):
        return
    row["at"] = time.time()
    path = _file(data)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        if path.stat().st_size > 2_000_000:
            trim(data)
    except OSError:
        pass


def read(data, since: float, until: float) -> list:
    out = []
    try:
        for line in _file(data).read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if since <= float(row.get("at", 0)) < until:
                out.append({k: v for k, v in row.items() if k != "at"})
    except OSError:
        pass
    return out


def trim(data) -> None:
    cutoff = time.time() - KEEP_DAYS * 86400
    path = _file(data)
    try:
        keep = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip() and _at(ln) >= cutoff]
        path.write_text("\n".join(keep) + ("\n" if keep else ""), encoding="utf-8")
    except OSError:
        pass


def _at(line):
    try:
        return float(json.loads(line).get("at", 0))
    except ValueError:
        return 0.0
