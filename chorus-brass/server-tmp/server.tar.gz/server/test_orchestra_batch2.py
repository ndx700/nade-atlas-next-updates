"""Second orchestra batch: pure graph/profile checks and isolated review execution."""
import json
from unittest.mock import AsyncMock, patch
import pytest
import orchestra as o
import chorus2 as c
import server as s
from test_chorus2 import Base, seg


@pytest.mark.parametrize('model,tier', [
    ('gemini', 'mid'), ('gemini-4-argon', 'strong'), ('gpt-6.1-sol', 'strong'),
    ('claude-sonnet', 'strong'), ('deepseek-v4.1-pro', 'strong'), ('kimi-k3.1', 'strong'),
    ('mimo-v2.6-pro', 'mid'), ('glm-5.3', 'mid'), ('minimax-m3', 'mid'),
    ('gemini-3.8-flash', 'mid'), ('gpt-mini', 'weak'), ('chair', 'mid'),
])
def test_capability_tiers(model, tier):
    assert o.tier_of({'model': model}) == tier


def test_profile_scores_drive_tier_and_planning(monkeypatch):
    import profiles
    monkeypatch.setattr(profiles, '_cache', {'unknown_prior': .6, 'profiles': [
        {'match': 'coder', 'skill': dict(code=.99, agent=.99, reasoning=.99, plan=.7)},
        {'match': 'planner', 'skill': dict(code=.8, agent=.8, reasoning=.8, plan=.98)},
    ]})
    members = [{'name': 'c', 'model': 'coder'}, {'name': 'p', 'model': 'planner'}]
    assert o.tier_of(members[0]) == 'strong'
    assert o.tier_of(members[1]) == 'mid'
    assert o.pick_lead({}, members) == 'p'
    assert o.pick_lead({'lead': 'c'}, members) == 'c'
    assert o.pick_lead({}, members, {'p': {'pct': 0}}) == 'c'


def test_plan_runtime_fields_and_member_allowlist():
    raw = [dict(id='a', assignee='real', stage='done', progress=1, spend={'cost': 99},
                started=1, done_at=2, ladder=[{'step': 'ask'}], events=['fake']),
           dict(id='b', assignee='invented')]
    out = o.parse_plan(json.dumps(raw), members=[{'name': 'real'}])
    assert [s['assignee'] for s in out] == ['real', '']
    for s1 in out:
        for key in ('stage', 'progress', 'spend', 'started', 'done_at', 'ladder', 'events'):
            assert s1[key] == o._new_segment()[key]
    assert o.parse_plan(json.dumps(raw))[0]['assignee'] == ''
    out[0]['spend']['cost'] = 1
    assert out[1]['spend']['cost'] == 0


def test_topology_preserves_forward_dependencies_and_only_breaks_cycle_edges():
    raw = [dict(id='tail', inputs=['a']), dict(id='a', inputs=['b', 'root']),
           dict(id='b', inputs=['a', 'root']), dict(id='root'), dict(id='free')]
    out = o.parse_plan(json.dumps(raw))
    by = {s['id']: s for s in out}
    assert by['tail']['inputs'] == ['a']
    assert 'root' in by['a']['inputs'] and 'root' in by['b']['inputs']
    assert sum(len(s['inputs']) for s in out) == 4
    seen = set()
    for s1 in out:
        assert set(s1['inputs']) <= seen
        seen.add(s1['id'])
    assert o.parse_plan('[{"id":"a","inputs":["b"]},{"id":"b"}]')[1]['inputs'] == ['b']


def test_compaction_uses_structure_and_preserves_parallel_deliverables():
    raw = [dict(id=f's{i}', title=f'实现{i}', difficulty=2, deliverable=f'file{i}') for i in range(12)]
    assert o.parse_plan(json.dumps(raw), 'x') == o.parse_plan(json.dumps(raw), 'x'*9000)
    assert len(o.parse_plan(json.dumps(raw), 'x')) == 12
    raw.append(dict(id='doc', title='README', inputs=['s0'], difficulty=1))
    out = o.parse_plan(json.dumps(raw), '')
    assert len(out) == 12
    assert 'README' in next(s1 for s1 in out if s1['id'] == 's0')['title']


def test_compaction_does_not_delete_alternate_dependency_path():
    raw = [dict(id='a'), dict(id='b', inputs=['a']),
           dict(id='doc', title='README', difficulty=1, inputs=['a', 'b'], assignee='writer')]
    out = o.parse_plan(json.dumps(raw), '', members=[{'name': 'writer'}])
    assert len(out) == 3  # distinct assignees cannot be merged
    assert out[-1]['inputs'] == ['a', 'b']


def test_max_always_needs_review():
    assert all(o.review_needed({'id': str(i), 'difficulty': 1, 'quality': 'max'}) for i in range(100))


class TestMaxReviews(Base):
    async def asyncSetUp(self):
        with patch('aiohttp.test_utils.TestClient.start_server', new_callable=AsyncMock):
            await super().asyncSetUp()
        self.P()['quality'] = 'max'

    async def test_two_distinct_reviews_even_when_executor_is_lead(self):
        self.P()['segments'] = [seg(1, assignee='强')]
        review = AsyncMock(return_value='PASS')
        with patch.object(c, 'review', review), patch.object(o, 'review_needed', return_value=False), patch('autopilot.review_policy', return_value=False):
            await self.run_all()
        assert self.P()['segments'][0]['stage'] == 'done'
        assert {call.args[1]['name'] for call in review.await_args_list} == {'甲', '乙'}
        assert len(self.P()['segments'][0]['reviews']) == 2

    async def test_missing_second_reviewer_blocks_with_pending_card(self):
        self.P()['members'] = ['强', '甲']
        self.P()['segments'] = [seg(1, assignee='甲')]
        with patch.object(c, 'review', AsyncMock()) as review:
            await self.run_all()
        review.assert_not_awaited()
        assert self.P()['segments'][0]['stage'] == 'blocked'
        assert self.P()['pending'][0]['kind'] == 'review_unavailable'

    async def test_either_review_can_reject(self):
        self.P()['segments'] = [seg(1, assignee='强')]
        with patch.object(c, 'review', AsyncMock(side_effect=['PASS', 'FIX: 缺测试', 'PASS', 'PASS'])) as review:
            await self.run_all()
        assert review.await_count == 4
        assert '缺测试' in self.P()['segments'][0]['review_feedback']
        assert self.P()['segments'][0]['stage'] == 'done'

    async def test_review_unavailable_decision_can_retry(self):
        from types import SimpleNamespace
        self.P()['segments'] = [seg(1, assignee='甲', stage='blocked')]
        self.P()['pending'] = [dict(id='d', kind='review_unavailable', seg='s1', state='open')]
        request = SimpleNamespace(match_info={'pid': 'p'}, json=AsyncMock(return_value={'id': 'd', 'choice': 0}))
        with patch.object(c, 'start'):
            await c.h_decide(request)
        assert self.P()['segments'][0]['stage'] == 'waiting'
        assert self.P()['pending'][0]['state'] == 'done'


def test_compaction_rejects_cycle_creating_contraction():
    out = o.parse_plan(json.dumps([
        dict(id='a'), dict(id='b', inputs=['a']),
        dict(id='doc', title='README', difficulty=1, inputs=['a', 'b']),
    ]), '')
    assert len(out) == 2
    assert out[1]['id'] == 'b' and out[1]['inputs'] == ['a']
    assert 'README' in out[1]['title']


def test_profile_assignment_respects_tier_and_legacy_ties(monkeypatch):
    import profiles
    monkeypatch.setenv('CHORUS_PROFILE_MODE', 'on')
    monkeypatch.setattr(profiles, '_cache', {'unknown_prior': .6, 'profiles': [
        {'match': 'cheap', 'skill': dict(code=.7, agent=.7, reasoning=.7, plan=.7)},
        {'match': 'strong', 'skill': dict(code=.99, agent=.99, reasoning=.99, plan=.99)},
    ]})
    members = [{'name': 'cheap', 'model': 'cheap'}, {'name': 'strong', 'model': 'strong'}]
    assert o.assign({'difficulty': 1}, members) == 'cheap'
    members = [{'name': 'a', 'model': 'unknown-a'}, {'name': 'b', 'model': 'unknown-b'}]
    assert o.assign({'difficulty': 3}, members, stats={'a': {'pass': .1}, 'b': {'pass': .99}}) == 'b'
    assert o.assign({'difficulty': 3}, members, queue={'a': 10}) == 'b'


def test_profile_assignment_still_selects_stronger_skill_in_same_tier(monkeypatch):
    import profiles
    monkeypatch.setenv('CHORUS_PROFILE_MODE', 'on')
    monkeypatch.setattr(profiles, '_cache', {'unknown_prior': .6, 'profiles': [
        {'match': 'a', 'skill': dict(code=.8, agent=.8, reasoning=.8, plan=.8)},
        {'match': 'b', 'skill': dict(code=.86, agent=.8, reasoning=.8, plan=.8)},
    ]})
    members = [{'name': 'a', 'model': 'a'}, {'name': 'b', 'model': 'b'}]
    assert o.assign({'difficulty': 3}, members) == 'b'
    members[1]['priority'] = 'low'
    assert o.assign({'difficulty': 3}, members) == 'a'
