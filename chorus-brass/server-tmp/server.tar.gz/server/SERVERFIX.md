
## 2026-11-01 第一批：chorus2 调度核心

做了什么：
- conduct 用 FIRST_COMPLETED 持续补位，不再等整波结束；退出时回收活动任务。
- feedback_retry 将审核意见写入新任务卡；trim_retry 压缩任务上下文并使 build_prompt 仅使用本次任务卡；rephrase_retry 写入重新表述后的执行要求。
- recovery 和待定卡的跳过使用 skipped；下游缺失依赖产物时生成 dependency_skipped 待定卡，不消费失败结果。
- 下游任务卡携带摘要、产物路径和原始回复引用；无产物标签时从回复开头取摘要。
- 项目预算停止、唤醒拒绝、调度异常补待定卡及持久化；重试循环检查暂停和项目预算。
- 定音拦截进入 awaiting_consent，允许后自动恢复；授权前不记录派发，避免恢复被去重拦截。
- 限流无可用替代成员时 assignee 置空字符串。
- 新增 test_scheduler_batch1.py，使用临时目录及不监听端口的调度测试，覆盖以上行为。

没做及原因：
- 未改 app/、/var/lib/chorus、任何 max_segment_s 等时限默认值；未 commit，遵守本批范围和沙箱限制。
- 记录放在 server/SERVERFIX.md：仓库原本无 SERVERFIX.md，遵守仅改 server/ 的要求。
- 未处理已知 test_connect、test_review_b5、test_faults 问题，属于后续批次。
- 原有 test_chorus2/test_collab_api HTTP 测试及 test_task_cards 的 HTTP 路由测试无法在此沙箱正常运行：创建 AF_INET socket 抛 PermissionError。没有修改这些测试以掩盖环境限制。

验证：
- cd server && python3 -m pytest -q test_scheduler_batch1.py test_recovery.py test_orchestra.py test_wakegraph.py：183 passed, 3 subtests passed。
- 扩展运行 test_autopilot.py/test_task_cards.py/test_redline.py，HTTP 用例因上述环境权限失败；其余结果见本次最终验证。
- 最终验证：cd server && python3 -m pytest -q test_scheduler_batch1.py test_recovery.py test_orchestra.py test_wakegraph.py test_autopilot.py test_task_cards.py test_redline.py -k 'not test_http_auth_and_new_routes'：393 passed, 1 deselected, 3 subtests passed。排除的唯一用例需要沙箱不允许的 HTTP socket。
- git diff --check 通过；跳过依赖还覆盖逆序排列的多层传播。

## 2026-11-01 补修：ladder_exhausted 决定测试

做了什么：
- 修正 test_chorus2.py::TestConcerto::test_ladder_exhausted_asks_then_decide 的旧期望：choice=1 对应“跳过这一段”，应为 skipped，而非代表成功产出的 done。保留本批服务端的跳过语义，不改生产逻辑。
- 加强同一单测：检查 ladder_exhausted 待定卡及选项、skipped 标记、决定状态和选择值；等待决定触发的真实调度任务结束，确认没有再次执行成员任务。
- Base 增加按用例选择不启动 HTTP 监听的测试配置，仅此用例使用；通过异步 JSON 请求替身调用真实 h_decide，仍执行真实恢复阶梯、决定处理及调度，使用原有临时目录隔离数据。

没做及原因：
- 此用例不再验证 HTTP 传输与认证层：当前沙箱创建 AF_INET socket 会抛 PermissionError，原用例在 setup 阶段即失败；本次关注的是跳过决定的状态语义，其他路由测试保持原样。
- 未修已知 test_connect 两个、test_review_b5 一个及 test_faults 重启偶发问题，均不属于本次指定新增失败。
- 未改 app/、/var/lib/chorus、max_segment_s 等时限默认值；未 commit。保留工作区此前已有的服务端修改。

验证：
- cd server && python3 -m pytest -q test_chorus2.py::TestConcerto::test_ladder_exhausted_asks_then_decide test_scheduler_batch1.py test_recovery.py test_orchestra.py test_wakegraph.py：185 passed, 3 subtests passed。
- cd server && python3 -m pytest -q test_chorus2.py::TestConcerto::test_ladder_exhausted_asks_then_decide test_scheduler_batch1.py test_recovery.py test_orchestra.py test_wakegraph.py test_autopilot.py test_task_cards.py test_redline.py -k 'not test_http_auth_and_new_routes'：394 passed, 1 deselected, 3 subtests passed。排除的既有 test_http_auth_and_new_routes 需要沙箱禁止的 HTTP socket，未声称全套测试通过。
- git diff --check 通过。

## 2026-11-01 第二、三批：orchestra 与 redline

做了什么：
- 核对 Opus 审查第二、三批清单。当前基线已包含 tier_of 能力分档、pick_lead 规划分优先、parse_plan 强制重置运行态字段及成员白名单、稳定拓扑排序与仅断环边、按结构压缩 compact_plan、华彩每段两位独立成员审核；运行 test_orchestra_batch2.py 验证上述行为，无须重复改写已有实现。
- 实测另发现能力画像派活跨档替换及同分覆盖历史评分，修正为在 legacy 选定档位内比较能力，同分保留价格/通过率/队列结果，排除不符合难度要求的低优先级成员。新增回归覆盖跨档、同分、同档更强能力和低优先级限制；原有三个失败全部恢复通过。
- redline 使用 shlex 解析 rm 参数，识别 -r -f、-f -r、-fr、-R、--recursive 及 -- 终止选项；规范化路径中的 . 和 ..，处理引号/空格，并保护数据目录及其祖先目录。
- 相对删除路径使用 ctx.cwd（未提供时仅用唯一工作区）；命令包含 cd/pushd/popd 时，对相对递归删除保守返回 ask，不猜测条件、子 shell 或变量展开后的目录。修复 bash -c 应在分段前解包，防止引号和链式命令影响检测。
- mv、rsync 删除同步/移除源文件、git clean、find -exec/-execdir/-ok/-okdir 执行 rm 返回 ask；更新原来允许 git clean 的旧单测。
- python -c（含版本化命令、紧贴代码、组合短选项）、base64 解码管道交给 shell 执行均 ask；保留 illegal 的 deny 优先级。
- 新增 test_redline_batch3.py。命令仅用于分类，绝不执行；需要文件路径的用例用 pytest tmp_path，其余相关调度测试沿用临时目录。

没做及原因：
- 未改 app/、/var/lib/chorus、max_segment_s 等任何时限默认值，未 commit；所有变更仅在 server/。
- 未重复实现已有 orchestra 第二批功能，也未扩展到审查第四批及以后模块。
- 未处理已知 test_connect 两个、test_review_b5 一个及 test_faults 重启偶发问题，不属于本批范围。
- 未运行需要 AF_INET 监听的既有 test_http_auth_and_new_routes：前批已确认沙箱禁止 socket；本次相关纯逻辑及不监听端口的调度回归均通过，不声称全仓测试通过。
- redline 仍为静态判定，不执行 shell 来解析目录；切换目录后的相对递归删除、mv 采用保守 ask，因此部分普通移动/工作区删除也需同意。

验证：
- cd server && python3 -m pytest -q test_orchestra.py test_orchestra_batch2.py test_redline.py test_redline_batch3.py test_scheduler_batch1.py test_recovery.py test_wakegraph.py test_autopilot.py test_task_cards.py -k 'not test_http_auth_and_new_routes'：459 passed, 1 deselected, 3 subtests passed。
- cd server && python3 -m pytest -q test_profile_assign.py test_skills_consent.py：7 passed。
- git diff --check 通过。

## 2026-11-02 FIX3：九条缺后端接口

做了什么：
- 阅读根目录 FIX3.md 九条契约及 Opus 苛刻审查第16条；保留工作区已有第二、三批未提交改动。在 server/fix3.py 集中注册新接口，沿用服务器 Bearer 鉴权。
- 创建 POST /api/projects 在首次启动前校验并保存 lead、project_caps（也接受顶层 caps/connectors/skills/ask_first）。client_id、请求指纹和首次实际生效回执随项目一同持久化；重试不重建、不重派，即使之后配置改变也返回首次回执。修正 test_uifix 的隔离依赖注入，并增加配置变化后的幂等断言。
- GET /api/account/capabilities 查询 build/search/github 的账户授权与适配器可用性；POST /api/projects/{pid}/execute/{capability} 校验账户、项目、ask_first、账户额度后调用真实异步适配器。项目授权使用已有 PUT /api/orchestra/{pid}/caps；build/search 纳入 effective 能力收窄。管理员可配置 CFG.execution_services 中各能力的 HTTPS url/token，或安装 execution_adapters 异步回调；不可用明确返回503，远端错误返回502。GitHub执行要求账户和项目的有效write权限。
- GET/PUT /api/orchestra/{pid}/duty 提供夜曲值班启停、interval_s、next_at及执行回执；应用生命周期常驻扫描，调用真实调度，完成/失败/取消更新回执。尊重夜曲能力、账户额度、休止、归档；已有执行/规划任务时不重复派发。停用停止后续调度，不隐式取消已派发工作。
- skills.matches 已在原任务单路径中使用，未重复接线；仅补 skill_load 的 matched/failed 结果和失败类型，并通过乐章快照返回。
- GET/POST /api/management/restart 提供影响范围、实例ID/启动时间、immediate/when_idle策略、request_id幂等受理及持久化状态。立即策略先等待任务取消，空闲策略等待执行/规划/root结束；调用管理员配置的 restart_service 或 management_restart_argv。新实例启动核验旧实例的 restarting 回执，记录completed、新实例ID及启动时间。没有进程管理适配器则503，不用退出进程冒充重启。
- GET /api/account/caps 增加 spent_week、week_by_currency、week_start/week_end、timezone、resolution_s、week_complete；按服务器CFG.tz的周一零点汇总持久化日账本，分币种，不依赖会淘汰的分钟桶。旧账有金额却没有币种明细时标记数据不完整。
- 所有新增分派记录事件ID、src/dst、版本；乐章快照返回 assignment_events 与段落 assignment_version。POST /api/orchestra/{pid}/handovers/{eid}/withdraw 按事件期限（需求所述10分钟）、预期版本及当前执行者CAS撤回；等待项目执行/规划/root取消，再检查版本并回派。保留进度、文件、分支，项目保持休止；拒绝已完成、过期、原执行者退出或段落删除；同请求重放返回回执，同ID改内容返回409。未改任何段落执行时限默认值。
- POST /api/orchestra/{pid}/segments/{sid}/reassign 使用 request_id、expected_version、expected_assignee，要求项目休止且段落未运行/完成，按能力、可用额度等选择其他候选并落盘，返回目标、首席、依据、事件与新版本。与撤回共享项目锁；旧手动改派增加休止保护并记录版本。
- GET /api/projects/archived、POST/DELETE /api/projects/{pid}/archive 独立归档/取消归档；使用filed与原删除态archived/deleted_at分离。归档等待任务取消并休止，普通索引隐藏；取消归档仍休止，不擅自恢复。调度、规划及成员执行入口禁止归档项目启动。
- test_fix3.py 覆盖创建原子顺序/幂等、权限及确认/失败适配器、夜曲防重入、重启受理/幂等/鉴权、账单周界及币种、乐谱回执、归档分离、撤回CAS/并发取消/进度保留、首席重派及快照字段；数据使用临时目录，不调用真实远端或进程管理器。

没做及原因：
- 未改 app/，客户端需要后续接入上述真实接口；未访问 /var/lib/chorus，未修改 max_segment_s 等时限默认值，未 commit。
- 没有部署构建/搜索/GitHub提供方、写入真实账户授权或配置生产重启命令：当前工作范围为服务端代码，且未提供这些服务的部署配置。接口真实调用配置的适配器；未配置时明确不可用，不声称外部服务已上线。账户执行授权由管理员配置CFG.account.execution，GitHub沿用CFG.account.connectors。
- 首席重派为服务端确定性能力/额度选择，并返回解析出的首席身份；不额外调用模型作自然语言决策。归档及撤回保留文件/分支，不做破坏性回滚。
- 未实现滚动额度触顶时刻预测；本周账单不冒充预测，原App静态估算口径保持。日账本只能提供日粒度完整度，无法恢复历史缺失的币种信息。
- 未处理已知 test_connect 两个、test_review_b5 一个、test_faults 重启偶发问题。未运行既有需要TCP监听的 test_http_auth_and_new_routes（此前已确认此沙箱禁止socket）；新增接口认证及路由注册用不监听端口的真实中间件测试覆盖。

验证：
- cd server && python3 -m pytest -q test_fix3.py test_uifix.py test_capabilities.py test_skills_consent.py test_profile_assign.py test_orchestra.py test_orchestra_batch2.py test_redline.py test_redline_batch3.py test_scheduler_batch1.py test_recovery.py test_wakegraph.py test_autopilot.py test_task_cards.py -k 'not test_http_auth_and_new_routes'：538 passed, 1 deselected, 13 subtests passed；两条aiohttp AppKey建议警告，不影响结果。
- git diff --check 通过；当前分支 codex/server-fix，所有工作区改动均在 server/。

## 2026-11-02 第十七条：主项与子项服务端补齐

做了什么：
- 核对已有 parent 子项实现：POST /api/projects、POST /api/projects/{pid}/children、POST /api/tasks/{pid}/{id}/children 创建独立成员、预算与进度的子项；GET children、/api/tasks、乐谱快照提供主项汇总，完成后在主聊天持久化 subproject_report 卡片并按稳定 receipt 去重。保留原有实现，不重复搭建。
- 分出子项未提供 brief 时，将已校验的来源任务标题及公开消息正文带入子项需求，避免只有来源编号、执行者却没有实际工作输入。使用创建请求原始指纹幂等，来源后来编辑不改变首次需求或回执；显式 brief 继续优先。
- /api/tasks 列表每个任务增加关联 children，保留顶层子项预算分币种汇总与进度汇总，不自动修改人工确认的任务状态。
- parent=null 明确拒绝，避免伪子项绕过主项与成员校验；删除态 archived 子项不发完成回报。
- 修正 test_subprojects 路由注册对后续执行用例的包装器泄漏，并隔离账户与首次 key 授权依赖；新增真实 asyncio 并发回归，验证同一 AI 在两个子项同时进入执行，不抢全局成员锁。已有测试继续覆盖不同成员、独立额度触顶、来源可见性、汇总、完成回报持久化及崩溃去重。
- 主人指出的 test_uifix.py::CreateContract::test_quality_and_idempotent_receipt 在本次初始复现已通过；增强断言确认持久化首次回执及账户权限变化后重试仍返回首次回执，最终整组运行通过。

没做及原因：
- 未改 app/，客户端展示和接口接入不在本批服务端范围；未访问 /var/lib/chorus，测试数据全部使用临时目录，未改 max_segment_s 或其他时限默认值，未 commit。
- 未处理已知 test_connect 两个、test_review_b5 一个、test_faults 重启偶发问题，不属于本批主项子项范围。
- 完成回报沿用已有段落全部 done 的完成判定；不把聊天回复、跳过或取消冒充项目完成。未自动确认来源任务完成，因为任务状态仍由人确认。
- 未运行既有 test_task_cards.py::Cards::test_http_auth_and_new_routes：此前已确认沙箱禁止 TCP 监听；本批路由注册及鉴权用不监听端口的真实路由和中间件测试验证，不声称全仓测试通过。

验证：
- cd server && python3 -m pytest -q test_subprojects.py test_uifix.py test_fix3.py test_task_cards.py test_orchestra.py test_scheduler_batch1.py test_recovery.py test_wakegraph.py test_autopilot.py -k 'not test_http_auth_and_new_routes'：280 passed, 1 deselected, 17 subtests passed；5 条 aiohttp 建议/弃用警告。
- git diff --check 通过；分支 codex/server-fix，变更仅在 server/。

## 2026-11-02 第九批 A：派单护栏与已用额度回归核验

做了什么：
- 本次开始时分支为 codex/server-fix，git status 为空；当前基线已经包含本批两项修复及上一轮 UI 幂等修复，因此保留现有实现，没有重复改写运行代码。
- 核对 run_segment 的首次派单、重试及限流改派不调用 GRAPH.can_wake；dispatch/retry/lead_plan/handover 只记录流转，不消耗 AI 相互唤醒的 hop、频率或来回计数。hops 独立序列化到 wakegraph.json，注册恢复并在 record 时保存，已有测试覆盖边日志截断及重新注册后仍保留 hop 限制。
- 新增真实调度回归：先耗尽 AI 唤醒跳数并序列化恢复，再执行正常派单及 429 限流改派；验证段落完成、更换执行者、记录 retry 且 hop 不增加，并断言整个执行过程不调用 can_wake。
- 核对 autopilot._pct_of 在缺少 pct 时已使用 100-used_pct；新增 pct=null、数字/字符串已用97%、已用100%、零用量、剩余5%边界和显式pct=0优先级回归。
- 指定 test_uifix.py::CreateContract::test_quality_and_idempotent_receipt 首轮复现及扩大验证均通过；现有测试已覆盖首次回执持久化、账户权限变化后重试及同ID不同内容冲突。

没做及原因：
- 两项运行逻辑和 UI 用例当前基线均已修复，无需再修改；本批仅补充针对缺口的回归测试及本记录。
- 未改 app/，未访问 /var/lib/chorus，测试持久化数据使用临时目录；未改 max_segment_s 等时限默认值，未 commit。
- 未处理已知 test_connect 两个、test_review_b5 一个及 test_faults 重启偶发失败，不属于本批范围。
- 扩大验证排除 test_task_cards.py::Cards::test_http_auth_and_new_routes：前轮已确认沙箱禁止 TCP 监听；本次不声称全仓测试通过。

验证：
- cd server && python3 -m pytest -q test_scheduler_batch1.py test_autopilot.py test_wakegraph.py test_uifix.py：101 passed，22 subtests passed。
- cd server && python3 -m pytest -q test_subprojects.py test_uifix.py test_fix3.py test_task_cards.py test_orchestra.py test_scheduler_batch1.py test_recovery.py test_wakegraph.py test_autopilot.py -k 'not test_http_auth_and_new_routes'：282 passed，1 deselected，22 subtests passed；5条既有aiohttp建议/弃用警告。
- git diff --check 通过；本批改动仅在 server/。

## 2026-11-02 第四批：协作模块接入

做了什么：
- `run_segment` 使用 `ensemble.Workspace`：每项目共享 main，每段落（含乐章标识）独立分支和 worktree；任务级 ContextVar 覆盖 CLI/DSH 的 cwd，禁用跨目录 session resume，不修改成员全局配置。首次初始化导入项目原有文件，不跟随外部符号链接。
- 执行交接包包含共同约定、上游内容、文件、机器验收规则和返工意见。段落回复/任务状态关联触发消息，避免同成员并行时串回复。服务端检查产物存在且不越界，机器验收通过、独立审核明确 PASS 后提交段落分支，再串行合并 main。冲突阻塞、保留提交分支；合并及证据落盘之前不向下游公布 done。
- `verify` 不再忽略列表 acceptance；纯文字验收标记 manual 且 passed=False，空 checks 不能绕过已有 acceptance。段落没有实际检查也不能完成。规划字段保留 checks，合并小任务保留规则，交接包说明规则；接口公开服务器 verification 与 acceptance_checked。
- `CFG.collab` 提供 assets/review_policy/split_roi/manifest/evidence 五个严格布尔开关，默认均 False，设置接口可保存。风险分数使用服务端 git diff（含新增文件）和成员统计；高风险双人审核任一未明确 PASS 均返工。ROI 不合算时合并谱稿，保留交付、验收、checks 和外部依赖。
- 图片共享接入 AssetHub：下游读取上游图片；CLI 可用原路径，支持视觉的 API 接收原图 base64 内容，不支持视觉的成员接收可用且已授权的视觉成员生成的缓存摘要。超过 4 MiB 的图片发送原文件引用及 768 像素缩略图；兼容 OpenAI/Anthropic 图片格式。摘要调用走既有账户限额、计费链并标记 share。
- 开启 manifest 时登记实际文件哈希并在下游交接时校验；开启 evidence 时把文件、验收及合并/审核决定写入项目 memory、events.jsonl 和段落 manifest，可在摘要缺失时恢复交接。
- 自动加密备份默认间隔 24 小时、保留 7 份；显式 interval_hours=0 仍关闭。未指定外部密钥时生成权限 0600 的 `DATA/backups/schedule.key`（不进入快照），外部密钥模式继续支持。升级脚本停写后运行新包里的 pre_upgrade.py，取得 writer_lock、成功完成快照才替换旧代码；快照失败启动旧服务并退出。
- 新增 test_batch4.py：真实 git + 临时目录 + 并行子进程的隔离/合并、同文件冲突、旧文件导入、CLI cwd/session、图片原文/摘要/缩略图及共享调用、验收、ROI、manifest 篡改、evidence 恢复、备份密钥与升级快照等。调度旧假成员改为真实生成测试产物并提供机器规则；恢复测试的数据目录改为临时目录。
- 指定 `test_uifix.py::CreateContract::test_quality_and_idempotent_receipt` 当前基线已通过，复跑仍通过；没有为已通过的行为重复修改业务逻辑。

没做及原因/边界：
- 未改 app/、未访问 /var/lib/chorus，未改 max_segment_s 或成员等待等时限默认值，未 commit；git 提交只发生在测试临时仓库及运行期项目工作区逻辑中。
- 未调用真实付费模型或执行部署；集成测试使用假成员/临时进程。新增原生多模态传输覆盖图片；视频/网页已有 AssetHub 能力仍未在本批开启自动抓取或扩展各厂商视频协议。
- 保留既有备份 STATE_ROOTS 范围，work/（源码、git 工作区）、CLI 登录凭据和备份密钥仍不入状态快照，避免扩大私密凭据归档范围。源码仓库与本机恢复密钥仍需单独备份；本机密钥不替代异地保存的恢复口令。
- 未处理已知 test_connect 两个、test_review_b5 一个及 test_faults 重启偶发问题。
- 当前沙箱禁止 TCP socket；test_ensemble.TestMixedProject 四项、test_backup 的 api_auth_boundaries 与 executor_health_uses_authenticated_index 两项实际尝试均在监听初始化失败，最终离线回归排除这六项，没有将其标为通过。没有宣称全仓测试全绿。
- 另验证到此沙箱 asyncio executor 线程完成不能可靠唤醒 selector（最小 asyncio.to_thread 复现）；扩大回归通过 /tmp/srvfix-test-loop/sitecustomize.py 为新事件循环加 10ms 定时唤醒。辅助只在 /tmp，不改产品或断言，不开放网络；测试命令使用 PYTHONPATH 加载它。

验证：
- `cd server && python3 -m pytest -q test_verify.py test_uifix.py test_review_policy.py test_split_roi.py`：104 passed，10 subtests passed（无辅助）。
- 扩大离线回归：在 server/ 下设置 `PYTHONPATH=/tmp/srvfix-test-loop:$PWD`，运行 `python3 -m pytest -q test_batch4.py test_verify.py test_uifix.py test_review_policy.py test_split_roi.py test_manifest.py test_evidence.py test_backup.py test_orchestra.py test_ensemble.py test_scheduler_batch1.py test_dogfood_fixes.py test_review_b9.py -k 'not api_auth_boundaries and not executor_health_uses_authenticated_index and not TestMixedProject'`，最终结果见本节末。
- `sh -n server/deploy/install.sh`、`git diff --check` 通过。
- 最终扩大回归：302 passed，6 deselected，24 subtests passed（12.91s）；六项排除原因如上。

## 2026-11-02 第四批新增失败修复：备份 API 与审核交接

做了什么：
- 保留开始时工作区已有的未提交改动。本次仅修改 server/chorus2.py、server/test_backup.py、server/test_chorus2.py 并追加本记录。
- 修正单人独立审核分支绕过指挥交接的问题：审核调用异常后标记故障成员，若其为当前指挥则交接，再由健康的独立审核员重试。交接候选排除本段执行者，不允许自审；审核员全部失败仍按原有返工/阻塞路径处理，不能完成。正常 FIX 结论不触发故障交接。双人审核保持原有保守失败处理。
- 增强指定审核测试：验证新指挥收到以【交接】开头的上下文、实际审核人为乙、审核记录及执行者未被标记故障。新增全部审核员调用失败回归，验证不自审且段落不完成；这两项调度测试不需要 TCP，使用已有 no_http_tests 机制。
- 备份 API 测试显式设置 interval_hours=0，隔离新增默认自动备份与手动备份的锁竞争，并断言没有定时备份记录。修测试配置而非修改产品默认：该用例验证手动 API 流程，自动备份已有独立回归。
- HTTP 客户端在启动前登记清理，避免监听初始化失败时泄漏。仅当 socket 被环境以 PermissionError 拒绝时，使用进程内请求执行真实路由解析、鉴权中间件和流式上传，并检查下载文件内容；允许 TCP 的环境继续运行原真实 HTTP 流程。未跳过指定测试或放宽其状态码/加密/恢复断言。

没做及原因：
- 未改 app/，未访问 /var/lib/chorus，测试数据均在临时目录；未改 max_segment_s 或任何时限默认值，未 commit。
- 未处理已知 test_connect 两项、test_review_b5 一项及 test_faults 偶发重启问题，均不属本次两项新增失败。
- 沙箱禁止 TCP，因此本次指定备份用例通过的是进程内等价路由路径，不能声称真实 TCP HTTP 已验证。扩大测试排除 executor_health_uses_authenticated_index，它必须以真实 HTTP 验证外部执行器健康检查；未声称全仓全绿。
- 无辅助的首轮测试受既有 asyncio executor 无法可靠唤醒 selector 问题阻塞，已终止；最终使用已有 /tmp/srvfix-test-loop/sitecustomize.py 定时唤醒辅助，不修改产品事件循环。

验证：
- cd server && PYTHONPATH=/tmp/srvfix-test-loop:$PWD python3 -m pytest -q test_backup.py::BackupTests::test_api_auth_boundaries_and_real_http_flow test_chorus2.py::TestLeadHandover::test_review_failure_promotes_new_lead_gets_context：2 passed。
- cd server && PYTHONPATH=/tmp/srvfix-test-loop:$PWD python3 -m pytest -q test_backup.py test_chorus2.py::TestLeadHandover::test_review_failure_promotes_new_lead_gets_context test_chorus2.py::TestLeadHandover::test_review_failure_never_promotes_executor test_batch4.py test_review_policy.py -k 'not executor_health_uses_authenticated_index'：90 passed，1 deselected，6 subtests passed，2 条 aiohttp 既有鉴权状态用法警告。
- git diff --check 通过。

## 2026-11-02 第五批：消息主流程

做了什么：
- `run_member` 的队列锁统一为 `(pid, member)`，普通乐章与子项一致；`priority=now` 也排队，编排不再绕过聊天锁。同声部在不同乐章可独立执行。
- 新增 `background.py`：所有生产代码的 `asyncio.ensure_future` 经 `spawn` 纳入共享 `BACKGROUND` 强引用集合，结束（包括取消）后移除；覆盖 server、chorus2、ensemble、adapters、plugins、voice。新增任务保活/释放及生产调用点扫描回归。
- 聊天 CLI 与 ensemble 共用按规范化物理 cwd 的锁；符号链接别名也排队，独立 worktree 仍可并行。锁覆盖 CLI session 使用和写回，取消任务会释放锁。CLI 未显式指定 cwd 时按实际继承目录加锁；DSH 与 full_access 的项目目录回退也计入。
- CLI stdout/stderr 改为分块读取，无换行也算进展；使用增量 UTF-8 解码，避免拆开汉字。执行前及每次输出重置单调时钟静默计时；等待 cwd 锁期间不计入静默提醒。复用已有 `member_timeout_ms` 配置，不新增执行截止时限，不自动杀任务。
- 提醒消息提供 `action={method,url,label}`，指向带 root_id 的本轮叫停 API；保留原成员叫停 API。修正本轮叫停按成员名杀所有进程的问题：取消命中的任务，由各任务 finally 清理自身进程组，避免波及其他乐章。
- 新增 `test_batch5.py`：now 排队、跨乐章独立执行、叫停不串房间、真实临时 CLI 的 stdout/stderr 静默重置、无换行输出、UTF-8 分块、取消清理进程/释放锁、cwd 等待不误报、共享 cwd 锁与 worktree 隔离、后台任务引用与调用点覆盖。调整旧超时测试的锁键，并隔离假模型的首次授权门；旧“两个并行 CLI 叫停”用两个独立临时 worktree 验证，旧 CLI AST 测试改为检查实际执行函数 `_call_cli`。相关消息/调用预算测试也显式隔离假模型授权，无真实模型调用。
- 指定 `test_uifix.py::CreateContract::test_quality_and_idempotent_receipt` 在本轮修改前单独运行已通过；最终连同整个 test_uifix.py 再次通过。未复现用户所述失败，未为此改动已通过的业务逻辑。

没做及原因/边界：
- 只修改 server/；未改 app/、未访问 /var/lib/chorus、未 commit。测试数据和 CLI 工作目录均为临时目录。
- 保持 `member_timeout_ms=0` 的原默认（关闭提醒），N 由现有设置指定；未擅自设定分钟数，未改 max_segment_s 或任何其他时限默认值。CLI 未配置 timeout 时仍无限等待，但可在启用提醒后获知静默并叫停。
- 服务端提供提醒操作描述并验证叫停 API；未添加 App 按钮渲染，不能声称新操作描述已在 App 上显示成按钮。已有成员叫停入口继续有效。附件独立计时和 markdown 图片渲染按用户指示留给 codex/fix3。
- 未处理已知 test_connect 两项、test_review_b5 一项及 test_faults 偶发重启问题；未做部署或真实付费模型验证。
- 扩大检查中实测 `test_review_fixes.py::ReviewFixes::test_real_http_and_stream_error_classification` 与 test_plugins 的六项在 TCP socket 初始化时被沙箱 PermissionError 拒绝；最终离线回归不包含这些测试及既有 TestMixedProject 四项，未称全仓全绿。插件任务调度替换由新增 AST 调用点测试与共享 helper 行为测试覆盖。
- 扩大回归使用已有 `/tmp/srvfix-test-loop/sitecustomize.py` 定时唤醒辅助，绕开当前沙箱已知 executor/selector 唤醒问题；不修改产品事件循环或测试断言。核心回归另以原生命令通过。

验证：
- 修改前：`cd server && python3 -m pytest -q test_uifix.py::CreateContract::test_quality_and_idempotent_receipt`：1 passed。
- 核心：`cd server && python3 -m pytest -q test_batch5.py test_member_timeout.py test_uifix.py test_subprojects.py test_review_fixes.py test_rhythm.py -k 'not real_http_and_stream_error_classification'`：71 passed，1 deselected，31 subtests passed（含 UTF-8 与静默恢复测试）。
- 扩大：`cd server && PYTHONPATH=/tmp/srvfix-test-loop:$PWD python3 -m pytest -q test_batch5.py test_member_timeout.py test_uifix.py test_subprojects.py test_review_fixes.py test_rhythm.py test_batch4.py test_ensemble.py -k 'not TestMixedProject and not real_http_and_stream_error_classification'`：95 passed，5 deselected，31 subtests passed。7 条既有 aiohttp 警告。
- `git diff --check` 通过；分支确认 `codex/server-fix`。

## 2026-11-02 第五批回归：B8 探针等待挂起与 CLI 测试兼容

定位与修复：
- 保留开始时已有未提交改动，分支为 `codex/server-fix`，本轮只改 `server/`，未 commit。
- B8 原用例的旧调用与半开探针都省略 cwd。第五批 `Ensemble.call()` 新增的物理 cwd 锁把两者串行化：旧调用持锁等待 `release[0]`，测试等待新调用的 `entered[1]` 才释放旧调用，构成循环等待。原来的 `card_timeout` 只包 adapter.run，未覆盖锁等待，因此后者无法兜底。
- 保留同一物理 cwd 串行执行的合理行为。B8 的两个受控调用显式使用独立临时 worktree 路径，继续验证旧调用完成、十次拒绝调用都不能释放活动探针，取消探针才释放它，实际 adapter 调用仍恰好两次。没有删减原有熔断器断言。
- `Ensemble.call()` 的现有 `card_timeout` 改为同时覆盖 cwd 排队和 adapter 执行。新增锁被其他任务持有时的超时回归，验证返回 timeout、未执行 adapter、探针释放、持锁者的锁未被误释放，以及锁释放后后续调用可以成功。
- 给 B7/B8、第五批调度、member_timeout、review_fixes、telemetry 生命周期测试中的事件同步、受控假任务、任务 join/gather、异步上下文退出加有限等待；共享 cwd 队列测试用 async with 确保断言失败也释放锁，并登记有超时的任务清理。这里只给测试同步设防护；未把生产环境明确配置为不限时的 `card_timeout=None` / CLI 默认执行改成强制限时。
- 完整辅助回归另发现 `test_telemetry_job.py` 两个 CLI 测试仍用只支持异步迭代的假 stdout/stderr，而第五批读取已经改为 read(n)。改用真实 `asyncio.StreamReader`（EOF 或不喂数据），保留默认不限时、显式 7200 秒、显式短超时与进程回收断言。

验证与环境边界：
- 原生核心命令：`cd server && timeout 60 python3 -m pytest -q -x test_telemetry_job.py test_review_b7.py test_review_b8.py test_batch5.py test_member_timeout.py test_review_fixes.py test_rhythm.py -k 'not real_http_and_stream_error_classification'`：88 passed、1 deselected、21 subtests passed（最终 3.01s）。排除项必须监听真实 TCP；B8 与消息主流程无辅助通过。
- 指定原生命令 `cd server && timeout 600 python3 -m pytest -q -x --ignore=test_import_live.py .` 已实际运行；它在 48 个测试进度点后停在 `test_backup.py::BackupTests::test_api_auth_boundaries_and_real_http_flow`。另用 12 秒外层 timeout、`-vv -o faulthandler_timeout=4` 定位，线程池工作线程已空闲，主线程仍在 selector.select；诊断命令退出 124。符合此前已记录的沙箱 executor 完成无法唤醒 selector 问题，不是 B8 再次挂起。
- 使用既有 `/tmp/srvfix-test-loop/sitecustomize.py` 10ms 唤醒辅助运行完整 `-q -x --ignore=test_import_live.py .`：54 passed 后，`test_backup.py::BackupTests::test_executor_health_uses_authenticated_index` 在创建 socket 时 PermissionError 失败。
- 为全面排查，用同一辅助去掉 `-x` 运行全部测试（仍 `--ignore=test_import_live.py`，外层 `timeout 600`）：修正 CLI 假流后的结果为 1148 passed、137 failed、131 subtests passed（30.35s）。逐项异常统计：137 项全部为 `PermissionError: [Errno 1] Operation not permitted`，没有其他类型失败。日志 `/tmp/srvfix-full-review-final.log`。没有修改产品网络逻辑或通过跳过测试伪造全绿。
- 另尝试仅 deselect 上述 137 个受限测试，258 passed 后遇到 `test_dogfood_fixes.py::Runtime::test_actual_plan_parsing_guardrail_and_invalid_failure`：`connect.S` 残留为缺少 member 的 SimpleNamespace，属于改变测试选择后暴露的全局状态隔离问题，未为这次排除方案修改产品。日志 `/tmp/srvfix-offline-review.log`，排除清单 `/tmp/srvfix-network-deselected.txt`。
- 本轮不能保证指定完整命令全绿：当前执行环境禁止创建 TCP socket，并有原生 selector 唤醒限制。未处理用户列出的既有 test_connect / test_review_b5 / test_faults 偶发问题，也未把环境错误标记为测试通过。
- 补充组合验证：单独组合 fault/B5/B7/B8/B9/B10 等测试时，67 passed 后 B9 `test_usage_without_project_cap_still_dispatches` 的两个 subtest 在假 run_member 未调用处失败；同用例在完整辅助回归中通过，属于测试组合/全局状态敏感的额外限制。未删断言或给本轮无关产品逻辑打补丁；核心 88 项仍通过。
- `git diff --check` 通过；本轮新增修改限于 ensemble.py、test_review_b7.py、test_review_b8.py、test_batch5.py、test_member_timeout.py、test_review_fixes.py、test_telemetry_job.py 及本记录，其他开始时已有改动保留。
- 指定原生完整命令最终由 `timeout 600` 终止，实际退出码 **124**，期间仍仅有最初 48 个测试进度点，未到达 B8。原生单独 B8 最终复跑：`cd server && timeout 15 python3 -m pytest -q -x test_review_b8.py`，10 passed（0.74s）。

## 2026-11-02 第六批：connect.py 多 CLI、邀请范围与自启

做了什么：
- `h_register` 为所有受支持 CLI 分别建立声部、独立 secret 和任务队列，同名 CLI 去重；响应新增 `members`，并保留首声部的旧顶层字段。连接器持久化全部凭证，每个 CLI 独立轮询和上报额度，兼容旧单声部 state。
- 邀请接口接受 `project`（兼容 `pid`），校验乐章存在并绑定邀请；注册只加入该乐章。无乐章上下文的邀请只注册声部，不加入任何乐章。未修改 API 密钥接入流程。
- 有 host 的注册按 host+CLI 复用原声部，包括从旧 cmd 推断 CLI；重邀轮换 secret，释放旧待返回任务并提示重试。其他机器的显示名冲突使用 host/CLI 区分，不再补 `2`；缺失 host 不冒认旧机器。测试覆盖同机复用、异机区分、旧成员迁移和旧任务释放。
- 安装器先注册并保存私密 state，再安装自启：Linux 写 systemd --user 单元、启用 linger、enable 并 restart；macOS 写 LaunchAgent plist，bootout 后 bootstrap，RunAtLoad/KeepAlive。服务文件不保存邀请或成员 secret；从 state 恢复服务器地址。命令失败会返回失败，不能静默声称自启成功。
- `save_remote` 在目标目录以 0600 临时文件写入、flush/fsync 后 os.replace；失败保留旧文件并清理临时文件，兼容缺失 hash 的旧运行时记录。新增成功、失败、权限和重载测试。
- 新增 `test_batch6.py`，不依赖 TCP 监听或真实服务管理器。`test_connect` 夹具 DATA 和连接器记录使用临时目录/独立字典；安装器端到端测试使用假的 systemctl/loginctl，并明确邀请目标。B5 原重名 `A2` 断言按新命名规则更新，继续验证旧声部队列未被替换。
- 修正 test_faults 重启测试的时间窗竞态：事件暂停依赖前两张卡的第三张卡，再取消；恢复断言加强为恰好执行剩余一张。未修改生产重启逻辑或时限。

没做及原因/边界：
- 仅改 server/，未改 app/、OneClick.kt，未访问 /var/lib/chorus，未 commit；测试文件、工作目录和服务配置均放临时目录。未改 max_segment_s 或任何执行时限默认值。
- `test_uifix.py::CreateContract::test_quality_and_idempotent_receipt` 在修改前和最终组合、单独运行均通过，未复现所述失败，没有为已通过逻辑引入无依据改动。
- macOS LaunchAgent 随用户登录启动；Linux 开机运行依赖系统允许该用户 enable-linger，拒绝时安装明确失败。测试使用 mock 服务管理器，未实际修改本机自启配置或声称已在真实 Linux/macOS 上验证开机启动。
- 未改变客户端传邀请上下文的调用；客户端须提供 project/pid，缺省时不猜测乐章。
- 无法保证完整 test_connect 全绿：沙箱禁止创建 TCP socket，20 个 HTTP 测试全部在夹具启动时 PermissionError，未进入断言；没有跳过或弱化这些用例来声称通过。需要允许本地 TCP 的环境完成真实 curl/HTTP 回归。

验证：
- 基线 `cd server && python3 -m pytest -q test_connect.py test_review_b5.py test_uifix.py test_faults.py`：45 passed、20 failed（全部 socket PermissionError）、36 subtests passed。
- 最终 `cd server && python3 -m pytest -q test_batch6.py test_review_b5.py test_uifix.py test_faults.py test_connect.py::TestConnectorState`：52 passed、36 subtests passed（5.43s）。所有本批新增测试及 B5、uifix、faults 均通过，未使用事件循环辅助。
- 最终单独 `cd server && python3 -m pytest -q test_faults.py::TestFaults::test_server_restart_mid_run_resumes_without_redoing test_uifix.py::CreateContract::test_quality_and_idempotent_receipt`：2 passed。
- 最终实际运行 `cd server && python3 -m pytest -q test_connect.py`：3 passed、20 failed（全部 socket PermissionError，0.78s），日志 `/tmp/srvfix-batch6-connect.log`。
- `git diff --check` 通过；当前分支 codex/server-fix。

## 2026-11-02 第七批：上下文预算

做了什么：
- `budget_for(m, p)` 读取项目 quality：save → save（8000）、standard → standard（20000）、max → more（60000）；build_prompt 的窗口和预算元数据使用同一项目预算。旧项目未设置 quality 时保留成员/全局 context 配置回退。
- `context.window` 为置顶分配预算份额，超大置顶在消息副本上截断，附加「置顶消息过大，已按上下文预算截断」提示；提示、消息头和消息间分隔符都计入估算预算。不修改持久化聊天原文。普通消息不再因是第一条而突破预算，单条超大消息也截断并提示。保留置顶优先、输出时间顺序及旧消息剪枝规则；无法容纳的原消息进入 fallen。
- 新增 `test_batch7.py`：覆盖三个力度与真实 build_prompt 接线、旧配置回退、中文/英文多条超大置顶、置顶加超大普通消息、零/微小预算、普通历史顺序与剪枝、真实 msg_line 保留截断提示和原消息不变。

没做及原因/边界：
- 本轮开工 git status 为空；保留当前分支已有代码，未撤销任何既有修复。仅修改 server/，未改 app/，未访问 /var/lib/chorus，未 commit；新增需要目录的测试使用 tmp_path，未改 max_segment_s 或其他时限默认值。
- 指定 `test_uifix.py::CreateContract::test_quality_and_idempotent_receipt` 未复现失败：基线整个 test_uifix.py 为 4 passed、10 subtests passed，最终组合也通过。保留持久化回执、配置变化后重试一致、请求冲突的原断言，没有无依据修改回执生产逻辑。
- 预算仍使用现有 context.tokens 粗估，作用范围为 window 的聊天消息；未将系统提示、技能或增量 CLI 会话改成新的总窗口限制。
- 完整 test_connect 的 20 个 HTTP 用例均因沙箱禁止创建 TCP socket 而失败（PermissionError: Operation not permitted），未进入业务断言。未跳过这些用例来声称完整连接测试通过，需支持本地 TCP 的环境验证。

验证：
- 实际运行 `cd server && python3 -m pytest -q test_batch7.py test_uifix.py test_review_b5.py test_faults.py test_batch6.py test_connect.py`：新增真实 msg_line 用例前为 64 passed、20 failed、36 subtests passed；失败均为上述 socket 限制。
- 最终 `cd server && python3 -m pytest -q test_batch7.py test_uifix.py test_review_b5.py test_faults.py test_batch6.py test_connect.py::TestConnectorState`：65 passed、36 subtests passed（4.90s）。
- `git diff --check` 通过。

## 2026-11-02 第八批：工作区路径、导入安全、审计轮转

做了什么：
- 副本工具根目录随当前服务 DATA 使用 `DATA / "work"`，校验和错误提示不再写死旧部署路径；保留独立子目录、禁止路径穿越和逐级 O_NOFOLLOW 限制。新增临时 DATA 路径回归。
- 聊天 ZIP 在读取内容前累计检查解压声明大小（32 MiB）和条目数（2000），嵌套解析共享预算、限制错误不得被单文件容错吞掉；内存导入 ZIP 使用同一上限。按 ZipInfo 读取，避免重名条目反复导入最后一个文件；新增累计大小、数量、嵌套、重复名称及两类 HTTP 错误回归。
- 未知格式默认仅返回 requires_consent、费用及外发提示，明确 `allow_helper: true` 才调用辅助模型；超过 80000 字时，在确认前和转换后都告知仅导入部分。新增拒绝隐式调用和明确同意后的输入长度回归。
- PARSED 使用单调时钟，10 分钟失效；请求时清理并用定时回调清除闲置上传，过期提交返回 410。日期使用全部消息中最早的有效时间，不再只取首条。新增到期、闲置清理及首条缺失日期回归。
- dm_notify 在当前服务器上复用 HookEngine，DATA 变化时重建；审计按 5 MiB 轮转并保留 3 个备份，内存记录/重载最多保留 2000 条，启动时也处理超限文件。新增实例复用、目录切换、轮转文件和内存上限回归，既有审计导出测试通过。

没做及原因/边界：
- 仅修改 server/，未改 app/，未触碰 /var/lib/chorus，测试持久化使用临时目录；未改 max_segment_s 等运行时限默认值，未 commit。开工 git status 为空，当前分支 codex/server-fix。
- 指定 test_uifix 的回执失败未复现：开工单独运行已通过，最终包含整个文件的组合也通过；未无依据修改已存在的回执逻辑，保留其持久化、重试及冲突断言。
- 前端确认卡未接线（禁止修改 app/）：当前服务端不会再静默转换未知格式；调用方须展示响应中的费用/截断提示并取得同意后重新上传且带 allow_helper=true。无法预报实际金额，因为取决于配置的模型服务商。
- PARSED 仍为进程内缓存，重启需重新上传；轮转备份为有界留存，read_all/query/export_jsonl 查询当前内存最近记录，不合并历史备份。
- 初次整文件回归发现 test_workspace_tools 的 NativeTools 和 HTTP 认证测试因沙箱禁止 TCP socket 失败；另两个 WorkspaceConfiguration 用例未绑定 chorus2.S，进入既有 retry_unavailable 时失败。未删断言或伪装这些测试全绿，最终选择实际相关的无 socket WorkspaceFiles 与新增 DATA 测试。既有 test_import_live 同样需支持 socket 的环境（自动跳过）。

验证：
- 最终实际运行：`cd server && python3 -m pytest -q test_batch8.py test_import_handlers.py test_hooks.py test_dm_notify.py test_workspace_tools.py::WorkspaceFiles test_uifix.py test_batch7.py test_batch6.py test_review_b5.py test_faults.py test_connect.py::TestConnectorState`。
- 结果：153 passed、36 subtests passed（5.94s）；上述选择的测试全部通过，包含所指定的 test_uifix 回执用例和 test_review_b5/test_faults。
- `git diff --check` 通过。

## 2026-11-02 第九批 B：审核优先级与 autopilot 接入

做了什么：
- 审核决策抽出 review_required：项目华彩/风险双审优先，orchestra.review_needed 与 autopilot.review_policy 改为或关系；不再要求指挥必须与执行者不同才进入审核，审核阶段仍选独立成员，不可用则阻塞。30% 确定性抽查、难度/低通过率要求不会被省钱模式否决。review_policy 自身也优先接受段落 quality=max。保留真实工作区原有强制审核要求，不降低现有审核覆盖率。
- 新增 CFG.autopilot.batch/cache_plan 严格布尔开关，默认均 False，现有 settings/config 接口可保存和读取；非法值返回 400，不修改配置。
- conduct 在无活动任务时调用 autopilot.batch 合并尚未执行的便宜小活：同成员、同依赖、同执行策略，难度 1–2，有正整数 token 估算，合计不超过 batch 既有 6000 token 默认预算。华彩、重试/恢复、已计费及缺估算任务不合并。合并保留全部目标、交付物、上下文、acceptance/checks，原始任务快照存入 batch_segments；下游依赖重写到合并段落，执行、验收、审核和工作区合并仍走原路径。没有改变运行时限。
- 普通 API 请求在开关开启时调用 cache_plan，把已构建的 system 作为前缀、当前 task 作为 user；system 已含 persona/技能，不重复拼入。OpenAI 兼容请求去掉内部 cache 标记，依赖供应商自动前缀缓存；Anthropic 映射为已有 ephemeral cache_control。多模态任务内容原样保留，沿用已有 usage 缓存计量。
- 新增 test_batch9b.py：覆盖抽查在 normal/frugal/minimal 下不被否决、任一策略触发、华彩与双审优先、实际 minimal 预算下双人审核、合并合同和下游依赖、危险任务排除、开关校验与保存、真实调度从两次执行合成一次且检查两份产物、默认关闭仍分别执行、两种 API 的缓存接线及多模态内容保持。

没做及原因/边界：
- rank_candidates 未直接用于初次派工；已有 escalate 在升级路径间接调用它，本批保留现有 orchestra.assign 的质量、健康、额度及优先级约束。should_wake 未接入唤醒链（现有授权/定向派工语义需单独核对）；counterfactual 未接账本展示（缺少统一对照价格及展示口径）；stop_early 未接执行循环（不能用局部通过结果跳过工作区验收、审核和合并）。
- cache_plan 不覆盖 CLI 或启用 workspace_tools 的 API 工具循环；这些有独立会话/消息构建路径，不能只替换普通请求体。既有 Anthropic 默认缓存行为保留，关闭新开关不会关闭原有缓存；缓存实际命中仍由供应商决定。本轮未移动系统提示内部的动态记忆/摘要，命中收益受其变化影响。
- batch 是执行前的持久化谱稿合并，不是多份独立任务共享一次返回文本；原任务 ID/合同保存在 batch_segments，下游使用合并任务 ID。保守要求同依赖和策略，避免改变任务顺序或丢失验收。开关关闭不自动拆回已经合并的任务。
- 开工 git status 为空（未发现提示中的上一轮未提交改动），分支 codex/server-fix；仅修改 server/，未改 app/、未触碰 /var/lib/chorus、未 commit；持久化测试使用临时目录，未改 max_segment_s 等时限默认值。
- 指定 test_uifix.py::CreateContract::test_quality_and_idempotent_receipt 未复现失败：基线整个文件 4 passed、10 subtests passed，最终组合也通过；保留其持久化回执、配置变化后重试一致及冲突断言，未无依据修改生产回执逻辑。

验证：
- 最终实际运行 `cd server && python3 -m pytest -q test_batch9b.py test_autopilot.py test_orchestra.py test_orchestra_batch2.py test_uifix.py test_review_b5.py test_faults.py test_connect.py::TestConnectorState`：222 passed、45 subtests passed（6.40s），本批与所选相关回归全部通过。
- 完整实际运行 `cd server && python3 -m pytest -q test_connect.py`：3 passed、20 failed（0.75s），20 个 HTTP 用例全部因沙箱禁止创建 TCP socket 的 PermissionError 未能进入业务断言；日志 /tmp/srvfix-b9b-connect.log。未声称完整连接测试全绿，需允许本地监听的环境补验。
- `git diff --check` 通过。

## 2026-11-02 第十批：索引落盘、适配器管道与后台额度刷新

做了什么：
- artifacts 索引原本已有临时文件替换，本批补齐独占创建临时文件、flush、文件 fsync、os.replace、父目录 fsync，并在失败后清理临时文件。写入或替换失败保持旧索引完整；新增顺序、内容和故障回归。
- CliAdapter/AcpAdapter 默认超时由 3600 改为 600 秒（与 API 适配器现有默认一致）；可通过成员 timeout 配置，构造参数 timeout 优先。仅调整本批明确要求的适配器超时，没有修改 max_segment_s 等调度时限。
- CLI 的 stdin 写入、stdout 解析、stderr 排空和退出等待并发进行，整段纳入超时；stderr 持续排空、只保留有界诊断尾部。ACP 同样并发排空 stderr。超时/取消清理进程组并回收进程、读取任务。新增真实临时子进程测试：大 stdout/stderr 先于大 stdin、非零退出诊断尾部、stdin 阻塞、stdout 提前 EOF、ACP RPC、大 stderr、超时和取消回收。
- POST /api/quota/refresh 立即返回 202，含 state、error、quota_at、status_url；重复点击复用正在进行的全量任务。新增 GET /api/quota/refresh 返回 idle/running/done/failed/cancelled 状态及当前 quota 结果；原 index 轮询和完成后的 bump 保留。失败不留下 running 状态，也不泄露异常详情，完成后可再次刷新。
- 充值/更新价格接口 h_wallet 中的额度探测也移到后台；Codex 本地额度日志扫描委派 asyncio.to_thread，避免后台协程仍同步阻塞事件循环。新增立即响应、去重、轮询完成、失败、取消、重试、路由、充值响应及线程委派回归。
- test_uifix 的固定 /tmp/uifix-contract-only 改为每个测试独立 TemporaryDirectory；保留创建回执的持久化、配置变化后重试一致及请求冲突全部断言。

没做及原因/边界：
- 开工 git status 为空，分支 codex/server-fix；没有发现提示中的上一轮未提交改动。指定 test_uifix 回执失败未复现：基线 4 passed、10 subtests passed，最终仍通过，因此未无依据修改生产回执逻辑。
- 仅改 server/，未改 app/，未触碰 /var/lib/chorus，未 commit；测试文件/子进程工作区均用临时目录。
- 新刷新状态为进程内的当前全量手动任务，重启回到 idle；不是持久化任务历史。原有定时刷新和局部刷新仍可独立执行，未改变每成员探测的 90 秒时限、调度周期或额度判断语义。充值接口后台探测继续通过原 index 展示结果。
- 参照审查中的 fsync、stderr 死锁和默认超时条目；本批未扩展修复索引读坏时的恢复、blob 保留策略、CLI 文本截断/用量映射等其他审计项。
- 完整 test_connect 实际执行为 20 failed、3 passed，失败均为沙箱禁止 TCP socket 的 PermissionError，日志 /tmp/srvfix-b10-connect.log。扩大选择时，test_remote_quota 的 3 个 ServerShows 测试、test_ensemble 的 HTTP 用例也受同一限制，未修改或跳过其断言来声称完整 HTTP 测试通过。
- 扩大选择的 test_review_b9::B9Runtime::test_usage_without_project_cap_still_dispatches 有两条子测试未派工，涉及既有审核/派工合同，不属于本批修改范围；该组合结果为 2 failed、62 passed、43 subtests passed，保留原断言。
- 一次包含 test_collab_api 的扩大运行及一次真实 to_thread 测试在执行器关闭时挂起，已中止；线程委派回归改为 AsyncMock 验证实际调用及结果，不宣称本环境已验证真实线程关闭行为。没有以这些未完成运行计入通过数量。

验证：
- 最终实际运行：cd server && python3 -m pytest -q test_batch10.py test_uifix.py test_review_b5.py test_faults.py test_connect.py::TestConnectorState test_remote_quota.py::ConnectorReads test_remote_quota.py::Normalize test_ensemble.py::TestPieces test_review_b9.py::Storage。
- 结果：69 passed、44 subtests passed（6.05s），本批及所选相关回归全部通过；2 条既有 aiohttp 弃用/键类型提示。包含指定 test_uifix、整个 test_review_b5 和整个 test_faults。
- git diff --check 通过。

## 2026-11-02 主项／子项服务端补齐（SUBITEMS_APP.md）

仅修改 server/，未提交。按原文六条及额外第七条逐项处理：

1. `GET /api/projects/{pid}/children` 的 `items[]`（即 children.summary）与独立详情新增 `running_status`（resolved/paused/awaiting_user/running/idle）、`waiting_for_user`、`pending_decisions`、`dependency_reasons[{segment_id,depends_on,reason}]`、`last_activity_at`（Unix 秒，未知 null）、`estimated_seconds`（未知 null）、`resolved`、`resolution`、`completion_reported`、`assign_log`、`source_artifact_ids`、`consent_cards`。状态读取真实任务、执行根、调度器、待定卡和定音台账；活动时间包含消息、段落事件、项目更新及审计。预计时间只接受明确输入，不编造预测。无小节手工解决后 pct=100，done/total 仍为真实小节数 0/0；主项百分比用至少为1的子项权重统计。
2. `GET /api/chat/{pid}?v=0` 的 `project` 增加 `parent/source_task_id/source_message_ids`。新增 `GET /api/projects/{pid}/subitem`：包含上述摘要，以及 `brief/context/acceptance_criteria/source_task/source_messages/tasks/segments/messages/source_artifacts/artifacts/artifact_lines/handoffs/resolution`。`messages` 为完整正式群消息，不包含私信、直播片段、撤回和删除消息；最近12条由 App 自行截取。来源消息同样过滤私信和撤回。来源任务和消息在创建时保留快照供执行上下文使用，详情仍显示当前可见来源。
3. 创建支持 `assignment_reason`（默认“用户手工选择成员”），换人支持 `reason`；记录持久化在对应子项，不冒充自动分配结论。自动段落派发和限流改派也写入子项 assign_log（kind=dispatch，带 segment_id 和真实选择快照）；画像 shadow 记录新增 project_id/segment_id/mode，明确区分影子建议和派发决定。`GET /api/collab/assign_log?project_id={child_id}` 支持按项目过滤，返回记录带 `project_id`。无过滤时保留原全局记录并追加子项手工记录。新增 `POST /api/projects/{parent_id}/assignment-preview`，正文 `{source_task_id?, brief?, skill?}`，按来源任务内容推断代码题材（或显式 skill）；返回 `items[{member,skill,score,busy,available,quota,price,historical_pass_rate,reason,unknown_factors}]` 和 `persisted:false`。使用现有能力档案、真实忙闲、额度可用性、配置价格、已有审核指数移动通过率排序；缺数据返回 null 并列入 unknown_factors，题材不明要求手工选择。跨币种不做汇率换算；未建设语义分类模型，代码关键词以外请显式提交 skill。预览不派活、不写“实际派活理由”。
4. 新增 `POST /api/projects/{child_id}/subitem/replace-members`，正文 `{client_id, members:["成员"], reason?}`。返回 `{ok,project_id,client_id,handoff}`。完整项目成员、未完成段落 assignee、lead、交接包和分派记录在一次 projects.json 原子替换中提交；写入失败不改变内存或磁盘项目。支持无小节子项，独奏限制一人。已有完成段落保留历史署名。规划／执行／审核在途返回409，请先用原有 pause/room stop 并等待在途结束；接口不在事务中取消外部模型请求。交接包包含完整正式群聊、目标、验收条件、任务、来源、所有段落及产物路径、登记产物各版本、随行产物。`handoff.status=stored` 表示服务端持久接收，不表示新成员已经阅读；后续普通执行及协奏模型调用自动注入该包。不会自动恢复或发起付费执行。
5. 新增 `POST /api/projects/{child_id}/subitem/resolve`，正文 `{client_id,note?}`，返回 `{ok,project_id,client_id,resolution,report_receipt}`。一次原子项目提交同时记录独立 resolved、paused、所有小节 done、验收记录、请求回执和待回报状态；无小节也可解决，不伪造小节。验收后向主项发送真实 subproject_report，稳定凭据 `subproject:{child_id}` 防重。主项聊天不与 projects.json 共用存储事务，因此使用持久待回报记录：聊天写入失败时已提交的验收仍成功，下次调度 tick／save_projects 自动重试；进程重启也恢复，聊天已写而项目标记未写的崩溃窗口按稳定凭据去重。App 应将接口成功视为验收已持久化，以主项报告或详情 completion 状态核实报告投递，不能将网络超时视为失败并换新号。对写入提交前的失败保证回滚；不承诺外部聊天存储同步提交。
6. 两种原有子项创建路径及 `POST /api/projects` 的 parent 模式新增 `source_artifact_ids:[id]`（最多100）、`context`、`acceptance_criteria`、`estimated_seconds`。产物必须在主项产物仓库存在，且 blob 可读、SHA256 验证一致；跨项目、私密、缺失、损坏产物返回400，创建前校验，不生成子项。交接保留 `source_artifacts[{id,project_id,artifact,transfer_mode:"reference",blob_path,content_url}]`；文件以服务端持久 blob 引用和真实内容接口随行，未声称已复制到新成员机器。内容路径为原有 `GET /api/collab/{parent_id}/artifacts/{aid}/content`。创建幂等回执不依赖来源仍可读取，并在产物异步读取后再次检查请求号以防并发重复创建。历史消息可提交任意有效正式消息序号，沿用最多50条验证；原始消息附件随消息快照交接，非登记产物没有伪造 artifact ID。
7. 创建子项时为具有 model 的 API 成员提前登记定音卡；创建回执增加 `consent_cards`（含 id/state/member/project_id），详情和摘要实时按项目成员及模型/key 指纹关联台账，无需等首次执行后刷新。允许／拒绝继续使用原有 `POST /api/collab/consent`，绝不自动允许；同一模型/key 在多个项目共用既有授权语义，不引入项目独立授权。关闭 consent 或 CLI/dsh 不登记 API 定音卡。

两个新写接口都必须提供非空 client_id（最多128字符）：同项目同操作同请求号同正文返回原回执，改正文返回409。已归档、已解决或仍在执行时拒绝新操作。所有新路径继续使用现有登录校验，保留旧路径和旧字段。

验证覆盖：test_subprojects.py 原11项加12项，覆盖每条缺口、登记产物交接与执行提示、来源校验／隔离／缺失blob、无小节解决、全部段落一次收束、写失败回滚、报告写失败恢复与防重、并发幂等、不同正文冲突、在途拒绝、项目派活记录、真实费用和通过率预览、项目定音卡及新路径鉴权。

验证结果：

- 子项专项：`PYTHONPATH=/tmp/srvfix-poll python3 -m pytest -q test_subprojects.py`，23 passed（原11项＋新增12项）。
- 全量：`cd server && PYTHONPATH=/tmp/srvfix-poll python3 -m pytest -q`，1245 passed / 137 failed / 1 skipped / 139 subtests passed；修改前 HEAD 在 /tmp 独立副本以相同条件运行，1233 passed / 137 failed / 1 skipped / 139 subtests passed。137条失败测试名称完全一致，新增失败为0。失败包括既有 test_connect 两项和当前沙箱禁止 TCP socket 导致的 HTTP 测试失败（`PermissionError: [Errno 1] Operation not permitted`），不能宣称全绿。
- 原始 `cd server && python3 -m pytest -q` 已尝试，在 asyncio 执行器退出时挂起；独立最小程序 `asyncio.run(asyncio.to_thread(lambda: None))` 也复现。上述临时 `/tmp/srvfix-poll/sitecustomize.py` 仅将 EpollSelector 单次等待限制为50ms，解决环境中线程唤醒不生效的退出挂起，未放进仓库、未改变产品或测试断言、未跳过任何用例。全量结果是在该环境补丁下取得；仍需允许本地 TCP socket 的环境复跑原命令才能验收全绿。
- `git diff --check` 通过；专项加画像与调度回归共44 passed / 3 subtests passed。仅 server/ 文件发生变化；分支 codex/server-fix；未 commit。

## 2026-11-02 龙娘审计：服务端中档与低档

依据 `/mnt/project-files/chorus-brass/audit/opus_review_20261101/逐行_龙娘.md`。开工分支 `codex/server-fix`，工作区干净；本批只修改 server/（测试数据、数据库、进程文件和基线副本均位于临时目录），没有 commit。

逐项修复与测试：

1. `dm_index.py`：删除时保存 `hidden_cursors={pid:seq}`，恢复判断逐项目比较；新项目的低序号消息能恢复私信。恢复操作清除全部删除游标，保留旧 `hidden_seq` 数据的兼容读取。回归覆盖 p=900、q=1 删除后 q=2 恢复，不再被 p 的高序号遮住。
2. `context.py`：遇到超长最新非置顶消息，用剩余预算截断再保留；有普通消息时，为它们保留一半预算，置顶平分其余预算。覆盖多个超长置顶、超长最新要求、预算上界、顺序及不修改存储原文。原 test_batch7 中要求丢弃最新消息的三项断言随新合同更新，预算和原文保护断言保留。
3. `concierge.py` 预算：遍历所有数字，过滤没有预算或币种标记的候选，明确预算／上限优先。覆盖“2个人用，预算100元”、英文美元、前置其他金额、人民币和无金额情况。
4. `concierge.py` 确认：项目首次原子保存即包含 queued 状态、规划正文、intent 凭据和确认方案；复用 chorus2.queue_plan 后立即返回 HTTP 202。queued/planning 在服务生命周期启动时恢复，失败保持 failed，可用原确认接口重试同一项目；重复确认不重复建项目、不并发重复规划。项目已落盘而配置保存失败时，按持久 intent 凭据找回项目。测试覆盖阻塞模型下立即响应、磁盘任务状态、失败重试、去重、配置写失败恢复和启动恢复；旧设计方案测试替身补齐后台队列接口，并保留设计会话关联断言。后台规划仍是可重启重试语义，不承诺崩溃时外部模型请求恰好执行一次。
5. `voice.py` 打断：抽出并复用 `stop_round(pid, root_id)`，只取消本轮执行根及其派生任务；等待拥有者 finally 回收 CLI 子进程组。移除按成员全局 stop，关闭 WebSocket、切换会话和异常退出也清理当前轮次；初始回答已结束而后续分支仍在运行时同样按根取消。覆盖其他项目同成员任务不受影响、CLI 回收、已结束初始任务的后续取消。
6. `voice.py` 识别：每次最多4秒，超时／网络／HTTP失败自动重试一次，总期限8秒；每次重建 multipart 表单，取消不重试。失败最终进入现有语音错误消息通道，未虚构本地识别引擎。测试验证重试、不同请求体、短期限和取消传播。
7. `plugins.py`：安装进程独立进程组，正常／失败／取消路径均终止整个组并 await wait 回收；卸载改为异步，等待任务清理后再删除模型文件，并阻止卸载期间重装。覆盖回收先于删目录、重装拒绝，并用真实 Python→sleep 后代进程验证整组已终止（孤儿僵尸的最终 reap 由 init 负责）。调用接口和原测试均改为 await uninstall。
8. `workspace_tools.py`：替换前读取原 mode，写入临时文件后 fchmod，再 fsync 和 replace；保留可执行位与私有权限。写回结果、基线与 review_diff 的 changes 记录 mode_before/mode_after。测试覆盖0755、0640、0700和交审权限信息；新文件继续使用0600。
9. `telemetry_job.py`：汇总服务器配置时区内已结束的前一天，以 `last_report_date` 去重；旧的“今天已尝试”记录不再遮住昨天的报告。覆盖本地午夜边界、今日／更早日期排除、持续去重；原并发 tick、持久化、网络失败不重复上传测试保留。
10. `deploy/install.sh:20`：最低 Python 改为3.11，与头像的 asyncio.timeout 接口一致。
11. `deploy/install.sh:60`：root 收归 /opt/chorus2 后，仅将实际运行解释器的 venv 交给 chorus，使插件 pip 可写；服务端源码仍归 root。测试检查版本和 chown 顺序；`sh -n` 通过。未执行真实安装。原83／96行涉及的环境字段读取与配对逻辑完整保留；当前 HEAD 配对地址仍为 HTTP，本批未触碰这项高档问题。
12. `task_cards.py`：任务状态与审计分开为 `tasks/{pid}.json`、`tasks/{pid}.audit.json`，每项目最多1000条、保留90天。GET 保持 audit 字段，增加 audit_offset/audit_limit 分页，每页最多100条；普通任务读取不加载历史审计。状态原子保存携带待投递审计，随后写独立审计并清除待投递记录；稳定 event_id 防止中途失败后重复投递，旧内嵌审计在读取时迁移。覆盖上限、保留期、分页、迁移和审计写失败后的恢复；原任务更新／提案确认／备份测试继续运行。
13. `checkpoints.py`：事件默认保留30天，可由构造参数调整；启动清理，持续写入时每小时清理一次，时间列增加索引。只清理过期事件，任务卡与幂等副作用凭据不删。测试覆盖重启清理、运行中清理以及卡片／凭据保留；SQLite 删除页可复用，不每次 VACUUM。

验证：

- 新增 `test_audit_medium_low.py`：19 passed、6 subtests passed，包含上述13条的离线回归。
- 原始指定命令 `cd server && python3 -m pytest -q` 已实际启动两次（修改前及最终），均在 asyncio 执行器退出处挂起，已中止；日志分别为 `/tmp/srvfix-baseline.txt`、`/tmp/srvfix-audit-raw-final.log`，不把未完成运行计为通过。
- 最终无需环境补丁的相关离线回归：`cd server && python3 -m pytest -q test_audit_medium_low.py test_task_cards.py test_telemetry_job.py test_workspace_tools.py::WorkspaceFiles test_batch7.py test_designopts.py -k 'not http_auth_and_new_routes'`，89 passed、1 deselected、23 subtests passed（1.90s）。排除的HTTP项在全量中照常执行且失败，没有删除或弱化鉴权断言。日志 `/tmp/srvfix-audit-offline.log`。
- 使用既有 `/tmp/srvfix-poll/sitecustomize.py`（仅将 EpollSelector 单次等待限制为50ms，处理本沙箱线程唤醒／退出挂起；不入库、不改产品、不跳过测试）完成全量：`cd server && PYTHONPATH=/tmp/srvfix-poll python3 -m pytest -q`。结果 **1264 passed、137 failed、1 skipped、145 subtests passed**（39.78s）。日志 `/tmp/srvfix-audit-final.log`。
- 修改前 HEAD 的 server/ 与原 tools/ 在 `/tmp/srvfix-audit-baseline` 独立副本，以完全相同环境补丁和命令运行：**1245 passed、137 failed、1 skipped、139 subtests passed**（39.16s）。日志 `/tmp/srvfix-audit-baseline.log`。137条失败测试名称集合完全一致，新增失败0，全部失败均为沙箱 `PermissionError: [Errno 1] Operation not permitted`（禁止 TCP socket）。不宣称全量全绿，仍需允许本地监听的环境复跑原命令。
- 全量首跑曾有额外4项旧测试合同／替身失败，已按第2、4条修正后重跑，以上数字为最终结果。
- `git diff --check`、安装脚本语法检查通过。未改 server/ 以外的仓库文件，未 commit。

## 2026-11-02 龙娘：轮次停止记录污染修复

本次沿用已有脏工作区，分支 `codex/server-fix`；只新增修改 `server/server.py`、`server/test_rhythm.py` 及本文件，未 commit，保留此前修改。

根因：语音取消现在调用 `stop_round`，会写入进程全局 `STOPPED_ROOTS[root_id]`。`reserve_call` 原先仅检查编号是否存在，不比较停止时间与本轮 `_budget.t0`。因此前序轮次留下 `p:1` 后，重置聊天序号／复用客户端编号产生的新轮次也被永久阻断；目标用例表现为实际调用 0 次、期望 8 次。不是 task_cards 审计文件、checkpoints 或 telemetry 路径污染。

产品修复：用已存的停止时间与预算共享的轮次开始时间比较，只有停止时已经存在的执行被拦截。旧分支共享原 t0，所以交接空档的停止保护继续有效；显式 budget.stopped、整群 STOP_AT 和缺少 t0 的保守行为保留。新增测试覆盖停止前、同一时刻、停止后复用同编号，以及显式 stopped，不修改原失败用例或断言。

验证：

- 用独立 Python 进程预置 `STOPPED_ROOTS['p:1'] = time.time()` 后运行原目标测试。仅在该进程内恢复旧判断可稳定复现 `AssertionError: 0 != 8`；相同预置状态使用修复代码，目标用例及 `test_rhythm.py` 合跑 **7 passed、3 subtests passed**。
- 原始指定全量命令已启动，在输出约67个点后持续无进展，已中止；当前沙箱仍有此前记录的 asyncio 执行器退出挂起问题。
- 使用已有 `/tmp/srvfix-poll/sitecustomize.py`（仅限制 epoll 单次等待50ms，未入库）完成指定全量命令的前后对比：`cd server && PYTHONPATH=/tmp/srvfix-poll python3 -m pytest -q --ignore=test_import_live.py -p no:cacheprovider .`。修复前 **1264 passed、137 failed、145 subtests passed**（40.35s）；修复后 **1265 passed、137 failed、148 subtests passed**（39.26s）。137个失败名称集合完全一致，目标测试全量通过。日志 `/tmp/srvfix-state-before.log`、`/tmp/srvfix-state-after.log`。沙箱禁止 TCP socket，HTTP测试报 `PermissionError: [Errno 1] Operation not permitted`；其中语音HTTP测试在 setUp 就失败，故本环境的全量未走到原污染路径，另以上述直接预置状态复现补充证据。
- 额外尝试 `test_audit_medium_low.py test_rhythm.py test_review_fixes.py -k 'not real_http'` 的特殊顺序组合，38 passed、5 failed、1 deselected；该组合暴露 `chorus2.S is None` 的另一项初始化依赖，涉及用量记录／后台调度，并非本次停止记录判断，未据此宣称相关组合全绿。日志 `/tmp/srvfix-state-focused.log`。
- `git diff --check` 通过。受当前执行环境限制，**无法确认原始命令除 test_connect 两项外全绿**；还需在可创建本地 TCP socket 且 asyncio 正常唤醒的环境执行原命令验收。未跳过全量中的HTTP测试，未将环境补丁写入产品代码。
