"""一键接入: (A) CLI/agent members join through a single-use invite the user pastes to their AI or terminal; a tiny
stdlib connector on their machine registers, reports which CLIs it has, then long-polls for jobs. (B) API members:
paste a key (or the whole clipboard) and the server detects the vendor, probes, picks a default model, test-calls.
Tokens travel only in headers / JSON bodies (never URLs, never logs); the server keeps sha256 of member secrets."""
from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import math
import os
import tempfile
import pathlib
import re
import secrets
import time
from collections import deque
from urllib.parse import urlsplit

import api_errors as errors

from aiohttp import web

TTL = 600
HERE = pathlib.Path(__file__).resolve().parent
S = None        # server module
C2 = None       # chorus2
INV = {}        # invite token -> {"expires","state","at":{state:ts},"member","error","created"}
REMOTE = {}     # member name -> {"hash", "queue": asyncio.Queue, "wait": {job id: future}, "seen", "clis"}
METRICS = {"connected": deque(maxlen=1000)}   # seconds from invite to 已接入
TEST_TASKS = set()
OFFLINE_REASON = "连接器超过 60 秒没上线，成员已离席"


def _h(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


# ---------------------------------------------------------------- (B) paste a key
# (pattern, vendor id in server.CATALOG or a base URL). Ordered: specific prefixes first.
KEY_RULES = [
    (r"sk-ant-[A-Za-z0-9_\-]{20,}", "anthropic"),
    (r"sk-or-v1-[a-f0-9]{40,}", ("openrouter", "OpenRouter", "openai", "https://openrouter.ai/api/v1", "openai/gpt-5-mini")),
    (r"tp-[A-Za-z0-9_\-]{16,}", ("mimo", "小米 MiMo（Token Plan）", "openai", "https://token-plan-cn.xiaomimimo.com/v1", "mimo-v2.6-pro")),
    (r"xai-[A-Za-z0-9]{20,}", "xai"),
    (r"AIza[0-9A-Za-z_\-]{30,}", "gemini"),
    (r"gsk_[A-Za-z0-9]{20,}", ("groq", "Groq", "openai", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile")),
    (r"[a-f0-9]{32}\.[A-Za-z0-9]{16}", "zhipu"),
    (r"sk-proj-[A-Za-z0-9_\-]{20,}|sk-svcacct-[A-Za-z0-9_\-]{20,}", "openai"),
    (r"sk-[A-Za-z0-9]{32,}", None),   # ambiguous sk-: DeepSeek / Moonshot / SiliconFlow / Qwen / relays — probe them all
]
AMBIGUOUS = ["deepseek", "moonshot", ("mimo-api", "小米 MiMo（按量）", "openai", "https://api.xiaomimimo.com/v1", "mimo-v2.6-pro"), ("siliconflow", "硅基流动", "openai", "https://api.siliconflow.cn/v1", "deepseek-ai/DeepSeek-V3"),
             ("qwen", "阿里云百炼（通义千问）", "openai", "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-plus"), "openai"]


def explain(err) -> dict:
    result = errors.upstream(err)
    return {**result, "message": result["error"]}


def _vendor(v):
    if isinstance(v, tuple):
        return v
    c = next((x for x in S.CATALOG if x[1] == v), None)
    return (c[1], c[2], c[3], c[4], c[5]) if c else None


def detect(text: str) -> list:
    """Every (key, vendor tuple, base override) the pasted text could be. Base URL in the text wins (relays)."""
    text = text or ""
    base = None
    m = re.search(r"https?://[^\s\"'<>，。]+", text)
    if m:
        base = m.group(0).rstrip("/.,)")
    out, seen = [], set()
    for pat, v in KEY_RULES:
        for k in re.findall(pat, text):
            if k in seen:
                continue
            seen.add(k)
            if base and v != "anthropic":
                out.append((k, ("relay", "中转站", "openai", base, ""), base))
            elif v is None:
                out.extend((k, _vendor(a), None) for a in AMBIGUOUS if _vendor(a))
            elif _vendor(v):
                out.append((k, _vendor(v), None))
    if base and not out:
        # 中转站的 key 形态五花八门：地址旁边最像 key 的那一串都当候选；地址不带路径就再试一遍 /v1
        rest = text.replace(m.group(0), " ")
        for k in re.findall(r"[A-Za-z0-9_\-.]{16,200}", rest)[:3]:
            if k not in seen:
                seen.add(k)
                out.append((k, ("relay", "中转站", "openai", base, ""), base))
    if base and urlsplit(base).path in ("", "/"):
        out += [(k, ("relay", "中转站", "openai", base.rstrip("/") + "/v1", ""), base.rstrip("/") + "/v1") for k, _v, _b in list(out)]
    if not out and base is None:
        bare = text.strip()
        if re.fullmatch(r"[A-Za-z0-9_\-.]{20,200}", bare):
            out.extend((bare, _vendor(a), None) for a in AMBIGUOUS if _vendor(a))
    return out


def _validate_base(base):
    """Keep local relays usable, but never send keys to metadata addresses."""
    try:
        host = urlsplit(base).hostname or ""
    except ValueError:
        raise ValueError("接口地址格式不对，请换一个接口地址。") from None
    host = host.rstrip(".").lower()
    if host in ("metadata.google.internal", "metadata.goog"):
        raise ValueError("这个地址是本机元数据地址，不能用来接入。请换一个接口地址。")
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        # Parse inet_aton syntax independently of libc: the last component
        # occupies the remaining bytes (a.b.c, a.b, or one integer).
        parts = host.split(".")
        numeric = r"(?:0[xX][0-9a-fA-F]+|[0-9]+)"
        if not 1 <= len(parts) <= 4 or not all(re.fullmatch(numeric, p) for p in parts):
            return  # ordinary DNS name; local relays are intentionally supported
        try:
            values = [int(p, 16 if p.lower().startswith("0x") else 8 if len(p) > 1 and p.startswith("0") else 10)
                      for p in parts]
            limits = [256] * (len(values) - 1) + [1 << (8 * (5 - len(values)))]
            if any(v >= limit for v, limit in zip(values, limits)):
                raise ValueError
            number = values[-1]
            for i, value in enumerate(values[:-1]):
                number += value << (24 - 8 * i)
            addr = ipaddress.IPv4Address(number)
        except ValueError:
            raise ValueError("接口地址格式不对，请换一个接口地址。") from None
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    if addr.version == 4:
        blocked = addr in ipaddress.ip_network("169.254.0.0/16") or str(addr) == "100.100.100.200"
    else:
        blocked = addr in ipaddress.ip_network("fd00::/8") or addr.is_link_local
    if blocked:
        raise ValueError("这个地址是本机元数据地址，不能用来接入。请换一个接口地址。")


def _redact(value, keys):
    if isinstance(value, str):
        for key in keys:
            value = value.replace(key, "[已隐藏]")
        return value
    if isinstance(value, dict):
        return {k: _redact(v, keys) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v, keys) for v in value]
    return value


async def _probe(key, v, base):
    vid, pn, kind, vbase, model = v
    pr = {"id": vid, "name": pn, "kind": kind, "base": base or vbase, "key": key}
    try:
        _validate_base(pr["base"])
        await asyncio.wait_for(S.fetch_models(pr), 20)
        return pr, model, None
    except Exception as e:  # noqa: BLE001
        return None, None, (_redact(str(e), [key]) if str(e) else e)


def default_model(pr, preferred):
    ids = [x[0] for x in pr.get("models") or []]
    if not ids or preferred in ids:
        return preferred or (ids[0] if ids else "")
    rank = ["pro", "plus", "sonnet", "chat", "flash", "mini", "turbo"]
    ids_text = [i for i in ids if not re.search(r"embed|whisper|tts|image|vision-preview|audio|rerank|moderation", i, re.I)] or ids
    return next((i for r in rank for i in ids_text if r in i.lower()), ids_text[0])


def _model_ids(pr):
    return [x[0] for x in pr.get("models") or []][:300]


def add_models(provider_id: str, models: list) -> dict:
    """Make a member out of each chosen model of an already-connected provider (relay stations list dozens)."""
    pr = S.provider(provider_id)
    if not pr:
        return {"ok": False, "error": "没找到这个接口，请先接入", "message": "没找到这个接口，请先接入", "fix": "repaste"}
    have = set(_model_ids(pr))
    added, skipped = [], []
    for mid in models[:100]:
        mid = str(mid)
        if mid not in have:
            skipped.append(mid); continue
        if any(m.get("provider") == provider_id and m.get("model") == mid for m in S.CFG["members"]):
            skipped.append(mid); continue
        nm = re.sub(r"[^\w.\-]+", "-", mid).strip("-")[:24] or "AI"
        while S.member(nm):
            nm += "2"
        S.CFG["members"].append({"name": nm, "kind": "api", "provider": provider_id, "auto": True, "model": mid})
        for p in S.PROJECTS:
            if nm not in p["members"]:
                p["members"].append(nm)
        added.append(nm)
    if added:
        S.save_cfg()
        S.bump()
    return {"ok": True, "added": added, "skipped": skipped}


async def paste(text: str, name: str = "") -> dict:
    t0 = time.monotonic()
    cands = detect(text)
    if not cands:
        message = "没在粘贴的内容里找到密钥，请复制带密钥的整段文字后重新粘贴"
        return {"ok": False, "error": message, "message": message, "fix": "repaste"}
    keys = [k for k, _, _ in cands]
    try:
        for _, v, base in cands:
            _validate_base(base or v[3])
    except ValueError as e:
        return {"ok": False, "error": str(e), "message": str(e), "fix": "edit_base"}
    res = await asyncio.gather(*(_probe(k, v, b) for k, v, b in cands))
    hit = next((r for r in res if r[0]), None)
    if not hit:
        return {"ok": False, **explain(next((e for _, _, e in res if e), "")), "tried": [v[1] for _, v, _ in cands]}
    pr, model, _ = hit
    if S.provider(pr["id"]):
        pr["id"] = f"{pr['id']}-{secrets.token_hex(2)}"
    model = default_model(pr, model)
    S.CFG["providers"].append(pr)
    nm = _redact(name or pr["name"].split("（")[0], keys).strip()[:24] or "AI"
    while S.member(nm):
        nm += "2"
    m = {"name": nm, "kind": "api", "provider": pr["id"], "auto": True, "model": model}
    S.CFG["members"].append(m)
    for p in S.PROJECTS:
        if nm not in p["members"]:
            p["members"].append(nm)
    S.save_cfg()
    S.bump()
    test = ""
    try:
        test = _redact(await asyncio.wait_for(C2.ask_model(m, "只回复两个字：已接入", "测试"), 30), keys).strip()[:40]
    except Exception as e:  # noqa: BLE001  — key works for listing but chat failed: keep the member, tell why
        return _redact({"ok": True, "member": nm, "provider": pr["name"], "provider_id": pr["id"], "model": model, "models": _model_ids(pr), "test": "", **explain(_redact(str(e), keys)),
                        "ms": round((time.monotonic() - t0) * 1000)}, keys)
    finally:
        S.bump()
    return _redact({"ok": True, "member": nm, "provider": pr["name"], "provider_id": pr["id"], "model": model, "models": _model_ids(pr),
                    "test": test, "balance": _balance_method(pr),
                    "ms": round((time.monotonic() - t0) * 1000)}, keys)


def _balance_method(pr):
    try:
        import quota_probes
        return quota_probes.detect(pr)
    except Exception:  # noqa: BLE001
        return "self"


# ---------------------------------------------------------------- (A) CLI / agent invite
def new_invite(url: str, project: str = "") -> dict:
    now = time.time()
    for k in [k for k, v in INV.items() if v["expires"] < now and v["state"] != "connected"]:
        INV.pop(k, None)
    if sum(1 for v in INV.values() if v["state"] == "waiting") >= 20:
        raise errors.http_error(web.HTTPTooManyRequests, "未用的邀请太多了，等几分钟", fix="retry")
    tok = "ci_" + secrets.token_urlsafe(24)
    sid = secrets.token_hex(6)   # status id ≠ token, so the app polling never puts the token in a URL
    INV[tok] = {"project": project, "sid": sid, "expires": now + TTL, "state": "waiting", "at": {"waiting": now}, "created": now, "member": "", "error": ""}
    one = f"curl -fsSL -H 'X-Chorus-Invite: {tok}' {url}/api/connect/pub/install | sh"
    prompt = ("请帮我把你自己接入 Chorus（我的多 AI 协作服务器）。在终端运行下面这一行（10 分钟内有效，只能用一次），"
              "它会下载一个很小的 Python 连接器、识别本机的 claude / codex / gemini 等命令行并注册，然后保持在线接活。"
              "需要 python3。运行后告诉我输出的最后一行。\n\n" + one)
    return {"token": tok, "expires_in": TTL, "oneliner": one, "prompt": prompt, "qr": one, "status": f"/api/connect/status/{sid}", "id": sid}


def _mark(inv, state, err="", fix="none"):
    inv["state"] = state
    inv["at"][state] = time.time()
    if err:
        inv["error"] = err
    inv["fix"] = fix
    S.bump()


def _invite(request, consume=False):
    tok = request.headers.get("X-Chorus-Invite", "")
    inv = INV.get(tok)
    if not inv or inv["expires"] < time.time() or inv["state"] in ("registered", "connected"):
        raise errors.http_error(web.HTTPForbidden, "邀请无效、已用过或已过期，请在 app 里重新点「一键复制」", fix="retry")
    return tok, inv


INSTALL = """#!/bin/sh
# Chorus connector installer (single-use invite; nothing is installed system-wide)
set -e
command -v python3 >/dev/null || { echo "需要 python3"; exit 1; }
D="$HOME/.chorus-connector"; mkdir -p "$D"
curl -fsSL -H "X-Chorus-Invite: $INV" "$SRV/api/connect/pub/connector.py" -o "$D/connector.py"
CHORUS_SERVER="$SRV" CHORUS_INVITE="$INV" python3 "$D/connector.py" --install
sleep 3; tail -n 1 "$D/connector.log" 2>/dev/null || true
"""


async def h_install(request):
    tok, inv = _invite(request)
    _mark(inv, "fetched")
    srv = _server_url(request)
    return web.Response(text=f"SRV='{srv}'\nINV='{tok}'\n" + INSTALL, content_type="text/plain")


async def h_connector(request):
    _invite(request)
    return web.Response(text=(HERE / "connector" / "connector.py").read_text(), content_type="text/x-python")


CLI_TEMPLATES = {   # how each CLI is driven headless; prompt goes in on stdin
    "claude": {"cmd": "claude -p", "quota": {"type": "cli", "exe": "claude"}, "caps": ["code_exec", "long_ctx", "web"]},
    "codex": {"cmd": "codex exec -", "quota": {"type": "codex_sessions", "home": "~/.codex"}, "caps": ["code_exec", "long_ctx"]},
    "gemini": {"cmd": "gemini -p", "quota": {"type": "cli", "exe": "gemini"}, "caps": ["code_exec", "long_ctx", "web", "vision"]},
    "qwen": {"cmd": "qwen -p", "quota": {"type": "self"}, "caps": ["code_exec"]},
    "dsh": {"cmd": "dsh --profile headless", "quota": {"type": "self"}, "caps": ["code_exec"]},
}


async def h_register(request):
    tok, inv = _invite(request)
    b = await errors.json_object(request)
    clis = [c for c in (b.get("clis") or []) if isinstance(c, dict) and c.get("name") in CLI_TEMPLATES]
    if not clis:
        _mark(inv, "error", "这台机器上没找到可用的命令行，请安装后重新接入", "settings")
        return errors.response(inv["error"], "settings", status=400)
    host = str(b.get("host", ""))[:60]
    registered = []
    for c in {c["name"]: c for c in clis}.values():
        cli = c["name"]
        t = CLI_TEMPLATES[cli]
        m = next((m for m in S.CFG["members"] if host and m.get("remote") and m.get("host") == host
                  and m.get("cli", m.get("cmd", "").split(" ")[0]) == cli), None)
        if m is None:
            base = re.sub(r"[^\w\u4e00-\u9fff .·-]", "", str(b.get("name") or cli.capitalize()))[:24] or "CLI"
            nm = base
            if S.member(nm):
                nm = f"{base}·{host or 'remote'}·{cli}"
            if S.member(nm):
                nm += "·" + secrets.token_hex(4)
            m = {"name": nm, "kind": "cli", "remote": True, "auto": True}
            S.CFG["members"].append(m)
        nm = m["name"]
        m.update(cmd=t["cmd"], quota=dict(t["quota"]), caps=list(t["caps"]), host=host,
                 cli=cli, cli_version=str(c.get("version", ""))[:40])
        secret = "cm_" + secrets.token_urlsafe(32)
        old = REMOTE.get(nm, {})
        for future in old.get("wait", {}).values():
            if not future.done():
                future.set_result({"error": "连接器已重新注册，请重试"})
        REMOTE[nm] = {"hash": _h(secret), "queue": asyncio.Queue(), "wait": {}, "seen": time.time(), "clis": [c]}
        for p in S.PROJECTS:
            if p["id"] == inv.get("project") and nm not in p["members"]:
                p["members"].append(nm)
        registered.append({"member": nm, "secret": secret, "cmd": t["cmd"], "cli": cli})
    S.save_cfg()
    save_remote()
    inv["member"] = registered[0]["member"]
    inv["members"] = [r["member"] for r in registered]
    _mark(inv, "registered")
    task = asyncio.create_task(_test(tok, inv["member"]))
    TEST_TASKS.add(task)
    task.add_done_callback(TEST_TASKS.discard)
    return web.json_response({**registered[0], "members": registered})


async def _test(tok, nm):
    try:
        r = await remote_call(nm, "只回复两个字：已接入", "测试", timeout=120)
        inv = INV.get(tok)
        if inv is None:
            return
        inv["test"] = (r.get("text") or "").strip()[:40]
        if r.get("error"):
            raise RuntimeError(r["error"])
        _mark(inv, "connected")
        METRICS["connected"].append(round(inv["at"]["connected"] - inv["created"], 2))
    except Exception as e:  # noqa: BLE001
        if (inv := INV.get(tok)) is not None:
            detail = explain(e)
            _mark(inv, "error", "已注册，但测试消息没回：" + detail["error"], detail["fix"])


def remote_status(name):
    """Refresh presence on every quota/status read, including after a server restart."""
    if S is None or C2 is None:
        return ""
    m = S.member(name)
    if not m or not m.get("remote"):
        return ""
    r = REMOTE.get(name)
    if r is None or time.time() - r["seen"] > 60:
        if C2.MEMBER_STATE.get(name) != "resting" or C2.STATE_REASON.get(name) != OFFLINE_REASON:
            C2.mark(name, "resting", OFFLINE_REASON)
            S.bump()
        return OFFLINE_REASON
    if C2.STATE_REASON.get(name) == OFFLINE_REASON:
        C2.STATE_REASON.pop(name, None)
        C2.MEMBER_STATE.pop(name, None)
        C2.STATE_AT.pop(name, None)
        S.bump()
    return ""


def quota_view(quotas, names):
    out = {name: dict(q or {}) for name, q in quotas.items()}
    for name in names:
        if reason := remote_status(name):
            out.setdefault(name, {}).update(state="resting", short="离席", reason=reason)
    return out


def _member_of(request):
    nm = request.headers.get("X-Chorus-Member", "")
    r = REMOTE.get(nm)
    if not r or not secrets.compare_digest(r["hash"], _h(request.headers.get("X-Chorus-Secret", ""))):
        raise errors.http_error(web.HTTPForbidden, "连接器凭证不对", fix="relogin")
    r["seen"] = time.time()
    remote_status(nm)
    return nm, r


async def h_jobs(request):
    nm, r = _member_of(request)
    r["seen"] = time.time()
    try:
        wait = float(request.query.get("wait", 25))
    except ValueError:
        wait = 25
    wait = max(0, min(30, wait))
    deadline = asyncio.get_running_loop().time() + wait
    while True:
        try:
            job = await asyncio.wait_for(r["queue"].get(), wait)
        except asyncio.TimeoutError:
            return web.json_response({"job": None})
        fut = r["wait"].get(job["id"])
        if fut is not None and not fut.done():
            return web.json_response({"job": job})
        # Do not dispatch jobs whose caller has timed out or been cancelled.
        wait = max(0, deadline - asyncio.get_running_loop().time())


async def h_result(request):
    nm, r = _member_of(request)
    b = await errors.json_object(request)
    fut = r["wait"].pop(str(b.get("id", "")), None)
    if fut and not fut.done():
        fut.set_result({"text": str(b.get("text", ""))[:200000], "error": str(b.get("error", ""))[:400], "usage": b.get("usage")})
    return web.json_response({"ok": bool(fut)})



def _remote_file():
    return pathlib.Path(S.DATA) / "remote_connectors.json" if S is not None else None

def save_remote():
    path = _remote_file()
    if path is None:
        return
    fd, temp = tempfile.mkstemp(prefix=".remote-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump({n: {"hash": r.get("hash", ""), "clis": r.get("clis", []), "seen": r.get("seen", 0)}
                       for n, r in REMOTE.items()}, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        pathlib.Path(temp).unlink(missing_ok=True)

def load_remote():
    path = _remote_file()
    if path is None or not path.exists():
        return
    try:
        data = json.loads(path.read_text())
    except (ValueError, OSError):
        return
    for n, r in data.items():
        if n in REMOTE:
            continue
        REMOTE[n] = {"hash": r["hash"], "queue": asyncio.Queue(), "wait": {}, "seen": r.get("seen", 0), "clis": r.get("clis", [])}

def normalize_quota(b):
    """Connector report → {pct, reset, week, week_reset} (remaining %), or None when it says nothing usable."""
    import cli_quota
    import quota_probes
    kind = str(b.get("kind", ""))
    if kind == "codex" and isinstance(b.get("rate_limits"), dict):
        r = quota_probes.codex_rate_limits(b["rate_limits"])
    elif kind == "claude":
        text = str(b.get("text", ""))[:20000]
        try:
            text = json.loads(text).get("result", text)
        except (ValueError, AttributeError):
            pass
        r = cli_quota.parse_claude_usage(text)
    elif kind == "gemini":
        r = cli_quota.parse_gemini_stats(str(b.get("text", ""))[:20000])
    else:
        return None
    r = {k: r.get(k) for k in ("pct", "reset", "week", "week_reset")}
    return r if r["pct"] is not None or r["week"] is not None else None


async def h_quota(request):
    import cli_quota
    nm, r = _member_of(request)
    b = await errors.json_object(request)
    q = normalize_quota(b)
    if q is None:
        return web.json_response({"ok": False})
    cli_quota.CACHE[nm] = (time.time(), {**q, "remote": True})
    r["quota_at"] = time.time()
    if C2 is not None:
        m = S.member(nm)
        if m:
            asyncio.get_running_loop().create_task(_reprobe(m))
    return web.json_response({"ok": True, **q})


async def _reprobe(m):
    try:
        await C2.refresh_one(m)
    except Exception as e:  # noqa: BLE001 - next refresh_all picks it up anyway
        print("quota reprobe", m.get("name"), type(e).__name__)


async def remote_call(name, system, prompt, model="", timeout=900):
    r = REMOTE.get(name)
    if not r:
        raise RuntimeError("这个成员的连接器不在线")
    jid = secrets.token_hex(8)
    fut = asyncio.get_running_loop().create_future()
    r["wait"][jid] = fut
    try:
        await r["queue"].put({"id": jid, "system": system, "prompt": prompt, "model": model})
        return await asyncio.wait_for(fut, timeout)
    except asyncio.TimeoutError:
        fut.cancel()
        return {"text": "", "error": f"连接器 {timeout:g} 秒没回，可能掉线了"}
    finally:
        if not fut.done():
            fut.cancel()
        r["wait"].pop(jid, None)


async def h_status(request):
    sid = request.match_info["tok"]
    inv = next((v for v in INV.values() if v.get("sid") == sid), None)
    if not inv:
        raise errors.http_error(web.HTTPNotFound, fix="retry")
    label = {"waiting": "等你粘贴运行", "fetched": "正在连接", "registered": "已注册，发测试消息", "connected": "已接入", "error": "出错了"}
    detail = ({"error": inv["error"], "message": inv["error"], "fix": inv["fix"]}
              if inv["error"] and inv.get("fix") in errors.FIXES
              else explain(inv["error"]) if inv["error"] else {"error": "", "message": "", "fix": "none"})
    return web.json_response({"state": inv["state"], "label": label[inv["state"]], "member": inv["member"], "test": inv.get("test", ""),
                              **detail,
                              "seconds": round((inv["at"].get(inv["state"], time.time()) if inv["state"] in ("connected", "error") else time.time()) - inv["created"], 1)})


async def h_metrics(request):
    values = sorted(METRICS["connected"])
    def percentile(p):
        return values[max(0, math.ceil(len(values) * p) - 1)] if values else None
    return web.json_response({"connected": {"count": len(values), "p50": percentile(0.5), "p95": percentile(0.95)}})


def _server_url(request):
    prefix = request.headers.get("X-Forwarded-Prefix", "")
    if not re.fullmatch(r"[/A-Za-z0-9._-]*", prefix):
        prefix = ""
    scheme = request.headers.get("X-Forwarded-Proto", "")
    if scheme not in ("http", "https"):
        scheme = request.scheme
    return f"{scheme}://{request.host}{prefix}"


async def h_new(request):
    srv = _server_url(request)
    b = await errors.json_object(request) if request.can_read_body else {}
    pid = b.get("project", b.get("pid", ""))
    if not isinstance(pid, str) or pid and not any(p["id"] == pid for p in S.PROJECTS):
        raise errors.http_error(web.HTTPBadRequest, "乐章不存在", fix="settings")
    return web.json_response(new_invite(srv, pid))


async def h_paste(request):
    b = await errors.json_object(request)
    return web.json_response(await paste(str(b.get("text", ""))[:20000], str(b.get("name", ""))))


async def h_add_models(request):
    b = await errors.json_object(request)
    return web.json_response(add_models(str(b.get("provider", "")), list(b.get("models") or [])))


def patch_call_cli():
    """Remote CLI members go through the connector; everything else (consent, quota, ledger) stays the same path."""
    orig = S.call_cli

    async def call_cli(pid, m, reply, system, prompt, model, effort, sess=None, skey=""):
        if not m.get("remote"):
            return await orig(pid, m, reply, system, prompt, model, effort, sess, skey)
        r = await remote_call(m["name"], system, prompt, model)
        if r.get("error"):
            raise RuntimeError(r["error"])
        reply["text"] = r.get("text", "")
    S.call_cli = call_cli


def register(app, server, chorus2):
    global S, C2
    S, C2 = server, chorus2
    r = app.router
    r.add_post("/api/connect/invite", h_new)
    r.add_get("/api/connect/status/{tok}", h_status)
    r.add_get("/api/connect/metrics", h_metrics)
    r.add_post("/api/connect/paste", h_paste)
    r.add_post("/api/connect/add_models", h_add_models)
    r.add_get("/api/connect/pub/install", h_install)
    r.add_get("/api/connect/pub/connector.py", h_connector)
    r.add_post("/api/connect/pub/register", h_register)
    r.add_get("/api/connect/pub/jobs", h_jobs)
    r.add_post("/api/connect/pub/result", h_result)
    r.add_post("/api/connect/pub/quota", h_quota)
    load_remote()
    patch_call_cli()

    async def cleanup(app_):
        tasks = list(TEST_TASKS)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    app.on_cleanup.append(cleanup)
