"""Run with the old server's Python before replacing its code, after stopping its writer."""
import asyncio
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import backup


async def snapshot(data):
    data = Path(data)
    manager = backup.BackupManager(data, lambda: {"backups": {"keep": 7}})
    password = manager.scheduled_password({})
    with backup.writer_lock(data):
        row = await manager.start_backup(password)
        await asyncio.gather(*manager.tasks)
    result = backup.read_json(manager.path("backup-", row["id"]).with_suffix(".json"))
    if result["state"] != "completed":
        raise backup.BackupError("升级前快照失败，停止升级")
    return result


if __name__ == "__main__":
    asyncio.run(snapshot(sys.argv[1]))
