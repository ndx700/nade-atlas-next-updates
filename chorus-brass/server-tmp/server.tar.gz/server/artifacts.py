"""共享产物线（N11）：内容寻址 + 版本链 + 任务续作描述。

设计要点：
- 产物元数据存 ``DATA/ledger/<pid>/artifacts.json``，原子写（临时文件 + ``os.replace``）。
- 内容寻址：blob 存 ``DATA/ledger/<pid>/blobs/<sha[:2]>/<sha>``，同内容只存一份。
- 版本链：``line`` + ``version`` + ``parent``，``op`` ∈ create|edit|annotate，``kind`` ∈ image|doc|code|file。
- ``secret`` 产物不对外列出内容（``public_view`` / ``list_by_project`` 均脱敏）。
- 声部删除后产物保留署名（``producer`` 只是字符串，不依赖成员表）。
- 所有行为带开关，默认关（``enabled=False`` 时 API 直接返回空/False，不落盘）。
- 纯标准库，无网络。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

__all__ = [
    "Artifact",
    "ArtifactError",
    "ArtifactNotFoundError",
    "ArtifactStore",
    "KINDS",
    "OPS",
    "can_consume",
    "add_artifact",
    "get",
    "list_by_project",
    "line_history",
    "continue_from",
    "default_store",
    "sha256_bytes",
    "sha256_file",
    "guess_kind",
    "is_sensitive_name",
    "looks_sensitive",
]

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

KINDS = ("image", "doc", "code", "file")
OPS = ("create", "edit", "annotate")

# 能力 → 可消费的 kind（§7.4）
_CAP_KINDS: dict[str, frozenset[str]] = {
    "vision": frozenset({"image", "doc", "code", "file"}),
    "image_edit": frozenset({"image"}),
    "code_exec": frozenset({"code", "doc", "file"}),
    "video": frozenset({"image", "file"}),
}

# 敏感文件名模式（§7.8）
_SENSITIVE_NAME_RE = re.compile(
    r"(^|/)(\.env(\..+)?|.*\.pem|id_rsa.*|credentials\.json|.*\.key|.*\.keystore)$",
    re.IGNORECASE,
)

# 敏感内容模式（§7.8）
_KEY_RULES = (
    re.compile(r"sk-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"AIza[A-Za-z0-9_\-]{8,}"),
    re.compile(r"gsk_[A-Za-z0-9_\-]{8,}"),
    re.compile(r"tp-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
)

_ID_RE = re.compile(r"^(art|ln)_([0-9a-f]{6,32})$")


class ArtifactError(Exception):
    """Base class for artifact errors."""


class ArtifactNotFoundError(ArtifactError):
    """Raised when an artifact id cannot be located."""


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Artifact:
    """一条产物版本记录。``producer`` 为字符串署名，声部删除后仍保留。"""

    id: str
    project: str
    line: str
    version: int
    parent: str | None
    op: str
    kind: str
    inputs: list[str]
    producer: str
    secret: bool
    sha256: str
    bytes: int
    mime: str
    title: str = ""
    origin_path: str = ""
    created_at: int = 0
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Artifact":
        try:
            return cls(
                id=str(data["id"]),
                project=str(data.get("project", "")),
                line=str(data["line"]),
                version=int(data.get("version", 1)),
                parent=(str(data["parent"]) if data.get("parent") else None),
                op=str(data.get("op", "create")),
                kind=str(data.get("kind", "file")),
                inputs=[str(x) for x in (data.get("inputs") or [])],
                producer=str(data.get("producer", "")),
                secret=bool(data.get("secret", False)),
                sha256=str(data["sha256"]),
                bytes=int(data.get("bytes", 0)),
                mime=str(data.get("mime", "application/octet-stream")),
                title=str(data.get("title", "")),
                origin_path=str(data.get("origin_path", "")),
                created_at=int(data.get("created_at", 0)),
                meta=dict(data.get("meta") or {}),
            )
        except (KeyError, TypeError, ValueError) as exc:  # pragma: no cover
            raise ArtifactError(f"invalid artifact payload: {exc}") from exc

    # -- 便捷 ---------------------------------------------------------
    @property
    def blob_rel(self) -> str:
        return f"blobs/{self.sha256[:2]}/{self.sha256}"

    def public_view(self) -> dict[str, Any]:
        """对外视图：secret 产物不暴露内容（sha/大小/路径脱敏）。"""
        d = self.to_dict()
        if self.secret:
            d["sha256"] = ""
            d["bytes"] = 0
            d["mime"] = "application/octet-stream"
            d["origin_path"] = ""
            d["blob"] = None
            d["content_hidden"] = True
        else:
            d["blob"] = self.blob_rel
            d["content_hidden"] = False
        return d


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | os.PathLike[str], chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _guess_mime(path: str | os.PathLike[str]) -> str:
    import mimetypes

    mime, _ = mimetypes.guess_type(str(path))
    return mime or "application/octet-stream"


def guess_kind(path: str | os.PathLike[str] = "", mime: str = "") -> str:
    """按扩展名/mime 猜 kind，默认 file。"""
    ext = Path(str(path)).suffix.lower()
    mime = (mime or "").lower()
    if ext in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"} or mime.startswith("image/"):
        return "image"
    if ext in {".py", ".js", ".ts", ".go", ".rs", ".java", ".c", ".cc", ".cpp", ".h", ".sh", ".sql"} or mime.startswith(
        "text/x-"
    ):
        return "code"
    if ext in {".md", ".txt", ".rst", ".json", ".yaml", ".yml", ".toml", ".csv", ".html", ".pdf"} or mime.startswith(
        "text/"
    ):
        return "doc"
    return "file"


def is_sensitive_name(path: str | os.PathLike[str]) -> bool:
    return bool(_SENSITIVE_NAME_RE.search(str(path).replace("\\", "/")))


def looks_sensitive(name: str = "", data: bytes | None = None) -> bool:
    """§7.8 敏感判定：文件名模式 + 小文本内容扫描。"""
    if name and is_sensitive_name(name):
        return True
    if data is not None and len(data) < 2 * 1024 * 1024:
        try:
            text = data.decode("utf-8", errors="ignore")
        except Exception:  # pragma: no cover
            text = ""
        for rule in _KEY_RULES:
            if rule.search(text):
                return True
    return False


def _now() -> int:
    return int(time.time())


def _new_artifact_id() -> str:
    return f"art_{uuid.uuid4().hex[:16]}"


def _new_line_id() -> str:
    return f"ln_{uuid.uuid4().hex[:12]}"


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp{os.getpid()}.{uuid.uuid4().hex[:8]}")
    try:
        with tmp.open("x", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        tmp.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# 能力判定
# ---------------------------------------------------------------------------


def can_consume(member_caps: Iterable[str] | Mapping[str, Any] | None, kind: str) -> bool:
    """成员能力是否能消费该 kind 的产物。

    ``member_caps`` 可以是能力名集合，也可以是 ``{"caps": [...]}`` 映射。
    """
    if kind not in KINDS:
        return False
    if member_caps is None:
        caps: set[str] = set()
    elif isinstance(member_caps, Mapping):
        raw = member_caps.get("caps") or member_caps.get("capabilities") or []
        if isinstance(raw, str):
            raw = [raw]
        caps = {str(c) for c in raw}
    else:
        caps = {str(c) for c in member_caps}

    for cap in caps:
        allowed = _CAP_KINDS.get(cap)
        if allowed and kind in allowed:
            return True
    return False


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


class ArtifactStore:
    """项目级共享产物线存储。

    布局::

        DATA/ledger/<pid>/artifacts.json
        DATA/ledger/<pid>/blobs/<sha[:2]>/<sha>

    所有写操作经 ``asyncio.Lock`` 串行化，落盘用临时文件 + ``os.replace``。
    """

    SCHEMA_VERSION = 1

    def __init__(
        self,
        data_dir: str | os.PathLike[str],
        project: str,
        *,
        enabled: bool = False,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.project = str(project)
        self.enabled = bool(enabled)
        self._lock = asyncio.Lock()
        self._cache: dict[str, Artifact] | None = None

    # -- 路径 ---------------------------------------------------------
    @property
    def ledger_dir(self) -> Path:
        return self.data_dir / "ledger" / self.project

    @property
    def index_path(self) -> Path:
        return self.ledger_dir / "artifacts.json"

    @property
    def blobs_dir(self) -> Path:
        return self.ledger_dir / "blobs"

    def blob_path(self, sha256: str) -> Path:
        return self.blobs_dir / sha256[:2] / sha256

    # -- 持久化 -------------------------------------------------------
    def _load_sync(self) -> dict[str, Artifact]:
        if not self.index_path.exists():
            return {}
        try:
            raw = json.loads(self.index_path.read_text("utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            # 读失败不能当成空表：下一次 add 会用空表覆盖掉所有产物元数据
            raise ArtifactError(f"产物索引读不出来，已保留原文件：{e}")
        items = raw.get("artifacts") if isinstance(raw, dict) else None
        if not isinstance(items, dict):
            return {}
        out: dict[str, Artifact] = {}
        for key, value in items.items():
            if not isinstance(value, Mapping):
                continue
            try:
                out[str(key)] = Artifact.from_dict(value)
            except ArtifactError:
                continue
        return out

    def _save_sync(self, artifacts: Mapping[str, Artifact]) -> None:
        payload = {
            "version": self.SCHEMA_VERSION,
            "project": self.project,
            "artifacts": {k: v.to_dict() for k, v in artifacts.items()},
        }
        _atomic_write_json(self.index_path, payload)

    async def _ensure_loaded(self) -> dict[str, Artifact]:
        if self._cache is None:
            self._cache = await asyncio.to_thread(self._load_sync)
        return self._cache

    # -- blob ---------------------------------------------------------
    def _store_blob_sync(self, data: bytes) -> tuple[str, int]:
        digest = hashlib.sha256(data).hexdigest()
        target = self.blob_path(digest)
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name + f".tmp{os.getpid()}")
            tmp.write_bytes(data)
            os.replace(tmp, target)
        return digest, len(data)

    def _read_blob_sync(self, sha256: str) -> bytes:
        return self.blob_path(sha256).read_bytes()

    # -- 公共 API -----------------------------------------------------
    async def add_artifact(
        self,
        *,
        content: bytes | str | os.PathLike[str] | None = None,
        project: str | None = None,
        line: str | None = None,
        version: int | None = None,
        parent: str | None = None,
        op: str = "create",
        kind: str = "file",
        inputs: Sequence[str] | None = None,
        producer: str = "",
        secret: bool | None = None,
        title: str = "",
        origin_path: str = "",
        mime: str | None = None,
        meta: Mapping[str, Any] | None = None,
        created_at: int | None = None,
        artifact_id: str | None = None,
    ) -> Artifact:
        """登记一条产物版本。

        ``content`` 可以是 bytes、str（utf-8 编码）或本地文件路径。
        ``secret`` 为 None 时按文件名/内容自动判定。
        """
        if not self.enabled:
            raise ArtifactError("artifacts disabled")

        if project is not None and str(project) != self.project:
            raise ArtifactError("cross-project artifact registration is not allowed")

        op = str(op)
        if op not in OPS:
            raise ArtifactError(f"invalid op: {op!r}")
        kind = str(kind)
        if kind not in KINDS:
            raise ArtifactError(f"invalid kind: {kind!r}")

        # 读取内容
        data: bytes
        if content is None:
            raise ArtifactError("content is required")
        if isinstance(content, bytes):
            data = content
        elif isinstance(content, str):
            p = Path(content)
            if p.is_file():
                data = await asyncio.to_thread(p.read_bytes)
                if not origin_path:
                    origin_path = str(p)
            else:
                data = content.encode("utf-8")
        elif isinstance(content, os.PathLike):
            p = Path(content)
            if not p.is_file():
                raise FileNotFoundError(f"artifact file not found: {p}")
            data = await asyncio.to_thread(p.read_bytes)
            if not origin_path:
                origin_path = str(p)
        else:  # pragma: no cover
            raise ArtifactError(f"unsupported content type: {type(content)!r}")

        # 敏感判定
        if secret is None:
            secret = looks_sensitive(origin_path or title, data)

        digest, size = await asyncio.to_thread(self._store_blob_sync, data)

        async with self._lock:
            artifacts = await self._ensure_loaded()

            # 版本归属：同 line 自增；否则新建 line
            if line:
                line = str(line)
                if not line.startswith("ln_"):
                    raise ArtifactError(f"invalid line id: {line!r}")
                existing = [a for a in artifacts.values() if a.line == line]
                if version is None:
                    version = (max((a.version for a in existing), default=0) + 1) if existing else 1
                if parent is None and existing:
                    head = max(existing, key=lambda a: (a.version, a.created_at))
                    parent = head.id
            else:
                line = _new_line_id()
                version = 1

            art = Artifact(
                id=artifact_id or _new_artifact_id(),
                project=self.project,
                line=line,
                version=int(version),
                parent=str(parent) if parent else None,
                op=op,
                kind=kind,
                inputs=[str(x) for x in (inputs or [])],
                producer=str(producer),
                secret=bool(secret),
                sha256=digest,
                bytes=size,
                mime=mime or (_guess_mime(origin_path) if origin_path else "application/octet-stream"),
                title=str(title),
                origin_path=str(origin_path),
                created_at=int(created_at if created_at is not None else _now()),
                meta=dict(meta or {}),
            )
            artifacts[art.id] = art
            await asyncio.to_thread(self._save_sync, artifacts)
        return art

    async def get(self, artifact_id: str) -> Artifact:
        if not self.enabled:
            raise ArtifactNotFoundError(f"artifacts disabled: {artifact_id!r}")
        async with self._lock:
            artifacts = await self._ensure_loaded()
            art = artifacts.get(str(artifact_id))
        if art is None:
            raise ArtifactNotFoundError(f"unknown artifact id: {artifact_id!r}")
        return art

    async def list_by_project(
        self,
        project: str | None = None,
        *,
        kind: str | None = None,
        line: str | None = None,
        include_secret: bool = False,
    ) -> list[dict[str, Any]]:
        """返回产物线列表，每条含 head 与 versions[]。secret 产物内容脱敏。"""
        if not self.enabled:
            return []
        if project is not None and str(project) != self.project:
            return []
        async with self._lock:
            artifacts = await asyncio.to_thread(self._load_sync) if self._cache is None else dict(self._cache)
            self._cache = artifacts

        lines: dict[str, list[Artifact]] = {}
        for a in artifacts.values():
            if kind and a.kind != kind:
                continue
            if line and a.line != line:
                continue
            lines.setdefault(a.line, []).append(a)

        out: list[dict[str, Any]] = []
        for ln, items in lines.items():
            items.sort(key=lambda a: (a.version, a.created_at))
            head = items[-1]
            out.append(
                {
                    "line": ln,
                    "project": self.project,
                    "head": head.public_view() if include_secret or not head.secret else head.public_view(),
                    "versions": [
                        (a.public_view() if include_secret or not a.secret else a.public_view()) for a in items
                    ],
                    "count": len(items),
                }
            )
        out.sort(key=lambda e: e["head"]["created_at"], reverse=True)
        return out

    async def line_history(self, line: str) -> list[Artifact]:
        """按版本升序返回该产物线的全部版本。"""
        if not self.enabled:
            return []
        async with self._lock:
            artifacts = await self._ensure_loaded()
            items = [a for a in artifacts.values() if a.line == str(line)]
        items.sort(key=lambda a: (a.version, a.created_at))
        return items

    async def continue_from(
        self,
        artifact_id: str,
        member: str,
        instruction: str = "",
    ) -> dict[str, Any]:
        """生成给声部的续作任务描述（含产物路径和 sha）。"""
        art = await self.get(artifact_id)
        history = await self.line_history(art.line)
        next_version = (history[-1].version + 1) if history else art.version + 1
        ext = Path(art.origin_path).suffix or ""
        out_rel = f"artifacts/{art.line}/v{next_version}{ext}"

        if art.secret:
            content_note = "（敏感产物，仅本机，不内联给任何 API 供应商）"
            blob_note = "内容不下发；需要时由本机 CLI 读取。"
        else:
            content_note = ""
            blob_note = f"产物路径: {self.blob_path(art.sha256)}\nsha256: {art.sha256}"

        lines = [
            f"# 续作任务：{art.title or art.id}",
            f"产物线: {art.line}（当前 v{art.version}，目标 v{next_version}）",
            f"来源: {art.producer or '未知'} · op={art.op} · kind={art.kind}{content_note}",
            f"输入产物: {artifact_id}",
            blob_note,
            f"期望输出路径: {out_rel}",
            f"parent: {artifact_id}",
            f"op: edit",
        ]
        if instruction:
            lines.append(f"指令: {instruction}")
        lines.append("请基于以上产物生成下一个版本，保持产物线不变。")

        return {
            "artifact_id": art.id,
            "line": art.line,
            "member": str(member),
            "instruction": str(instruction),
            "next_version": next_version,
            "output_path": out_rel,
            "parent": art.id,
            "op": "edit",
            "kind": art.kind,
            "sha256": art.sha256,
            "blob_path": str(self.blob_path(art.sha256)),
            "secret": art.secret,
            "prompt": "\n".join(lines),
        }

    # -- 内容读取 -----------------------------------------------------
    async def read_blob(self, artifact_id: str, *, allow_secret: bool = False) -> bytes:
        """读取 blob 内容；secret 产物默认拒绝。"""
        art = await self.get(artifact_id)
        if art.secret and not allow_secret:
            raise ArtifactError(f"artifact {artifact_id} is secret; content withheld")
        return await asyncio.to_thread(self._read_blob_sync, art.sha256)

    async def verify(self, artifact_id: str) -> Artifact:
        art = await self.get(artifact_id)
        data = await asyncio.to_thread(self._read_blob_sync, art.sha256)
        actual = hashlib.sha256(data).hexdigest()
        if actual != art.sha256:
            raise ArtifactError(f"artifact {artifact_id} sha256 mismatch")
        return art


# ---------------------------------------------------------------------------
# 模块级便捷 API（进程内默认 store）
# ---------------------------------------------------------------------------

_DEFAULT_STORES: dict[str, ArtifactStore] = {}
_DEFAULT_LOCK = asyncio.Lock()


def default_store(
    data_dir: str | os.PathLike[str] = "DATA",
    project: str = "default",
    *,
    enabled: bool = False,
) -> ArtifactStore:
    key = f"{data_dir}::{project}"
    store = _DEFAULT_STORES.get(key)
    if store is None:
        store = ArtifactStore(data_dir, project, enabled=enabled)
        _DEFAULT_STORES[key] = store
    elif enabled and not store.enabled:
        store.enabled = True
    return store


async def add_artifact(*, store: ArtifactStore | None = None, **kwargs: Any) -> Artifact:
    st = store or default_store()
    return await st.add_artifact(**kwargs)


async def get(artifact_id: str, *, store: ArtifactStore | None = None) -> Artifact:
    st = store or default_store()
    return await st.get(artifact_id)


async def list_by_project(
    project: str | None = None, *, store: ArtifactStore | None = None, **kwargs: Any
) -> list[dict[str, Any]]:
    st = store or default_store()
    return await st.list_by_project(project, **kwargs)


async def line_history(line: str, *, store: ArtifactStore | None = None) -> list[Artifact]:
    st = store or default_store()
    return await st.line_history(line)


async def continue_from(
    artifact_id: str, member: str, instruction: str = "", *, store: ArtifactStore | None = None
) -> dict[str, Any]:
    st = store or default_store()
    return await st.continue_from(artifact_id, member, instruction)
