import os, unittest
import orchestra


class ProfileAssign(unittest.TestCase):
    def setUp(self):
        self.cands = [{"name": "a", "model": "deepseek-v4-flash"}, {"name": "b", "model": "claude-opus-5-5"}]
        self.seg = {"title": "修复登录接口", "difficulty": "easy"}

    def tearDown(self):
        os.environ.pop("CHORUS_PROFILE_MODE", None)

    def test_skill_guess(self):
        self.assertEqual(orchestra.segment_skill({"title": "做个海报出图"}), "image_gen")
        self.assertEqual(orchestra.segment_skill({"skill_key": "plan"}), "plan")
        self.assertEqual(orchestra.segment_skill({"title": "x"}), "code")

    def test_off_equals_legacy(self):
        os.environ["CHORUS_PROFILE_MODE"] = "off"
        self.assertEqual(orchestra.assign(self.seg, self.cands), orchestra._assign_legacy(self.seg, self.cands))

    def test_shadow_never_changes_result_but_logs(self):
        os.environ["CHORUS_PROFILE_MODE"] = "shadow"
        n = len(orchestra.PROFILE_SHADOW_LOG)
        r = orchestra.assign(self.seg, self.cands)
        self.assertEqual(r, orchestra._assign_legacy(self.seg, self.cands))
        self.assertEqual(len(orchestra.PROFILE_SHADOW_LOG), n + 1)

    def test_on_respects_explicit_assignee(self):
        os.environ["CHORUS_PROFILE_MODE"] = "on"
        seg = dict(self.seg, assignee="a")
        self.assertEqual(orchestra.assign(seg, self.cands), orchestra._assign_legacy(seg, self.cands))


if __name__ == "__main__":
    unittest.main()
