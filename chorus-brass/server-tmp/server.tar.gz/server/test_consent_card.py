"""定音卡直接进群聊：带 id，可点；同一把 key 没定之前不重复发；定了以后不再发。"""
import pathlib
import tempfile
import unittest
from unittest.mock import patch

import collab_api
import consent
import server as s


class ConsentCard(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        data = pathlib.Path(self.tmp.name)
        self.patches = [patch.object(s, "DATA", data), patch.object(s, "CHATS", {}),
                        patch.dict(s.CFG, {"providers": [{"id": "pv", "key": "sk-test-1234"}]}),
                        patch.object(collab_api, "S", s), patch.object(s, "persist", lambda *a: None),
                        patch.dict("os.environ", {"CHORUS_CONSENT": "on"}), patch.object(collab_api, "settings", lambda: {"consent": True})]
        for p in self.patches:
            p.start()
        self.m = {"name": "DeepSeek", "provider": "pv", "model": "deepseek-chat", "kind": "api"}

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.tmp.cleanup()

    def test_card_once_with_id_and_not_after_decision(self):
        self.assertEqual(collab_api.consent_block(self.m), "pending")
        first = collab_api.consent_card("p", self.m, "允许一次")
        self.assertIsNotNone(first)
        self.assertEqual(first["consent"]["id"], consent.fingerprint("deepseek-chat", "sk-test-1234"))
        self.assertIsNone(collab_api.consent_card("p", self.m, "允许一次"))
        self.assertEqual(len(s.CHATS["p"]), 1)
        consent.decide(s.DATA, first["consent"]["id"], True)
        self.assertEqual(collab_api.consent_block(self.m), "")
        s.CHATS["p"].clear()
        self.assertIsNone(collab_api.consent_card("p", self.m, "允许一次"))


if __name__ == "__main__":
    unittest.main()
