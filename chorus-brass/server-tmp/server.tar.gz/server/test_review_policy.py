"""
Offline unit tests for server/review_policy.py (task card N2).

Runs with either::

    python -m unittest server.test_review_policy
    python -m pytest server/test_review_policy.py

No network, no third-party dependencies.
"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from review_policy import (  # noqa: E402
    RISK_DUAL_THRESHOLD,
    RISK_REQUIRED_THRESHOLD,
    pick_reviewer,
    review_plan,
    risk_score,
)


# ---------------------------------------------------------------------------
# risk_score
# ---------------------------------------------------------------------------
class TestRiskScore(unittest.TestCase):
    def test_all_zero_when_nothing_risky(self):
        self.assertEqual(risk_score({}, {}), 0.0)

    def test_irreversible_alone(self):
        self.assertEqual(risk_score({"irreversible": True}), 0.4)

    def test_diff_lines_scales_linearly(self):
        # Linear scaling: 0 lines -> 0.0, 150 lines -> 0.15, 300 lines -> 0.3 (cap).
        self.assertAlmostEqual(risk_score({"diff_lines": 150}), 0.15, places=6)
        self.assertAlmostEqual(risk_score({"diff_lines": 300}), 0.3, places=6)

    def test_diff_lines_capped_at_0_3(self):
        self.assertAlmostEqual(risk_score({"diff_lines": 10_000}), 0.3, places=6)

    def test_negative_diff_lines_treated_as_zero(self):
        self.assertEqual(risk_score({"diff_lines": -50}), 0.0)

    def test_new_member_alone(self):
        self.assertEqual(risk_score({"member_is_new": True}), 0.2)

    def test_pass_rate_below_threshold(self):
        self.assertEqual(risk_score({"pass_rate": 0.69}), 0.2)
        self.assertEqual(risk_score({"pass_rate": 0.7}), 0.0)
        self.assertEqual(risk_score({"pass_rate": 1.0}), 0.0)

    def test_difficulty_boundary(self):
        self.assertEqual(risk_score({"difficulty": 3}), 0.0)
        self.assertEqual(risk_score({"difficulty": 4}), 0.1)

    def test_max_risk_is_capped_at_one(self):
        seg = {
            "irreversible": True,
            "diff_lines": 5000,
            "member_is_new": True,
            "pass_rate": 0.1,
            "difficulty": 5,
        }
        self.assertEqual(risk_score(seg), 1.0)

    def test_full_formula_mid_value(self):
        # 0.4 + min(0.3, 150/300 = 0.15) + 0 + 0.2 + 0 = 0.75
        seg = {"irreversible": True, "diff_lines": 150, "pass_rate": 0.5}
        self.assertAlmostEqual(risk_score(seg), 0.75, places=6)

    def test_context_supplies_missing_values(self):
        seg = {"diff_lines": 300}
        ctx = {"member_is_new": True, "difficulty": 4}
        self.assertAlmostEqual(risk_score(seg, ctx), 0.6, places=6)

    def test_seg_overrides_ctx(self):
        seg = {"pass_rate": 1.0}
        ctx = {"pass_rate": 0.1}
        self.assertEqual(risk_score(seg, ctx), 0.0)

    def test_accepts_object_with_attributes(self):
        class Seg:
            irreversible = True
            diff_lines = 300

        self.assertAlmostEqual(risk_score(Seg()), 0.7, places=6)

    def test_alternate_key_names(self):
        seg = {"destructive": True, "changed_lines": 300, "is_new": True, "level": 4}
        self.assertAlmostEqual(risk_score(seg), 1.0, places=6)

    def test_string_bools_are_parsed(self):
        self.assertEqual(risk_score({"irreversible": "yes"}), 0.4)
        self.assertEqual(risk_score({"irreversible": "false"}), 0.0)

    def test_missing_pass_rate_does_not_add_risk(self):
        self.assertEqual(risk_score({"difficulty": 0}), 0.0)

    def test_result_is_never_negative(self):
        self.assertEqual(risk_score({"diff_lines": -100, "pass_rate": 2.0}), 0.0)


# ---------------------------------------------------------------------------
# pick_reviewer
# ---------------------------------------------------------------------------
class TestPickReviewer(unittest.TestCase):
    def test_lead_reviews_when_lead_is_not_executor(self):
        self.assertEqual(pick_reviewer("lead", "worker", ["a", "b"]), "lead")

    def test_lead_is_executor_falls_back_to_pool(self):
        # DoD: "指挥即执行者" 场景必须仍有审核者
        reviewer = pick_reviewer("lead", "lead", ["second", "third"])
        self.assertEqual(reviewer, "second")
        self.assertNotEqual(reviewer, "lead")

    def test_fallback_skips_executor_in_pool(self):
        reviewer = pick_reviewer("lead", "lead", ["lead", "second", "third"])
        self.assertEqual(reviewer, "second")

    def test_fallback_respects_capable_set(self):
        reviewer = pick_reviewer(
            "lead", "lead", ["weak", "second", "third"], capable={"second"}
        )
        self.assertEqual(reviewer, "second")

    def test_fallback_respects_capable_predicate(self):
        caps = {"second": True, "weak": False}
        reviewer = pick_reviewer(
            "lead", "lead", ["weak", "second"], capable=lambda m: caps.get(m, False)
        )
        self.assertEqual(reviewer, "second")

    def test_no_capable_candidate_returns_none(self):
        self.assertIsNone(pick_reviewer("lead", "lead", ["lead"], capable=set()))

    def test_empty_pool_returns_none_when_lead_is_executor(self):
        self.assertIsNone(pick_reviewer("lead", "lead", []))

    def test_pool_of_dicts(self):
        pool = [{"name": "lead"}, {"name": "second"}]
        self.assertEqual(pick_reviewer("lead", "lead", pool), "second")

    def test_pool_of_objects(self):
        class Member:
            def __init__(self, name):
                self.name = name

        pool = [Member("lead"), Member("second")]
        self.assertEqual(pick_reviewer("lead", "lead", pool), "second")

    def test_lead_as_dict(self):
        self.assertEqual(
            pick_reviewer({"name": "lead"}, {"name": "worker"}, ["x"]), "lead"
        )

    def test_none_lead_falls_back_to_pool(self):
        self.assertEqual(pick_reviewer(None, "worker", ["second"]), "second")

    def test_none_lead_and_empty_pool(self):
        self.assertIsNone(pick_reviewer(None, "worker", []))

    def test_single_member_pool(self):
        self.assertEqual(pick_reviewer("lead", "lead", "second"), "second")

    def test_capable_none_means_everyone(self):
        self.assertEqual(pick_reviewer("lead", "lead", ["a", "b"]), "a")


# ---------------------------------------------------------------------------
# review_plan
# ---------------------------------------------------------------------------
class TestReviewPlan(unittest.TestCase):
    def test_low_risk_is_spot_check(self):
        plan = review_plan(0.0)
        self.assertEqual(plan["tier"], "spot")
        self.assertTrue(plan["spot_check"])
        self.assertFalse(plan["required"])
        self.assertFalse(plan["dual"])
        self.assertEqual(plan["votes_required"], 0)

    def test_just_below_required_threshold_is_spot(self):
        plan = review_plan(RISK_REQUIRED_THRESHOLD - 1e-9)
        self.assertEqual(plan["tier"], "spot")

    def test_required_threshold_is_required(self):
        plan = review_plan(0.4)
        self.assertEqual(plan["tier"], "required")
        self.assertTrue(plan["required"])
        self.assertEqual(plan["reviewers"], ["lead"])
        self.assertEqual(plan["votes_required"], 1)

    def test_mid_risk_is_required(self):
        plan = review_plan(0.55)
        self.assertEqual(plan["tier"], "required")

    def test_just_below_dual_threshold_is_required(self):
        plan = review_plan(RISK_DUAL_THRESHOLD - 1e-9)
        self.assertEqual(plan["tier"], "required")

    def test_dual_threshold_is_dual(self):
        plan = review_plan(0.7)
        self.assertEqual(plan["tier"], "dual")
        self.assertTrue(plan["dual"])
        self.assertEqual(plan["reviewers"], ["lead", "fallback"])
        self.assertEqual(plan["votes_required"], 2)
        self.assertTrue(plan["fix_on_any_fix"])

    def test_high_risk_is_dual(self):
        plan = review_plan(0.95)
        self.assertEqual(plan["tier"], "dual")

    def test_risk_above_one_is_clamped(self):
        plan = review_plan(5.0)
        self.assertEqual(plan["risk"], 1.0)
        self.assertEqual(plan["tier"], "dual")

    def test_negative_risk_is_clamped(self):
        plan = review_plan(-3.0)
        self.assertEqual(plan["risk"], 0.0)
        self.assertEqual(plan["tier"], "spot")

    def test_non_numeric_risk_defaults_to_zero(self):
        plan = review_plan("nonsense")
        self.assertEqual(plan["risk"], 0.0)
        self.assertEqual(plan["tier"], "spot")

    def test_plan_keys_are_stable(self):
        plan = review_plan(0.5)
        expected = {
            "tier",
            "risk",
            "reviewers",
            "dual",
            "required",
            "spot_check",
            "votes_required",
            "fix_on_any_fix",
            "description",
        }
        self.assertEqual(set(plan.keys()), expected)


# ---------------------------------------------------------------------------
# DoD integration: "指挥即执行者" + 高风险双审
# ---------------------------------------------------------------------------
class TestDoDScenarios(unittest.TestCase):
    def test_lead_as_executor_still_gets_a_reviewer(self):
        seg = {"id": "seg-1", "executor": "lead", "diff_lines": 120, "irreversible": False}
        ctx = {"lead": "lead", "pool": ["second", "third"], "capable": {"second", "third"}}

        reviewer = pick_reviewer(ctx["lead"], seg["executor"], ctx["pool"], ctx["capable"])
        self.assertIsNotNone(reviewer)
        self.assertNotEqual(reviewer, seg["executor"])

        risk = risk_score(seg, ctx)
        plan = review_plan(risk)
        self.assertIn(plan["tier"], {"required", "dual", "spot"})
        # The reviewer must be recorded in review_meta as the design requires.
        seg["review_meta"] = {
            "reviewer": reviewer,
            "risk": risk,
            "votes": [],
            "verdicts": [],
        }
        self.assertEqual(seg["review_meta"]["reviewer"], "second")

    def test_high_risk_segment_gets_dual_review(self):
        seg = {
            "id": "seg-2",
            "executor": "lead",
            "irreversible": True,       # 0.4
            "diff_lines": 300,          # 0.3
            "member_is_new": False,
            "pass_rate": 1.0,
            "difficulty": 0,
        }
        ctx = {"lead": "lead", "pool": ["second", "third"]}

        risk = risk_score(seg, ctx)
        self.assertAlmostEqual(risk, 0.7, places=6)

        plan = review_plan(risk)
        self.assertEqual(plan["tier"], "dual")
        self.assertEqual(plan["votes_required"], 2)
        self.assertTrue(plan["fix_on_any_fix"])

        # lead is the executor -> fallback reviewer is picked from the pool
        fallback = pick_reviewer(ctx["lead"], seg["executor"], ctx["pool"])
        self.assertEqual(fallback, "second")

        reviewers = ["lead", fallback]
        self.assertEqual(len(set(reviewers)), 2)

        seg["review_meta"] = {
            "reviewer": fallback,
            "risk": risk,
            "votes": [],
            "verdicts": [],
        }
        self.assertEqual(seg["review_meta"]["risk"], risk)

    def test_dual_review_any_fix_means_rework(self):
        plan = review_plan(0.9)
        votes = ["PASS", "FIX"]
        verdicts = votes
        needs_rework = plan["fix_on_any_fix"] and any(v == "FIX" for v in verdicts)
        self.assertTrue(needs_rework)

    def test_required_review_single_fix_is_authoritative(self):
        plan = review_plan(0.5)
        self.assertFalse(plan["fix_on_any_fix"])
        self.assertEqual(plan["votes_required"], 1)


if __name__ == "__main__":
    unittest.main()
