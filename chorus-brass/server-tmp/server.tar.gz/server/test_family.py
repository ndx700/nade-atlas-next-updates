import unittest, chorus2 as c


class Family(unittest.TestCase):
    def test_family_and_preference(self):
        a = {"name": "A", "model": "claude-opus-5-5"}
        b = {"name": "B", "model": "claude-sonnet-5-5"}
        g = {"name": "G", "model": "gpt-6.1-sol"}
        self.assertEqual(c.model_family(a), c.model_family(b))
        self.assertNotEqual(c.model_family(a), c.model_family(g))
        self.assertEqual([m["name"] for m in c.prefer_other_family([b, g], a)], ["G", "B"])


if __name__ == "__main__":
    unittest.main()
