"""server/test_wakegraph.py — wakegraph 单元测试（stdlib unittest）。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import wakegraph  # noqa: E402
from wakegraph import Graph, REASONS, STEPS, WakeVerdict  # noqa: E402


class Clock:
    """可注入的假时钟。"""

    def __init__(self, t: float = 1000.0) -> None:
        self.t = float(t)

    def __call__(self) -> float:
        return self.t

    def advance(self, dt: float) -> None:
        self.t += float(dt)


class TestConstants(unittest.TestCase):
    def test_reasons_tuple(self):
        self.assertEqual(
            REASONS,
            ("mention", "handoff", "help", "review", "dispatch", "lead_plan", "retry"),
        )

    def test_steps_tuple(self):
        self.assertEqual(
            STEPS,
            ("planning", "working", "selfcheck", "review", "waiting", "idle", "resting"),
        )

    def test_verdict_defaults(self):
        v = WakeVerdict(True)
        self.assertTrue(v.ok)
        self.assertEqual(v.why, "")
        self.assertTrue(bool(v))
        self.assertFalse(bool(WakeVerdict(False, "x")))


class TestCanWake(unittest.TestCase):
    def test_allow_normal(self):
        g = Graph(now=Clock())
        v = g.can_wake("root", "大肥鱼", "小克", "handoff", "来搭把手")
        self.assertIsInstance(v, WakeVerdict)
        self.assertTrue(v.ok)
        self.assertEqual(v.why, "")

    def test_self_wake_refused(self):
        g = Graph(now=Clock())
        v = g.can_wake("root", "小克", "小克", "handoff", "")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "不能自己唤醒自己")

    def test_resting_refused(self):
        g = Graph(now=Clock())
        v = g.can_wake("root", "A", "B", "handoff", "", dst_state="resting")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "对方在休息")

    def test_budget_refused(self):
        g = Graph(now=Clock())
        for budget in (0, 0.0, -1.0):
            v = g.can_wake("root", "A", "B", "handoff", "", budget_left=budget)
            self.assertFalse(v.ok)
            self.assertEqual(v.why, "预算用完")

    def test_budget_positive_and_none_ok(self):
        g = Graph(now=Clock())
        self.assertTrue(g.can_wake("root", "A", "B", "handoff", "", budget_left=0.5).ok)
        self.assertTrue(g.can_wake("root", "A", "C", "handoff", "", budget_left=None).ok)

    def test_hop_limit(self):
        g = Graph(max_hops=3, now=Clock())
        for s, d in (("A", "B"), ("C", "D"), ("E", "F")):
            g.record("r", "p", s, d, "handoff")
        v = g.can_wake("r", "G", "H", "help", "")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "超过 3 跳")

    def test_hop_limit_is_per_root(self):
        g = Graph(max_hops=2, now=Clock())
        g.record("r1", "p", "A", "B", "handoff")
        g.record("r1", "p", "C", "D", "handoff")
        self.assertFalse(g.can_wake("r1", "E", "F", "help", "").ok)
        self.assertTrue(g.can_wake("r2", "E", "F", "help", "").ok)

    def test_pingpong(self):
        g = Graph(pingpong_limit=3, now=Clock())
        g.record("r", "p", "A", "B", "handoff")
        g.record("r", "p", "B", "A", "handoff")
        # 两次来回还允许
        self.assertTrue(g.can_wake("r", "A", "B", "handoff", "").ok)
        g.record("r", "p", "A", "B", "handoff")
        v = g.can_wake("r", "B", "A", "handoff", "")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "互相来回 3 次已停")
        # 另一个 root 不受影响
        self.assertTrue(g.can_wake("r2", "B", "A", "handoff", "").ok)

    def test_pingpong_resets_when_pair_changes(self):
        g = Graph(pingpong_limit=3, now=Clock())
        g.record("r", "p", "A", "B", "handoff")
        g.record("r", "p", "B", "A", "handoff")
        g.record("r", "p", "A", "B", "handoff")
        g.record("r", "p", "C", "D", "handoff")
        self.assertTrue(g.can_wake("r", "B", "A", "handoff", "").ok)

    def test_user_bypass(self):
        g = Graph(max_hops=0, pingpong_limit=1, rate_per_min=1, now=Clock())
        g.record("r", "p", "X", "Y", "handoff")
        self.assertFalse(g.can_wake("r", "X", "Y", "handoff", "").ok)
        self.assertTrue(g.can_wake("r", "user", "Y", "mention", "来一下").ok)
        self.assertTrue(g.can_wake("r", "Ali", "Y", "mention", "来一下").ok)

    def test_user_still_blocked_by_resting_and_budget(self):
        g = Graph(now=Clock())
        self.assertFalse(
            g.can_wake("r", "user", "Y", "mention", "", dst_state="resting").ok
        )
        self.assertFalse(
            g.can_wake("r", "Ali", "Y", "mention", "", budget_left=0).ok
        )

    def test_dedupe_window(self):
        clk = Clock()
        g = Graph(dedupe_window=120.0, now=clk)
        self.assertTrue(g.can_wake("r", "A", "B", "help", "please review   this").ok)
        v = g.can_wake("r", "A", "B", "help", "please review this")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "同一内容 2 分钟内重复")
        # 不同内容放行
        self.assertTrue(g.can_wake("r", "A", "B", "help", "something else").ok)
        # 过了窗口后同样内容重新放行
        clk.advance(121.0)
        self.assertTrue(g.can_wake("r", "A", "B", "help", "please review this").ok)

    def test_dedupe_normalisation(self):
        g = Graph(dedupe_window=120.0, now=Clock())
        self.assertTrue(g.can_wake("r", "A", "B", "help", "Hello   World").ok)
        self.assertFalse(g.can_wake("r", "A", "B", "help", "  hello world ").ok)
        # 不同收件人不算重复
        self.assertTrue(g.can_wake("r", "A", "C", "help", "hello world").ok)

    def test_rate_limit(self):
        clk = Clock()
        g = Graph(rate_per_min=2, now=clk)
        g.record("r", "p", "A", "X", "handoff")
        g.record("r2", "p", "B", "X", "handoff")  # 跨 root 一起统计
        v = g.can_wake("r", "C", "X", "help", "")
        self.assertFalse(v.ok)
        self.assertEqual(v.why, "频率过高")

    def test_rate_limit_window_slide(self):
        clk = Clock()
        g = Graph(rate_per_min=2, now=clk)
        g.record("r", "p", "A", "X", "handoff")
        g.record("r", "p", "B", "X", "handoff")
        self.assertFalse(g.can_wake("r", "C", "X", "help", "").ok)
        clk.advance(61.0)
        self.assertTrue(g.can_wake("r", "C", "X", "help", "").ok)


class TestRecord(unittest.TestCase):
    def test_record_fields_and_hops(self):
        clk = Clock()
        g = Graph(now=clk)
        e1 = g.record("r1", "p1", "A", "B", "handoff", "s3", "note-1")
        e2 = g.record("r1", "p1", "B", "C", "help")
        e3 = g.record("r2", "p1", "C", "D", "review")
        self.assertEqual([e1["hop"], e2["hop"], e3["hop"]], [1, 2, 1])
        self.assertEqual(set(e1.keys()),
                         {"id", "at", "root", "pid", "src", "dst", "reason", "seg", "note", "hop"})
        self.assertEqual(e1["root"], "r1")
        self.assertEqual(e1["pid"], "p1")
        self.assertEqual(e1["seg"], "s3")
        self.assertEqual(e1["note"], "note-1")
        self.assertEqual(e1["at"], 1000.0)
        self.assertNotEqual(e1["id"], e2["id"])

    def test_record_returns_copy(self):
        g = Graph(now=Clock())
        e = g.record("r", "p", "A", "B", "handoff")
        e["src"] = "HACKED"
        self.assertEqual(g.flow("p")["edges"][0]["src"], "A")


class TestSteps(unittest.TestCase):
    def test_set_step_and_steps(self):
        clk = Clock()
        g = Graph(now=clk)
        g.set_step("p1", "大肥鱼", "working", "s2", "读代码")
        clk.advance(5)
        g.set_step("p1", "小克", "planning")
        s = g.steps("p1")
        self.assertEqual(set(s.keys()), {"大肥鱼", "小克"})
        self.assertEqual(s["大肥鱼"]["step"], "working")
        self.assertEqual(s["大肥鱼"]["seg"], "s2")
        self.assertEqual(s["大肥鱼"]["detail"], "读代码")
        self.assertEqual(s["大肥鱼"]["since"], 1000.0)
        self.assertEqual(s["小克"]["step"], "planning")
        self.assertEqual(s["小克"]["seg"], "")
        self.assertEqual(g.steps("nope"), {})

    def test_steps_returns_copy(self):
        g = Graph(now=Clock())
        g.set_step("p1", "A", "idle")
        g.steps("p1")["A"]["step"] = "resting"
        self.assertEqual(g.steps("p1")["A"]["step"], "idle")

    def test_set_step_invalid(self):
        g = Graph(now=Clock())
        with self.assertRaises(ValueError):
            g.set_step("p1", "A", "napping")


class TestFlow(unittest.TestCase):
    def test_flow(self):
        g = Graph(now=Clock())
        g.record("r1", "p1", "A", "B", "handoff")
        g.record("r1", "p1", "B", "C", "help")
        g.record("r2", "p1", "A", "B", "dispatch")
        g.record("r1", "p2", "A", "B", "review")
        g.set_step("p1", "A", "working", "s1")

        f = g.flow("p1")
        self.assertEqual(len(f["edges"]), 3)
        self.assertEqual(f["roots"], {"r1": 2, "r2": 1})
        self.assertEqual(f["steps"]["A"]["step"], "working")

        f2 = g.flow("p1", limit=1)
        self.assertEqual(len(f2["edges"]), 1)
        self.assertEqual(f2["edges"][0]["root"], "r2")

        self.assertEqual(g.flow("p2")["edges"][0]["reason"], "review")
        self.assertEqual(g.flow("missing"), {"edges": [], "steps": {}, "roots": {}})


class TestSystemLine(unittest.TestCase):
    def test_system_line(self):
        g = Graph(now=Clock())
        e = g.record("r", "p", "大肥鱼", "小克", "handoff", "s3")
        self.assertEqual(g.system_line(e), "大肥鱼 → 小克 · 接棒 s3")
        e2 = g.record("r", "p", "指挥", "DeepSeek", "dispatch", "s1")
        self.assertEqual(g.system_line(e2), "指挥 → DeepSeek · 派单 s1")
        e3 = g.record("r", "p", "MiMo", "指挥", "help")
        self.assertEqual(g.system_line(e3), "MiMo → 指挥 · 求助")

    def test_system_line_labels(self):
        g = Graph(now=Clock())
        labels = {
            "mention": "点名",
            "handoff": "接棒",
            "help": "求助",
            "review": "送审",
            "dispatch": "派单",
            "lead_plan": "谱稿",
            "retry": "重试",
        }
        for reason, label in labels.items():
            edge = {"src": "A", "dst": "B", "reason": reason, "seg": ""}
            self.assertEqual(g.system_line(edge), f"A → B · {label}")
        # 未知 reason 原样输出
        self.assertEqual(
            g.system_line({"src": "A", "dst": "B", "reason": "custom"}),
            "A → B · custom",
        )


class TestCollapse(unittest.TestCase):
    @staticmethod
    def _line(at, pid, src, dst, reason="handoff", seg=""):
        g = Graph()
        edge = {"src": src, "dst": dst, "reason": reason, "seg": seg}
        return {
            "at": at,
            "pid": pid,
            "src": src,
            "dst": dst,
            "reason": reason,
            "seg": seg,
            "text": g.system_line(edge),
        }

    def test_collapse_grouping(self):
        g = Graph(now=Clock())
        lines = [
            self._line(100.0, "p1", "大肥鱼", "小克"),
            self._line(110.0, "p1", "小克", "MiMo", "help"),
            self._line(120.0, "p1", "MiMo", "指挥", "review"),
        ]
        out = g.collapse(lines, window=30.0)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["at"], 100.0)
        self.assertEqual(out[0]["summary"], "3 次交接 · 大肥鱼 → 小克 → MiMo → 指挥")
        self.assertEqual(len(out[0]["items"]), 3)

    def test_collapse_window_split(self):
        g = Graph(now=Clock())
        lines = [
            self._line(0.0, "p1", "A", "B"),
            self._line(10.0, "p1", "B", "C"),
            self._line(60.0, "p1", "C", "D"),
        ]
        out = g.collapse(lines, window=30.0)
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0]["summary"], "2 次交接 · A → B → C")
        self.assertEqual(out[1]["items"][0]["at"], 60.0)
        self.assertEqual(out[1]["summary"], "C → D · 接棒")

    def test_collapse_single_and_pid_split(self):
        g = Graph(now=Clock())
        lines = [
            self._line(0.0, "p1", "A", "B"),
            self._line(1.0, "p2", "B", "C"),
            self._line(2.0, "p2", "C", "D"),
        ]
        out = g.collapse(lines, window=30.0)
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0]["pid"], "p1")
        self.assertEqual(out[0]["summary"], "A → B · 接棒")
        self.assertEqual(out[1]["summary"], "2 次交接 · B → C → D")

    def test_collapse_empty(self):
        g = Graph(now=Clock())
        self.assertEqual(g.collapse([]), [])


class TestPersistence(unittest.TestCase):
    def test_roundtrip(self):
        clk = Clock()
        g = Graph(max_hops=4, pingpong_limit=2, dedupe_window=90.0,
                  rate_per_min=5, now=clk)
        g.record("r1", "p1", "A", "B", "handoff", "s1", "n1")
        g.record("r1", "p1", "B", "C", "help")
        g.record("r2", "p1", "C", "D", "review")
        g.set_step("p1", "A", "review", "s2", "等回执")

        dump = g.to_json()
        h = Graph.from_json(dump, now=clk)

        self.assertEqual(h.max_hops, 4)
        self.assertEqual(h.pingpong_limit, 2)
        self.assertEqual(h.dedupe_window, 90.0)
        self.assertEqual(h.rate_per_min, 5)
        self.assertEqual(h.to_json()["edges"], dump["edges"])
        self.assertEqual(h.steps("p1"), g.steps("p1"))
        self.assertEqual(h.flow("p1"), g.flow("p1"))

        # 恢复后 hop 继续累加
        e = h.record("r1", "p1", "D", "E", "handoff")
        self.assertEqual(e["hop"], 3)
        self.assertTrue(e["id"].startswith("e"))

    def test_config_override(self):
        g = Graph(now=Clock())
        g.record("r", "p", "A", "B", "handoff")
        h = Graph.from_json(g.to_json(), max_hops=9, rate_per_min=3)
        self.assertEqual(h.max_hops, 9)
        self.assertEqual(h.rate_per_min, 3)
        self.assertEqual(len(h.flow("p")["edges"]), 1)

    def test_json_edge_cap_500(self):
        g = Graph(now=Clock())
        for i in range(510):
            g.record("r", "p", f"A{i}", f"B{i}", "handoff")
        dump = g.to_json()
        self.assertEqual(len(dump["edges"]), 500)
        self.assertEqual(dump["edges"][-1]["hop"], 510)

        h = Graph.from_json(dump)
        self.assertEqual(len(h.to_json()["edges"]), 500)
        self.assertEqual(h.flow("p", limit=0)["edges"][-1]["hop"], 510)
        # 上限之后仍然接着编号
        self.assertEqual(h.record("r", "p", "X", "Y", "handoff")["hop"], 511)

    def test_from_json_bad_input(self):
        with self.assertRaises(ValueError):
            Graph.from_json(None)
        g = Graph.from_json({"edges": [None, 1, {"src": "A", "pid": "p"}], "steps": {"p": 5}})
        self.assertEqual(len(g.flow("p")["edges"]), 1)
        self.assertEqual(g.steps("p"), {})


if __name__ == "__main__":
    unittest.main(verbosity=2)


class OrchestrationIsolation(unittest.TestCase):
    def test_scheduler_events_do_not_exhaust_ai_wake_guards(self):
        g = Graph()
        for reason in ('dispatch', 'retry', 'lead_plan', 'handover'):
            for _ in range(8):
                g.record('root', 'p', 'A', 'B', reason)
        g = Graph.from_json(g.to_json())
        self.assertTrue(g.can_wake('root', 'A', 'B', 'mention', 'same').ok)
        self.assertEqual(g.record('root', 'p', 'A', 'B', 'mention')['hop'], 1)
        self.assertFalse(g.can_wake('root', 'A', 'B', 'mention', 'same').ok)

    def test_hop_limit_survives_edge_truncation(self):
        g = Graph()
        for _ in range(6):
            g.record('root', 'p', 'A', 'B', 'mention')
        for _ in range(501):
            g.record('other', 'p', 'C', 'D', 'dispatch')
        g = Graph.from_json(g.to_json())
        self.assertFalse(g.can_wake('root', 'A', 'C', 'mention', '').ok)
