"""Avatar API regression tests. Isolated data, real HTTP/image decoding, no services/models."""
import asyncio
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
from urllib.parse import quote

from aiohttp.test_utils import TestClient, TestServer
from PIL import Image, PngImagePlugin

import backup
import member_avatars as av
import server as s


def picture(fmt="PNG", size=(400, 200), **options):
    image = Image.new("RGBA" if fmt != "JPEG" else "RGB", size, (90, 50, 130))
    stream = io.BytesIO()
    image.save(stream, format=fmt, **options)
    return stream.getvalue()


class Avatars(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.enterContext(patch.object(s, "DATA", Path(self.tmp.name)))
        self.enterContext(patch.object(s, "CFG", {"password": "test", "providers": [],
            "members": [{"name": "白龙娘", "role": "开发"}, {"name": "B"}]}))
        self.enterContext(patch.object(s, "PROJECTS", []))
        self.enterContext(patch.object(s, "PVER", {}))
        self.enterContext(patch.object(s, "VER", 0))
        self.enterContext(patch.object(s, "CHANGED", asyncio.Event()))
        for directory in ("tmp", "files", "skills"):
            (s.DATA / directory).mkdir()
        s.save_cfg()
        s.save(s.DATA / "projects.json", [])
        app = s.make_app()
        app.on_startup.clear()
        app.cleanup_ctx.clear()
        self.client = TestClient(TestServer(app))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)
        self.headers = {"Authorization": "Bearer " + s.token()}
        self.url = "/api/member/" + quote("白龙娘", safe="") + "/avatar"

    async def upload(self, raw=None, mime="image/png", **kw):
        return await self.client.post(self.url, data=picture() if raw is None else raw,
            headers={**self.headers, "Content-Type": mime}, **kw)

    async def uploaded(self, **kw):
        response = await self.upload(**kw)
        self.assertEqual(response.status, 200, await response.text())
        return await response.json()

    def path(self, value):
        return s.DATA / "files" / av.stored_name(value["avatar"])

    async def test_upload_resize_persist_and_download(self):
        result = await self.uploaded()
        self.assertEqual((result["width"], result["height"]), (256, 128))
        self.assertIn("?v=" + result["avatar_version"], result["avatar"])
        cfg = json.loads(s.cfg_path().read_text())["members"][0]
        self.assertEqual(cfg["avatar"], result["avatar"])
        self.assertEqual(s.member_view(s.member("白龙娘"))["avatar"], result["avatar"])
        response = await self.client.get(result["avatar"], headers=self.headers)
        self.assertEqual(response.status, 200)
        self.assertEqual(response.content_type, "image/png")
        with Image.open(io.BytesIO(await response.read())) as image:
            self.assertEqual(image.size, (256, 128))
        self.assertEqual(s.VER, 1)
        self.assertEqual(list((s.DATA / "tmp").iterdir()), [])

    async def test_jpeg_and_webp_decode_to_png(self):
        for fmt, mime in (("JPEG", "image/jpeg"), ("WEBP", "image/webp")):
            result = await self.uploaded(raw=picture(fmt), mime=mime)
            self.assertEqual(Image.open(self.path(result)).format, "PNG")

    async def test_small_transparent_avatar_not_upscaled(self):
        raw = io.BytesIO()
        Image.new("RGBA", (24, 16), (1, 2, 3, 0)).save(raw, "PNG")
        result = await self.uploaded(raw=raw.getvalue())
        with Image.open(self.path(result)) as image:
            self.assertEqual(image.size, (24, 16))
            self.assertEqual(image.getpixel((0, 0))[3], 0)

    async def test_exif_orientation_and_metadata_removed(self):
        exif = Image.Exif()
        exif[274] = 6
        exif[270] = "private caption"
        result = await self.uploaded(raw=picture("JPEG", exif=exif), mime="image/jpeg")
        with Image.open(self.path(result)) as image:
            self.assertEqual(image.size, (128, 256))
            self.assertEqual(dict(image.getexif()), {})
            self.assertNotIn("exif", image.info)

    async def test_png_text_metadata_removed(self):
        meta = PngImagePlugin.PngInfo()
        meta.add_text("Comment", "private metadata")
        result = await self.uploaded(raw=picture(pnginfo=meta))
        with Image.open(self.path(result)) as image:
            self.assertNotIn("Comment", image.info)

    async def test_animation_is_rejected(self):
        raw = io.BytesIO()
        Image.new("RGB", (20, 20), "red").save(raw, format="PNG", save_all=True,
            append_images=[Image.new("RGB", (20, 20), "blue")], duration=100, loop=0)
        response = await self.upload(raw.getvalue())
        self.assertEqual(response.status, 400)
        self.assertEqual(list((s.DATA / "files").iterdir()), [])

    async def test_svg_gif_and_binary_mime_rejected(self):
        for mime in ("image/svg+xml", "image/gif", "application/octet-stream", "multipart/form-data"):
            self.assertEqual((await self.upload(mime=mime)).status, 415)

    async def test_format_mismatch_rejected(self):
        self.assertEqual((await self.upload(picture("JPEG"))).status, 400)
        self.assertEqual((await self.upload(b"<svg onload='alert(1)'/>")).status, 400)

    async def test_empty_and_truncated_image_rejected(self):
        for raw in (b"", picture()[:60], b"not an image"):
            self.assertEqual((await self.upload(raw)).status, 400)
        self.assertNotIn("avatar", s.member("白龙娘"))
        self.assertEqual(list((s.DATA / "files").iterdir()), [])

    async def test_pixel_limit(self):
        with patch.object(av, "MAX_PIXELS", 100):
            self.assertEqual((await self.upload(picture(size=(11, 10)))).status, 400)
            self.assertEqual((await self.upload(picture(size=(10, 10)))).status, 200)

    async def test_byte_limit_with_content_length(self):
        with patch.object(av, "MAX_BYTES", 128):
            self.assertEqual((await self.upload(b"a" * 129)).status, 413)
        self.assertEqual(list((s.DATA / "tmp").iterdir()), [])

    async def test_byte_limit_for_chunked_upload(self):
        async def chunks():
            yield b"a" * 70
            yield b"b" * 70
        with patch.object(av, "MAX_BYTES", 128):
            self.assertEqual((await self.upload(chunks())).status, 413)
        self.assertEqual(list((s.DATA / "files").iterdir()), [])

    async def test_auth_required_for_upload_and_delete(self):
        for method in ("post", "delete"):
            response = await getattr(self.client, method)(self.url, data=picture())
            self.assertEqual(response.status, 401)
        self.assertNotIn("avatar", s.member("白龙娘"))

    async def test_avatar_download_uses_existing_file_auth(self):
        result = await self.uploaded()
        self.assertEqual((await self.client.get(result["avatar"])).status, 401)
        self.assertEqual((await self.client.get(result["avatar"] + "&t=" + s.token())).status, 200)

    async def test_unknown_member(self):
        for method in ("post", "delete"):
            response = await getattr(self.client, method)("/api/member/missing/avatar", headers=self.headers)
            self.assertEqual(response.status, 404)

    async def test_replacement_changes_version_and_removes_old_file(self):
        first = await self.uploaded()
        second = await self.uploaded()
        self.assertNotEqual(first["avatar_version"], second["avatar_version"])
        self.assertFalse(self.path(first).exists())
        self.assertTrue(self.path(second).exists())

    async def test_delete_restores_initials_and_is_idempotent(self):
        result = await self.uploaded()
        for _ in range(2):
            response = await self.client.delete(self.url, headers=self.headers)
            self.assertEqual(response.status, 200)
            self.assertEqual((await response.json())["avatar"], "")
        self.assertFalse(self.path(result).exists())
        self.assertEqual(s.member_view(s.member("白龙娘"))["avatar_version"], "")
        self.assertEqual(json.loads(s.cfg_path().read_text())["members"][0]["avatar"], "")

    async def test_legacy_bundled_external_base64_are_hidden_in_views(self):
        for value in ("/assets/dragon.png", "https://example.com/avatar.png", "data:image/png;base64,aaa", {"url": "x"}):
            s.member("白龙娘")["avatar"] = value
            self.assertEqual(s.member_view(s.member("白龙娘"))["avatar"], "")
            response = await self.client.get("/api/config", headers=self.headers)
            self.assertEqual((await response.json())["members"][0]["avatar"], "")
        self.assertEqual(s.member_view(s.member("B"))["avatar"], "")

    async def test_settings_cannot_set_arbitrary_avatar_or_version(self):
        result = await self.uploaded()
        with patch.object(s, "refresh_quota", AsyncMock()):
            response = await self.client.put("/api/members", headers=self.headers,
                json={"name": "白龙娘", "avatar": "data:image/png;base64,bad", "avatar_version": "bad", "role": "新职责"})
        self.assertEqual(response.status, 200)
        self.assertEqual(s.member("白龙娘")["avatar"], result["avatar"])
        self.assertEqual(s.member("白龙娘")["avatar_version"], result["avatar_version"])
        self.assertEqual(s.member("白龙娘")["role"], "新职责")

    async def test_config_save_failure_preserves_previous_avatar(self):
        first = await self.uploaded()
        with patch.object(s, "save_cfg", side_effect=OSError("test write failure")):
            response = await self.upload()
        self.assertEqual(response.status, 500)
        self.assertEqual(s.member("白龙娘")["avatar"], first["avatar"])
        self.assertEqual([x.name for x in (s.DATA / "files").iterdir()], [self.path(first).name])
        self.assertEqual(s.VER, 1)

    async def test_delete_save_failure_keeps_file_and_config(self):
        first = await self.uploaded()
        with patch.object(s, "save_cfg", side_effect=OSError("test write failure")):
            response = await self.client.delete(self.url, headers=self.headers)
        self.assertEqual(response.status, 500)
        self.assertTrue(self.path(first).exists())
        self.assertEqual(s.member("白龙娘")["avatar"], first["avatar"])

    async def test_delete_only_unlinks_managed_file(self):
        attachment = s.DATA / "files" / "important.txt"
        attachment.write_text("keep")
        s.member("白龙娘")["avatar"] = "/files/important.txt"
        self.assertEqual((await self.client.delete(self.url, headers=self.headers)).status, 200)
        self.assertTrue(attachment.exists())

    async def test_avatar_survives_rename_and_removed_with_member(self):
        result = await self.uploaded()
        with patch.object(s, "refresh_quota", AsyncMock()):
            response = await self.client.put("/api/members", headers=self.headers,
                json={"old_name": "白龙娘", "name": "新名"})
        self.assertEqual(response.status, 200)
        self.assertEqual(s.member_view(s.member("新名"))["avatar"], result["avatar"])
        response = await self.client.delete("/api/members/" + quote("新名", safe=""), headers=self.headers)
        self.assertEqual(response.status, 200)
        self.assertFalse(self.path(result).exists())

    async def test_member_removed_or_replaced_during_upload(self):
        original = av.normalize
        def replace_member(*args):
            output = original(*args)
            s.CFG["members"][0] = {"name": "白龙娘"}
            return output
        with patch.object(av, "normalize", side_effect=replace_member):
            self.assertEqual((await self.upload()).status, 409)
        self.assertEqual(list((s.DATA / "files").iterdir()), [])

    async def test_missing_or_symlink_file_is_not_exposed(self):
        result = await self.uploaded()
        avatar_path = self.path(result)
        avatar_path.unlink()
        self.assertEqual(s.member_view(s.member("白龙娘"))["avatar"], "")
        avatar_path.symlink_to(s.cfg_path())
        self.assertEqual(s.member_view(s.member("白龙娘"))["avatar"], "")

    async def test_linked_storage_directory_is_refused(self):
        (s.DATA / "files").rmdir()
        outside = s.DATA / "outside"
        outside.mkdir()
        (s.DATA / "files").symlink_to(outside, target_is_directory=True)
        self.assertEqual((await self.upload()).status, 400)
        self.assertEqual(list(outside.iterdir()), [])

    async def test_backup_snapshot_keeps_manual_avatar_across_replacement(self):
        result = await self.uploaded()
        snapshot = s.DATA / "snapshot"
        backup.capture_snapshot(s.DATA, snapshot)
        old = snapshot / "files" / self.path(result).name
        await self.uploaded()
        self.assertFalse(self.path(result).exists())
        self.assertTrue(old.is_file())
        cfg = json.loads((snapshot / "config.json").read_text())
        self.assertEqual(av.view(snapshot, cfg["members"][0])["avatar"], result["avatar"])

    async def test_invalid_upload_does_not_replace_existing_avatar(self):
        result = await self.uploaded()
        self.assertEqual((await self.upload(b"bad")).status, 400)
        self.assertTrue(self.path(result).exists())
        self.assertEqual(s.member_view(s.member("白龙娘"))["avatar"], result["avatar"])


if __name__ == "__main__":
    unittest.main()
