"""Optional collaboration integrations. All paths belong to the project workspace."""
from pathlib import Path
import hashlib
import re
import json

import evidence
import manifest
import review_policy
import split_roi

_HUBS = {}


def enabled(server, feature):
    options = server.CFG.get("collab", {})
    return isinstance(options, dict) and options.get(feature) is True


def plan_gate(server, project, segments):
    if not enabled(server, "split_roi"):
        return segments
    decision = split_roi.split_decision(segments)
    project["split_roi"] = decision
    project["collab_serial"] = decision["verdict"] == "merge"
    if decision["verdict"] != "merge" or len(segments) < 2:
        return segments
    # Keep every deliverable and machine rule when the split costs more than it saves.
    merged = dict(segments[0])
    internal = {s["id"] for s in segments}
    for field in ("title", "goal", "deliverable", "context"):
        merged[field] = "\n".join(str(s.get(field, "")) for s in segments if s.get(field))
    for field in ("acceptance", "skills", "checks"):
        values = []
        for segment in segments:
            raw = segment.get(field, [])
            values.extend(raw if isinstance(raw, list) else [raw])
        if values:
            merged[field] = values
    merged["inputs"] = list(dict.fromkeys(i for s in segments for i in s.get("inputs", []) if i not in internal))
    merged["est_tokens"] = sum(s.get("est_tokens", 0) for s in segments)
    merged["difficulty"] = max(s.get("difficulty", 3) for s in segments)
    merged["assignee"] = ""
    merged["merged_segments"] = [s["id"] for s in segments]
    return [merged]


def review(server, seg, stats):
    if not enabled(server, "review_policy"):
        return {}
    return review_policy.review_plan(review_policy.risk_score(seg, {
        "pass_rate": stats.get("pass", .8), "member_is_new": stats.get("n", 0) < 3}))


def artifact_paths(root, paths):
    root = Path(root).resolve()
    for name in paths:
        path = (root / name).resolve()
        if path.is_relative_to(root) and path.is_file() and ".git" not in path.relative_to(root).parts:
            yield path
        else:
            raise ValueError(f"invalid or missing artifact: {name}")


async def record(server, pid, seg, root):
    paths = list(artifact_paths(root, [a for a in seg.get("artifacts", []) if "://" not in a]))
    store = Path(root).parent / "records"
    store.mkdir(exist_ok=True)
    records = []
    if enabled(server, "manifest"):
        registry = manifest.ManifestRegistry(store / "artifacts.json")
        for path in paths:
            item = await registry.register(path=path, seg=seg["id"], producer=seg.get("assignee", ""), checks=seg.get("verification", {}))
            records.append(item.to_dict())
        seg["artifact_manifests"] = records
    if enabled(server, "evidence"):
        key = hashlib.sha256(str(seg["id"]).encode()).hexdigest()[:24]
        args = dict(events_path=store / "events.jsonl", manifest_path=store / (key + ".json"), seg=seg["id"], pid=pid)
        decision = {"merged": True, "reviews": seg.get("reviews", [])}
        evidence.record_decision(**args, decision=decision)
        evidence.record_acceptance(**args, acceptance=seg.get("verification", {}))
        files = [{"path": str(path), "sha256": manifest.sha256_file(path)} for path in paths]
        for entry in files:
            evidence.record_file(**args, file_entry=entry)
        server.project(pid).setdefault("memory", {})[seg["id"]] = evidence.build_handoff(seg["id"], decisions=[decision], files=records or files, acceptances=[seg.get("verification", {})])


async def share(server, pid, project, seg, tree, who):
    """Use the existing server call path so capability sharing retains billing and consent."""
    import adapters
    import assets
    import chorus2
    if not enabled(server, "assets"):
        return [], []
    refs = []
    for upstream in project.get("segments", []):
        if upstream.get("id") in seg.get("inputs", []):
            refs.extend(upstream.get("artifacts", []))
    refs.extend(a.get("ref", "") for a in seg.get("assets", []) if a.get("kind") == "image")
    paths = list(artifact_paths(tree, refs))
    paths = [p for p in paths if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif"}]
    import collab_api
    members = [m for m in chorus2.candidates(project) if m.get("kind", "api") == "api"
               and not collab_api.consent_block(m) and chorus2.healthy(m["name"])]

    class Bridge:
        def __init__(self, member):
            self.member = member
        async def run(self, prompt, emit, gate):
            member = self.member
            provider = server.provider(member.get("provider")) or {}
            ref = prompt.splitlines()[0].removeprefix("[图片] ")
            prompt = assets.image_content(prompt, [ref], provider.get("kind") == "anthropic")
            token = chorus2.ROLE.set("share")
            try:
                return adapters.Result(ok=True, text=await chorus2.ask_model(member, "客观描述共享图片并提取文字", prompt, pid))
            finally:
                chorus2.ROLE.reset(token)

    async def deny(tool, inp, *args):
        return False

    store = Path(tree).parent.parent / "asset-cache.json"
    hub = _HUBS.setdefault((id(server), str(store)), assets.AssetHub(store, members, Bridge, deny,
                          lambda *args: None, chorus2.price_of, chorus2.stats()))
    hub.members = members
    member = server.member(who) or {}
    card = {"assets": [{"kind": "image", "ref": str(p)} for p in paths]}
    notes = await hub.for_card(card, member)
    caps = adapters.capabilities(member, chorus2.price_of(member), chorus2.stats().get(who))
    return notes, [str(p) for p in paths] if caps.get("vision") else []


def upstream(server, project, seg, root):
    """Recover durable handoffs and verify signed file content before downstream dispatch."""
    result = {}
    store = Path(root).parent / "records"
    for item in project.get("segments", []):
        if item["id"] not in seg.get("inputs", []):
            continue
        entry = {"summary": item.get("summary", ""), "artifacts": item.get("artifacts", []), "output_ref": item.get("output_ref")}
        if enabled(server, "manifest"):
            for record in item.get("artifact_manifests", []):
                path = next(artifact_paths(root, [str(Path(record["path"]).relative_to(root))]))
                if manifest.sha256_file(path) != record["sha256"]:
                    raise manifest.ManifestIntegrityError(record["id"], record["sha256"], manifest.sha256_file(path))
            entry["summary"] += "\n" + json.dumps(item.get("artifact_manifests", []), ensure_ascii=False)
        if enabled(server, "evidence") and not item.get("summary"):
            key = hashlib.sha256(str(item["id"]).encode()).hexdigest()[:24]
            recovered = evidence.recover_from_artifacts(item["id"], store / (key + ".json"), store / "events.jsonl")
            entry["summary"] = json.dumps(recovered, ensure_ascii=False)
        result[item["id"]] = entry
    return result


def read_text(root, name):
    try:
        path = next(artifact_paths(root, [name]))
        with path.open("r", encoding="utf-8") as stream:
            return stream.read(6000)
    except (OSError, UnicodeError, ValueError, StopIteration):
        return None


def validate_options(value):
    keys = {"assets", "review_policy", "split_roi", "manifest", "evidence"}
    if not isinstance(value, dict) or value.keys() - keys or any(type(v) is not bool for v in value.values()):
        raise ValueError("collab 只接受 assets/review_policy/split_roi/manifest/evidence 布尔开关")
    return {key: value.get(key, False) for key in sorted(keys)}


_HEREDOC = re.compile(r"cat\s*>\s*['\"]?([\w./-]+)['\"]?\s*<<-?\s*['\"]?(\w+)['\"]?[^\n]*\n(.*?)\n\2[ \t]*(?:\n|$)", re.S)
_FENCE = re.compile(r"```[ \t]*([\w+-]*)[ \t]*([\w./-]*)[^\n]*\n(.*?)\n```", re.S)


def materialize(root, text, names, overwrite=()):
    """API 声部不能执行命令，只会把文件写在回复里：把 heredoc / 带文件名的代码块落盘到工作目录。
    只写产物清单里、目录里还不存在的文件，不出根目录、不碰 .git。返回写入的文件名。"""
    if not root or not text or not names:
        return []
    root = Path(root).resolve()

    def norm(n):
        n = str(n).strip()
        return n[2:] if n.startswith("./") else n
    wanted = {norm(n) for n in names}
    found = {}
    for m in _HEREDOC.finditer(text):
        found.setdefault(norm(m.group(1)), m.group(3))
    for m in _FENCE.finditer(text):
        name = norm(m.group(2))
        if not name:
            before = text[:m.start()].rstrip().splitlines()[-1:] or [""]
            hit = re.search(r"([\w-]+(?:/[\w-]+)*\.\w+)", before[0])
            name = hit.group(1) if hit else ""
        body = m.group(3)
        if not name and len(wanted) == 1:
            only = next(iter(wanted))
            ext = only.rsplit(".", 1)[-1].lower()
            if m.group(1).lower() in (ext, {"htm": "html", "js": "javascript", "py": "python", "md": "markdown"}.get(ext, ext)):
                name = only
        if name and "cat >" not in body:
            found.setdefault(name, body)
    wrote = []
    for name in wanted:
        if name not in found:
            continue
        path = (root / name).resolve()
        if not path.is_relative_to(root) or ".git" in path.relative_to(root).parts or (path.exists() and name not in overwrite):
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(found[name].rstrip("\n") + "\n", encoding="utf-8")
        wrote.append(name)
    return wrote
