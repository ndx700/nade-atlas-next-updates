"""FIX3 handlers exercised without TCP or production data."""
import asyncio
import functools
import datetime as dt
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest
from aiohttp import web
import capabilities
import chorus2 as c
import fix3
import server as s
import skills
from test_chorus2 import Base, seg


def req(body=None, method='POST', **match):
    return SimpleNamespace(json=AsyncMock(return_value=body or {}), method=method,
                           match_info=match, query={}, headers={})


def data(response):
    return json.loads(response.text)


class TestFix3(Base):
    no_http_tests = frozenset({'test_create', 'test_invalid_create', 'test_archive',
        'test_reassign_withdraw', 'test_withdraw_conflicts', 'test_execution',
        'test_duty', 'test_restart', 'test_skills_receipt', 'test_caps_validation',
        'test_week_ledger'})

    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.service = fix3.Service(s, c)

    async def test_create(self):
        body = {'name': '原子项目', 'members': ['强'], 'mode': 'solo', 'brief': '执行',
                'lead': '强', 'client_id': 'create1',
                'project_caps': {'caps': {'search': True}, 'ask_first': True}}
        saved = []
        s.save = lambda path, rows: saved.append(json.loads(json.dumps(rows)))
        seen = []
        original = s.run_chain
        async def run(pid, *args):
            p = s.project(pid)
            seen.append((p['lead'], p['caps'], p['ask_first']))
        s.run_chain = run
        self.addCleanup(setattr, s, 'run_chain', original)
        first = data(await s.h_new_project(req(body)))
        await asyncio.sleep(0)
        again = data(await s.h_new_project(req(body)))
        assert first == again
        assert seen == [('强', {'search': True}, True)]
        assert saved[0][-1]['create_client_id'] == 'create1'
        assert first['effective']['caps']['search'] is False
        with pytest.raises(web.HTTPConflict):
            await s.h_new_project(req({**body, 'lead': ''}))

    async def test_invalid_create(self):
        for bad in ({'lead': '乙'}, {'project_caps': []}, {'ask_first': 'yes'}, {'caps': []}):
            with pytest.raises(web.HTTPBadRequest):
                await s.h_new_project(req({'name': '坏项目', 'members': ['强'], **bad}))
            assert len(s.PROJECTS) == 1

    async def test_archive(self):
        p = self.P()
        task = asyncio.create_task(asyncio.Event().wait())
        c.RUNNING['p'] = task
        response = data(await self.service.archive(req(pid='p')))
        assert task.cancelled() and response['paused'] and p['filed']
        assert not p.get('deleted_at') and not p.get('archived')
        assert data(await self.service.archive(req(method='GET')))['items'][0]['id'] == 'p'
        assert data(await c.h_trash(req(method='GET')))['items'] == []
        assert all(row['id'] != 'p' for row in s.index_view()['projects'])
        await self.service.archive(req(method='DELETE', pid='p'))
        assert not p['filed'] and p['paused']

    async def test_reassign_withdraw(self):
        p = self.P()
        p.update(paused=True, segments=[seg(1, assignee='甲')])
        body = {'request_id': 'r1', 'expected_version': 0, 'expected_assignee': '甲'}
        first = data(await self.service.reassign(req(body, pid='p', sid='s1')))
        assert first['target'] in ('强', '乙')
        snapshot = c.view('p')
        assert snapshot['assignment_events'][0]['id'] == first['event']['id']
        assert snapshot['segments'][0]['assignment_version'] == 1
        assert data(await self.service.reassign(req(body, pid='p', sid='s1'))) == first
        with pytest.raises(web.HTTPConflict):
            await self.service.reassign(req({**body, 'request_id': 'r2'}, pid='p', sid='s1'))
        withdrawal = {'request_id': 'w1', 'expected_version': 1}
        result = data(await self.service.withdraw(req(withdrawal, pid='p', eid=first['event']['id'])))
        assert result['target'] == '甲' and result['cancelled'] and result['version'] == 2
        assert data(await self.service.withdraw(req(withdrawal, pid='p', eid=first['event']['id']))) == result
        with pytest.raises(web.HTTPConflict):
            await self.service.withdraw(req({**withdrawal, 'expected_version': 2}, pid='p', eid=first['event']['id']))
        assert p['segments'][0]['assignee'] == '甲'

    async def test_withdraw_conflicts(self):
        p = self.P()
        x = seg(1, assignee='甲')
        p.update(paused=True, segments=[x])
        event = fix3.assignment_event(p, x, '乙')
        for change in ({'expected_version': 0}, {'expected_version': 1}):
            if change['expected_version'] == 1:
                event['at'] -= 601
            with pytest.raises(web.HTTPConflict):
                await self.service.withdraw(req({'request_id': 'w', **change}, pid='p', eid=event['id']))
        assert x['assignee'] == '乙'
        event['at'] += 601
        p['members'].remove('甲')
        with pytest.raises(web.HTTPConflict):
            await self.service.withdraw(req({'request_id': 'w2', 'expected_version': 1}, pid='p', eid=event['id']))
        p['segments'] = []
        with pytest.raises(web.HTTPConflict):
            await self.service.withdraw(req({'request_id': 'w3', 'expected_version': 1}, pid='p', eid=event['id']))

    async def test_execution(self):
        p = self.P()
        adapter = AsyncMock(return_value={'url': 'artifact'})
        s.execution_adapters = {'build': adapter, 'github': adapter}
        self.addCleanup(delattr, s, 'execution_adapters')
        with pytest.raises(web.HTTPForbidden):
            await self.service.execute(req(pid='p', capability='build'))
        s.CFG['account'] = {'execution': {'build': True}, 'connectors': {'github': True}}
        p.update(caps={'build': True, 'connectors': True}, connectors={'github': 'write'}, ask_first=True)
        with pytest.raises(web.HTTPConflict):
            await self.service.execute(req(pid='p', capability='build'))
        result = data(await self.service.execute(req({'confirmed': True}, pid='p', capability='build')))
        assert result['state'] == 'completed'
        assert adapter.await_count == 1
        await self.service.execute(req({'confirmed': True}, pid='p', capability='github'))
        with pytest.raises(web.HTTPServiceUnavailable):
            await self.service.execute(req(pid='p', capability='search'))
        available = data(await self.service.available(req()))['capabilities']
        assert available['build']['available'] and not available['search']['available']
        assert available['github']['enabled']

    async def test_duty(self):
        p = self.P()
        with pytest.raises(web.HTTPForbidden):
            await self.service.duty(req({'enabled': True}, method='PUT', pid='p'))
        p['caps'] = {'nocturne': True}
        await self.service.duty(req({'enabled': True, 'interval_s': 10}, method='PUT', pid='p'))
        original = c.start
        c.start = Mock()
        self.addCleanup(setattr, c, 'start', original)
        await self.service.tick()
        assert p['duty']['state'] == 'dispatched'
        c.start.assert_called_once_with('p')
        await self.service.tick()
        assert c.start.call_count == 1
        p['duty']['next_at'] = 0
        busy = asyncio.create_task(asyncio.Event().wait())
        c.RUNNING['p'] = busy
        await self.service.tick()
        assert c.start.call_count == 1
        busy.cancel()
        await asyncio.gather(busy, return_exceptions=True)
        c.RUNNING.pop('p')
        await self.service.duty(req({'enabled': False}, method='PUT', pid='p'))
        await self.service.tick()
        assert c.start.call_count == 1

    async def test_restart(self):
        body = {'request_id': 'restart1', 'policy': 'when_idle'}
        with pytest.raises(web.HTTPServiceUnavailable):
            await self.service.management(req(body))
        s.restart_service = AsyncMock()
        self.addCleanup(delattr, s, 'restart_service')
        response = data(await self.service.management(req(body)))
        assert response['state'] == 'accepted'
        await asyncio.gather(*self.service.tasks)
        s.restart_service.assert_awaited_once()
        assert data(await self.service.management(req(body)))['state'] == 'restarting'
        with pytest.raises(web.HTTPConflict):
            await self.service.management(req({**body, 'policy': 'immediate'}))
        info = data(await self.service.management(req(method='GET')))
        assert info['instance_id'] == response['instance_id']

    async def test_skills_receipt(self):
        original = skills.matches
        skills.matches = Mock(return_value=['score'])
        self.addCleanup(setattr, skills, 'matches', original)
        x = seg(1)
        assert 'score' in c.learned_context('甲', x)
        assert x['skill_load'] == {'state': 'matched', 'ids': ['score']}
        skills.matches.side_effect = ValueError('broken')
        c.learned_context('甲', x)
        assert x['skill_load']['state'] == 'failed'

    async def test_caps_validation(self):
        assert fix3.initial_config({'skills': ['score']})['skills'] == ['score']
        for bad in ({'skills': {}}, {'connectors': {'github': 'root'}}, {'caps': {'search': 'yes'}}):
            with pytest.raises(web.HTTPBadRequest):
                await c.h_caps(req(bad, method='PUT', pid='p'))
        assert not self.P().get('caps')

    async def test_week_ledger(self):
        now = __import__('time').time()
        day = s.today()
        path = s.spend_file()
        path.write_text(json.dumps({'甲': {day: {'cost_by_currency': {'¥': 7, '$': 2}}}}))
        result = fix3.week_spend(s, '¥', now)
        assert result['spent_week'] == 7 and result['week_complete']
        assert result['week_by_currency']['$'] == 2
        response = data(await c.h_caps_account(req(method='GET')))
        assert response['spent_week'] == 7


def test_week_boundary_and_currency():
    monday = dt.datetime(2026, 10, 26, tzinfo=dt.timezone(dt.timedelta(hours=8))).timestamp()
    cfg = {'spend_buckets': {str(int(monday // 60) - 1): {'¥': 90},
                             str(int(monday // 60)): {'¥': 2, '$': 3},
                             str(int(monday // 60) + 1440): {'¥': 4}}}
    result = fix3.week_spend(SimpleNamespace(CFG=cfg), '¥', monday + 86460)
    assert result['spent_week'] == 6
    assert result['week_by_currency'] == {'¥': 6, '$': 3}


def async_test(fn):
    @functools.wraps(fn)
    def run(*args, **kwargs):
        return asyncio.run(fn(*args, **kwargs))
    return run


@async_test
async def test_auth_and_registered_routes(tmp_path, monkeypatch):
    from aiohttp.test_utils import make_mocked_request
    monkeypatch.setattr(s, 'DATA', tmp_path)
    monkeypatch.setattr(s, 'CFG', {'password': 'pw'})
    app = web.Application(middlewares=[s.auth])
    fix3.register(app, s, c)
    for path in ('/api/management/restart', '/api/projects/p/archive',
                 '/api/projects/p/execute/build', '/api/orchestra/p/duty',
                 '/api/orchestra/p/segments/s1/reassign', '/api/orchestra/p/handovers/e/withdraw'):
        handler = AsyncMock(return_value=web.Response())
        response = await s.auth(make_mocked_request('POST', path, app=app), handler)
        assert response.status == 401
        handler.assert_not_awaited()
    paths = {route.resource.canonical for route in app.router.routes()}
    assert '/api/account/capabilities' in paths
    assert '/api/projects/archived' in paths


@async_test
async def test_configured_execution_and_restart_adapters(monkeypatch):
    cfg = {'execution_services': {'build': {'url': 'https://builder.example/run', 'token': 'secret'},
                                  'search': {'url': 'http://invalid'}},
           'management_restart_argv': ['/bin/manager', 'restart', 'chorus']}
    service = fix3.Service(SimpleNamespace(CFG=cfg), SimpleNamespace())
    response = SimpleNamespace(status=200, json=AsyncMock(return_value={'artifact': 'a'}))
    class Context:
        async def __aenter__(self):
            return response
        async def __aexit__(self, *args):
            pass
    post = Mock(return_value=Context())
    class Session:
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            pass
        def post(self, *args, **kwargs):
            return post(*args, **kwargs)
    monkeypatch.setattr(fix3, 'ClientSession', Session)
    adapters = service.adapters()
    assert 'search' not in adapters
    assert await adapters['build']('p', {'ref': 'main'}) == {'artifact': 'a'}
    assert post.call_args.kwargs['json'] == {'project_id': 'p', 'input': {'ref': 'main'}}
    response.status = 503
    with pytest.raises(web.HTTPBadGateway):
        await adapters['build']('p', {})
    spawn = AsyncMock(return_value=SimpleNamespace(wait=AsyncMock(return_value=0)))
    monkeypatch.setattr(asyncio, 'create_subprocess_exec', spawn)
    await service.restart_adapter()()
    assert spawn.call_args.args == ('/bin/manager', 'restart', 'chorus')


@async_test
async def test_concurrent_withdraw_keeps_progress_and_awaits_cancellation(monkeypatch):
    x = seg(1, assignee='甲', progress=.5)
    p = {'id': 'p', 'members': ['甲', '乙'], 'segments': [x]}
    event = fix3.assignment_event(p, x, '乙')
    exited = []
    async def work():
        try:
            await asyncio.Event().wait()
        finally:
            exited.append(True)
    task = asyncio.create_task(work())
    await asyncio.sleep(0)
    fake = SimpleNamespace(CFG={}, PROJECTS=[p], ROOTS={}, STOP_AT={}, project=lambda pid: p, bump=Mock())
    engine = SimpleNamespace(RUNNING={'p': task}, PLANNING={}, save_projects=Mock())
    service = fix3.Service(fake, engine)
    b = {'request_id': 'same', 'expected_version': 1}
    results = await asyncio.gather(*(service.withdraw(req(b, pid='p', eid=event['id'])) for _ in range(2)))
    assert data(results[0]) == data(results[1])
    assert exited and task.cancelled()
    assert x['progress'] == .5 and x['assignment_version'] == 2 and p['paused']
