"""B10: warning isolation and evidence for planning/budget review findings."""
import asyncio
import unittest
from unittest.mock import AsyncMock, patch

import chorus2 as c
import orchestra as o
import server as s
import test_dogfood_fixes as dogfood
from test_dogfood_fixes import request, segment


class Runtime(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = dogfood.Runtime.asyncSetUp
    cancel_tasks = dogfood.Runtime.cancel_tasks

    async def test_warning_kinds_deduplicate_independently_per_member(self):
        missing = {'pricing_warning': '缺少价格', 'cost': 0}
        foreign = {'cost': 1, 'cur': '$'}
        both = {**foreign, 'pricing_warning': '缺少价格'}
        for usages in ((missing, foreign), (foreign, missing), (both,)):
            with self.subTest(usages=usages):
                self.p['pending'] = []
                for _ in range(2):
                    for usage in usages:
                        c.on_usage(self.ms[0], usage, 'p')
                cards = self.p['pending']
                self.assertCountEqual([d['kind'] for d in cards],
                                      ['pricing_missing', 'currency_mismatch'])
                self.assertTrue(all(d['member'] == 'a' for d in cards))
                self.assertEqual(next(d['question'] for d in cards if d['kind'] == 'pricing_missing'), '缺少价格')
                self.assertIn('预算币种', next(d['question'] for d in cards if d['kind'] == 'currency_mismatch'))
                c.on_usage(self.ms[1], both, 'p')
                self.assertEqual(len(cards), 3)   # 缺价格合成一张卡
                self.assertEqual(next(d for d in cards if d['kind'] == 'pricing_missing')['members'], ['a', 'b'])
                missing_card = next(d for d in cards if d['kind'] == 'pricing_missing' and d['member'] == 'a')
                missing_card['state'] = 'done'
                c.on_usage(self.ms[0], both, 'p')
                self.assertEqual(len(cards), 4)
                self.assertEqual(cards[-1]['kind'], 'pricing_missing')
                self.assertEqual(len([d for d in cards if d['kind'] == 'currency_mismatch' and d['member'] == 'a']), 1)

    async def test_concurrent_clarifications_replan_once_with_all_answers_api_and_cli(self):
        for kind in ('api', 'cli'):
            with self.subTest(kind=kind):
                self.ms[1].update(kind=kind, provider='p', model='custom')
                self.p.update(lead_resolved='b', plan_start=False, pending=[
                    {'id': 'old', 'kind': 'clarify', 'state': 'done', 'question': '历史问题', 'answer': '历史答案'},
                    {'id': 'a', 'kind': 'clarify', 'state': 'open', 'question': '语言', 'options': ['Go']},
                    {'id': 'b', 'kind': 'clarify', 'state': 'open', 'question': '格式', 'options': ['CSV']},
                ])
                gate = asyncio.Event()
                text = '[{"title":"实现","difficulty":1}]'
                async def wait_reply(*args, **kwargs):
                    await gate.wait()
                    return text
                with patch.object(c, 'ask_model', side_effect=wait_reply) as ask, \
                     patch.object(s, 'run_member', side_effect=wait_reply), \
                     patch.object(s, 'add_msg', return_value={'seq': 1}) as add, \
                     patch.object(c, 'reply_to', return_value={'text': text}), \
                     patch.object(c.designopts, 'speculate'), \
                     patch.object(c, 'queue_plan', wraps=c.queue_plan) as queue, \
                     patch.object(c, 'start') as start:
                    await asyncio.gather(
                        c.h_decide(request({'id': 'a', 'choice': 0})),
                        c.h_decide(request({'id': 'b', 'answer': 'TSV'})),
                        c.h_decide(request({'id': 'b', 'answer': '重复回答'})))
                    task = c.PLANNING['p']
                    queue.assert_called_once_with('p', self.p['brief'])
                    self.assertIs(c.queue_plan('p', '重复规划'), task)
                    gate.set()
                    await task
                    context = ask.call_args.args[2] if kind == 'api' else add.call_args.args[2]
                    for answer in ('历史问题', '历史答案', '语言', 'Go', '格式', 'TSV'):
                        self.assertIn(answer, context)
                    self.assertNotIn('重复回答', context)
                    self.assertNotIn('p', c.PLANNING)
                    start.assert_not_called()

    async def test_immediate_plan_completion_and_failure_allow_retry(self):
        self.p['plan_start'] = False
        with patch.object(c, 'plan', new_callable=AsyncMock) as plan:
            plan.return_value = []
            first = c.queue_plan('p', 'first')
            self.assertIs(c.queue_plan('p', 'duplicate'), first)
            await first
            self.assertNotIn('p', c.PLANNING)
            plan.side_effect = RuntimeError('test planning failure')
            with self.assertLogs(c.__name__, level='ERROR'), self.assertRaisesRegex(RuntimeError, 'test planning failure'):
                await c.queue_plan('p', 'failure')
            self.assertNotIn('p', c.PLANNING)
            self.assertEqual(self.p['planning'], 'failed')
            self.assertEqual(self.p['pending'][-1]['kind'], 'plan_failed')
            plan.side_effect = None
            await c.queue_plan('p', 'retry')
            self.assertNotIn('p', c.PLANNING)
            self.assertEqual(self.p['planning'], 'done')
            self.assertEqual(plan.await_count, 3)


class Budget(unittest.TestCase):
    def test_segment_fallback_and_project_ledger_are_alternative_totals(self):
        sg = segment()
        o.record_spend(sg, 'exec', {}, 4)
        p = {'budget': {'cap': 10, 'cur': '¥'}, 'segments': [sg]}
        self.assertEqual(o.budget_state(p)['spent'], 4)
        p['cost_split'] = {}
        self.assertEqual(o.budget_state(p)['spent'], 4)
        # The project ledger already includes execution, plus planning/review.
        p['cost_split'] = {'exec': {'cost': {'¥': 4}}, 'plan': {'cost': {'¥': 2}},
                           'review': {'cost': {'¥': 3, '$': 20}}}
        state = o.budget_state(p)
        self.assertEqual(state['spent'], 9)
        self.assertEqual(state['level'], 'warn')
        p['budget']['cur'] = '$'
        self.assertEqual(o.budget_state(p)['spent'], 20)
        p['cost_split'] = {'exec': {'cost': {'$': 20}}}
        p['budget']['cur'] = '¥'
        self.assertEqual(o.budget_state(p)['spent'], 0)


if __name__ == '__main__':
    unittest.main()
