"""Deployment entry: fixed app only; no source/config directory exposure."""
import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from aiohttp.test_utils import TestClient, TestServer
import server

class WebEntry(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.entry = Path(self.tmp.name) / 'app.html'
        self.entry.write_text('<!doctype html><title>Chorus</title>')
        self.enterContext(patch.object(server, 'WEB_APP', self.entry))
        self.enterContext(patch.object(server, 'CFG', {'password':'test', 'members':[], 'providers':[]}))
        app=server.make_app(); app.on_startup.clear(); app.cleanup_ctx.clear()
        self.client=TestClient(TestServer(app)); await self.client.start_server()
        self.addAsyncCleanup(self.client.close)

    async def test_entry_is_public_but_api_stays_authenticated(self):
        response=await self.client.get('/')
        self.assertEqual(response.status,200)
        self.assertIn('<title>Chorus</title>',await response.text())
        self.assertEqual(response.headers['Cache-Control'],'no-cache')
        self.assertEqual((await self.client.get('/api/config')).status,401)

    async def test_no_directory_or_config_exposure(self):
        (self.entry.parent/'config.json').write_text('private')
        (self.entry.parent/'avatars.js').write_text('private old material')
        for url in ('/config.json','/avatars.js','/app.html','/server.py'):
            self.assertEqual((await self.client.get(url)).status,404)

    async def test_server_without_bundled_web_keeps_banner(self):
        self.entry.unlink()
        response=await self.client.get('/')
        self.assertEqual(response.status,200)
        self.assertIn('AI 协作服务器在运行',await response.text())
