import unittest, collab_api


class Settings(unittest.TestCase):
    def test_defaults_and_names(self):
        collab_api.S = None
        self.assertEqual(collab_api.settings()["tier"], "standard")
        self.assertEqual(collab_api.TIERS["save"], "轻奏")
        self.assertEqual(collab_api.TIERS["max"], "华彩")


if __name__ == "__main__":
    unittest.main()


class Record(unittest.TestCase):
    def test_register_and_version_chain(self):
        import asyncio, tempfile, pathlib, types
        d = pathlib.Path(tempfile.mkdtemp())
        (d / "files").mkdir()
        (d / "files" / "a.txt").write_text("v1")
        collab_api.S = types.SimpleNamespace(DATA=d, CFG={})
        ids1 = asyncio.run(collab_api.record_segment_artifacts("p1", "甲", ["/files/a.txt"], "说明"))
        (d / "files" / "a.txt").write_text("v2")
        ids2 = asyncio.run(collab_api.record_segment_artifacts("p1", "乙", ["/files/a.txt"], "说明"))
        self.assertEqual(len(ids1), 1)
        self.assertEqual(len(ids2), 1)
        import artifacts
        artifacts._DEFAULT_STORES.clear()
        items = asyncio.run(artifacts.default_store(d, "p1", enabled=True).list_by_project("p1"))
        self.assertEqual(items[0]["count"], 2)
        self.assertEqual(items[0]["head"]["version"], 2)

    def test_outside_files_ignored(self):
        import asyncio, tempfile, pathlib, types
        d = pathlib.Path(tempfile.mkdtemp())
        (d / "files").mkdir()
        collab_api.S = types.SimpleNamespace(DATA=d, CFG={})
        self.assertEqual(asyncio.run(collab_api.record_segment_artifacts("p1", "x", ["/etc/passwd", "/files/../../etc/passwd", "/files/../files-evil/x"])), [])


class ConsentBlock(unittest.TestCase):
    def test_blocks_until_allowed(self):
        import tempfile, pathlib, types, os, consent
        os.environ.pop("CHORUS_CONSENT", None)
        d = pathlib.Path(tempfile.mkdtemp())
        collab_api.S = types.SimpleNamespace(DATA=d, CFG={"providers": [{"id": "p", "key": "sk-xxxx1234"}]})
        m = {"name": "甲", "kind": "api", "provider": "p", "model": "gpt"}
        self.assertEqual(collab_api.consent_block(m), "pending")
        fp = consent.fingerprint("gpt", "sk-xxxx1234")
        consent.decide(d, fp, True)
        self.assertEqual(collab_api.consent_block(m), "")
        self.assertEqual(collab_api.consent_block({"name": "乙", "kind": "cli"}), "")  # CLI 声部没有 key
        os.environ["CHORUS_CONSENT"] = "off"
