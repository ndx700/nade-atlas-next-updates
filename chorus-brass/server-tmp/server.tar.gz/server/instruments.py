"""出图乐器：在用户自己接入的服务商里挑最擅长出图的模型，生成后存进 DATA/files、登记进产物线、发到群里。
所有产物对其他声部可见（总谱），别的 AI 可以「基于它继续改」。"""
from __future__ import annotations

import base64
import re
import secrets

from aiohttp import ClientSession, ClientTimeout

IMAGE_ID = re.compile(r"gpt-image|dall-e|imagen|seedream|flux|cogview|wanx|image", re.I)
NOT_GEN = re.compile(r"embed|rerank|asr|whisper|tts|speech|audio|moderation|video|seedance", re.I)


def pick_image_model(S):
    """返回 (provider, model_id)；没有任何出图模型时返回 None。按能力分高者优先，同分取先接入的。"""
    import profiles
    best, best_score = None, 0.0
    for pr in S.CFG.get("providers", []):
        for item in pr.get("models") or []:
            mid = item[0] if isinstance(item, list) else item
            if not isinstance(mid, str) or not IMAGE_ID.search(mid) or NOT_GEN.search(mid):
                continue
            sc = profiles.skill_score(mid, "image_gen")
            if sc > best_score:
                best, best_score = (pr, mid), sc
    return best


MAX_IMAGE = 20 * 1024 * 1024
EXT = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif"}


class Blocked(RuntimeError):
    """要等用户点头（定音卡）或预算已用完：不是故障。"""


def _sniff(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    if data[:4] == b"GIF8":
        return "gif"
    return ""


def check_allowed(S, pid, pr, mid):
    """出图花的是用户的钱：先过定音（第一次用这把 key 要手动允许），再看项目预算有没有用完。"""
    import collab_api, orchestra
    collab_api.S = collab_api.S or S
    why = collab_api.consent_block({"name": "出图乐器", "model": mid, "provider": pr.get("id"), "kind": "api"})
    if why == "denied":
        raise Blocked("你拒绝了这把 key 给出图模型用。到「同意卡」里改成允许后再画")
    if why:
        raise Blocked("出图模型第一次用这把 key，要你在「同意卡」里点一次允许，允许后再发一次 /画")
    p = S.project(pid) if hasattr(S, "project") else None
    if p and orchestra.budget_state(p).get("level") == "stop":
        raise Blocked("这个乐章的预算已经用完，出图先停下。调高预算后再画")


async def generate(S, prompt: str, pid: str = "", size: str = "1024x1024"):
    """调用 OpenAI 兼容的 /images/generations，返回 (bytes, model_id, 扩展名)。"""
    pick = pick_image_model(S)
    if not pick:
        raise RuntimeError("还没有接入能出图的模型。到「中转站」把出图模型（如 gpt-image、seedream）加进来就行")
    pr, mid = pick
    check_allowed(S, pid, pr, mid)
    body = {"model": mid, "prompt": prompt, "n": 1, "size": size}
    async with ClientSession(trust_env=True, timeout=ClientTimeout(total=180)) as s:
        async with s.post(pr["base"].rstrip("/") + "/images/generations", json=body,
                          headers={"Authorization": "Bearer " + str(pr.get("key", "")), "api-key": str(pr.get("key", ""))},
                          proxy=pr.get("proxy") or None) as r:
            if r.status >= 400:
                raise RuntimeError(f"出图失败 HTTP {r.status}：{(await r.text())[:160]}")
            j = await r.json(content_type=None)
        row = ((j or {}).get("data") or [{}])[0]
        if row.get("b64_json"):
            data = base64.b64decode(row["b64_json"])
            if len(data) > MAX_IMAGE or not _sniff(data):
                raise RuntimeError("出图服务返回的不是图片")
            return data, mid, _sniff(data)
        if row.get("url"):
            async with s.get(row["url"], proxy=pr.get("proxy") or None) as r2:
                if r2.status >= 400:
                    raise RuntimeError(f"取图失败 HTTP {r2.status}")
                if not r2.headers.get("Content-Type", "").split(";")[0].strip().lower() in EXT:
                    raise RuntimeError("出图服务返回的不是图片")
                data = bytearray()
                async for chunk in r2.content.iter_chunked(65536):
                    data += chunk
                    if len(data) > MAX_IMAGE:
                        raise RuntimeError("图片超过 20MB，已放弃")
                ext = _sniff(bytes(data))
                if not ext:
                    raise RuntimeError("出图服务返回的不是图片")
                return bytes(data), mid, ext
    raise RuntimeError("出图服务没有返回图片")


async def draw(S, pid: str, prompt: str):
    """出图 → 存文件 → 登记产物 → 发到群里。返回发到群里的消息。"""
    import collab_api
    data, mid, ext = await generate(S, prompt, pid)
    name = f"gen-{secrets.token_hex(6)}.{ext}"
    d = S.DATA / "files"
    d.mkdir(parents=True, exist_ok=True)
    (d / name).write_bytes(data)
    await collab_api.record_segment_artifacts(pid, mid, [f"/files/{name}"], prompt[:40])
    return S.add_msg(pid, mid, f"![{prompt[:40]}](/files/{name})\n出图：{mid}")
