"""Plain stdout CLI (no ACP): reads the packet until EOF, prints Codex-style JSON events, writes app.py."""
import json
import sys

sys.stdin.read()
print(json.dumps({"type": "item.started", "item": {"type": "reasoning"}}), flush=True)
open("app.py", "w").write("def add(a, b):\n    return a + b\n")
print(json.dumps({"type": "item.completed", "item": {"type": "file_change", "changes": [{"path": "app.py"}]}}), flush=True)
print(json.dumps({"type": "item.started", "item": {"type": "command_execution", "command": "pytest -q"}}), flush=True)
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "[产物]\napp.py\n[/产物]"}}), flush=True)
print(json.dumps({"type": "result", "usage": {"in": 500, "out": 100}}), flush=True)
