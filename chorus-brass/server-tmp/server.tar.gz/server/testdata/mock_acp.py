"""A minimal ACP agent (JSON-RPC 2.0 over stdio) for the e2e test: real subprocess, real files in its cwd.
It asks permission for each tool via session/request_permission and reports usage in update _meta."""
import json
import os
import sys

state = {"id": 100, "cwd": "."}


def send(o):
    sys.stdout.write(json.dumps(o, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def update(sid, u):
    send({"jsonrpc": "2.0", "method": "session/update", "params": {"sessionId": sid, "update": u}})


def ask(sid, kind, title, raw):
    state["id"] += 1
    i = state["id"]
    send({"jsonrpc": "2.0", "id": i, "method": "session/request_permission", "params": {
        "sessionId": sid, "toolCall": {"toolCallId": f"t{i}", "title": title, "kind": kind, "rawInput": raw},
        "options": [{"optionId": "a1", "name": "Allow", "kind": "allow_once"}, {"optionId": "a2", "name": "Always", "kind": "allow_always"},
                    {"optionId": "r1", "name": "Reject", "kind": "reject_once"}]}})
    while True:
        o = json.loads(sys.stdin.readline())
        if o.get("id") == i:
            out = o["result"]["outcome"]
            return out.get("outcome") == "selected" and out.get("optionId", "").startswith("a")


for line in sys.stdin:
    o = json.loads(line)
    m, i, p = o.get("method"), o.get("id"), o.get("params") or {}
    if m == "initialize":
        send({"jsonrpc": "2.0", "id": i, "result": {"protocolVersion": 1, "agentCapabilities": {}}})
    elif m == "session/new":
        state["cwd"] = p.get("cwd", ".")
        send({"jsonrpc": "2.0", "id": i, "result": {"sessionId": "s1"}})
    elif m == "session/prompt":
        if os.environ.get("MOCK_MODE") == "fail":
            sys.exit(3)
        sid = p["sessionId"]
        update(sid, {"sessionUpdate": "agent_thought_chunk", "content": {"type": "text", "text": "plan"}})
        update(sid, {"sessionUpdate": "plan", "entries": [{"content": "写 add", "status": "in_progress"}]})
        if ask(sid, "edit", "Write app.py", {"file_path": "app.py"}):
            open(os.path.join(state["cwd"], "app.py"), "w").write("def add(a, b):\n    return a + b\n")
            update(sid, {"sessionUpdate": "tool_call", "toolCallId": "w1", "title": "Write app.py", "kind": "edit", "status": "completed"})
        pushed = ask(sid, "execute", "git push --force", {"command": "git push --force origin main"})
        update(sid, {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "pushed\n" if pushed else "force push denied\n"}})
        if ask(sid, "execute", "pytest", {"command": "python -m pytest -q"}):
            update(sid, {"sessionUpdate": "tool_call", "toolCallId": "x1", "title": "python -m pytest -q", "kind": "execute", "status": "completed",
                         "rawInput": {"command": "python -m pytest -q"}})
        update(sid, {"sessionUpdate": "plan", "entries": [{"content": "写 add", "status": "completed"}]})
        update(sid, {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "[产物]\napp.py\n[/产物]"},
                     "_meta": {"usage": {"inputTokens": 900, "outputTokens": 300}, "rate_limits": {"primary": {"used_percent": 30, "resets_in_seconds": 600}, "secondary": {"usedPercent": 55}}}})
        send({"jsonrpc": "2.0", "id": i, "result": {"stopReason": "end_turn"}})
