"""Seeded handler/persistence verification where the sandbox denies sockets."""
import asyncio
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from aiohttp import web
import server as s
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from seed_demo import seed


class ImportHandlers(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        tmp = tempfile.TemporaryDirectory(prefix='round3-handlers-')
        self.addCleanup(tmp.cleanup)
        for key, value in dict(DATA=seed(Path(tmp.name) / 'demo'), CHATS={}, PARSED={},
                               CFG={}, PROJECTS=[], CHANGED=asyncio.Event(), PVER={}).items():
            self.enterContext(patch.object(s, key, value))
        s.setup()
        # Sandbox also blocks the worker-thread wakeup socket: parse inline here.
        async def inline_parse(executor, func, *args):
            return func(*args)
        self.enterContext(patch.object(asyncio.get_running_loop(), 'run_in_executor', inline_parse))
        self.enterContext(patch.object(s, 'complete', AsyncMock(side_effect=RuntimeError('offline helper'))))

    async def call(self, handler, body):
        response = await handler(SimpleNamespace(json=AsyncMock(return_value=body)))
        self.assertEqual(response.status, 200)
        return json.loads(response.body)

    async def test_memory_paste_file_zip_and_dedup(self):
        body = {'scope': 'all', 'text': '- 喜欢简短回复\n- 只使用临时数据\n- 喜欢简短回复'}
        result = await self.call(s.h_memory_import, body)
        self.assertEqual(result['added'], 2)
        self.assertEqual(len(result['items']), 2)
        self.assertEqual((await self.call(s.h_memory_import, body))['added'], 0)
        import zipfile
        with zipfile.ZipFile(s.DATA / 'files/memory.zip', 'w') as z:
            z.writestr('memories.txt', '- 新的记忆')
        self.assertEqual((await self.call(s.h_memory_import, {'scope': 'all', 'url': '/files/memory.zip'}))['added'], 1)
        self.assertEqual(len(s.memory('all')), 3)

    async def test_chat_parse_commit_and_file(self):
        body = {'name': 'demo.json', 'text': json.dumps([
            {'role': 'user', 'content': '演示导入'}, {'role': 'assistant', 'content': '收到'}])}
        result = await self.call(s.h_import, body)
        self.assertEqual(result['conversations'][0]['count'], 2)
        committed = await self.call(s.h_import_commit, {'token': result['token']})
        messages = s.load_chat(committed['projects'][0])
        self.assertEqual([m['text'] for m in messages], ['演示导入', '收到'])
        (s.DATA / 'files/export.json').write_text(body['text'])
        result = await self.call(s.h_import, {'url': '/files/export.json'})
        self.assertEqual(result['conversations'][0]['count'], 2)

    async def test_invalid_inputs(self):
        (s.DATA / 'files/broken.zip').write_bytes(b'PKbroken')
        for handler in (s.h_memory_import, s.h_import):
            for body in ({}, {'text': 123}, {'url': '/files/broken.zip'}):
                with self.assertRaises(web.HTTPBadRequest):
                    await self.call(handler, body)
