"""Batch eight boundaries; all persistence is confined to pytest temporary paths."""
import io
import json
import zipfile
from unittest.mock import patch

from aiohttp import web
import pytest
import server as s
import hooks
import importers
import workspace_tools as w
from test_import_handlers import ImportHandlers


class ImportSafety(ImportHandlers):
    async def test_helper_requires_explicit_consent_and_reports_partial_import(self):
        body = {'name': 'unknown.bin', 'text': '?' * 80001}
        s.complete.return_value = '[{"role":"user","text":"converted"}]'
        s.complete.side_effect = None
        response = await self.call(s.h_import, body)
        self.assertTrue(response['requires_consent'])
        self.assertIn('费用', response['cost'])
        self.assertTrue(response['truncated'])
        s.complete.assert_not_awaited()
        body['allow_helper'] = True
        response = await self.call(s.h_import, body)
        self.assertTrue(response['truncated'])
        self.assertIn('部分', response['warning'])
        self.assertEqual(len(s.complete.await_args.args[1]), 80000)

    async def test_expiry_prunes_uploads_and_rejects_commit(self):
        with patch.object(s.time, 'monotonic', return_value=100):
            result = await self.call(s.h_import, {'name': 'x.json', 'text': '[{"role":"user","content":"hi"}]'})
        with patch.object(s.time, 'monotonic', return_value=700):
            with self.assertRaises(web.HTTPGone):
                await self.call(s.h_import_commit, {'token': result['token']})
        self.assertEqual(s.PARSED, {})

    async def test_idle_upload_is_removed_by_timer(self):
        import asyncio
        with patch.object(asyncio.get_running_loop(), 'call_later') as timer:
            result = await self.call(s.h_import, {'text': '[{"role":"user","content":"hi"}]'})
        delay, callback, *args = timer.call_args.args
        self.assertEqual(delay, 600)
        callback(*args)
        self.assertNotIn(result['token'], s.PARSED)

    async def test_date_uses_earliest_available_message_timestamp(self):
        convs = [{'title': 'x', 'source': 'json', 'messages': [
            {'role': 'user', 'text': 'no time'}, {'role': 'assistant', 'text': 'later', 'ts': 1704153600},
            {'role': 'user', 'text': 'earlier', 'ts': 1704067200}]}]
        with patch.object(importers, 'parse', return_value=convs):
            result = await self.call(s.h_import, {'text': 'anything'})
        self.assertEqual(result['conversations'][0]['at'], '2024-01-01')

    async def test_chat_and_memory_zip_limits_are_errors(self):
        path = s.DATA / 'files/large.zip'
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('memory.txt', 'a' * 100)
        with patch.object(importers, 'MAX_IMPORT_BYTES', 50):
            for handler in (s.h_import, s.h_memory_import):
                with self.assertRaises(web.HTTPBadRequest):
                    await self.call(handler, {'url': '/files/large.zip'})


def archive(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in entries:
            z.writestr(name, data)
    return buffer.getvalue()


def test_zip_total_entries_and_nested_budget():
    with patch.object(importers, 'MAX_IMPORT_BYTES', 150):
        with pytest.raises(importers.ImportLimitError):
            importers.parse(archive([('a.txt', 'a' * 100), ('b.txt', 'b' * 100)]), 'x.zip')
    with patch.object(importers, 'MAX_ZIP_ENTRIES', 1):
        with pytest.raises(importers.ImportLimitError):
            importers.parse(archive([('a.txt', 'a'), ('b.txt', 'b')]), 'x.zip')
    nested = archive([('a.txt', 'a' * 1000)])
    with patch.object(importers, 'MAX_IMPORT_BYTES', len(nested) + 500):
        with pytest.raises(importers.ImportLimitError):
            importers.parse(archive([('nested.txt', nested)]), 'x.zip')


def test_workspace_tracks_current_data_directory(tmp_path):
    with patch.object(s, 'DATA', tmp_path), patch.object(w, 'ALLOWED_ROOT', None):
        root = tmp_path / 'work' / 'copy'
        root.mkdir(parents=True)
        assert w.Workspace({'enabled': True, 'root': str(root)}).root == root
        for rejected in (tmp_path / 'work', tmp_path / 'elsewhere', tmp_path / 'work/../escape'):
            with pytest.raises(w.ToolError):
                w.settings({'enabled': True, 'root': str(rejected)})


def test_audit_rotation_and_bounded_reload(tmp_path):
    path = tmp_path / 'audit.jsonl'
    with patch.object(hooks.AuditLogger, 'MAX_BYTES', 1000), patch.object(hooks.AuditLogger, 'MAX_RECORDS', 2):
        logger = hooks.AuditLogger(path)
        record = hooks.AuditRecord(audit_id='x', ts=1, event=hooks.HookEvent.BEFORE_TOOL,
                                  decision=hooks.Decision.ALLOW, tool='test', policy_id='', policy_name='', reason='')
        for _ in range(30):
            logger.write_sync(record)
        assert len(logger.read_all()) == 2
        assert len(hooks.AuditLogger(path).read_all()) <= 2
        assert len(list(tmp_path.glob('audit.jsonl*'))) == 4
        for file in tmp_path.iterdir():
            assert file.stat().st_size <= 1000
            for line in file.read_text().splitlines():
                assert json.loads(line)['tool'] == 'test'


def test_duplicate_zip_names_read_each_entry_once():
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        data = archive([('same.txt', 'user: first\nassistant: ok'), ('same.txt', 'user: second\nassistant: ok')])
    result = importers.parse(data, 'x.zip')
    assert [c['messages'][0]['text'] for c in result] == ['first', 'second']
