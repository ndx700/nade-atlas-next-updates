"""Standalone workspace file boundaries and native API protocol regressions."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, AsyncMock

from aiohttp import web
from aiohttp.test_utils import TestServer, TestClient
import server as s
import workspace_tools as w
from test_review_fixes import Request


class WorkspaceFiles(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.patch = patch.object(w, 'ALLOWED_ROOT', root)
        self.patch.start(); self.addCleanup(self.patch.stop)
        self.root = root / 'copy'; self.root.mkdir()
        (self.root / 'server.py').write_text('line 1\nneedle\nline 3\n')
        self.work = w.Workspace({'enabled': True, 'root': str(self.root), 'writable': True})

    def test_read_search_list_and_cas_write(self):
        got = json.loads(self.work.execute('read_file', {'path': 'server.py', 'start_line': 2, 'end_line': 2}))
        self.assertEqual(got['text'], 'needle')
        self.assertEqual(json.loads(self.work.execute('search_file', {'path': 'server.py', 'text': 'needle'}))['matches'][0]['line'], 2)
        self.assertEqual(len(self.work.files()), 1)
        self.work.write('server.py', 'updated', got['sha256'])
        self.assertEqual((self.root / 'server.py').read_text(), 'updated')
        with self.assertRaises(w.ToolError):
            self.work.write('server.py', 'lost update', got['sha256'])

    def test_creating_new_files_does_not_overwrite_existing(self):
        self.work.write('new.py', 'new', None)
        with self.assertRaises(w.ToolError):
            self.work.write('new.py', 'overwrite', None)
        self.assertEqual((self.root / 'new.py').read_text(), 'new')

    def test_traversal_absolute_and_unknown_tools(self):
        for name in ('../secret', '/etc/passwd', 'a/../../secret', 'x\\y', 'a//b', '.env', '.git/config'):
            self.assertIn('error', json.loads(self.work.execute('read_file', {'path': name})))
        self.assertIn('error', json.loads(self.work.execute('exec', {'cmd': 'id'})))

    def test_symlink_files_directories_and_hardlinks_rejected(self):
        outside = self.root.parent / 'private'; outside.write_text('secret')
        (self.root / 'link').symlink_to(outside)
        (self.root / 'dirlink').symlink_to(self.root.parent, target_is_directory=True)
        os.link(outside, self.root / 'hardlink')
        for name in ('link', 'dirlink/private', 'hardlink'):
            self.assertIn('error', json.loads(self.work.execute('read_file', {'path': name})))
            self.assertIn('error', json.loads(self.work.execute('write_file', {'path': name, 'content': 'bad', 'expected_sha256': None})))
        self.assertEqual(outside.read_text(), 'secret')

    def test_root_and_ancestor_symlinks_rejected(self):
        alias = self.root.parent / 'alias'; alias.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(OSError):
            w.Workspace({'enabled': True, 'root': str(alias)})
        with self.assertRaises(w.ToolError):
            w.settings({'enabled': True, 'root': '/opt/chorus/aichat-server'})
        with self.assertRaises(w.ToolError):
            w.settings({'enabled': True, 'root': str(self.root.parent)})

    def test_readonly_configuration_cannot_write_even_direct_call(self):
        work = w.Workspace({'enabled': True, 'root': str(self.root)})
        self.assertNotIn('write_file', [x['function']['name'] for x in work.schemas()])
        self.assertIn('error', json.loads(work.execute('write_file', {'path': 'new.py', 'content': 'bad'})))
        self.assertFalse((self.root / 'new.py').exists())

    def test_size_binary_line_range_and_total_calls_bounded(self):
        (self.root / 'large').write_bytes(b'x' * (w.MAX_FILE + 1))
        (self.root / 'binary').write_bytes(b'\x00data')
        for name in ('large', 'binary'):
            self.assertIn('error', json.loads(self.work.execute('read_file', {'path': name})))
        self.assertIn('error', json.loads(self.work.execute('read_file', {'path': 'server.py', 'start_line': 1, 'end_line': 1000})))
        self.work.calls = w.MAX_CALLS
        self.assertIn('error', json.loads(self.work.execute('list_files', {})))


    def test_generated_diff_applies_to_original_and_cannot_be_tampered_by_tools(self):
        import subprocess
        old, sha = self.work.read('server.py')
        self.work.write('server.py', 'updated without newline', sha)
        self.work.write('new.py', 'new file\n', None)
        result = json.loads(self.work.execute('review_diff', {}))
        self.assertFalse(result['tests_run'])
        self.assertEqual(len(result['changes']), 2)
        review = Path(result['patch'])
        original = self.root.parent / 'original'; original.mkdir()
        (original / 'server.py').write_text(old)
        run = subprocess.run(['patch', '-p1', '-i', str(review)], cwd=original, capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertEqual((original / 'server.py').read_text(), 'updated without newline')
        self.assertEqual((original / 'new.py').read_text(), 'new file\n')
        self.assertIn('error', json.loads(self.work.execute('write_file', {'path': '.chorus-tool-state/review.patch', 'content': 'tamper', 'expected_sha256': None})))



    def test_diff_preserves_empty_new_files_and_space_in_filename(self):
        import subprocess
        self.work.write('empty.py', '', None)
        self.work.write('file with spaces.py', 'content\n', None)
        result = self.work.review_diff()
        original = self.root.parent / 'original'; original.mkdir()
        run = subprocess.run(['git', 'apply', str(result['patch'])], cwd=original, capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertEqual((original / 'empty.py').read_text(), '')
        self.assertEqual((original / 'file with spaces.py').read_text(), 'content\n')



    def test_partial_edit_preserves_other_content_and_records_actual_diff(self):
        original, sha = self.work.read('server.py')
        result = json.loads(self.work.execute('edit_file', {'path': 'server.py', 'old_text': 'needle', 'new_text': '局部修改', 'expected_sha256': sha}))
        self.assertNotIn('error', result)
        self.assertEqual((self.root / 'server.py').read_text(), original.replace('needle', '局部修改'))
        patch_text = Path(self.work.review_diff()['patch']).read_text()
        self.assertIn('-needle', patch_text); self.assertIn('+局部修改', patch_text)

    def test_partial_edit_rejects_ambiguous_fragment_or_stale_hash(self):
        old, sha = self.work.read('server.py')
        for fragment, token in (('line', sha), ('needle', 'stale'), ('', sha)):
            with self.assertRaises(w.ToolError): self.work.edit('server.py', fragment, 'bad', token)
        self.assertEqual((self.root / 'server.py').read_text(), old)


class NativeTools(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.enterContext(patch.object(w, 'ALLOWED_ROOT', root))
        self.root = root / 'copy'; self.root.mkdir()
        (self.root / 'code.py').write_text('old')
        self.member = {'name': 'A', 'provider': 'pr', 'workspace_tools': {'enabled': True, 'root': str(self.root), 'writable': True}, 'extra_body': {'stream': True, 'tools': [], 'messages': []}}
        self.calls = []
        self.responses = []
        async def handler(req):
            body = await req.json(); self.calls.append(body)
            return web.json_response(self.responses.pop(0))
        app = web.Application(); app.router.add_post('/chat/completions', handler); app.router.add_post('/v1/messages', handler)
        self.http = TestServer(app); await self.http.start_server(); self.addAsyncCleanup(self.http.close)
        self.provider = {'id': 'pr', 'base': str(self.http.make_url('')).rstrip('/'), 'key': 'test'}
        self.enterContext(patch.object(s, 'CFG', {'providers': [self.provider]}))
        self.reply = {'who': 'A', 'text': ''}

    def openai(self, calls=None, text=None, finish='stop'):
        return {'choices': [{'message': {'role': 'assistant', 'content': text, **({'tool_calls': calls} if calls else {})}, 'finish_reason': finish}],
                'usage': {'prompt_tokens': 10, 'completion_tokens': 2}}

    def call(self, name, args, ident='call1'):
        return {'id': ident, 'type': 'function', 'function': {'name': name, 'arguments': json.dumps(args)}}

    async def run_api(self, opts=None):
        await s.call_api('p', self.member, self.reply, 'system', 'work', 'model', '', opts)

    async def test_openai_read_write_final_and_total_usage(self):
        old_hash = hashlib.sha256(b'old').hexdigest()
        self.responses = [self.openai([self.call('read_file', {'path': 'code.py'})]),
                          self.openai([self.call('write_file', {'path': 'code.py', 'content': 'new', 'expected_sha256': old_hash}, 'call2')]), self.openai(text='done')]
        await self.run_api()
        self.assertEqual((self.root / 'code.py').read_text(), 'new')
        self.assertEqual(self.reply['text'], 'done')
        self.assertEqual(self.reply['usage'], {'in': 30, 'out': 6, 'cached': 0})
        self.assertTrue(self.calls[0]['tools'])
        self.assertFalse(self.calls[0]['stream'])
        self.assertEqual(self.calls[0]['messages'][0]['role'], 'system')
        self.assertEqual(self.reply['workspace_usage'], {'rounds': 3, 'calls': 2})

    async def test_anthropic_tool_blocks_and_usage(self):
        self.provider['kind'] = 'anthropic'
        self.responses = [
            {'content': [{'type': 'tool_use', 'id': 't1', 'name': 'read_file', 'input': {'path': 'code.py'}}], 'usage': {'input_tokens': 5, 'output_tokens': 1}},
            {'content': [{'type': 'text', 'text': 'done'}], 'usage': {'input_tokens': 8, 'output_tokens': 2}}]
        await self.run_api()
        self.assertEqual(self.reply['text'], 'done')
        self.assertEqual(self.calls[1]['messages'][-1]['content'][0]['type'], 'tool_result')
        self.assertEqual(self.reply['usage']['in'], 13)

    async def test_call_budget_blocks_extra_model_round(self):
        self.responses = [self.openai([self.call('read_file', {'path': 'code.py'})])]
        with self.assertRaises(w.ToolError):
            await self.run_api({'_budget': {'used': 1, 'limit': 1, 'notified': True}, 'root_id': 'r'})
        self.assertEqual(len(self.calls), 1)

    async def test_round_limit_does_not_execute_unfinishable_write(self):
        self.member['workspace_tools']['max_rounds'] = 1
        self.responses = [self.openai([self.call('write_file', {'path': 'new.py', 'content': 'bad', 'expected_sha256': None})])]
        with self.assertRaises(w.ToolError):
            await self.run_api()
        self.assertFalse((self.root / 'new.py').exists())

    async def test_truncated_tool_response_does_not_write(self):
        self.responses = [self.openai([self.call('write_file', {'path': 'new.py', 'content': 'bad', 'expected_sha256': None})], finish='length')]
        with self.assertRaises(w.ToolError):
            await self.run_api()
        self.assertFalse((self.root / 'new.py').exists())

    async def test_duplicate_call_ids_rejected_before_any_write(self):
        self.responses = [self.openai([self.call('write_file', {'path': 'a', 'content': 'a', 'expected_sha256': None}),
                                      self.call('write_file', {'path': 'b', 'content': 'b', 'expected_sha256': None})])]
        with self.assertRaises(w.ToolError):
            await self.run_api()
        self.assertFalse((self.root / 'a').exists())

    async def test_unknown_tool_returns_error_without_command_execution(self):
        self.responses = [self.openai([self.call('exec', {'cmd': 'id'})]), self.openai(text='no exec')]
        await self.run_api()
        result = json.loads(self.calls[1]['messages'][-1]['content'])
        self.assertIn('error', result)

    async def test_disabled_member_keeps_existing_streaming_path(self):
        self.member.pop('workspace_tools')
        self.member.pop('extra_body')
        self.responses = [self.openai(text='ordinary reply')]
        with patch.object(s.api_workspace, 'run', AsyncMock()) as native:
            await self.run_api()
        native.assert_not_awaited()
        self.assertTrue(self.calls[0]['stream'])
        self.assertNotIn('tools', self.calls[0])
        self.assertEqual(self.reply['text'], 'ordinary reply')

    async def test_auxiliary_calls_do_not_receive_workspace_tools(self):
        self.member.pop('extra_body')
        self.responses = [self.openai(text='auxiliary reply')]
        with patch.object(s.api_workspace, 'run', AsyncMock()) as native:
            await s.call_api(None, self.member, self.reply, 'system', 'work', 'model', '')
        native.assert_not_awaited()
        self.assertNotIn('tools', self.calls[0])

    async def test_readonly_model_cannot_gain_write_access_through_arguments(self):
        self.member['workspace_tools']['writable'] = False
        self.responses = [self.openai([self.call('write_file', {
            'path': 'code.py', 'content': 'bad', 'expected_sha256': hashlib.sha256(b'old').hexdigest(),
            'writable': True, 'root': str(self.root.parent)})]), self.openai(text='readonly')]
        await self.run_api()
        self.assertEqual((self.root / 'code.py').read_text(), 'old')
        self.assertNotIn('write_file', [t['function']['name'] for t in self.calls[0]['tools']])
        self.assertIn('error', json.loads(self.calls[1]['messages'][-1]['content']))


class WorkspaceConfiguration(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.enterContext(patch.object(s, 'DATA', self.root))
        self.enterContext(patch.object(w, 'ALLOWED_ROOT', self.root))
        self.enterContext(patch.object(s, 'CFG', {'password': 'testpass', 'members': [{'name': 'Kimi'}]}))
        self.enterContext(patch.object(s, 'PROJECTS', []))
        self.enterContext(patch.object(s, 'bump'))
        self.enterContext(patch.object(s, 'refresh_quota', AsyncMock()))

    async def test_grant_is_persisted_and_defaults_to_readonly(self):
        await s.h_member(Request({'name': 'Kimi', 'workspace_tools': {
            'enabled': True, 'root': str(self.root / 'copy'), 'unexpected': 'ignored'}}))
        await asyncio.sleep(0)
        saved = json.loads(s.cfg_path().read_text())['members'][0]['workspace_tools']
        self.assertEqual(saved, {'enabled': True, 'root': str(self.root / 'copy'),
                                 'writable': False, 'max_rounds': 6})

    async def test_invalid_grant_rejected_before_other_member_fields_change(self):
        with self.assertRaises(web.HTTPBadRequest):
            await s.h_member(Request({'name': 'Kimi', 'role': 'changed', 'workspace_tools': {
                'enabled': True, 'root': '/opt/chorus/aichat-server', 'writable': True}}))
        self.assertEqual(s.member('Kimi'), {'name': 'Kimi'})
        self.assertFalse(s.cfg_path().exists())

    async def test_disable_removes_saved_write_grant(self):
        s.member('Kimi')['workspace_tools'] = {'enabled': True, 'root': str(self.root / 'copy'), 'writable': True}
        await s.h_member(Request({'name': 'Kimi', 'workspace_tools': {'enabled': False, 'writable': True}}))
        await asyncio.sleep(0)
        self.assertEqual(s.member('Kimi')['workspace_tools'], {'enabled': False})

    async def test_http_grant_update_requires_existing_authentication(self):
        app = web.Application(middlewares=[s.auth])
        app.router.add_put('/api/members', s.h_member)
        body = {'name': 'Kimi', 'workspace_tools': {'enabled': True, 'root': str(self.root / 'copy'), 'writable': True}}
        async with TestClient(TestServer(app)) as client:
            response = await client.put('/api/members', json=body)
            self.assertEqual(response.status, 401)
            self.assertNotIn('workspace_tools', s.member('Kimi'))
            response = await client.put('/api/members', json=body, headers={'Authorization': 'Bearer ' + s.token()})
            self.assertEqual(response.status, 200)
            self.assertTrue(s.member('Kimi')['workspace_tools']['writable'])
