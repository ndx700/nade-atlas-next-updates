#!/usr/bin/env python3
"""Chorus connector: registers this machine's AI CLI with a Chorus server, then runs the jobs it is sent (prompt on
stdin, reply on stdout). Stdlib only. Secrets live in ~/.chorus-connector/state.json (0600) and are never printed."""
import json, os, pathlib, secrets, shutil, socket, subprocess, sys, threading, time, urllib.request

SRV = os.environ.get("CHORUS_SERVER", "").rstrip("/")
STATE = pathlib.Path.home() / ".chorus-connector" / "state.json"
CLIS = {"claude": ["claude", "-p"], "codex": ["codex", "exec", "--skip-git-repo-check", "-"], "gemini": ["gemini", "-p"], "qwen": ["qwen", "-p"],
        "dsh": ["dsh", "--profile", "headless"]}


def req(method, path, headers, body=None, timeout=40):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(SRV + path, data=data, method=method, headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(r, timeout=timeout) as f:
        return json.loads(f.read() or b"{}")


def found():
    out = []
    for n in CLIS:
        p = shutil.which(n)
        if p:
            try:
                v = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=10).stdout.strip()[:40]
            except Exception:
                v = ""
            out.append({"name": n, "version": v})
    return out


def run(job, cmd):
    text = (job.get("system") + "\n\n" if job.get("system") else "") + job.get("prompt", "")
    try:
        p = subprocess.run(cmd, input=text, capture_output=True, text=True, timeout=1800)
        return {"id": job["id"], "text": p.stdout.strip(), "error": "" if p.returncode == 0 else (p.stderr.strip()[-300:] or f"exit {p.returncode}")}
    except Exception as e:
        return {"id": job["id"], "text": "", "error": str(e)[:300]}


QUOTA_EVERY = 600


def codex_limits(home=None):
    """Latest rate_limits event from this machine's own ~/.codex/sessions (newest files first). No auth files read."""
    base = pathlib.Path(home or os.environ.get("CODEX_HOME") or pathlib.Path.home() / ".codex") / "sessions"
    files = sorted(base.rglob("*.jsonl"), key=lambda f: f.stat().st_mtime, reverse=True)[:5] if base.is_dir() else []
    for f in files:
        try:
            lines = f.read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            if '"rate_limits"' not in line:
                continue
            try:
                o = json.loads(line)
            except ValueError:
                continue
            rl = o.get("rate_limits") or (o.get("payload") or {}).get("rate_limits")
            if isinstance(rl, dict) and (rl.get("primary") or rl.get("secondary")):
                return {"kind": "codex", "rate_limits": rl, "at": f.stat().st_mtime}
    return None


def _get_json(url, key):
    r = urllib.request.Request(url, headers={"Authorization": "Bearer " + key})
    with urllib.request.urlopen(r, timeout=15) as f:
        return json.loads(f.read() or b"{}")


def key_balance(cli):
    """DSH / Kimi CLI 背后是 DeepSeek / Kimi 的 API key：在本机用它查官方余额，只把数字报给服务器，key 不出本机。"""
    try:
        if cli == "dsh" and (k := os.environ.get("DEEPSEEK_API_KEY")):
            infos = _get_json("https://api.deepseek.com/user/balance", k).get("balance_infos") or []
            acc = [{"cur": "¥" if i.get("currency") == "CNY" else "$", "amount": float(i.get("total_balance"))} for i in infos if i.get("total_balance") is not None]
            return {"kind": "balance", "accounts": acc} if acc else None
        if cli == "kimi" and (k := os.environ.get("KIMI_API_KEY") or os.environ.get("MOONSHOT_API_KEY")):
            try:
                d = _get_json("https://api.kimi.com/coding/v1/usages", k)
                lim = ((d.get("limits") or [{}])[0].get("detail") or {})
                if lim.get("limit"):
                    return {"kind": "window", "pct": round(float(lim["remaining"]) / float(lim["limit"]) * 100, 1), "reset": lim.get("resetTime", "")}
            except Exception:
                pass
            d = _get_json("https://api.moonshot.cn/v1/users/me/balance", k).get("data") or {}
            if d.get("available_balance") is not None:
                return {"kind": "balance", "accounts": [{"cur": "¥", "amount": float(d["available_balance"])}]}
    except Exception:
        return None
    return None


def quota_report(cli):
    """The CLI's own usage limits: Codex from its session log, Claude/Gemini from their /usage and /stats reports,
    DSH / Kimi from their API key's official balance (queried here, only the number leaves this machine)."""
    if cli == "codex":
        return codex_limits()
    if cli in ("dsh", "kimi"):
        return key_balance(cli)
    probe = {"claude": ["claude", "-p", "/usage", "--output-format", "json"], "gemini": ["gemini", "-p", "/stats model"]}.get(cli)
    if not probe or not shutil.which(probe[0]):
        return None
    try:
        out = subprocess.run(probe, capture_output=True, text=True, timeout=90, stdin=subprocess.DEVNULL).stdout
    except Exception:
        return None
    return {"kind": cli, "text": out[-20000:]} if out.strip() else None


def quota_loop(h, cli):
    while True:
        try:
            q = quota_report(cli)
            if q:
                req("POST", "/api/connect/pub/quota", h, q, timeout=20)
        except Exception as e:
            print("额度上报失败：", type(e).__name__, flush=True)
        time.sleep(QUOTA_EVERY)


def save_state(st):
    temp = STATE.with_name(f".{STATE.name}.{secrets.token_hex(8)}.tmp")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(st, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, STATE)
    finally:
        temp.unlink(missing_ok=True)


def install_service():
    """Persist only paths and the CLI environment; invite credentials stay in state.json."""
    script = str(pathlib.Path(__file__).resolve())
    log = str(STATE.parent / "connector.log")
    if sys.platform == "darwin":
        import plistlib
        target = pathlib.Path.home() / "Library/LaunchAgents/com.chorus.connector.plist"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(plistlib.dumps({"Label": "com.chorus.connector",
            "ProgramArguments": [sys.executable, script], "RunAtLoad": True, "KeepAlive": True,
            "EnvironmentVariables": {"PATH": os.environ.get("PATH", "")},
            "StandardOutPath": log, "StandardErrorPath": log}))
        domain = f"gui/{os.getuid()}"
        subprocess.run(["launchctl", "bootout", domain, str(target)], check=False, capture_output=True)
        subprocess.run(["launchctl", "bootstrap", domain, str(target)], check=True)
    elif sys.platform.startswith("linux"):
        # systemd values use quoted C-style escapes; percent specifiers must be escaped.
        quote = lambda value: json.dumps(str(value)).replace("%", "%%")
        target = pathlib.Path.home() / ".config/systemd/user/chorus-connector.service"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("[Unit]\nDescription=Chorus connector\n[Service]\nExecStart=" +
            quote(sys.executable) + " " + quote(script) + "\nEnvironment=" +
            quote("PATH=" + os.environ.get("PATH", "")) +
            "\nRestart=always\n[Install]\nWantedBy=default.target\n")
        subprocess.run(["loginctl", "enable-linger", str(os.getuid())], check=True)
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
        subprocess.run(["systemctl", "--user", "enable", target.name], check=True)
        subprocess.run(["systemctl", "--user", "restart", target.name], check=True)
    else:
        raise RuntimeError("自动启动仅支持 systemd --user 或 launchd")


def worker(st):
    h = {"X-Chorus-Member": st["member"], "X-Chorus-Secret": st["secret"]}
    cmd = CLIS[st["cli"]]
    threading.Thread(target=quota_loop, args=(h, st["cli"]), daemon=True).start()
    while True:
        try:
            j = req("GET", "/api/connect/pub/jobs?wait=25", h, timeout=40).get("job")
            if j:
                req("POST", "/api/connect/pub/result", h, run(j, cmd))
                if st["cli"] == "codex" and (q := codex_limits()):   # a job just ran: its fresh limits
                    req("POST", "/api/connect/pub/quota", h, q, timeout=20)
        except Exception as e:
            print("连接中断，5 秒后重连：", type(e).__name__, flush=True); time.sleep(5)


def main():
    global SRV
    STATE.parent.mkdir(parents=True, exist_ok=True)
    st = json.loads(STATE.read_text()) if STATE.exists() else {}
    SRV = SRV or st.get("server", "")
    members = st.get("members") or [st]
    if os.environ.get("CHORUS_INVITE") or not all(m.get("secret") and m.get("member") and m.get("cli") in CLIS for m in members):
        clis = found()
        if not clis:
            print("没找到 claude / codex / gemini 命令行，装好其中一个再运行。"); sys.exit(1)
        r = req("POST", "/api/connect/pub/register", {"X-Chorus-Invite": os.environ.get("CHORUS_INVITE", "")},
                {"clis": clis, "host": socket.gethostname()})
        members = r.get("members") or [{**r, "cli": clis[0]["name"]}]
        st = {**members[0], "members": members, "server": SRV}
        save_state(st)
    if "--install" in sys.argv:
        install_service()
        print("已接入 Chorus，已启用自动启动。", flush=True)
        return
    print("已接入 Chorus，成员：" + "、".join(m["member"] for m in members), flush=True)
    for m in members[1:]:
        threading.Thread(target=worker, args=(m,), daemon=True).start()
    worker(members[0])


if __name__ == "__main__":
    main()
