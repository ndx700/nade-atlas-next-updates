import asyncio
import json
import unittest

import cli_quota as cq
import quota_probes as qp

CLAUDE = """You are currently using your subscription to power your Claude Code usage

Current session: 60% used · resets Aug 10 at 8:59pm (Asia/Seoul)
Current week (all models): 96% used · resets Aug 13 at 7:59am (Asia/Seoul)
Current week (Fable): 100% used · resets Aug 13 at 8am (Asia/Seoul)
"""
GEMINI = """│  Model Usage                                   Reqs                  Usage left  │
│  ──────────────────────────────────────────────────────────────────────────────  │
│  gemini-2.5-pro                                   3        75.0% (Resets in 1h 30m)  │
│  gemini-2.5-flash                                 -        50.0% (Resets in 2h)  │
"""


class TestParsers(unittest.TestCase):
    def test_claude(self):
        r = cq.parse_claude_usage("\x1b[1m" + CLAUDE)
        self.assertEqual((r["pct"], r["week"]), (40.0, 4.0))   # remaining, all-models week (not the Fable row)
        self.assertIn("Aug 10", r["reset"])

    def test_claude_garbage(self):
        self.assertEqual(cq.parse_claude_usage("Unknown skill: usage")["pct"], None)

    def test_gemini(self):
        r = cq.parse_gemini_stats(GEMINI, now=0, model="gemini-2.5-pro")
        self.assertEqual((r["pct"], r["reset"]), (75.0, "1970-01-01T01:30:00+00:00"))
        self.assertEqual(cq.parse_gemini_stats(GEMINI, now=0)["pct"], 50.0)   # unknown model -> tightest
        self.assertIsNone(cq.parse_gemini_stats("no table")["pct"])


class TestRefresh(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        cq.CACHE.clear()

    async def test_claude_json_wrapper_and_cache(self):
        calls = []

        async def run(cmd, t):
            calls.append(cmd)
            return json.dumps({"type": "result", "result": CLAUDE})
        m = {"name": "小克", "kind": "cli", "cmd": "sh claude_say.sh"}
        r = await cq.refresh(m, run)
        self.assertEqual(r["pct"], 40.0)
        await cq.refresh(m, run)
        self.assertEqual(len(calls), 1)
        self.assertIn("/usage", calls[0])
        self.assertNotIn("oauth", calls[0].lower())

    async def test_probe_uses_cli_result(self):
        async def run(cmd, t):
            return CLAUDE
        m = {"name": "小克", "kind": "cli", "cmd": "claude -p"}
        await cq.refresh(m, run)
        ctx = qp.Ctx(None)
        ctx.cmd_json = cq.cached
        res = await qp.probe({}, m, ctx)
        self.assertEqual((res["source"], res["method"], res["pct"], res["week"]), ("official", "cli", 40.0, 4.0))

    async def test_failure_is_unknown_not_crash(self):
        async def run(cmd, t):
            return ""
        m = {"name": "g", "kind": "cli", "cmd": "gemini"}
        self.assertIsNone(await cq.refresh(m, run))
        res = await qp.probe({}, m, type("C", (), {"now": lambda self: 0, "session": None, "cmd_json": staticmethod(cq.cached),
                                                   "last_headers": lambda self, n: None, "last_error": lambda self, n: None,
                                                   "spent_tokens": lambda self, n: 0, "spent_money": lambda self, a, b: 0,
                                                   "read_file": lambda self, p: None})())
        self.assertEqual((res["source"], res["kind"]), ("estimate", "count"))   # 查不到窗口也要有数：今日调用次数
        self.assertTrue(res["short"].startswith("今日"))


class FakeResp:
    def __init__(self, status, body):
        self.status, self.body = status, body

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def json(self, content_type=None):
        return self.body

    async def text(self):
        return json.dumps(self.body)


class FakeSession:
    def __init__(self, routes):
        self.routes, self.seen = routes, []

    def get(self, url, headers=None, **kw):
        self.seen.append((url, headers))
        for k, v in self.routes.items():
            if k in url:
                return FakeResp(200, v)
        return FakeResp(404, {})


class TestNewOfficial(unittest.IsolatedAsyncioTestCase):
    async def test_glm_paygo_balance(self):
        s = FakeSession({"query-customer-account-report": {"code": 200, "data": {"availableBalance": 12.5}}})
        r = await qp.ADAPTERS["glm"].official(s, {"key": "k", "base": "https://open.bigmodel.cn/api/paas/v4"})
        self.assertEqual(r["accounts"], [{"cur": "¥", "amount": 12.5}])
        self.assertEqual(s.seen[-1][1]["Authorization"], "Bearer k")

    async def test_minimax_token_plan_documented_endpoint(self):
        s = FakeSession({"/v1/token_plan/remains": {"model_remains": [{"current_interval_remaining_percent": 70, "current_weekly_remaining_percent": 40}]}})
        r = await qp.ADAPTERS["minimax"].official(s, {"key": "k", "plan": True})
        self.assertEqual((r["pct"], r["week"]), (70.0, 40.0))
        self.assertIn("api.minimaxi.com/v1/token_plan/remains", s.seen[0][0])


class TestAgyScreen(unittest.TestCase):
    def test_parse_usage_panel(self):
        import sys, pathlib
        sys.path.insert(0, str(pathlib.Path(__file__).parent / "ali"))
        import agy_usage
        screen = ("\x1b[2J\x1b[1;1HGEMINI MODELS\x1b[2;1HFive Hour Limit Remaining\x1b[3;1H│████░░│ 63.5%  Resets in 2h 10m"
                  "\x1b[4;1HWeekly Limit Remaining\x1b[5;1H██ 12%\x1b[6;1HCLAUDE MODELS\x1b[7;1HWeekly Limit Remaining\x1b[8;1H 90%")
        u = agy_usage.parse_usage(screen, now=0)
        self.assertEqual(u["left"], {"5小时": 63.5, "本周": 12.0})
        self.assertEqual(u["reset"], {"5小时": 7800})
