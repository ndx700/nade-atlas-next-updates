"""Tests for server/orchestra.py — pure logic, no network, no server import."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import orchestra as orch  # noqa: E402


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #

def member(name, model, tier=None, kind="api", skills=None, auto=True):
    m = {"name": name, "model": model, "kind": kind, "auto": auto}
    if tier:
        m["tier"] = tier
    if skills is not None:
        m["skills"] = skills
    return m


def seg(sid="s1", **kw):
    s = orch._new_segment()
    s["id"] = sid
    s.update(kw)
    return s


class FakeServer:
    """Injected module object `s` stand-in."""

    def __init__(self, prices=None):
        self.CFG = {"members": []}
        self.QUOTA = {}
        self._prices = prices or {}

    def price(self, m, model):
        return self._prices.get(m.get("name"))


# --------------------------------------------------------------------------- #
# tier_of
# --------------------------------------------------------------------------- #

class TestTier(unittest.TestCase):
    def test_explicit_tier_wins(self):
        self.assertEqual(orch.tier_of({"model": "flash-mini", "tier": "strong"}), "strong")

    def test_inferred_strong(self):
        self.assertEqual(orch.tier_of({"model": "claude-opus-4"}), "strong")
        self.assertEqual(orch.tier_of({"model": "gpt-6.1-sol"}), "strong")
        self.assertEqual(orch.tier_of({"model": "gemini-4-argon"}), "strong")
        self.assertEqual(orch.tier_of({"model": "glm-5"}), "mid")

    def test_inferred_weak(self):
        self.assertEqual(orch.tier_of({"model": "gemini-2-flash"}), "weak")
        self.assertEqual(orch.tier_of({"model": "gpt-5-mini"}), "weak")
        self.assertEqual(orch.tier_of({"model": "claude-haiku"}), "weak")

    def test_inferred_mid(self):
        self.assertEqual(orch.tier_of({"model": "some-random-model"}), "mid")
        self.assertEqual(orch.tier_of({}), "mid")


# --------------------------------------------------------------------------- #
# pick_lead
# --------------------------------------------------------------------------- #

class TestPickLead(unittest.TestCase):
    def test_auto_prefers_strong_over_cheaper_weak(self):
        members = [
            member("w", "gemini-flash"),
            member("s", "claude-opus-4"),
        ]
        got = orch.pick_lead({"lead": ""}, members, {}, {})
        self.assertEqual(got, "s")

    def test_explicit_lead_respected(self):
        members = [member("w", "gemini-flash"), member("s", "claude-opus-4")]
        got = orch.pick_lead({"lead": "w"}, members, {}, {})
        self.assertEqual(got, "w")

    def test_arrears_member_skipped_and_replaced(self):
        members = [member("s", "claude-opus-4"), member("m", "some-mid-model")]
        quota = {"s": {"state": "arrears", "pct": 50}}
        got = orch.pick_lead({"lead": "s"}, members, quota, {})
        self.assertEqual(got, "m")

    def test_low_quota_pct_unavailable(self):
        members = [member("s", "claude-opus-4"), member("m", "some-mid-model")]
        quota = {"s": {"state": "ok", "pct": 3}}
        self.assertEqual(orch.pick_lead({"lead": ""}, members, quota, {}), "m")

    def test_no_one_available_returns_empty(self):
        members = [member("s", "claude-opus-4", auto=False)]
        self.assertEqual(orch.pick_lead({"lead": ""}, members, {}, {}), "")

    def test_pass_rate_breaks_tie(self):
        members = [member("a", "model-a", tier="mid"), member("b", "model-b", tier="mid")]
        stats = {"a": {"pass": 0.5}, "b": {"pass": 0.95}}
        self.assertEqual(orch.pick_lead({"lead": ""}, members, {}, stats), "b")


# --------------------------------------------------------------------------- #
# need_tier / assign
# --------------------------------------------------------------------------- #

class TestNeedTier(unittest.TestCase):
    def test_need_tier(self):
        self.assertEqual(orch.need_tier(1), "weak")
        self.assertEqual(orch.need_tier(2), "weak")
        self.assertEqual(orch.need_tier(3), "mid")
        self.assertEqual(orch.need_tier(4), "strong")
        self.assertEqual(orch.need_tier(5), "strong")
        self.assertEqual(orch.need_tier(None), "mid")


class TestAssign(unittest.TestCase):
    def test_difficulty_1_picks_cheap_weak(self):
        members = [
            member("w", "gemini-flash"),
            member("s", "claude-opus-4"),
        ]
        got = orch.assign({"difficulty": 1, "est_tokens": 4000}, members, {}, {}, {})
        self.assertEqual(got, "w")

    def test_difficulty_5_picks_strong(self):
        members = [
            member("w", "gemini-flash"),
            member("s", "claude-opus-4"),
        ]
        got = orch.assign({"difficulty": 5, "est_tokens": 4000}, members, {}, {}, {})
        self.assertEqual(got, "s")

    def test_skills_must_overlap(self):
        members = [
            member("w", "gemini-flash", skills=["doc"]),
            member("s", "claude-opus-4", skills=["code"]),
        ]
        got = orch.assign(
            {"difficulty": 1, "est_tokens": 4000, "skills": ["code"]}, members, {}, {}, {}
        )
        self.assertEqual(got, "s")

    def test_no_capable_member_returns_empty(self):
        members = [member("w", "gemini-flash")]
        got = orch.assign({"difficulty": 5, "est_tokens": 4000}, members, {}, {}, {})
        self.assertEqual(got, "")

    def test_subscription_plan_scarcity_less_attractive(self):
        # api member: 4000 tokens -> tiny cost; plan member with low pct gets inflated.
        api = member("api", "some-mid-model", tier="mid", kind="api")
        plan = member("plan", "some-mid-model", tier="mid", kind="cli")
        quota = {"plan": {"kind": "plan", "pct": 0}}
        got = orch.assign({"difficulty": 3, "est_tokens": 4000}, [plan, api], quota, {}, {})
        self.assertEqual(got, "api")

    def test_queue_penalty_can_flip_choice(self):
        a = member("a", "model-a", tier="mid")
        b = member("b", "model-b", tier="mid")
        # equal price -> queue decides
        got = orch.assign({"difficulty": 3, "est_tokens": 4000}, [a, b], {}, {}, {"a": 10, "b": 0})
        self.assertEqual(got, "b")

    def test_fail_rate_increases_score(self):
        a = member("a", "model-a", tier="mid")
        b = member("b", "model-b", tier="mid")
        stats = {"a": {"pass": 0.1}, "b": {"pass": 0.99}}
        got = orch.assign({"difficulty": 3, "est_tokens": 4000}, [a, b], {}, stats, {})
        self.assertEqual(got, "b")


# --------------------------------------------------------------------------- #
# parse_plan
# --------------------------------------------------------------------------- #

class TestParsePlan(unittest.TestCase):
    def test_fenced_json(self):
        text = '```json\n[{"title":"A","goal":"g","deliverable":"d"}]\n```'
        out = orch.parse_plan(text)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["id"], "s1")
        self.assertEqual(out[0]["difficulty"], 3)
        self.assertEqual(out[0]["est_tokens"], 4000)

    def test_object_with_segments_key(self):
        text = '{"segments":[{"title":"A"},{"title":"B"}]}'
        out = orch.parse_plan(text)
        self.assertEqual([s["id"] for s in out], ["s1", "s2"])

    def test_missing_ids_assigned(self):
        out = orch.parse_plan('[{"title":"A"},{"id":"s9","title":"B"}]')
        self.assertEqual(out[0]["id"], "s1")
        self.assertEqual(out[1]["id"], "s9")

    def test_cycle_dropped(self):
        text = '[{"id":"s1","inputs":["s2"]},{"id":"s2","inputs":["s1"]}]'
        out = orch.parse_plan(text)
        self.assertEqual(out[0]["inputs"], [])
        self.assertEqual(out[1]["inputs"], ["s1"])

    def test_max_24(self):
        text = "[" + ",".join('{"title":"t%d"}' % i for i in range(40)) + "]"
        out = orch.parse_plan(text)
        self.assertEqual(len(out), 24)

    def test_defaults_and_normalisation(self):
        out = orch.parse_plan('[{"title":"A","difficulty":9,"est_tokens":"x","acceptance":"one"}]')
        self.assertEqual(out[0]["difficulty"], 5)
        self.assertEqual(out[0]["est_tokens"], 4000)
        self.assertEqual(out[0]["acceptance"], ["one"])
        self.assertEqual(out[0]["inputs"], [])

    def test_garbage_returns_empty(self):
        self.assertEqual(orch.parse_plan("no json here"), [])
        self.assertEqual(orch.parse_plan(""), [])


# --------------------------------------------------------------------------- #
# prompts / task card
# --------------------------------------------------------------------------- #

class TestPrompts(unittest.TestCase):
    def test_plan_prompt_mentions_questions(self):
        self.assertIn("questions", orch.PLAN_PROMPT)
        self.assertIn("acceptance", orch.PLAN_PROMPT)

    def test_clarify_limit(self):
        self.assertEqual(orch.CLARIFY_LIMIT, 3)

    def test_task_card_text(self):
        s = seg("s1", title="T", goal="G", deliverable="D", acceptance=["a1", "a2"], context="C")
        txt = orch.task_card_text(s, {"s0": "上游摘要"})
        self.assertIn("[进度]", txt)
        self.assertIn("[/进度]", txt)
        self.assertIn("[产物]", txt)
        self.assertIn("s0: 上游摘要", txt)
        self.assertIn("a1", txt)

    def test_advisor_request(self):
        s = seg("s1", title="T", goal="G", acceptance=["a"])
        req = orch.advisor_request(s, ["fail1", "fail2"])
        self.assertIn("fail1", req)
        self.assertIn("600", req)


# --------------------------------------------------------------------------- #
# ready / stage_weight / pct
# --------------------------------------------------------------------------- #

class TestProgress(unittest.TestCase):
    def test_ready(self):
        a = seg("s1", stage="done")
        b = seg("s2", inputs=["s1"], stage="waiting")
        c = seg("s3", inputs=["s2"], stage="waiting")
        got = [x["id"] for x in orch.ready([a, b, c])]
        self.assertEqual(got, ["s2"])

    def test_stage_weight(self):
        self.assertEqual(orch.stage_weight({"stage": "waiting"}), 0.0)
        self.assertEqual(orch.stage_weight({"stage": "running", "progress": 0.5}), 0.4)
        self.assertEqual(orch.stage_weight({"stage": "selfcheck"}), 0.85)
        self.assertEqual(orch.stage_weight({"stage": "review"}), 0.9)
        self.assertEqual(orch.stage_weight({"stage": "rework"}), 0.5)
        self.assertEqual(orch.stage_weight({"stage": "done"}), 1.0)
        self.assertEqual(orch.stage_weight({"stage": "blocked", "progress": 0.5}), 0.4)

    def test_segment_pct(self):
        self.assertEqual(orch.segment_pct({"stage": "done"}), 100.0)
        self.assertEqual(orch.segment_pct({"stage": "running", "progress": 0.5}), 40.0)

    def test_project_pct_weighted(self):
        p = {
            "segments": [
                seg("s1", stage="done", est_tokens=1000),
                seg("s2", stage="waiting", est_tokens=3000),
            ]
        }
        self.assertAlmostEqual(orch.project_pct(p), 25.0)

    def test_project_pct_empty(self):
        self.assertEqual(orch.project_pct({"segments": []}), 0.0)
        self.assertEqual(orch.project_pct({}), 0.0)

    def test_project_pct_uses_difficulty_when_no_tokens(self):
        p = {
            "segments": [
                seg("s1", stage="done", est_tokens=0, difficulty=1),
                seg("s2", stage="waiting", est_tokens=0, difficulty=3),
            ]
        }
        self.assertAlmostEqual(orch.project_pct(p), 25.0)

    def test_eta_seconds(self):
        import time

        now = time.time()
        p = {"segments": [seg("s1", stage="running", progress=0.0, est_tokens=1000)]}
        hist = [(now - 100, 0.0), (now, 50.0)]
        eta = orch.eta_seconds(p, hist)
        self.assertIsNotNone(eta)
        self.assertGreater(eta, 0)

    def test_eta_none_without_history(self):
        p = {"segments": [seg("s1", stage="running", progress=0.0)]}
        self.assertIsNone(orch.eta_seconds(p, []))

    def test_eta_zero_when_done(self):
        p = {"segments": [seg("s1", stage="done")]}
        self.assertEqual(orch.eta_seconds(p, []), 0)


# --------------------------------------------------------------------------- #
# ladder / review
# --------------------------------------------------------------------------- #

class TestLadder(unittest.TestCase):
    def test_ladder_order(self):
        s = seg("s1")
        self.assertEqual(orch.ladder_next(s), "retry")
        s["ladder"].append({"step": "retry"})
        self.assertEqual(orch.ladder_next(s), "advisor")
        s["ladder"].append({"step": "advisor"})
        self.assertEqual(orch.ladder_next(s), "upgrade")
        s["ladder"].append({"step": "upgrade"})
        self.assertEqual(orch.ladder_next(s), "ask")
        s["ladder"].append({"step": "ask"})
        self.assertEqual(orch.ladder_next(s), "ask")


class TestReview(unittest.TestCase):
    def test_difficulty_ge_3_always(self):
        self.assertTrue(orch.review_needed({"id": "x", "difficulty": 3, "assignee": "a"}, {"a": {"pass": 0.99}}))

    def test_low_pass_rate(self):
        self.assertTrue(orch.review_needed({"id": "x", "difficulty": 1, "assignee": "a"}, {"a": {"pass": 0.2}}))

    def test_deterministic_sampling(self):
        results = {}
        for i in range(40):
            sid = f"seg-{i}"
            results[sid] = orch.review_needed({"id": sid, "difficulty": 1, "assignee": ""}, {})
        # deterministic: same id -> same answer
        self.assertEqual(results["seg-0"], orch.review_needed({"id": "seg-0", "difficulty": 1}, {}))
        # roughly 30% sampled
        self.assertTrue(any(results.values()))
        self.assertTrue(not all(results.values()))


# --------------------------------------------------------------------------- #
# on_chunk / on_checklist
# --------------------------------------------------------------------------- #

class TestStreaming(unittest.TestCase):
    def test_on_chunk_caps_at_095(self):
        s = seg("s1", est_tokens=1000)  # est_out = 300
        orch.on_chunk(s, 100000)
        self.assertAlmostEqual(s["progress"], 0.95)

    def test_on_chunk_proportional(self):
        s = seg("s1", est_tokens=1000)
        orch.on_chunk(s, 150)
        self.assertAlmostEqual(s["progress"], 0.5)

    def test_on_chunk_ignored_when_checklist_present(self):
        s = seg("s1", est_tokens=1000)
        orch.on_checklist(s, [{"t": "a", "s": "done"}])
        before = s["progress"]
        orch.on_chunk(s, 100000)
        self.assertEqual(s["progress"], before)

    def test_on_checklist_math(self):
        s = seg("s1")
        p = orch.on_checklist(
            s,
            [
                {"t": "a", "s": "done"},
                {"t": "b", "s": "doing"},
                {"t": "c", "s": "todo"},
                {"t": "d", "s": "todo"},
            ],
        )
        self.assertAlmostEqual(p, (1 + 0.5) / 4)

    def test_on_checklist_all_done(self):
        s = seg("s1")
        p = orch.on_checklist(s, [{"t": "a", "s": "done"}, {"t": "b", "s": "done"}])
        self.assertEqual(p, 1.0)

    def test_on_checklist_empty(self):
        s = seg("s1")
        self.assertEqual(orch.on_checklist(s, []), 0.0)


# --------------------------------------------------------------------------- #
# spend / budget
# --------------------------------------------------------------------------- #

class TestBudget(unittest.TestCase):
    def test_record_spend(self):
        s = seg("s1")
        orch.record_spend(s, "exec", {"in": 100, "out": 50, "cached": 10}, 0.42)
        orch.record_spend(s, "review", {"in": 1, "out": 1}, 0.08)
        self.assertEqual(s["spend"]["in"], 101)
        self.assertEqual(s["spend"]["out"], 51)
        self.assertEqual(s["spend"]["cached"], 10)
        self.assertAlmostEqual(s["spend"]["cost"], 0.5)
        self.assertAlmostEqual(s["spend"]["by_role"]["exec"], 0.42)
        self.assertAlmostEqual(s["spend"]["by_role"]["review"], 0.08)

    def test_budget_ok(self):
        p = {"budget": {"cap": 100.0}, "segments": [seg("s1")]}
        orch.record_spend(p["segments"][0], "exec", {"in": 1}, 10.0)
        st = orch.budget_state(p)
        self.assertEqual(st["level"], "ok")
        self.assertAlmostEqual(st["spent"], 10.0)

    def test_budget_warn(self):
        p = {"budget": {"cap": 100.0}, "segments": [seg("s1")]}
        orch.record_spend(p["segments"][0], "exec", {"in": 1}, 85.0)
        self.assertEqual(orch.budget_state(p)["level"], "warn")

    def test_budget_stop(self):
        p = {"budget": {"cap": 100.0}, "segments": [seg("s1")]}
        orch.record_spend(p["segments"][0], "exec", {"in": 1}, 120.0)
        st = orch.budget_state(p)
        self.assertEqual(st["level"], "stop")
        self.assertGreaterEqual(st["pct"], 100.0)

    def test_baseline_cost_and_savings(self):
        p = {"budget": {"cap": 100.0}, "segments": [seg("s1")]}
        orch.record_spend(p["segments"][0], "exec", {"in": 1_000_000, "out": 1_000_000}, 0.5)
        base = orch.baseline_cost(p, {"in": 10.0, "out": 10.0, "cached": 0.0})
        self.assertAlmostEqual(base, 20.0)
        self.assertGreater(base - orch.budget_state(p)["spent"], 0)


# --------------------------------------------------------------------------- #
# decide_or_ask
# --------------------------------------------------------------------------- #

class TestDecide(unittest.TestCase):
    def test_ask_kinds(self):
        for k in ("ambiguous", "ladder_exhausted", "over_budget", "irreversible", "external", "plan_quota_over_50"):
            self.assertEqual(orch.decide_or_ask(k, {"countdown": 0}), "ask")

    def test_irreversible_never_auto_even_with_countdown(self):
        self.assertEqual(orch.decide_or_ask("irreversible", {"countdown": 0, "auto": True}), "ask")
        self.assertEqual(orch.decide_or_ask("external", {"countdown": 0}), "ask")

    def test_auto_otherwise(self):
        self.assertEqual(orch.decide_or_ask("routine", {}), "auto")
        self.assertEqual(orch.decide_or_ask("", {}), "auto")


# --------------------------------------------------------------------------- #
# concerto_route
# --------------------------------------------------------------------------- #

class TestRoute(unittest.TestCase):
    def setUp(self):
        self.members = [
            member("alice", "claude-opus-4"),
            member("bob", "gemini-flash"),
        ]
        self.project = {"lead_resolved": "alice", "lead": ""}

    def test_explicit_mention(self):
        r = orch.concerto_route("@bob 请看下这个", self.project, self.members)
        self.assertEqual(r["action"], "answer")
        self.assertEqual(r["who"], ["bob"])

    def test_mention_max_2(self):
        ms = self.members + [member("carl", "model-c")]
        r = orch.concerto_route("@alice @bob @carl hi", self.project, ms)
        self.assertEqual(len(r["who"]), 2)

    def test_short_question_uses_cheapest(self):
        r = orch.concerto_route("这是什么？", self.project, self.members)
        self.assertEqual(r["action"], "answer")
        self.assertEqual(r["who"], ["bob"])

    def test_short_question_english(self):
        r = orch.concerto_route("how to do this?", self.project, self.members)
        self.assertEqual(r["action"], "answer")

    def test_long_request_plans_by_lead(self):
        r = orch.concerto_route("请帮我把整个项目拆解成多个段落并给出谱稿，谢谢。" * 3, self.project, self.members)
        self.assertEqual(r["action"], "plan")
        self.assertEqual(r["who"], ["alice"])


# --------------------------------------------------------------------------- #
# conflicts
# --------------------------------------------------------------------------- #

class TestConflicts(unittest.TestCase):
    def test_same_file_conflict(self):
        a = seg("s1", stage="running", context="edit src/app.py", deliverable="patch")
        b = seg("s2", stage="running", context="touch src/app.py too", deliverable="patch")
        out = orch.parallel_conflicts([a, b])
        self.assertEqual(len(out), 1)
        self.assertIn("src/app.py", out[0][2])

    def test_near_duplicate_titles(self):
        a = seg("s1", stage="running", title="登录模块 - v1", context="x", deliverable="y")
        b = seg("s2", stage="running", title="登录模块 v1", context="z", deliverable="w")
        out = orch.parallel_conflicts([a, b])
        self.assertEqual(len(out), 1)

    def test_no_conflict_when_not_running(self):
        a = seg("s1", stage="waiting", context="src/app.py")
        b = seg("s2", stage="running", context="src/app.py")
        self.assertEqual(orch.parallel_conflicts([a, b]), [])


# --------------------------------------------------------------------------- #
# snapshot / diff
# --------------------------------------------------------------------------- #

class TestSnapshotDiff(unittest.TestCase):
    def _project(self):
        return {
            "mode": "concerto",
            "lead": "",
            "lead_resolved": "alice",
            "budget": {"cap": 100.0, "cur": "¥"},
            "segments": [seg("s1", title="A", stage="done", est_tokens=1000)],
        }

    def test_paused_state_survives_snapshot_and_delta(self):
        project = self._project()
        running = orch.snapshot(project)
        self.assertFalse(running["paused"])
        project["paused"] = True
        paused = orch.snapshot(project)
        self.assertTrue(paused["paused"])
        self.assertEqual(orch.diff(running, paused)["paused"], True)
        self.assertEqual(orch.diff(paused, running)["paused"], False)

    def test_snapshot_shape(self):
        snap = orch.snapshot(self._project(), {"alice": {"stage": "idle", "segment": "", "pct": 0}})
        self.assertEqual(snap["mode"], "concerto")
        self.assertEqual(snap["pct"], 100.0)
        self.assertEqual(len(snap["segments"]), 1)
        self.assertIn("alice", snap["members"])
        self.assertIn("budget", snap)

    def test_diff_only_changed_segments(self):
        p1 = self._project()
        snap1 = orch.snapshot(p1)
        p2 = self._project()
        p2["segments"].append(seg("s2", title="B", stage="waiting", est_tokens=1000))
        snap2 = orch.snapshot(p2)
        d = orch.diff(snap1, snap2)
        self.assertIn("segments", d)
        self.assertEqual([s["id"] for s in d["segments"]], ["s2"])
        self.assertIn("pct", d)

    def test_diff_removed_ids(self):
        snap1 = orch.snapshot(self._project())
        p2 = self._project()
        p2["segments"] = []
        snap2 = orch.snapshot(p2)
        d = orch.diff(snap1, snap2)
        self.assertIn("removed", d)
        self.assertEqual(d["removed"], ["s1"])

    def test_diff_empty_when_identical(self):
        snap = orch.snapshot(self._project())
        self.assertEqual(orch.diff(snap, snap), {})


if __name__ == "__main__":
    unittest.main()
