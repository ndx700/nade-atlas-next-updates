"""B7: reproductions of verified findings and boundaries behind rejected claims."""
import asyncio
from unittest.mock import AsyncMock, Mock, patch

import adapters as A
import checkpoints as CK
import ensemble as E
from test_faults import Base, Fake, cards


class TestB7(Base):
    async def test_half_open_failure_immediately_reopens_and_success_resets(self):
        now = [0]
        b = E.Breaker(threshold=3, cooldown=10, now=lambda: now[0])
        for _ in range(3):
            b.fail("w")
        now[0] = 11
        self.assertFalse(b.open("w"))
        self.assertTrue(b.fail("w"))
        self.assertEqual(b.until["w"], 21)
        self.assertTrue(b.open("w"))
        now[0] = 22
        b.ok("w")
        self.assertFalse(b.fail("w"))
        self.assertNotIn("w", b.until)

    async def test_reviewer_outage_waits_without_reexecuting_or_penalizing_author(self):
        members = [self.lead("down"), {"name": "w", "kind": "cli"}]
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        p = cards(1)
        e = self.ens(p, members, ckpt=db)
        await e.run()
        card = p["cards"][0]
        self.assertEqual(card["state"], "waiting")
        self.assertNotIn("pass", e.stats["w"])
        self.assertEqual(e.stats["w"]["runs"], 1)
        # A new engine restores the pending review after restart.
        members[0]["mode"] = "ok"
        p2 = cards(1)
        e2 = self.ens(p2, members, ckpt=db)
        e2.resume()
        self.assertEqual(p2["cards"][0]["retry_at"], card["retry_at"])
        self.assertEqual(p2["cards"][0]["_review_pending"], card["_review_pending"])
        with patch.object(E.time, "time", return_value=card["retry_at"] - 1):
            self.assertEqual(e2.ready(), [])
        with patch.object(E.time, "time", return_value=card["retry_at"] + 1):
            self.assertEqual(await e2.run(), 100)
        self.assertNotIn("runs", e2.stats["w"])  # execution was not repeated
        self.assertTrue((e2.ws.repo / "c0：卡0_w.txt").exists())

    async def test_review_tries_other_reviewer_before_repeating_failed_one(self):
        members = [self.lead("down"), {"name": "w"},
                   {"name": "r", "lead_role": True, "price": 30}]
        e = self.ens(cards(1), members)
        verdict = await e.review({"id": "c0", "title": "t", "assignee": "w"}, A.Result(ok=True), "")
        self.assertEqual(verdict, "PASS")
        self.assertEqual([name for name, _ in Fake.log], ["L", "r"])

    async def test_effect_restores_delivery_after_passed_save_is_lost(self):
        db = CK.Checkpoints(self.root / "ck.db")
        members = [self.lead(), {"name": "w", "kind": "cli"}]
        e = self.ens(cards(1), members, ckpt=db)
        real_save = db.save_card
        def save(pid, card):
            if card.get("state") != "passed":
                real_save(pid, card)
        with patch.object(db, "save_card", side_effect=save):
            self.assertEqual(await e.run(), 100)
        effect = db.effect("p:merge:c0")
        self.assertEqual(effect["artifacts"], ["c0：卡0_w.txt"])
        db.close()
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        # Also tolerate a missing cards row; effects contain the delivery.
        db.db.execute("DELETE FROM cards")
        p = cards(2)
        p["cards"][1]["inputs"] = ["c0"]
        e2 = self.ens(p, members, ckpt=db)
        e2.resume()
        c0 = e2.done["c0"]
        self.assertEqual(c0["summary"], "done")
        self.assertEqual(c0["artifacts"], ["c0：卡0_w.txt"])
        pk = E.packet(p["cards"][1], p, e2.done, [], lambda f: None, [], [])
        self.assertIn("c0：卡0_w.txt", pk)
        with patch.object(e2.ws, "merge", wraps=e2.ws.merge) as merge:
            self.assertEqual(await e2.run(), 100)
        self.assertEqual([c.args[0] for c in merge.await_args_list], ["c1"])

    async def test_error_history_is_bounded(self):
        e = self.ens(cards(1), [self.lead()])
        for i in range(1100):
            e.errors.append(str(i))
        self.assertEqual(len(e.errors), 1000)
        self.assertEqual(e.errors[0], "100")

    async def test_best_of_removes_all_trees_and_branches(self):
        p = cards(1)
        p["cards"][0]["best_of"] = 2
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        e = self.ens(p, [self.lead(), {"name": "a"}, {"name": "b"}], ckpt=db)
        self.assertEqual(await e.run(), 100)
        self.assertEqual(list(e.ws.trees.glob("*-bo*")), [])
        _, branches = await E.git(e.ws.repo, "branch", "--list", "card/*-bo*")
        self.assertFalse(branches.strip())
        self.assertTrue(db.effect("p:merge:c0")["artifacts"])

    async def test_best_of_cancellation_removes_trees(self):
        p = cards(1)
        p["cards"][0]["best_of"] = 2
        e = self.ens(p, [self.lead(), {"name": "a"}, {"name": "b"}])
        await e.ws.init()
        started = asyncio.Event()
        count = 0
        async def candidate(c):
            nonlocal count
            await e.ws.tree_for(c["id"])
            count += 1
            if count == 2:
                started.set()
            await asyncio.wait_for(asyncio.Event().wait(), 5)
        e._one_candidate = candidate
        t = asyncio.create_task(e.best_of(p["cards"][0]))
        self.addAsyncCleanup(self._drain, t)
        await asyncio.wait_for(started.wait(), 5)
        t.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(t, 5)
        self.assertEqual(list(e.ws.trees.glob("*-bo*")), [])
        _, branches = await E.git(e.ws.repo, "branch", "--list", "card/*-bo*")
        self.assertFalse(branches.strip())

    async def test_write_files_rejects_traversal_sibling_and_symlink(self):
        tree = self.root / "tree"
        tree.mkdir()
        outside = self.root / "tree_sibling"
        outside.mkdir()
        (tree / "link").symlink_to(outside, target_is_directory=True)
        paths = ["README.md", "new/deep/file.txt", "../tree_sibling/a", str(outside / "b"), "link/c", "a/../../tree_sibling/d"]
        text = "\n".join(f"=== FILE: {p} ===\nbody\n=== END ===" for p in paths)
        gate = AsyncMock(return_value=True)
        out = await E.write_files(tree, text, gate, lambda step: None, "w")
        self.assertEqual(out, paths[:2])
        self.assertEqual(list(outside.iterdir()), [])
        self.assertEqual(gate.await_count, 2)
        self.assertEqual((tree / "new/deep/file.txt").read_text(), "body\n")

    async def test_watchdog_waits_for_cancel_cleanup_before_retry(self):
        p = cards(1)
        e = self.ens(p, [self.lead(), {"name": "w"}], card_timeout=None)
        entered, cleaning, release = asyncio.Event(), asyncio.Event(), asyncio.Event()
        runs = 0
        async def worker(card):
            nonlocal runs
            runs += 1
            if runs == 1:
                card["assignee"] = "w"
                entered.set()
                try:
                    await asyncio.wait_for(asyncio.Event().wait(), 5)
                finally:
                    cleaning.set()
                    await asyncio.wait_for(release.wait(), 5)
            else:
                self.assertTrue(release.is_set())
                e.set_state(card, "passed")
        e.supervised = worker
        task = asyncio.create_task(e.run())
        self.addAsyncCleanup(self._drain, task)
        await asyncio.wait_for(entered.wait(), 5)
        with patch.object(e.hb, "stalled", return_value=["c0"]):
            e._watch()
        await asyncio.wait_for(cleaning.wait(), 5)
        await asyncio.sleep(0)
        self.assertEqual(runs, 1)
        self.assertEqual(p["cards"][0]["state"], "doing")
        release.set()
        self.assertEqual(await asyncio.wait_for(task, 3), 100)
        self.assertEqual(runs, 2)

    async def _drain(self, task):
        task.cancel()
        await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 5)

    async def test_half_open_allows_only_one_probe(self):
        e = self.ens(cards(1), [self.lead()])
        now = [0]
        e.breaker = E.Breaker(threshold=1, cooldown=10, now=lambda: now[0])
        e.breaker.fail("L")
        now[0] = 11
        entered, release = asyncio.Event(), asyncio.Event()
        class Probe(Fake):
            async def run(self, *args, **kwargs):
                entered.set()
                await asyncio.wait_for(release.wait(), 5)
                return A.Result(ok=False, error="503")
        ad = Probe(self.lead())
        task = asyncio.create_task(e.call(ad, "", lambda st: None, self._ok))
        self.addAsyncCleanup(self._drain, task)
        await asyncio.wait_for(entered.wait(), 5)
        second = await e.call(ad, "", lambda st: None, self._ok)
        self.assertEqual(second.error, E.BREAKER_BUSY)
        self.assertTrue(e.breaker.open("L"))
        release.set()
        first = await asyncio.wait_for(task, 5)
        self.assertEqual(first.error, "503")
        self.assertTrue(e.breaker.fail("L"))
        self.assertEqual(e.breaker.until["L"], 21)

    async def test_git_cancellation_kills_and_reaps_child(self):
        process = Mock(returncode=None)
        process.communicate = AsyncMock(side_effect=[asyncio.CancelledError(), (b"", b"")])
        with patch.object(E.asyncio, "create_subprocess_exec", AsyncMock(return_value=process)):
            with self.assertRaises(asyncio.CancelledError):
                await E.git(self.root, "status")
        process.kill.assert_called_once()
        self.assertEqual(process.communicate.await_count, 2)

    async def test_best_of_failed_candidates_are_cleaned_before_fallback_and_retry(self):
        p = cards(1)
        e = self.ens(p, [self.lead(), {"name": "a"}, {"name": "b"}])
        await e.ws.init()
        fallbacks = 0
        async def run(card):
            nonlocal fallbacks
            if card.get("_candidate"):
                await e.ws.tree_for(card["id"])
                return  # no candidate passed
            self.assertEqual(list(e.ws.trees.glob("*-bo*")), [])
            _, branches = await E.git(e.ws.repo, "branch", "--list", "card/*-bo*")
            self.assertFalse(branches.strip())
            fallbacks += 1
        e.run_card = run
        for _ in range(2):
            p["cards"][0]["best_of"] = 2
            await e.best_of(p["cards"][0])
        self.assertEqual(fallbacks, 2)

    async def test_git_cancellation_during_spawn_waits_then_reaps_child(self):
        entered, release = asyncio.Event(), asyncio.Event()
        process = Mock(returncode=None)
        process.communicate = AsyncMock(return_value=(b"", b""))
        async def spawn(*args, **kw):
            entered.set()
            await asyncio.wait_for(release.wait(), 5)
            return process
        with patch.object(E.asyncio, "create_subprocess_exec", spawn):
            task = asyncio.create_task(E.git(self.root, "status"))
            self.addAsyncCleanup(self._drain, task)
            await asyncio.wait_for(entered.wait(), 5)
            task.cancel()
            await asyncio.sleep(0)
            self.assertFalse(task.done())
            release.set()
            with self.assertRaises(asyncio.CancelledError):
                await asyncio.wait_for(task, 5)
        process.kill.assert_called_once()
        process.communicate.assert_awaited_once()
