import asyncio

import plugins as P
import server as s
from test_chorus2 import Base

SMALL = {"cores": 2, "ram_mb": 1024, "ram_free_mb": 600, "gpu_gb": 0}
BIG = {"cores": 16, "ram_mb": 32768, "ram_free_mb": 30000, "gpu_gb": 24}


class TestFit(Base):
    def test_small_server_offers_only_device_online_cloud(self):
        pl = P.Plugins(s, hostinfo=lambda: SMALL)
        ok = {r["id"] for r in pl.view()["plugins"] if r["fits"]}
        self.assertTrue({"tts_android", "tts_edge", "tts_minimax", "tts_openai", "asr_android", "asr_cloud"} <= ok)
        self.assertFalse({"tts_kokoro", "tts_cosyvoice", "asr_sensevoice"} & ok)
        edge = next(r for r in pl.view()["plugins"] if r["id"] == "tts_edge")
        self.assertFalse(edge["official"])        # flagged unofficial / may break

    def test_big_server_offers_local_models(self):
        pl = P.Plugins(s, hostinfo=lambda: BIG)
        ok = {r["id"] for r in pl.view()["plugins"] if r["fits"]}
        self.assertTrue({"tts_kokoro", "tts_cosyvoice", "asr_sensevoice", "tts_melo"} <= ok)

    def test_no_gpu_no_cosyvoice(self):
        pl = P.Plugins(s, hostinfo=lambda: {**BIG, "gpu_gb": 0})
        r = next(r for r in pl.view()["plugins"] if r["id"] == "tts_cosyvoice")
        self.assertFalse(r["fits"])
        self.assertIn("GPU", r["why"])


class TestInstall(Base):
    async def test_install_uninstall_and_voice_feature_gate(self):
        steps = []

        async def runner(step, dest):
            steps.append(step[0])
        pl = P.Plugins(s, runner=runner, hostinfo=lambda: BIG)
        self.assertFalse(pl.features()["voice"])
        pl.install("tts_edge")
        await pl.jobs["tts_edge"]
        self.assertFalse(pl.features()["voice"])        # TTS alone: still hidden
        pl.install("asr_android")
        await pl.jobs["asr_android"]
        self.assertTrue(pl.features()["voice"])
        self.assertEqual(steps, ["pip"])
        await pl.uninstall("tts_edge")
        self.assertFalse(pl.features()["voice"])

    async def test_failed_install_reported(self):
        async def runner(step, dest):
            raise RuntimeError("network down")
        pl = P.Plugins(s, runner=runner, hostinfo=lambda: BIG)
        pl.install("tts_kokoro")
        await pl.jobs["tts_kokoro"]
        self.assertEqual(s.CFG["plugins"]["tts_kokoro"]["state"], "failed")
        self.assertIn("连不上", s.CFG["plugins"]["tts_kokoro"]["error"])
        self.assertEqual(s.CFG["plugins"]["tts_kokoro"]["fix"], "retry")

    async def test_refuses_what_does_not_fit_and_unknown(self):
        pl = P.Plugins(s, hostinfo=lambda: SMALL)
        with self.assertRaises(ValueError):
            pl.install("tts_kokoro")
        with self.assertRaises(KeyError):
            pl.install("nope")
