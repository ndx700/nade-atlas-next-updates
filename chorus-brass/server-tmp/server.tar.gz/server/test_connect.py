"""一键接入 end to end: invite → `curl | sh` (real installer + real connector process + fake claude CLI) → register →
test message → 已接入; then a real remote call. Plus key-paste detection, probing, errors in plain Chinese."""
import asyncio
import json
import os
import pathlib
import subprocess
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, Mock, patch

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

import chorus2 as c
import connect
import server as s
from connector import connector as agent


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        keys = ("DATA", "CFG", "PROJECTS", "save_cfg", "save", "call_cli", "fetch_models", "bump")
        saved = {k: getattr(s, k) for k in keys}
        self.addCleanup(lambda: [setattr(s, k, v) for k, v in saved.items()])
        s.DATA = pathlib.Path(self.tmp.name)
        self.enterContext(patch.object(connect, "REMOTE", {}))
        self.enterContext(patch.object(connect, "INV", {}))
        s.CFG = {"password": "pw", "members": [], "providers": []}
        s.PROJECTS = [{"id": "p", "name": "P", "members": []}]
        s.save_cfg = lambda: None
        s.bump = lambda *a: None
        connect.INV.clear(); connect.REMOTE.clear(); connect.METRICS["connected"].clear()
        for attr in ("MEMBER_STATE", "STATE_AT", "STATE_REASON", "QUOTA2"):
            self.enterContext(patch.object(c, attr, {}))
        self.enterContext(patch.object(c, "S", s))
        app = web.Application(middlewares=[s.auth])
        connect.register(app, s, c)
        app.router.add_get("/api/quota/all", c.h_quota_all)
        app.router.add_get("/api/members/{name}/metrics", c.h_metrics)
        self.client = TestClient(TestServer(app, host="127.0.0.1"))
        await self.client.start_server()
        self.addAsyncCleanup(self.client.close)
        self.h = {"Authorization": "Bearer " + s.token()}


class TestCliInvite(Base):
    async def test_background_test_retained_and_missing_invite_tolerated(self):
        started, finish = asyncio.Event(), asyncio.Event()

        async def reply(*args, **kwargs):
            started.set()
            await finish.wait()
            return {"text": "已接入"}

        inv = connect.new_invite(str(self.client.make_url("")))
        with patch.object(connect, "remote_call", reply):
            response = await self.client.post("/api/connect/pub/register", headers={"X-Chorus-Invite": inv["token"]},
                                              json={"clis": [{"name": "claude"}]})
            self.assertEqual(response.status, 200)
            await started.wait()
            self.assertEqual(len(connect.TEST_TASKS), 1)
            task = next(iter(connect.TEST_TASKS))
            connect.INV.pop(inv["token"])
            finish.set()
            await task
            await asyncio.sleep(0)
        self.assertFalse(connect.TEST_TASKS)
        with patch.object(connect, "remote_call", AsyncMock(side_effect=RuntimeError("掉线了"))):
            await connect._test("missing", "missing")

    async def test_status_seconds_freeze_for_both_terminal_states(self):
        for state in ("connected", "error"):
            inv = connect.new_invite(str(self.client.make_url("")))
            record = connect.INV[inv["token"]]
            record.update(created=100, state=state)
            record["at"][state] = 112.5
            for now in (130, 400):
                with patch.object(connect.time, "time", return_value=now):
                    r = await (await self.client.get(inv["status"], headers=self.h)).json()
                self.assertEqual(r["seconds"], 12.5)
        record["state"] = "registered"
        with patch.object(connect.time, "time", return_value=140):
            r = await (await self.client.get(inv["status"], headers=self.h)).json()
        self.assertEqual(r["seconds"], 40)

    async def test_forwarded_prefix_is_safe_in_commands_and_installer(self):
        for prefix in ("/chorus/api-v1._", "'; echo injected; #", "/x$(id)", "/x`id`"):
            headers = {**self.h, "X-Forwarded-Prefix": prefix}
            inv = await (await self.client.post("/api/connect/invite", headers=headers)).json()
            response = await self.client.get("/api/connect/pub/install", headers={"X-Chorus-Invite": inv["token"], "X-Forwarded-Prefix": prefix})
            script = await response.text()
            expected = prefix if prefix == "/chorus/api-v1._" else ""
            srv = str(self.client.make_url("")).rstrip("/") + expected
            self.assertTrue(script.startswith(f"SRV='{srv}'\n"))
            self.assertIn(srv + "/api/connect/pub/install", inv["oneliner"])

    async def test_metrics_bounded_percentiles_and_auth(self):
        response = await self.client.get("/api/connect/metrics")
        self.assertEqual(response.status, 401)
        response = await (await self.client.get("/api/connect/metrics", headers=self.h)).json()
        self.assertEqual(response, {"connected": {"count": 0, "p50": None, "p95": None}})
        connect.METRICS["connected"].extend(range(1, 1002))
        self.assertEqual(len(connect.METRICS["connected"]), 1000)
        response = await (await self.client.get("/api/connect/metrics", headers=self.h)).json()
        self.assertEqual(response, {"connected": {"count": 1000, "p50": 501, "p95": 951}})

    async def test_curl_sh_to_connected(self):
        home = pathlib.Path(self.tmp.name)
        bin_ = home / "bin"; bin_.mkdir()
        (bin_ / "claude").write_text("#!/bin/sh\n[ \"$1\" = --version ] && { echo 2.1.0; exit 0; }\ncat >/dev/null; echo 已接入\n")
        (bin_ / "claude").chmod(0o755)
        (bin_ / "systemctl").write_text("#!/bin/sh\n[ \"$2\" = restart ] && { env -u CHORUS_INVITE python3 \"$HOME/.chorus-connector/connector.py\" > \"$HOME/.chorus-connector/connector.log\" 2>&1 & }\nexit 0\n")
        (bin_ / "systemctl").chmod(0o755)
        (bin_ / "loginctl").write_text("#!/bin/sh\nexit 0\n")
        (bin_ / "loginctl").chmod(0o755)
        t0 = time.monotonic()
        inv = await (await self.client.post("/api/connect/invite", headers=self.h)).json()
        connect.INV[inv["token"]]["project"] = "p"
        self.assertIn("curl -fsSL -H 'X-Chorus-Invite:", inv["oneliner"])
        self.assertIn(inv["oneliner"], inv["prompt"])
        self.assertNotIn(inv["token"], inv["status"])  # status uses a separate public id, never the invite credential
        env = {**os.environ, "HOME": str(home), "PATH": f"{bin_}:{os.environ['PATH']}"}
        p = await asyncio.create_subprocess_exec("sh", "-c", inv["oneliner"], env=env,
                                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.assertEqual(await asyncio.wait_for(p.wait(), 30), 0)
        self.addCleanup(lambda: (subprocess.run(["pkill", "-f", str(home / ".chorus-connector")]), time.sleep(0.3)))
        st = {}
        for _ in range(100):
            st = await (await self.client.get(inv["status"], headers=self.h)).json()
            if st["state"] in ("connected", "error"):
                break
            await asyncio.sleep(0.1)
        self.assertEqual(st["state"], "connected", st)
        self.assertEqual(st["label"], "已接入")
        self.assertEqual(st["test"], "已接入")
        m = s.member(st["member"])
        self.assertTrue(m["remote"]); self.assertEqual(m["quota"], {"type": "cli", "exe": "claude"})
        self.assertIn(st["member"], s.PROJECTS[0]["members"])
        state = json.loads((home / ".chorus-connector" / "state.json").read_text())
        self.assertEqual(oct((home / ".chorus-connector" / "state.json").stat().st_mode & 0o777), "0o600")
        self.assertNotIn(state["secret"], json.dumps(s.CFG))   # server keeps only a hash
        ttc = time.monotonic() - t0
        print(f"\n[metric] time-to-connected {ttc:.2f}s (server-side {connect.METRICS['connected'][-1]}s)")
        self.assertLess(ttc, 10)
        reply = {}
        await s.call_cli("p", m, reply, "", "你好", "", "")
        self.assertEqual(reply["text"], "已接入")
        # single use: the same invite cannot register again
        r = await self.client.get("/api/connect/pub/install", headers={"X-Chorus-Invite": inv["token"]})
        self.assertEqual(r.status, 403)

    async def test_bad_secret_and_expired(self):
        r = await self.client.get("/api/connect/pub/jobs", headers={"X-Chorus-Member": "x", "X-Chorus-Secret": "y"})
        self.assertEqual(r.status, 403)
        inv = await (await self.client.post("/api/connect/invite", headers=self.h)).json()
        connect.INV[inv["token"]]["expires"] = 0
        r = await self.client.get("/api/connect/pub/install", headers={"X-Chorus-Invite": inv["token"]})
        self.assertEqual(r.status, 403)
        self.assertIn("重新点", await r.text())

    async def test_no_cli_found_is_explained(self):
        inv = await (await self.client.post("/api/connect/invite", headers=self.h)).json()
        r = await self.client.post("/api/connect/pub/register", headers={"X-Chorus-Invite": inv["token"]}, json={"clis": []})
        self.assertEqual(r.status, 400)
        st = await (await self.client.get(inv["status"], headers=self.h)).json()
        self.assertEqual(st["state"], "error"); self.assertIn("没找到", st["error"])


class TestPaste(Base):
    def test_relay_overrides_every_non_anthropic_vendor(self):
        base = "http://localhost:8080/v1"
        keys = ["sk-" + "a" * 40, "sk-proj-" + "a" * 40, "sk-or-v1-" + "a" * 48,
                "tp-" + "a" * 30, "gsk_" + "a" * 30, "xai-" + "a" * 30, "AIza" + "a" * 35]
        for key in keys:
            with self.subTest(vendor=key.split("-")[0]):
                found = connect.detect(f"{base} {key}")
                self.assertEqual([(v[0], b) for _, v, b in found], [("relay", base)])
        found = connect.detect(base + " sk-ant-" + "a" * 40)
        self.assertEqual([(v[0], b) for _, v, b in found], [("anthropic", None)])

    async def test_metadata_addresses_rejected_before_probe(self):
        blocked = ["169.254.169.254", "169.254.0.1", "169.254.255.255", "100.100.100.200",
                   "[fd00:ec2::254]", "[fdff::1]", "[fe80::1]", "[::ffff:169.254.169.254]",
                   "2852039166", "0xa9fea9fe", "metadata.google.internal"]
        fetch = AsyncMock()
        with patch.object(s, "fetch_models", fetch):
            for host in blocked:
                r = await connect.paste(f"http://{host}/v1 sk-" + "a" * 40)
                self.assertEqual((r["ok"], r["fix"]), (False, "edit_base"))
                self.assertIn("地址", r["message"])
        fetch.assert_not_awaited()
        self.assertEqual(s.CFG["providers"], [])

    async def test_localhost_and_private_relays_still_work(self):
        with patch.object(s, "fetch_models", AsyncMock()), patch.object(c, "ask_model", AsyncMock(return_value="已接入")):
            for host in ("localhost:11434", "127.0.0.1", "192.168.1.1", "10.1.2.3", "172.16.0.1", "[::1]", "[fc00::1]"):
                r = await connect.paste(f"http://{host}/v1 sk-" + "a" * 40)
                self.assertTrue(r["ok"])
                self.assertEqual(s.CFG["providers"][-1]["base"], f"http://{host}/v1")

    async def test_failed_chat_still_persists_and_bumps_without_exposing_key(self):
        key = "sk-proj-" + "z" * 40
        save, bump = Mock(), Mock()
        with patch.object(s, "fetch_models", AsyncMock()), patch.object(s, "save_cfg", save), patch.object(s, "bump", bump), \
                patch.object(c, "ask_model", AsyncMock(side_effect=RuntimeError("HTTP 401 " + key))):
            r = await connect.paste(key, name=key)
        self.assertTrue(r["ok"])
        self.assertEqual(r["fix"], "repaste")
        self.assertEqual(len(s.CFG["members"]), 1)
        save.assert_called_once()
        self.assertGreaterEqual(bump.call_count, 2)   # 接入后台探额度完成时还会再推一次
        self.assertNotIn(key, json.dumps(r))
        self.assertNotIn(key[:24], r["member"])

    async def test_probe_exception_and_chat_echo_redact_before_truncation(self):
        key = "sk-proj-" + "z" * 40
        v = connect._vendor("openai")
        with patch.object(s, "fetch_models", AsyncMock(side_effect=RuntimeError("invalid key " + key))):
            _, _, error = await connect._probe(key, v, None)
            self.assertNotIn(key, error)
        with patch.object(s, "fetch_models", AsyncMock()), patch.object(c, "ask_model", AsyncMock(return_value=key)):
            r = await connect.paste(key)
        self.assertEqual(r["test"], "[已隐藏]")

    def test_detect(self):
        d = lambda t: [(v[0], b) for _, v, b in connect.detect(t)]
        self.assertEqual(d("sk-ant-api03-" + "a" * 40)[0][0], "anthropic")
        self.assertEqual(d("我的key是 AIza" + "b" * 35 + " 谢谢")[0][0], "gemini")
        self.assertEqual(d("tp-" + "c" * 30)[0][0], "mimo")
        self.assertEqual(d("xai-" + "d" * 40)[0][0], "xai")
        self.assertEqual(d("sk-proj-" + "e" * 40)[0][0], "openai")
        amb = [v for v, _ in d("sk-" + "f" * 48)]
        self.assertEqual(amb[:2], ["deepseek", "moonshot"]); self.assertIn("siliconflow", amb)
        relay = d("地址 https://relay.example.com/v1 key sk-" + "g" * 48)
        self.assertEqual(relay, [("relay", "https://relay.example.com/v1")])
        self.assertEqual(d("随便一段话"), [])

    async def test_paste_probes_all_picks_working_and_tests(self):
        tried = []

        async def fm(pr):
            tried.append(pr["id"])
            if pr["id"] != "moonshot":
                raise RuntimeError("HTTP 401 invalid api key")
            pr["models"] = [["moonshot-v1-embed", ""], ["kimi-k2-turbo-preview", ""]]
        s.fetch_models = fm

        async def ask(m, sys_, p, pid=None):
            return "已接入"
        orig = c.ask_model; c.ask_model = ask; self.addCleanup(setattr, c, "ask_model", orig)
        r = await (await self.client.post("/api/connect/paste", headers=self.h, json={"text": "sk-" + "f" * 48})).json()
        self.assertTrue(r["ok"], r)
        self.assertEqual((r["member"], r["model"], r["test"]), ("Moonshot", "kimi-k2-turbo-preview", "已接入"))
        self.assertGreaterEqual(len(tried), 3)
        self.assertNotIn("f" * 48, json.dumps(r))   # key never echoed back
        print(f"\n[metric] api paste-to-connected {r['ms']}ms (mocked network)")

    async def test_paste_errors_plain_chinese(self):
        async def fm(pr):
            raise RuntimeError("HTTP 402 insufficient balance")
        s.fetch_models = fm
        r = await (await self.client.post("/api/connect/paste", headers=self.h, json={"text": "sk-ant-api03-" + "a" * 40})).json()
        self.assertFalse(r["ok"]); self.assertEqual(r["fix"], "topup"); self.assertIn("没余额", r["message"])
        r = await (await self.client.post("/api/connect/paste", headers=self.h, json={"text": "hello"})).json()
        self.assertEqual(r["fix"], "repaste")


    async def test_paste_does_not_wait_for_hanging_vendor(self):
        """国内服务器连 OpenAI 会卡住：DeepSeek 一通就要立即返回，不能拖到 App 读超时。"""
        async def fm(pr):
            if pr["id"] == "deepseek":
                pr["models"] = [["deepseek-chat", ""]]
                return
            await asyncio.sleep(60)   # 卡住的海外接口
        s.fetch_models = fm

        async def ask(m, sys_, p, pid=None):
            return "已接入"
        orig = c.ask_model; c.ask_model = ask; self.addCleanup(setattr, c, "ask_model", orig)
        t0 = time.monotonic()
        r = await (await self.client.post("/api/connect/paste", headers=self.h, json={"text": "sk-" + "0123456789abcdef" * 2})).json()
        self.assertTrue(r["ok"], r)
        self.assertEqual(r["model"], "deepseek-chat")
        self.assertLess(time.monotonic() - t0, 2)

    async def test_paste_slow_test_reply_returns_in_budget(self):
        async def fm(pr):
            if pr["id"] != "deepseek":
                raise RuntimeError("HTTP 401 invalid api key")
            pr["models"] = [["deepseek-chat", ""]]
        s.fetch_models = fm

        async def ask(m, sys_, p, pid=None):
            await asyncio.sleep(5)
            return "已接入"
        orig = c.ask_model; c.ask_model = ask; self.addCleanup(setattr, c, "ask_model", orig)
        with patch.object(connect, "PASTE_BUDGET", 0.5):
            t0 = time.monotonic()
            r = await connect.paste("sk-" + "0123456789abcdef" * 2)
        self.assertTrue(r["ok"], r)
        self.assertTrue(r.get("testing"))
        self.assertLess(time.monotonic() - t0, 2)
        self.assertTrue(s.member(r["member"]))

    async def test_paste_all_fail_reports_key_error_not_network(self):
        async def fm(pr):
            if pr["id"] == "openai":
                raise asyncio.TimeoutError()
            raise RuntimeError("HTTP 401 invalid api key")
        s.fetch_models = fm
        r = await connect.paste("sk-" + "0123456789abcdef" * 2)
        self.assertFalse(r["ok"])
        self.assertEqual(r["fix"], "repaste")

    async def test_deleted_member_leaves_home_quota(self):
        s.CFG["members"].append({"name": "临时", "kind": "api", "provider": "x", "auto": True, "model": "m"})
        s.QUOTA["临时"] = {"short": "¥1"}
        c.QUOTA2["临时"] = {"short": "¥1"}
        req = Mock(method="DELETE", match_info={"name": "临时"})
        with patch.object(s, "save", Mock()), patch.object(s.member_avatars, "clean_unused", Mock()), patch.object(c, "retry_unavailable", Mock()):
            await s.h_member(req)
        self.assertNotIn("临时", s.QUOTA)
        self.assertNotIn("临时", c.QUOTA2)
        self.assertNotIn("临时", s.index_view()["quota"])
        self.assertEqual(connect.quota_view({"临时": {}, "在": {}}, ["在"]), {"在": {}})


class TestRemote(Base):
    def member(self, seen=None):
        name = "远程"
        s.CFG["members"].append({"name": name, "kind": "cli", "remote": True})
        connect.REMOTE[name] = {"hash": connect._h("test-secret"), "queue": asyncio.Queue(), "wait": {},
                                "seen": time.time() if seen is None else seen, "clis": []}
        return name, connect.REMOTE[name], {"X-Chorus-Member": name, "X-Chorus-Secret": "test-secret"}

    async def test_jobs_wait_clamped(self):
        _, _, headers = self.member()
        for raw, expected in (("-10", 0), ("100", 30), ("2.5", 2.5), ("inf", 30), ("-inf", 0), ("bad", 25), ("nan", 30)):
            waits = []

            async def timeout(coro, seconds):
                waits.append(seconds)
                coro.close()
                raise asyncio.TimeoutError

            with patch.object(connect.asyncio, "wait_for", timeout):
                r = await (await self.client.get("/api/connect/pub/jobs", params={"wait": raw}, headers=headers)).json()
            self.assertEqual(waits, [expected])
            self.assertEqual(r, {"job": None})

    async def test_timeout_cleans_future_and_late_result_is_ignored(self):
        name, remote, headers = self.member()
        call = asyncio.create_task(connect.remote_call(name, "sys", "prompt", timeout=0.01))
        job = await remote["queue"].get()
        future = remote["wait"][job["id"]]
        r = await call
        self.assertEqual(r, {"text": "", "error": "连接器 0.01 秒没回，可能掉线了"})
        self.assertTrue(future.cancelled())
        self.assertEqual(remote["wait"], {})
        r = await (await self.client.post("/api/connect/pub/result", headers=headers, json={"id": job["id"], "text": "late"})).json()
        self.assertFalse(r["ok"])
        with patch.object(connect, "remote_call", AsyncMock(return_value={"error": "连接器 1 秒没回，可能掉线了"})):
            with self.assertRaisesRegex(RuntimeError, "连接器 1 秒没回，可能掉线了"):
                await s.call_cli("p", s.member(name), {}, "", "", "", "")

    async def test_cancelled_call_cleans_future(self):
        name, remote, _ = self.member()
        call = asyncio.create_task(connect.remote_call(name, "", "", timeout=30))
        job = await remote["queue"].get()
        future = remote["wait"][job["id"]]
        call.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await call
        self.assertTrue(future.cancelled())
        self.assertEqual(remote["wait"], {})

    async def test_offline_member_rests_in_quota_and_status_until_poll(self):
        name, remote, headers = self.member(seen=100)
        c.QUOTA2[name] = {"state": "ok", "short": "可用"}
        with patch.object(connect.time, "time", return_value=160):
            self.assertEqual(connect.remote_status(name), "")
        with patch.object(connect.time, "time", return_value=161):
            status = s.status_view([name])[name]
            self.assertEqual((status["state"], status["label"]), ("resting", "离席"))
            self.assertIn("60 秒", status["reason"])
            self.assertEqual(c.MEMBER_STATE[name], "resting")
            self.assertFalse(c.healthy(name))
            with patch.object(s, "PROJECTS", []):
                self.assertEqual(s.index_view()["quota"][name]["short"], "离席")
            quota = await (await self.client.get("/api/quota/all", headers=self.h)).json()
            self.assertEqual(quota["members"][name]["short"], "离席")
            metrics = await (await self.client.get(f"/api/members/{name}/metrics", headers=self.h)).json()
            self.assertEqual(metrics["state"], "resting")
            with patch.object(c.quota_probes, "probe", AsyncMock(return_value={"state": "ok"})):
                await c.refresh_all()
            self.assertEqual(c.MEMBER_STATE[name], "resting")
        # The recovery window must not silently revive a connector which is still absent.
        with patch.object(connect.time, "time", return_value=5000):
            self.assertFalse(c.healthy(name))
            response = await self.client.get("/api/connect/pub/jobs", headers=headers, params={"wait": 0})
            self.assertEqual(response.status, 200)
            self.assertEqual(remote["seen"], 5000)
            self.assertNotIn(name, c.MEMBER_STATE)
            self.assertNotIn(name, c.STATE_REASON)
            self.assertTrue(c.healthy(name))
            self.assertNotIn(name, s.status_view([name]))
            quota = await (await self.client.get("/api/quota/all", headers=self.h)).json()
            self.assertEqual(quota["members"][name]["state"], "ok")

    async def test_poll_does_not_clear_an_unrelated_failure(self):
        name, _, headers = self.member()
        c.mark(name, "broken", "命令不可用")
        await self.client.get("/api/connect/pub/jobs", headers=headers, params={"wait": 0})
        self.assertEqual(c.MEMBER_STATE[name], "broken")


class TestConnectorState(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.state = pathlib.Path(self.tmp.name) / "state.json"
        self.enterContext(patch.object(agent, "STATE", self.state))

    def test_atomic_state_has_private_permissions_before_rename(self):
        original_open, original_replace = os.open, os.replace
        observed = []

        def open_temp(path, flags, mode):
            self.assertTrue(flags & os.O_CREAT)
            self.assertTrue(flags & os.O_EXCL)
            self.assertEqual(mode, 0o600)
            return original_open(path, flags, mode)

        def replace(temp, target):
            observed.append(pathlib.Path(temp).stat().st_mode & 0o777)
            self.assertEqual(json.loads(pathlib.Path(temp).read_text()), {"secret": "test-secret"})
            original_replace(temp, target)

        with patch.object(agent.os, "open", open_temp), patch.object(agent.os, "replace", replace):
            agent.save_state({"secret": "test-secret"})
        self.assertEqual(observed, [0o600])
        self.assertEqual(self.state.stat().st_mode & 0o777, 0o600)
        self.assertEqual(list(self.state.parent.iterdir()), [self.state])

    def test_failed_atomic_write_preserves_old_state_and_cleans_temp(self):
        self.state.write_text('{"old": true}')
        with patch.object(agent.os, "replace", side_effect=OSError("disk error")):
            with self.assertRaises(OSError):
                agent.save_state({"secret": "test-secret"})
        self.assertEqual(json.loads(self.state.read_text()), {"old": True})
        self.assertEqual(list(self.state.parent.iterdir()), [self.state])

    def test_invalid_cli_in_saved_state_registers_again(self):
        self.state.write_text(json.dumps({"member": "old", "secret": "old-secret", "cli": "unknown"}))
        register = {"member": "new", "secret": "new-secret"}
        request = Mock(side_effect=[register, KeyboardInterrupt])
        with patch.object(agent, "found", return_value=[{"name": "claude"}]), patch.object(agent, "req", request), patch("builtins.print"):
            with self.assertRaises(KeyboardInterrupt):
                agent.main()
        self.assertEqual(request.call_args_list[0].args[:2], ("POST", "/api/connect/pub/register"))
        self.assertEqual(json.loads(self.state.read_text())["cli"], "claude")
        self.assertEqual(self.state.stat().st_mode & 0o777, 0o600)
