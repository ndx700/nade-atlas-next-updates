"""Owner-authorized DM wake-ups; isolated files and no model/network calls."""
import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

import server as s


class DMRelay(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.enterContext(patch.object(s, "DATA", Path(self.tmp.name)))
        for directory in ("chats", "memory", "summaries", "skills"):
            (s.DATA / directory).mkdir()
        self.names = ["小克", "龙娘", "Kimi", "猫猫"]
        self.enterContext(patch.object(s, "CFG", {"owner": "群主", "providers": [],
            "members": [{"name": n} for n in self.names]}))
        self.enterContext(patch.object(s, "PROJECTS", [{"id": "p", "name": "测试", "lead": "小克", "members": self.names}]))
        for name in ("CHATS", "PVER", "STATUS", "TASK_STATUS", "LAST_RESULT", "QUOTA"):
            self.enterContext(patch.object(s, name, {}))
        self.enterContext(patch.object(s, "RESULTS", []))
        self.enterContext(patch.object(s, "VER", 0))
        self.enterContext(patch.object(s, "CHANGED", asyncio.Event()))
        self.chain = self.enterContext(patch.object(s, "run_chain", AsyncMock()))

    async def relay(self, name="龙娘", text="请叫 Kimi 帮忙", reply="@Kimi 审查补丁", **trigger):
        s.dm_relay("p", name, {"who": "Ali", "dm": name, "text": text, **trigger},
                   {"seq": 8, "text": reply}, {"root_id": "r"})
        await asyncio.sleep(0)

    async def test_every_member_can_relay_once_with_current_owner_authorization(self):
        for name in self.names:
            with self.subTest(name=name):
                target = "Kimi" if name != "Kimi" else "龙娘"
                self.chain.reset_mock()
                await self.relay(name=name, text=f"叫{target}帮忙", reply=f"@{target} 审查补丁")
                self.chain.assert_awaited_once()
                pid, who, message, opts = self.chain.call_args.args
                self.assertEqual((pid, who, message["dm"], message["who"]), ("p", [target], "", name))
                self.assertEqual(message["relayed_from"], 8)
                self.assertEqual(opts, {"root_id": "r", "priority": "queue"})

    async def test_lead_cannot_wake_anyone_not_named_in_current_dm(self):
        for text in ("你好", "之前的工作如何", "叫猫猫帮忙"):
            await self.relay(name="小克", text=text)
        self.chain.assert_not_called()
        self.assertEqual(s.CHATS, {})

    async def test_non_owner_missing_sender_and_non_dm_do_not_authorize(self):
        for trigger in ({"who": "Kimi"}, {"who": None}, {"who": ""}, {"dm": ""}, {"dm": "小克"}):
            await self.relay(**trigger)
        s.dm_relay("p", "龙娘", {"dm": "龙娘", "text": "叫 Kimi"}, {"seq": 8, "text": "@Kimi 帮忙"}, {})
        await asyncio.sleep(0)
        self.chain.assert_not_called()
        self.assertEqual(s.CHATS, {})

    async def test_only_named_targets_and_explicit_at_lines_relay(self):
        await self.relay(reply="私聊正文不转发\n提到 @猫猫 也不转发\n  @Kimi 审查\n@猫猫 没授权")
        self.chain.assert_awaited_once()
        _, who, message, _ = self.chain.call_args.args
        self.assertEqual(who, ["Kimi"])
        self.assertTrue(message["text"].endswith("@Kimi 审查"))
        self.assertNotIn("猫猫", message["text"])
        self.assertNotIn("私聊正文", message["text"])

    async def test_inline_mention_self_and_outsiders_do_not_wake(self):
        for text, reply in (("叫Kimi", "我会请 @Kimi 帮忙"), ("叫龙娘", "@龙娘 帮忙"),
                            ("叫外人", "@外人 帮忙")):
            await self.relay(text=text, reply=reply)
        self.chain.assert_not_called()

    async def test_group_broadcast_in_dm_does_not_bypass_named_targets(self):
        await self.relay(reply="@全体 来帮忙")
        self.chain.assert_awaited_once()
        self.assertEqual(self.chain.call_args.args[1], ["Kimi"])

    async def test_private_prompt_rule_applies_to_lead_and_other_members(self):
        for name in self.names:
            system, _, _ = s.build_prompt("p", name, {"who": "Ali", "text": "你好", "dm": name}, False)
            self.assertIn("只有 群主 在这条私聊里点名", system)
            self.assertIn("不能自行叫醒别人", system)
            self.assertNotIn("以 @ 开头的行会转发", system)

    async def test_group_dispatch_rules_unchanged(self):
        s.dispatch("p", "小克", {"text": "@Kimi 审查 @猫猫 界面"}, {})
        await asyncio.sleep(0)
        self.assertEqual(self.chain.call_args.args[1], ["Kimi", "猫猫"])
        self.chain.reset_mock()
        s.dispatch("p", "龙娘", {"text": "@Kimi 审查"}, {})
        await asyncio.sleep(0)
        self.chain.assert_not_called()
        s.dispatch("p", "龙娘", {"text": "@小克 完成 @Kimi 看看"}, {})
        await asyncio.sleep(0)
        self.assertEqual(self.chain.call_args.args[1], ["小克"])

    async def test_answer_uses_one_authorized_relay_and_skips_failed_replies(self):
        async def provider(pid, m, reply, *args):
            reply["text"] = "@Kimi 审查补丁"

        trigger = {"who": "Ali", "text": "叫 Kimi 帮忙", "dm": "小克", "seq": 1}
        with patch.object(s, "call_api", provider), patch.object(s, "over_cap", return_value=""), \
                patch.object(s, "refresh_quota", AsyncMock()):
            await s.answer("p", "小克", trigger, {})
            await asyncio.sleep(0)
            self.chain.assert_awaited_once()
            self.chain.reset_mock()
            with patch.object(s, "call_api", AsyncMock(side_effect=RuntimeError("offline"))):
                await s.answer("p", "小克", trigger, {})
                await asyncio.sleep(0)
            self.chain.assert_not_called()


if __name__ == "__main__":
    unittest.main()
