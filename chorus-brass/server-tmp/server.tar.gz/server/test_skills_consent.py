import tempfile, unittest, skills, consent


class Skills(unittest.TestCase):
    def test_list_toggle_match(self):
        d = tempfile.mkdtemp()
        rows = skills.listing(d)
        self.assertGreater(len(rows), 50)
        sid = rows[0]["id"]
        self.assertTrue(skills.set_enabled(d, sid, False))
        self.assertFalse([r for r in skills.listing(d) if r["id"] == sid][0]["enabled"])
        self.assertNotIn(sid, skills.matches(d, "code", "TDD"))
        self.assertFalse(skills.set_enabled(d, "不存在", True))

    def test_gpl_not_installable(self):
        self.assertFalse(skills.installable({"bundle_ok": True, "license": "AGPL-3.0"}))
        self.assertTrue(skills.installable({"bundle_ok": True, "license": "MIT"}))
        self.assertFalse(skills.installable({"bundle_ok": False, "license": "MIT"}))


class Consent(unittest.TestCase):
    def test_flow_and_key_change(self):
        d = tempfile.mkdtemp()
        self.assertEqual(consent.status(d, "gpt", "sk-aaaa1111"), "pending")
        c = consent.request(d, "龙娘", "gpt", "sk-aaaa1111")
        self.assertEqual(c["key_tail"], "1111")
        self.assertTrue(consent.decide(d, c["id"], True))
        self.assertEqual(consent.status(d, "gpt", "sk-aaaa1111"), "allowed")
        self.assertEqual(consent.status(d, "gpt", "sk-bbbb2222"), "pending")  # 换 key 重新允许
        self.assertEqual(consent.status(d, "gpt-2", "sk-aaaa1111"), "pending")  # 换模型重新允许
        self.assertNotIn("sk-aaaa1111", open(consent._path(d)).read())  # 不存 key 本身
        consent.revoke(d, c["id"])
        self.assertEqual(consent.status(d, "gpt", "sk-aaaa1111"), "pending")


if __name__ == "__main__":
    unittest.main()
