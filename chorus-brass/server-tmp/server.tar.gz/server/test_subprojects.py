"""Child project contracts; all state stays in temporary directories."""
import asyncio
import json
from unittest.mock import AsyncMock, patch

import unittest
from aiohttp import web
import server as s
import chorus2
import subprojects as sub
import test_task_cards as card_tests
from test_review_fixes import Request


class ChildCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        await card_tests.Cards.asyncSetUp(self)
        # make_app installs wrappers; keep registration from leaking to other tests.
        for name in ('run_member', 'record_usage', 'orchestra_view'):
            self.enterContext(patch.object(s, name, getattr(s, name)))
        self.enterContext(patch.object(chorus2, 'account_block', return_value=''))
        self.enterContext(patch('collab_api.consent_block', return_value=''))
    req = card_tests.Cards.req
    create = card_tests.Cards.create
    reply = card_tests.Cards.reply


class Children(ChildCase):
    async def split(self, body, tid=None):
        req = Request(body, pid='p', **({'id': tid} if tid else {}))
        req.method = 'POST'
        return json.loads((await sub.Subprojects(s).handle(req)).text)

    async def test_task_split_receipt_and_isolated_budget(self):
        task = await self.create(owner='A')
        body = dict(name='child', members=['B'], mode='concerto', budget=7, client_id='split')
        first = await self.split(body, task['id'])
        self.assertEqual(first, await self.split(body, task['id']))
        child = s.project(first['id'])
        self.assertEqual((child['parent'], child['source_task_id'], child['members']), ('p', task['id'], ['B']))
        self.assertEqual(s.load(s.DATA / 'projects.json', [])[-1]['parent'], 'p')
        self.assertNotIn('budget', s.project('p'))
        child['segments'] = [{'id': 'a', 'stage': 'done', 'spend': {'cost': 2}}, {'id': 'b', 'stage': 'waiting'}]
        data = await self.req('GET')
        self.assertEqual(data['children']['progress']['done'], 1)
        self.assertEqual(data['children']['budget_by_currency']['¥'], {'spent': 2, 'cap': 7})
        self.assertEqual(data['children']['items'][0]['source_task_id'], task['id'])
        self.assertEqual(data['items'][0]['children'][0]['id'], child['id'])
        self.assertEqual(child['brief'], task['title'])
        with self.assertRaises(web.HTTPConflict):
            await self.split({**body, 'budget': 8}, task['id'])

    async def test_message_provenance_and_validation(self):
        msg = self.reply('split this')
        base = dict(name='child', members=['A'], mode='concerto', source_message_ids=[msg['seq']])
        receipt = await self.split(base)
        self.assertEqual(s.project(receipt['id'])['source_message_ids'], [msg['seq']])
        self.assertEqual(s.project(receipt['id'])['brief'], 'split this')
        private = self.reply('secret', dm='A')
        for changes in ({'source_message_ids': [private['seq']]}, {'source_message_ids': [999]},
                        {'members': []}, {'budget': -1}, {'members': ['unknown']}):
            before = len(s.PROJECTS)
            with self.assertRaises(web.HTTPBadRequest):
                await self.split({**base, **changes})
            self.assertEqual(len(s.PROJECTS), before)
        with self.assertRaises(web.HTTPBadRequest):
            await self.split(base, 'missing')
        with self.assertRaises(web.HTTPBadRequest) as cm:
            await self.split({**base, 'source_message_ids': [private['seq']]})
        self.assertIn('来源必须是本群正式消息', cm.exception.text)
        s.project('p')['filed'] = True
        with self.assertRaises(web.HTTPConflict):
            await self.split(base)

    async def test_completion_report_persistent_and_recoverable(self):
        msg = self.reply('go')
        receipt = await self.split(dict(name='child', members=['A'], source_message_ids=[msg['seq']]))
        p = s.project(receipt['id'])
        p['segments'] = [{'id': 'one', 'stage': 'waiting'}]
        chorus2.save_projects()
        self.assertFalse(p.get('completion_reported'))
        p['segments'][0].update(stage='done', artifacts=['file.txt'])
        chorus2.save_projects()
        reports = [m for m in s.load_chat('p') if m.get('subproject_report')]
        self.assertEqual(len(reports), 1)
        self.assertEqual(reports[0]['subproject_report']['artifacts'], ['file.txt'])
        p.pop('completion_reported')  # crash after chat write, before projects write
        chorus2.save_projects()
        self.assertEqual(len([m for m in s.load_chat('p') if m.get('subproject_report')]), 1)
        self.assertTrue(s.load(s.DATA / 'projects.json', [])[-1]['completion_reported'])

    async def test_parallel_children_do_not_wait_for_member_global_lock(self):
        s.project('q')['parent'] = 'p'
        lock = asyncio.Lock()
        await lock.acquire()
        with patch.object(s, 'LOCKS', {'A': lock}), patch.object(s, 'TASKS', {}), patch.object(s, 'ROOTS', {}), \
             patch.object(s, 'QUEUED', {}), patch.object(s, 'reserve_call', return_value=True), \
             patch.object(s, 'answer', AsyncMock()) as answer:
            await asyncio.wait_for(s.run_member('q', 'A', {'text': 'go'}, {}), 1)
            answer.assert_awaited_once()
            self.assertTrue(lock.locked())
            self.assertIn(('q', 'A'), s.LOCKS)
        lock.release()

    async def test_routes_auth_and_project_index(self):
        from aiohttp.test_utils import make_mocked_request
        app = s.make_app()
        expected = {'/api/projects/{pid}/children', '/api/tasks/{pid}/{id}/children'}
        self.assertTrue(expected <= {r.resource.canonical for r in app.router.routes()})
        for path in ('/api/projects/p/children', '/api/tasks/p/task/children'):
            handler = AsyncMock(return_value=web.Response())
            response = await s.auth(make_mocked_request('POST', path, app=app), handler)
            self.assertEqual(response.status, 401)
            handler.assert_not_awaited()
        s.project('q')['parent'] = 'p'
        self.assertEqual(next(p for p in s.index_view()['projects'] if p['id'] == 'q')['parent'], 'p')


def test_child_snapshot_changes_are_sent():
    import orchestra
    current = {'parent': 'p', 'children': {'progress': {'pct': 50}}}
    assert orchestra.diff({}, current)['children'] == current['children']
    assert orchestra.diff({}, current)['parent'] == 'p'

class ChildBudget(ChildCase):
    async def test_child_cap_blocks_only_its_own_execution(self):
        child = s.project('q')
        child.update(parent='p', budget={'cap': 1, 'cur': '¥'}, cost_split={'execution': {'cost': {'¥': 1}}})
        s.project('p')['budget'] = {'cap': 999, 'cur': '¥'}
        with patch.object(s, 'LOCKS', {}), patch.object(s, 'TASKS', {}), patch.object(s, 'ROOTS', {}), \
             patch.object(s, 'QUEUED', {}), patch.object(s, 'reserve_call', return_value=True), \
             patch.object(s, 'answer', AsyncMock()) as answer:
            await s.run_member('q', 'A', {'text': 'go'}, {})
            answer.assert_not_awaited()
            # Parent cap does not control child: only its own cap changes this result.
            s.project('p')['budget']['cap'] = .01
            child['budget']['cap'] = 2
            await s.run_member('q', 'A', {'text': 'go'}, {})
            answer.assert_awaited_once()

class ChildEdges(ChildCase):
    split = Children.split
    async def test_null_parent_rejected_without_creation(self):
        before = len(s.PROJECTS)
        with self.assertRaises(web.HTTPBadRequest):
            await s.h_new_project(Request(dict(name='bad', members=['A'], parent=None)))
        self.assertEqual(len(s.PROJECTS), before)

    async def test_source_edit_does_not_change_creation_receipt(self):
        task = await self.create()
        body = dict(name='child', members=['A'], client_id='stable')
        first = await self.split(body, task['id'])
        await self.req('PATCH', {'revision': 1, 'title': 'changed'}, tid=task['id'])
        self.assertEqual(first, await self.split(body, task['id']))
        self.assertEqual(s.project(first['id'])['brief'], task['title'])

    async def test_deleted_child_has_no_completion_report(self):
        s.project('q').update(parent='p', archived=True, segments=[{'id': 'x', 'stage': 'done'}])
        chorus2.save_projects()
        self.assertEqual(s.load_chat('p'), [])
        self.assertFalse(s.project('q').get('completion_reported'))

    async def test_same_ai_runs_two_children_concurrently(self):
        s.project('q')['parent'] = 'p'
        s.PROJECTS.append({'id': 'r', 'name': 'r', 'parent': 'p', 'members': ['A']})
        entered = set()
        both = asyncio.Event()
        async def answer(pid, *args):
            entered.add(pid)
            if len(entered) == 2:
                both.set()
            await asyncio.wait_for(both.wait(), 1)
        with patch.object(s, 'LOCKS', {}), patch.object(s, 'TASKS', {}), patch.object(s, 'ROOTS', {}), \
             patch.object(s, 'QUEUED', {}), patch.object(s, 'reserve_call', return_value=True), \
             patch.object(s, 'answer', side_effect=answer):
            await asyncio.gather(*(s.run_member(pid, 'A', {'text': 'go'}, {}) for pid in ('q', 'r')))
        self.assertEqual(entered, {'q', 'r'})

class ServerGaps(ChildCase):
    split = Children.split

    async def child(self, **extra):
        msg = self.reply('source context')
        receipt = await self.split(dict(name='child', members=['A'], source_message_ids=[msg['seq']], **extra))
        return s.project(receipt['id'])

    async def mutation(self, p, op, **body):
        return json.loads((await sub.Subprojects(s).mutate(Request(body, pid=p['id'], op=op))).text)

    async def test_runtime_detail_and_chat_provenance(self):
        p = await self.child(context='背景', acceptance_criteria='用户验收', estimated_seconds=60)
        p['segments'] = [{'id': 'a', 'stage': 'awaiting_user', 'deps': ['b'], 'blocked_reason': '等待依赖'}]
        row = sub.children(s, 'p')['items'][0]
        self.assertEqual(row['running_status'], 'awaiting_user')
        self.assertTrue(row['waiting_for_user'])
        self.assertEqual(row['estimated_seconds'], 60)
        self.assertEqual(row['dependency_reasons'][0]['reason'], '等待依赖')
        self.assertEqual(row['assign_log'][0]['project_id'], p['id'])
        detail = json.loads((await sub.Subprojects(s).detail(Request(pid=p['id']))).text)
        self.assertEqual(detail['context'], '背景')
        self.assertEqual(detail['acceptance_criteria'], '用户验收')
        self.assertEqual(detail['source_messages'][0]['text'], 'source context')
        p['paused'] = True
        self.assertEqual(sub.summary(s, p['id'])['running_status'], 'paused')
        self.assertIsNotNone(row['last_activity_at'])

    async def test_replace_without_segments_idempotent_and_full_context(self):
        p = await self.child()
        s.add_msg(p['id'], 'A', '完整讨论')
        s.add_msg(p['id'], 'A', '私信', dm='A')
        first = await self.mutation(p, 'replace-members', client_id='swap', members=['B'], reason='更适合')
        self.assertEqual(first, await self.mutation(p, 'replace-members', client_id='swap', members=['B'], reason='更适合'))
        self.assertEqual(p['members'], ['B'])
        self.assertEqual(first['handoff']['context']['messages'][0]['text'], '完整讨论')
        self.assertEqual(len(first['handoff']['context']['messages']), 1)
        self.assertEqual(first['handoff']['status'], 'stored')
        self.assertEqual(s.load(s.DATA / 'projects.json', [])[-1]['handoffs'], p['handoffs'])
        with self.assertRaises(web.HTTPConflict):
            await self.mutation(p, 'replace-members', client_id='swap', members=['A'])

    async def test_mutation_write_failure_and_busy_are_unchanged(self):
        import copy
        p = await self.child()
        before = copy.deepcopy(p)
        disk = (s.DATA / 'projects.json').read_bytes()
        for op, fields in [('replace-members', {'members': ['B']}), ('resolve', {})]:
            with patch.object(s, 'save', side_effect=OSError('disk full')):
                with self.assertRaises(OSError):
                    await asyncio.wait_for(self.mutation(p, op, client_id='failure', **fields), 2)
            self.assertEqual(p, before)
            self.assertEqual((s.DATA / 'projects.json').read_bytes(), disk)
        from unittest.mock import Mock
        pending = Mock()
        pending.done.return_value = False
        with patch.object(s, 'ROOTS', {'root': {'pid': p['id'], 'tasks': {pending: 'A'}}}):
            with self.assertRaises(web.HTTPConflict):
                await self.mutation(p, 'resolve', client_id='busy')

    async def test_atomic_resolution_empty_and_segmented_and_report_retry(self):
        for segments in ([], [{'id': 'one', 'stage': 'waiting', 'artifacts': ['result.txt']} ]):
            p = await self.child()
            p['segments'] = segments
            with patch.object(s, 'add_msg', side_effect=OSError('chat offline')):
                first = await self.mutation(p, 'resolve', client_id='resolve', note='人工验收')
            self.assertTrue(p['resolved'])
            self.assertFalse(p['completion_reported'])
            self.assertTrue(all(x['stage'] == 'done' for x in p['segments']))
            self.assertEqual(first, await self.mutation(p, 'resolve', client_id='resolve', note='人工验收'))
            chorus2.save_projects()
            chorus2.save_projects()
            reports = [m for m in s.load_chat('p') if m.get('subproject_receipt') == first['report_receipt']]
            self.assertEqual(len(reports), 1)
            self.assertTrue(reports[0]['subproject_report']['resolved'])

    async def test_source_artifact_validation_and_handoff(self):
        import artifacts
        store = artifacts.default_store(s.DATA, 'p', enabled=True)
        art = await store.add_artifact(content=b'result', producer='A', title='output', secret=False)
        p = await self.child(source_artifact_ids=[art.id])
        self.assertEqual(p['source_artifacts'][0]['id'], art.id)
        first = await self.mutation(p, 'replace-members', client_id='swap', members=['B'])
        self.assertEqual(first['handoff']['context']['source_artifacts'][0]['id'], art.id)
        for value in (['missing'], 'bad', [123]):
            before = len(s.PROJECTS)
            with self.assertRaises(web.HTTPBadRequest):
                await self.child(source_artifact_ids=value)
            self.assertEqual(len(s.PROJECTS), before)

    async def test_preview_uses_task_and_reports_unknown_factors(self):
        task = await self.create(title='开发 Python API')
        result = json.loads((await sub.Subprojects(s).assignment_preview(Request({'source_task_id': task['id']}, pid='p'))).text)
        self.assertEqual(result['items'][0]['skill'], 'code')
        self.assertIn('price', result['items'][0]['unknown_factors'])
        self.assertFalse(result['persisted'])
        with self.assertRaises(web.HTTPBadRequest):
            await sub.Subprojects(s).assignment_preview(Request({'source_task_id': 'missing'}, pid='p'))

    async def test_project_consent_pre_registered_without_grant(self):
        import consent
        import os
        self.enterContext(patch.dict(os.environ, {"CHORUS_CONSENT": "on"}))
        s.CFG['members'][0].update(model='gpt-test', provider='provider')
        s.CFG['providers'] = [{'id': 'provider', 'key': 'test-key'}]
        p = await self.child(client_id='consent')
        cards = sub.consent_cards(s, p)
        self.assertEqual(cards[0]['state'], 'pending')
        self.assertEqual(cards[0]['project_id'], p['id'])
        self.assertEqual(p['create_receipt']['consent_cards'][0]['id'], cards[0]['id'])
        self.assertEqual(consent.status(s.DATA, 'gpt-test', 'test-key'), 'pending')
        self.assertTrue(sub.summary(s, p['id'])['waiting_for_user'])

    async def test_new_routes_registered_and_authenticated(self):
        from aiohttp.test_utils import make_mocked_request
        app = s.make_app()
        paths = {'/api/projects/{pid}/subitem', '/api/projects/{pid}/subitem/{op}', '/api/projects/{pid}/assignment-preview'}
        self.assertTrue(paths <= {r.resource.canonical for r in app.router.routes()})
        for path in ('/api/projects/p/subitem', '/api/projects/p/subitem/resolve', '/api/projects/p/assignment-preview'):
            handler = AsyncMock(return_value=web.Response())
            response = await s.auth(make_mocked_request('POST', path, app=app), handler)
            self.assertEqual(response.status, 401)

    async def test_handoff_registered_outputs_and_execution_context(self):
        import artifacts
        p = await self.child(context='独立背景', acceptance_criteria='验收规范')
        p['segments'] = [{'id': 'a', 'stage': 'done', 'assignee': 'A', 'artifacts': ['a.txt']},
                         {'id': 'b', 'stage': 'waiting', 'assignee': 'A'}]
        store = artifacts.default_store(s.DATA, p['id'], enabled=True)
        art = await store.add_artifact(content=b'output', producer='A', secret=False)
        result = await self.mutation(p, 'replace-members', client_id='full', members=['B'])
        self.assertEqual(p['segments'][0]['assignee'], 'A')
        self.assertEqual(p['segments'][1]['assignee'], 'B')
        self.assertEqual(result['handoff']['context']['artifact_lines'][0]['head']['id'], art.id)
        prompt = sub.execution_context(p)
        self.assertIn('验收规范', prompt)
        self.assertIn(art.id, prompt)
        self.assertIn('source context', prompt)
        chat = s.chat_view(p['id'], 0)['project']
        self.assertEqual(chat['parent'], 'p')
        self.assertEqual(chat['source_message_ids'], p['source_message_ids'])
        import collab_api
        with patch.object(collab_api, 'S', s):
            log = json.loads((await collab_api.h_assign_log(Request(query={'project_id': p['id']}))).text)['log']
        self.assertTrue(all(x['project_id'] == p['id'] for x in log))
        self.assertEqual(log[-1]['handoff_id'], 'full')
        with patch.dict('os.environ', {'CHORUS_PROFILE_MODE': 'shadow'}):
            sub.orchestra.assign({'id': 'b', 'project_id': p['id'], 'difficulty': 1},
                                 [{'name': 'B', 'model': 'unknown'}])
        sub.record_dispatch(p, p['segments'][1], 'B', '调度器选择')
        dispatch = sub.summary(s, p['id'])['assign_log'][-1]
        self.assertEqual(dispatch['project_id'], p['id'])
        self.assertEqual(dispatch['segment_id'], 'b')
        self.assertEqual(dispatch['kind'], 'dispatch')
        self.assertEqual(dispatch['selection']['project_id'], p['id'])

    async def test_artifact_isolation_secret_missing_blob_and_creation_replay(self):
        import artifacts
        store = artifacts.default_store(s.DATA, 'p', enabled=True)
        art = await store.add_artifact(content=b'public', secret=False)
        p = await self.child(source_artifact_ids=[art.id], client_id='artifact')
        # Replaying a committed create does not depend on a still-live source blob.
        store.blob_path(art.sha256).unlink()
        msg_id = p['source_message_ids'][0]
        replay = await self.split(dict(name='child', members=['A'], source_message_ids=[msg_id],
                                       source_artifact_ids=[art.id], client_id='artifact'))
        self.assertEqual(replay['id'], p['id'])
        secret = await store.add_artifact(content=b'secret', secret=True)
        other = await artifacts.default_store(s.DATA, 'q', enabled=True).add_artifact(content=b'other', secret=False)
        for aid in (art.id, secret.id, other.id):
            with self.assertRaises(web.HTTPBadRequest):
                await self.child(source_artifact_ids=[aid])

    async def test_parallel_idempotent_operations_and_validation(self):
        p = await self.child()
        p['mode'] = 'solo'
        broken = Request(pid=p['id'], op='resolve')
        broken.json = AsyncMock(side_effect=ValueError('bad json'))
        with self.assertRaises(web.HTTPBadRequest):
            await sub.Subprojects(s).mutate(broken)
        before = json.loads(json.dumps(p))
        for members in ([], ['missing'], ['A', 'B'], 'B'):
            with self.assertRaises(web.HTTPBadRequest):
                await self.mutation(p, 'replace-members', client_id='invalid', members=members)
            self.assertEqual(p, before)
        first, second = await asyncio.gather(
            self.mutation(p, 'replace-members', client_id='same', members=['B']),
            self.mutation(p, 'replace-members', client_id='same', members=['B']))
        self.assertEqual(first, second)
        self.assertEqual(len(p['handoffs']), 1)
        a, b = await asyncio.gather(self.mutation(p, 'resolve', client_id='done'), self.mutation(p, 'resolve', client_id='done'))
        self.assertEqual(a, b)
        self.assertEqual(sub.summary(s, p['id'])['progress']['pct'], 100)
        self.assertEqual(len([x for x in s.load_chat('p') if x.get('subproject_receipt') == a['report_receipt']]), 1)

    async def test_preview_consumes_actual_cost_pass_rate_and_quota(self):
        s.CFG['members'][0]['model'] = 'test-model'
        s.CFG['members'][0]['price'] = {'in': 1, 'out': 2, 'cur': '$'}
        s.CFG['member_stats'] = {'A': {'reviews': 10, 'pass': .9}}
        s.QUOTA['A'] = {'state': 'arrears', 'pct': 0}
        result = json.loads((await sub.Subprojects(s).assignment_preview(Request({'brief': '修复 API'}, pid='p'))).text)
        row = next(x for x in result['items'] if x['member'] == 'A')
        self.assertEqual(row['price']['out'], 2)
        self.assertEqual(row['historical_pass_rate'], .9)
        self.assertFalse(row['available'])
        self.assertEqual(result['items'][0]['member'], 'B')
