"""Remote CLI members: the connector reports the CLI's own usage limits and the quota sheet shows them (no more 额度未知)."""
import json
import os
import pathlib
import tempfile
import time
import unittest
from unittest.mock import patch

import cli_quota
import connect
import quota_probes
import server as s
from connector import connector as agent
from test_connect import Base

RL = {"limit_id": "codex", "primary": {"used_percent": 30.0, "window_minutes": 300, "resets_at": 1793352469},
      "secondary": {"used_percent": 88.0, "window_minutes": 10080, "resets_at": 1793776090}}


class ConnectorReads(unittest.TestCase):
    def test_codex_limits_from_newest_session_event(self):
        with tempfile.TemporaryDirectory() as d:
            day = pathlib.Path(d, "sessions", "2026", "10", "30"); day.mkdir(parents=True)
            old = day / "a.jsonl"; old.write_text(json.dumps({"rate_limits": {**RL, "primary": {"used_percent": 99, "window_minutes": 300}}}) + "\n")
            os.utime(old, (time.time() - 100, time.time() - 100))
            new = day / "b.jsonl"
            new.write_text(json.dumps({"type": "x"}) + "\n" + json.dumps({"payload": {"type": "token_count", "rate_limits": RL}}) + "\nnot json\n")
            q = agent.codex_limits(d)
            self.assertEqual(q["kind"], "codex")
            self.assertEqual(q["rate_limits"]["primary"]["used_percent"], 30.0)

    def test_no_sessions_means_no_report(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(agent.codex_limits(d))

    def test_claude_report_runs_the_cli_usage_command(self):
        with patch.object(agent.shutil, "which", return_value="/bin/claude"), \
             patch.object(agent.subprocess, "run") as run:
            run.return_value.stdout = "Current session: 40% used · resets 5pm"
            q = agent.quota_report("claude")
        self.assertEqual(q["kind"], "claude")
        self.assertEqual(run.call_args.args[0][:3], ["claude", "-p", "/usage"])


class Normalize(unittest.TestCase):
    def test_codex_remaining_percent(self):
        q = connect.normalize_quota({"kind": "codex", "rate_limits": RL})
        self.assertEqual((q["pct"], q["week"]), (70.0, 12.0))
        self.assertTrue(q["reset"] and q["week_reset"])

    def test_claude_and_gemini_text(self):
        q = connect.normalize_quota({"kind": "claude", "text": json.dumps({"result": "Current session: 25% used · resets 3pm\nCurrent week (all models): 60% used · resets Mon"})})
        self.assertEqual((q["pct"], q["week"]), (75.0, 40.0))
        g = connect.normalize_quota({"kind": "gemini", "text": "│ gemini-3.8-flash   12   75.0% (Resets in 1h 30m)"})
        self.assertEqual(g["pct"], 75.0)

    def test_garbage_is_ignored(self):
        self.assertIsNone(connect.normalize_quota({"kind": "codex", "rate_limits": {}}))
        self.assertIsNone(connect.normalize_quota({"kind": "evil"}))


class ServerShows(Base):
    def remote(self):
        name = "Codex"
        s.CFG["members"].append({"name": name, "kind": "cli", "remote": True, "cmd": "codex exec -",
                                 "quota": {"type": "codex_sessions", "home": "~/.codex"}})
        connect.REMOTE[name] = {"hash": connect._h("sec"), "queue": None, "wait": {}, "seen": time.time(), "clis": []}
        self.addCleanup(cli_quota.CACHE.pop, name, None)
        return name, {"X-Chorus-Member": name, "X-Chorus-Secret": "sec"}

    def ctx(self):
        ctx = quota_probes.Ctx(None)
        ctx.cmd_json = cli_quota.cached
        return ctx

    async def test_report_lands_in_quota_not_unknown(self):
        name, h = self.remote()
        r = await self.client.post("/api/connect/pub/quota", headers=h, json={"kind": "codex", "rate_limits": RL})
        body = await r.json()
        self.assertTrue(body["ok"]); self.assertEqual(body["pct"], 70.0)
        q = await quota_probes.probe({}, s.member(name), self.ctx())
        self.assertEqual((q["pct"], q["week"]), (70.0, 12.0))

    async def test_remote_codex_never_reads_the_servers_own_codex_home(self):
        name, _ = self.remote()
        with patch.object(quota_probes, "_read_codex_lines", side_effect=AssertionError("read server ~/.codex")):
            q = await quota_probes.probe({}, s.member(name), self.ctx())
        self.assertEqual(q.get("kind"), "count")   # until its connector reports: today's call count, never the server's own codex home

    async def test_bad_secret_rejected(self):
        name, _ = self.remote()
        r = await self.client.post("/api/connect/pub/quota", headers={"X-Chorus-Member": name, "X-Chorus-Secret": "no"},
                                   json={"kind": "codex", "rate_limits": RL})
        self.assertNotEqual(r.status, 200)
        self.assertNotIn(name, cli_quota.CACHE)
