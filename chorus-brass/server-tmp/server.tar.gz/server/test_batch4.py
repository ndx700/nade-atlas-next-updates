"""Offline integration coverage: real git, task-local dispatch, temporary storage."""
import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import functools

def async_test(fn):
    @functools.wraps(fn)
    def run(*args, **kwargs):
        return asyncio.run(fn(*args, **kwargs))
    return run
import chorus2
import ensemble
import verify


@async_test
async def test_parallel_segment_worktrees_merge_without_overwrite(tmp_path):
    segments = [{"id": "one"}, {"id": "two"}]
    project = {"segments": segments}
    state = SimpleNamespace(DATA=tmp_path, CFG={}, project=lambda pid: project)
    entered = 0
    both = asyncio.Event()

    async def execute(pid, seg):
        nonlocal entered
        tree = Path(chorus2.SEGMENT_CWD.get())
        import sys
        process = await asyncio.create_subprocess_exec(
            sys.executable, "-c", "import pathlib,sys; pathlib.Path(sys.argv[1]+'.txt').write_text(sys.argv[1])", seg["id"], cwd=tree)
        assert await process.wait() == 0
        entered += 1
        if entered == 2:
            both.set()
        await asyncio.wait_for(both.wait(), 5)
        assert not (tree / ("two.txt" if seg["id"] == "one" else "one.txt")).exists()
        seg["stage"] = "done"

    with patch.object(chorus2, "S", state), patch.object(chorus2, "_run_segment", execute), patch.object(chorus2, "save_projects"):
        await asyncio.gather(*(chorus2.run_segment("project", s) for s in segments))
    main = tmp_path / "work/project/ensemble/main"
    assert (main / "one.txt").read_text() == "one"
    assert (main / "two.txt").read_text() == "two"
    assert all(s["stage"] == "done" for s in segments)
    assert chorus2.SEGMENT_CWD.get() is None


@async_test
async def test_list_acceptance_is_not_empty_success(tmp_path):
    result = await verify.run_checks({"acceptance": ["must work"]}, tmp_path)
    assert result["manual"]
    assert not result["passed"]
    assert len(result["results"]) == 1
    assert not (await verify.run_checks({"checks": [], "acceptance": ["must work"]}, tmp_path))["passed"]
    result = await verify.run_checks({"acceptance": [{"type": "file_exists", "path": "missing"}]}, tmp_path)
    assert not result["passed"]


@async_test
async def test_workspace_rejects_traversal(tmp_path):
    ws = ensemble.Workspace(tmp_path)
    with pytest.raises(ValueError):
        await ws.tree_for("../outside")


def test_image_transport_original_and_thumbnail(tmp_path):
    import base64
    import assets
    from PIL import Image
    path = tmp_path / "image.png"
    Image.new("RGB", (1200, 900), "red").save(path)
    parts = assets.image_content("look", [path])
    assert base64.b64decode(parts[1]["image_url"]["url"].split(",")[1]) == path.read_bytes()
    small = assets.image_content("look", [path], anthropic=True, inline_limit=1)
    assert small[1]["text"].startswith("原文件引用")
    assert small[2]["source"]["media_type"] == "image/jpeg"


@async_test
async def test_optional_manifest_and_evidence(tmp_path):
    import collab_runtime
    import evidence
    root = tmp_path / "main"
    root.mkdir()
    (root / "file.txt").write_text("actual")
    project = {}
    server = SimpleNamespace(CFG={"collab": {"manifest": True, "evidence": True}}, project=lambda pid: project)
    seg = {"id": "seg", "artifacts": ["file.txt"], "verification": {"passed": True}}
    await collab_runtime.record(server, "p", seg, root)
    assert seg["artifact_manifests"][0]["bytes"] == 6
    assert project["memory"]["seg"]["acceptances"] == [{"passed": True}]
    assert len(evidence.read_events(tmp_path / "records/events.jsonl")) == 3
    with pytest.raises(ValueError):
        list(collab_runtime.artifact_paths(root, ["../escape"]))


def test_optional_policy_and_roi_are_explicit(tmp_path):
    import collab_runtime
    server = SimpleNamespace(CFG={})
    segments = [{"id": "a", "est_tokens": 1}, {"id": "b", "est_tokens": 1}]
    project = {}
    assert collab_runtime.plan_gate(server, project, segments) == segments
    assert project == {}
    assert collab_runtime.review(server, {"irreversible": True}, {}) == {}
    server.CFG = {"collab": {"review_policy": True, "split_roi": True}}
    assert collab_runtime.review(server, {"irreversible": True, "diff_lines": 300}, {})["dual"]
    collab_runtime.plan_gate(server, project, segments)
    assert project["collab_serial"] == (project["split_roi"]["verdict"] == "merge")


@async_test
async def test_default_backup_key_and_upgrade_snapshot(tmp_path):
    import backup
    from deploy.pre_upgrade import snapshot
    data = tmp_path / "data"
    data.mkdir()
    (data / "config.json").write_text('{}')
    (data / "projects.json").write_text('[]')
    manager = backup.BackupManager(data, lambda: {})
    key = manager.scheduled_password({})
    assert manager.scheduled_password({}) == key
    assert (manager.root / "schedule.key").stat().st_mode & 0o077 == 0
    result = await snapshot(data)
    assert result["state"] == "completed"
    script = Path(__file__).with_name("deploy").joinpath("install.sh").read_text()
    assert script.index("pre_upgrade.py") < script.index("rm -rf /opt/chorus2/server")


@async_test
async def test_cli_dispatch_uses_task_cwd_and_disables_resume(tmp_path):
    import ast
    import pathlib
    import secrets
    import shlex
    source = ast.parse(Path(__file__).with_name("server.py").read_text())
    function = next(n for n in source.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "_call_cli")
    class Captured(Exception):
        pass
    def guard(cmd):
        assert str(tmp_path / "isolated") in cmd
        assert "resume" not in cmd
        raise Captured
    namespace = dict(chorus2=chorus2, DATA=tmp_path, pathlib=pathlib, secrets=secrets, shlex=shlex,
                     approve_all_for=lambda name: False, CFG={})
    exec(compile(ast.Module(body=[function], type_ignores=[]), "cli-test", "exec"), namespace)
    token = chorus2.SEGMENT_CWD.set(str(tmp_path / "isolated"))
    member = {"name": "cli", "kind": "cli", "cmd": "tool {cwd}", "resume_cmd": "resume {cwd}", "cwd": "/wrong"}
    try:
        with patch.object(chorus2, "cli_guard", guard), pytest.raises(Captured):
            await namespace["_call_cli"]("p", member, {}, "", "", "", "", sess={"id": "old"})
    finally:
        chorus2.SEGMENT_CWD.reset(token)
    assert member["cwd"] == "/wrong"


def test_plan_keeps_machine_checks():
    import json
    import orchestra
    check = {"type": "file_exists", "path": "actual.py"}
    segments = orchestra.parse_plan(json.dumps({"segments": [{"id": "s", "checks": [check]}]}))
    assert segments[0]["checks"] == [check]


@async_test
async def test_asset_hub_shared_picture_is_original_or_digest(tmp_path):
    import assets
    from PIL import Image
    from unittest.mock import AsyncMock
    path = tmp_path / "made-by-model.png"
    Image.new("RGB", (20, 20)).save(path)
    vision = {"name": "vision", "caps": {"vision": True}}
    blind = {"name": "blind", "caps": {"vision": False}}
    hub = assets.AssetHub(tmp_path / "cache.json", [vision, blind], lambda m: None, AsyncMock(), lambda *a: None, lambda m: None, {})
    with patch.object(assets.A, "capabilities", side_effect=lambda m, *a: m["caps"]):
        card = {"assets": [{"kind": "image", "ref": str(path)}]}
        assert "直接看" in (await hub.for_card(card, vision))[0]
        with patch.object(hub, "_compute", AsyncMock(return_value=("generated red dragon", "vision"))) as compute:
            assert "generated red dragon" in (await hub.for_card(card, blind))[0]
            await hub.for_card(card, blind)
            assert compute.await_count == 1


def test_collab_config_rejects_implicit_truthiness():
    import collab_runtime
    assert not any(collab_runtime.validate_options({}).values())
    assert collab_runtime.validate_options({"assets": True})["assets"]
    for invalid in ({"assets": "true"}, {"unknown": True}, [], {"manifest": 1}):
        with pytest.raises(ValueError):
            collab_runtime.validate_options(invalid)


@async_test
async def test_conflicting_segments_do_not_overwrite_main(tmp_path):
    segments = [{"id": "one"}, {"id": "two"}]
    project = {"segments": segments}
    state = SimpleNamespace(DATA=tmp_path, CFG={}, project=lambda pid: project)
    both = asyncio.Event()
    count = 0
    async def execute(pid, seg):
        nonlocal count
        (Path(chorus2.SEGMENT_CWD.get()) / "same.txt").write_text(seg["id"])
        count += 1
        if count == 2:
            both.set()
        await asyncio.wait_for(both.wait(), 5)
        seg["stage"] = "done"
    with patch.object(chorus2, "S", state), patch.object(chorus2, "_run_segment", execute), patch.object(chorus2, "save_projects"):
        await asyncio.gather(*(chorus2.run_segment("project", s) for s in segments))
    assert sorted(s["stage"] for s in segments) == ["blocked", "done"]
    winner = next(s for s in segments if s["stage"] == "done")
    assert (tmp_path / "work/project/ensemble/main/same.txt").read_text() == winner["id"]


@async_test
async def test_existing_project_files_seed_workspace_without_external_symlinks(tmp_path):
    source = tmp_path / "project"
    source.mkdir()
    (source / "existing.py").write_text("existing code")
    (source / "external").symlink_to(tmp_path / "private")
    (tmp_path / "private").write_text("private")
    ws = ensemble.Workspace(source / "ensemble")
    await ws.init(seed=source)
    tree = await ws.tree_for("segment")
    assert (tree / "existing.py").read_text() == "existing code"
    assert not (tree / "external").exists()
    assert not (tree / "ensemble").exists()


@async_test
async def test_downstream_manifest_tamper_and_evidence_recovery(tmp_path):
    import collab_runtime
    import manifest
    root = tmp_path / "main"
    root.mkdir()
    path = root / "artifact.txt"
    path.write_text("original")
    seg = {"id": "up", "artifacts": ["artifact.txt"], "verification": {"passed": True}}
    project = {"segments": [seg]}
    server = SimpleNamespace(CFG={"collab": {"manifest": True, "evidence": True}}, project=lambda pid: project)
    await collab_runtime.record(server, "p", seg, root)
    recovered = collab_runtime.upstream(server, project, {"inputs": ["up"]}, root)
    assert '"recovered": true' in recovered["up"]["summary"]
    path.write_text("tampered")
    with pytest.raises(manifest.ManifestIntegrityError):
        collab_runtime.upstream(server, project, {"inputs": ["up"]}, root)


def test_roi_merge_keeps_all_contracts():
    import collab_runtime
    server = SimpleNamespace(CFG={"collab": {"split_roi": True}})
    segments = [{"id": "a", "acceptance": ["a"], "checks": [{"type": "file_exists", "path": "a"}]},
                {"id": "b", "inputs": ["a"], "acceptance": ["b"], "checks": [{"type": "file_exists", "path": "b"}]}]
    with patch.object(collab_runtime.split_roi, "split_decision", return_value={"verdict": "merge"}):
        merged = collab_runtime.plan_gate(server, {}, segments)
    assert len(merged) == 1
    assert merged[0]["acceptance"] == ["a", "b"]
    assert len(merged[0]["checks"]) == 2
    assert merged[0]["inputs"] == []


def test_handoff_contains_machine_contract():
    check = {"type": "file_exists", "path": "deliverable.py"}
    packet = ensemble.packet({"id": "s", "title": "work", "checks": [check]}, {}, {}, [], lambda f: None, [], [])
    assert "deliverable.py" in packet
    assert "file_exists" in packet


@async_test
async def test_review_risk_counts_new_files_before_commit(tmp_path):
    ws = ensemble.Workspace(tmp_path)
    await ws.init()
    tree = await ws.tree_for("s")
    (tree / "new.py").write_text("first\nsecond\nthird\n")
    assert await ensemble.changed_lines(tree) == 3
    _, log = await ensemble.git(tree, "log", "--oneline")
    assert len(log.splitlines()) == 1


@async_test
async def test_upgrade_snapshot_refuses_live_writer(tmp_path):
    import backup
    from deploy.pre_upgrade import snapshot
    (tmp_path / "config.json").write_text('{}')
    (tmp_path / "projects.json").write_text('[]')
    with backup.writer_lock(tmp_path), pytest.raises(backup.BackupError):
        await snapshot(tmp_path)


def test_daily_backup_retains_seven_by_default():
    import backup
    assert backup.validate_options({}) == {"interval_hours": 24, "keep": 7}
    assert backup.validate_options({"interval_hours": 0})["interval_hours"] == 0


@async_test
async def test_runtime_asset_bridge_bills_share_and_transports_pixels(tmp_path):
    import collab_runtime
    import assets
    from PIL import Image
    from unittest.mock import AsyncMock
    tree = tmp_path / "ensemble/trees/segment"
    tree.mkdir(parents=True)
    Image.new("RGB", (20, 20), "red").save(tree / "upstream.png")
    members = [{"name": "vision", "kind": "api", "caps": {"vision": True}},
               {"name": "blind", "kind": "api", "caps": {"vision": False}}]
    server = SimpleNamespace(CFG={"members": members, "collab": {"assets": True}},
                             member=lambda name: next(m for m in members if m["name"] == name),
                             price=lambda *a: None, provider=lambda p: {})
    project = {"segments": [{"id": "up", "artifacts": ["upstream.png"]}]}
    async def ask(member, system, prompt, pid):
        assert chorus2.ROLE.get() == "share"
        assert prompt[1]["image_url"]["url"].startswith("data:image/png;base64,")
        return "a red image"
    mock = AsyncMock(side_effect=ask)
    with patch.object(chorus2, "S", server), patch.object(chorus2, "healthy", return_value=True), patch.object(chorus2, "ask_model", mock), patch("collab_api.consent_block", return_value=None), patch.object(assets.A, "capabilities", side_effect=lambda m, *args: {"price_out": 1, "pass_rate": .8, **m["caps"]}):
        notes, refs = await collab_runtime.share(server, "p", project, {"inputs": ["up"]}, tree, "blind")
        assert "a red image" in notes[0]
        assert refs == []
        notes, refs = await collab_runtime.share(server, "p", project, {"inputs": ["up"]}, tree, "vision")
        assert refs == [str(tree / "upstream.png")]
        assert mock.await_count == 1
