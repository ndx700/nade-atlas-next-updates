"""capabilities.py 的单元测试。"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import capabilities as cap


def account(**kw):
    base = {
        "connectors": {},
        "skills": [],
        "cap": None,
        "ask_first": False,
    }
    base.update(kw)
    return base


def project(**kw):
    base = {
        "mode": "solo",
        "caps": {},
        "connectors": {},
        "skills": [],
        "cap": None,
        "ask_first": False,
    }
    base.update(kw)
    return base


class ConstantsTest(unittest.TestCase):
    def test_caps_tuple(self):
        self.assertEqual(
            cap.CAPS,
            ("connectors", "skills", "nocturne", "metronome", "memory", "build", "search"),
        )

    def test_modes_tuple(self):
        self.assertEqual(cap.MODES, ("solo", "parallel", "concerto", "symphony"))

    def test_chinese_names_cover_everything(self):
        for name in cap.CAPS:
            self.assertIn(name, cap.CAP_CN)
        for name in cap.MODES:
            self.assertIn(name, cap.MODE_CN)


class DefaultsTest(unittest.TestCase):
    def test_solo_only_memory(self):
        caps = cap.defaults_for_mode("solo")
        self.assertEqual(set(caps), set(cap.CAPS))
        self.assertTrue(caps["memory"])
        for name in cap.CAPS:
            if name != "memory":
                self.assertFalse(caps[name], name)

    def test_symphony_defaults(self):
        caps = cap.defaults_for_mode("symphony")
        for name in ("connectors", "skills", "memory"):
            self.assertTrue(caps[name], name)
        self.assertFalse(caps["nocturne"])
        self.assertFalse(caps["metronome"])

    def test_parallel_concerto_only_memory(self):
        for mode in ("parallel", "concerto"):
            caps = cap.defaults_for_mode(mode)
            self.assertTrue(caps["memory"])
            self.assertNotIn("workstation", caps)

    def test_defaults_are_fresh_dicts(self):
        first = cap.defaults_for_mode("solo")
        first["nocturne"] = True
        second = cap.defaults_for_mode("solo")
        self.assertFalse(second["nocturne"])


class ModeTest(unittest.TestCase):
    def test_project_mode_passthrough(self):
        out = cap.effective(account(), project(mode="parallel"))
        self.assertEqual(out["mode"], "parallel")
        self.assertEqual(out["notes"], [])

    def test_segment_overrides_mode(self):
        out = cap.effective(account(), project(mode="solo"), {"mode": "concerto"})
        self.assertEqual(out["mode"], "concerto")
        self.assertTrue(any("协奏" in n for n in out["notes"]))

    def test_segment_invalid_mode_ignored(self):
        out = cap.effective(account(), project(mode="solo"), {"mode": "duet"})
        self.assertEqual(out["mode"], "solo")
        self.assertTrue(any("duet" in n for n in out["notes"]))

    def test_project_invalid_mode_falls_back(self):
        out = cap.effective(account(), project(mode="jazz"))
        self.assertEqual(out["mode"], "solo")
        self.assertTrue(any("jazz" in n for n in out["notes"]))

    def test_segment_same_mode_no_note(self):
        out = cap.effective(account(), project(mode="concerto"), {"mode": "concerto"})
        self.assertEqual(out["mode"], "concerto")
        self.assertEqual(out["notes"], [])


class ConnectorTest(unittest.TestCase):
    def acct(self, cid="github", enabled=True, max_level="write"):
        return account(connectors={cid: {"enabled": enabled, "max_level": max_level}})

    def test_project_level_within_account(self):
        out = cap.effective(self.acct(), project(connectors={"github": "read"}))
        self.assertEqual(out["connectors"], {"github": "read"})

    def test_project_level_clamped_to_account_max(self):
        out = cap.effective(
            self.acct(max_level="read"), project(connectors={"github": "write"})
        )
        self.assertEqual(out["connectors"]["github"], "read")
        self.assertTrue(any("github" in n for n in out["notes"]))

    def test_account_disabled_connector_dropped(self):
        out = cap.effective(
            self.acct(enabled=False), project(connectors={"github": "write"})
        )
        self.assertEqual(out["connectors"], {})
        self.assertTrue(any("github" in n for n in out["notes"]))

    def test_account_missing_connector_dropped(self):
        out = cap.effective(account(), project(connectors={"feishu": "read"}))
        self.assertEqual(out["connectors"], {})
        self.assertTrue(any("feishu" in n for n in out["notes"]))

    def test_bool_account_form_accepted(self):
        out = cap.effective(account(connectors={"github": True}),
                            project(connectors={"github": "write"}))
        self.assertEqual(out["connectors"], {"github": "write"})

    def test_segment_narrows_write_to_read(self):
        out = cap.effective(
            self.acct(),
            project(connectors={"github": "write"}),
            {"connectors": {"github": "read"}},
        )
        self.assertEqual(out["connectors"]["github"], "read")

    def test_segment_cannot_raise_level(self):
        out = cap.effective(
            self.acct(),
            project(connectors={"github": "read"}),
            {"connectors": {"github": "write"}},
        )
        self.assertEqual(out["connectors"]["github"], "read")
        self.assertTrue(any("github" in n for n in out["notes"]))

    def test_segment_unknown_connector_ignored(self):
        out = cap.effective(
            self.acct(), project(), {"connectors": {"notion": "read"}}
        )
        self.assertEqual(out["connectors"], {})
        self.assertTrue(any("notion" in n for n in out["notes"]))

    def test_garbage_level_ignored(self):
        out = cap.effective(self.acct(), project(connectors={"github": "admin"}))
        self.assertEqual(out["connectors"], {})


class SkillsTest(unittest.TestCase):
    def test_intersection_of_account_and_project(self):
        out = cap.effective(
            account(skills=["a", "b"]), project(skills=["b", "c"])
        )
        self.assertEqual(out["skills"], ["b"])
        self.assertTrue(any("c" in n for n in out["notes"]))

    def test_segment_narrows_skills(self):
        out = cap.effective(
            account(skills=["a", "b"]),
            project(skills=["a", "b"]),
            {"skills": ["a"]},
        )
        self.assertEqual(out["skills"], ["a"])
        self.assertTrue(any("b" in n for n in out["notes"]))

    def test_segment_cannot_add_skill(self):
        out = cap.effective(
            account(skills=["a", "b"]), project(skills=["a"]), {"skills": ["a", "b"]}
        )
        self.assertEqual(out["skills"], ["a"])
        self.assertTrue(any("不生效" in n for n in out["notes"]))

    def test_project_skill_not_in_account_dropped(self):
        out = cap.effective(account(skills=[]), project(skills=["web-review"]))
        self.assertEqual(out["skills"], [])

    def test_no_segment_keeps_project_skills(self):
        out = cap.effective(
            account(skills=["a"]), project(skills=["a"]), None
        )
        self.assertEqual(out["skills"], ["a"])


class CapTest(unittest.TestCase):
    def test_min_of_three_layers(self):
        out = cap.effective(
            account(cap=50.0), project(cap=20.0), {"cap": 10.0}
        )
        self.assertEqual(out["cap"], 10.0)

    def test_none_means_no_cap(self):
        out = cap.effective(account(cap=None), project(cap=None))
        self.assertIsNone(out["cap"])

    def test_single_layer_cap_wins(self):
        out = cap.effective(account(), project(cap=7.5))
        self.assertEqual(out["cap"], 7.5)

    def test_segment_higher_cap_clamped(self):
        out = cap.effective(account(), project(cap=5.0), {"cap": 99.0})
        self.assertEqual(out["cap"], 5.0)
        self.assertTrue(any("5" in n for n in out["notes"]))

    def test_zero_cap_is_respected(self):
        out = cap.effective(account(cap=0.0), project(cap=10.0))
        self.assertEqual(out["cap"], 0.0)


class AskFirstTest(unittest.TestCase):
    def test_or_of_layers(self):
        out = cap.effective(account(), project(), {"ask_first": True})
        self.assertTrue(out["ask_first"])

    def test_account_true_cascades(self):
        out = cap.effective(
            account(ask_first=True), project(), {"ask_first": False}
        )
        self.assertTrue(out["ask_first"])
        self.assertTrue(any("先问我再做" in n for n in out["notes"]))

    def test_segment_cannot_turn_off_project(self):
        out = cap.effective(account(), project(ask_first=True), {"ask_first": False})
        self.assertTrue(out["ask_first"])

    def test_all_false(self):
        out = cap.effective(account(), project(), {})
        self.assertFalse(out["ask_first"])


class CapsTest(unittest.TestCase):
    def test_result_has_all_caps(self):
        out = cap.effective(account(), project())
        self.assertEqual(set(out["caps"]), set(cap.CAPS))

    def test_symphony_defaults_flow_through(self):
        out = cap.effective(account(), project(mode="symphony"))
        self.assertTrue(out["caps"]["connectors"])
        self.assertNotIn("workstation", out["caps"])
        self.assertTrue(out["caps"]["memory"])

    def test_project_can_disable_default_cap(self):
        out = cap.effective(
            account(), project(mode="symphony", caps={"skills": False})
        )
        self.assertFalse(out["caps"]["skills"])
        self.assertTrue(out["caps"]["connectors"])

    def test_segment_cannot_enable_disabled_cap(self):
        out = cap.effective(
            account(), project(mode="concerto"), {"caps": {"nocturne": True}}
        )
        self.assertFalse(out["caps"]["nocturne"])
        self.assertTrue(any("夜曲" in n for n in out["notes"]))

    def test_segment_can_disable_cap(self):
        out = cap.effective(
            account(), project(mode="symphony"), {"caps": {"connectors": False}}
        )
        self.assertFalse(out["caps"]["connectors"])

    def test_unknown_project_cap_noted(self):
        out = cap.effective(account(), project(caps={"teleport": True}))
        self.assertTrue(any("teleport" in n for n in out["notes"]))


class ValidateComboTest(unittest.TestCase):
    def test_nocturne_without_metronome(self):
        warnings = cap.validate_combo("parallel", {"nocturne": True})
        self.assertTrue(any("节拍器" in w for w in warnings))

    def test_nocturne_with_metronome_ok(self):
        warnings = cap.validate_combo(
            "parallel", {"nocturne": True, "metronome": True}
        )
        self.assertFalse(any("已默认每小时" in w for w in warnings))

    def test_unknown_mode(self):
        warnings = cap.validate_combo("duet", {})
        self.assertTrue(any("duet" in w for w in warnings))

    def test_symphony_missing_caps(self):
        warnings = cap.validate_combo("symphony", {"memory": True})
        self.assertTrue(any("交响" in w for w in warnings))

    def test_clean_combo_returns_empty(self):
        self.assertEqual(
            cap.validate_combo(
                "concerto", {"connectors": True, "skills": True, "memory": True}
            ),
            [],
        )

    def test_unknown_cap_key(self):
        warnings = cap.validate_combo("solo", {"teleport": True})
        self.assertTrue(any("teleport" in w for w in warnings))

    def test_metronome_without_connectors(self):
        warnings = cap.validate_combo("solo", {"metronome": True})
        self.assertTrue(any("连接器" in w for w in warnings))


class CombosTest(unittest.TestCase):
    def test_at_least_four_combos(self):  # 并行+工位 dropped with 工位
        self.assertGreaterEqual(len(cap.COMBOS), 4)
        self.assertFalse(any("工位" in c["name"] for c in cap.COMBOS))

    def test_combo_shape(self):
        for combo in cap.COMBOS:
            self.assertIn("name", combo)
            self.assertIn("mode", combo)
            self.assertIn("caps", combo)
            self.assertIn("story", combo)
            self.assertIn(combo["mode"], cap.MODES)
            self.assertTrue(combo["name"])
            self.assertTrue(combo["story"])

    def test_combo_caps_are_known(self):
        for combo in cap.COMBOS:
            for name in combo["caps"]:
                self.assertIn(name, cap.CAPS)

    def test_combos_are_valid(self):
        for combo in cap.COMBOS:
            flags = {name: True for name in combo["caps"]}
            warnings = cap.validate_combo(combo["mode"], flags)
            self.assertFalse(
                any("不认识" in w or "未知" in w for w in warnings),
                msg=combo["name"],
            )

    def test_symphony_combo_present(self):
        modes = [c["mode"] for c in cap.COMBOS]
        self.assertIn("symphony", modes)


if __name__ == "__main__":
    unittest.main()
