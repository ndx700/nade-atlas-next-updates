import asyncio, os, tempfile, unittest
from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase
import collab_api, profiles, telemetry_events, orchestra


class Ingest(AioHTTPTestCase):
    async def get_application(self):
        import types
        self.tmp = tempfile.mkdtemp()
        import pathlib
        S = types.SimpleNamespace(DATA=pathlib.Path(self.tmp), CFG={}, PROJECTS=[])
        collab_api.S = S
        app = web.Application()
        app.router.add_post("/api/telemetry/ingest", collab_api.h_ingest)
        app.router.add_get("/api/profiles/latest", collab_api.h_profiles_latest)
        return app

    async def test_disabled_by_default_then_enabled(self):
        os.environ.pop("CHORUS_COLLECTOR", None)
        r = await self.client.post("/api/telemetry/ingest", json={"version": "x"})
        self.assertEqual(r.status, 404)
        os.environ["CHORUS_COLLECTOR"] = "1"
        try:
            r = await self.client.post("/api/telemetry/ingest", json={"version": "x", "date": "2026-11-01"})
            self.assertEqual(r.status, 200)
            r = await self.client.post("/api/telemetry/ingest", data=b"[1]")
            self.assertEqual(r.status, 400)
        finally:
            os.environ.pop("CHORUS_COLLECTOR", None)

    async def test_latest_profiles(self):
        r = await self.client.get("/api/profiles/latest")
        self.assertEqual(r.status, 200)
        self.assertIn("profiles", await r.json())

    def test_events_roundtrip(self):
        telemetry_events.record(self.tmp, {"model": "m", "task_type": "code", "outcome": "pass", "tokens": 5, "secret": "x"})
        import time
        rows = telemetry_events.read(self.tmp, time.time() - 5, time.time() + 5)
        self.assertEqual(rows, [{"model": "m", "task_type": "code", "outcome": "pass", "tokens": 5}])


if __name__ == "__main__":
    unittest.main()


class IngestProxy(unittest.TestCase):
    def test_xrealip_ignored_by_default(self):
        import types
        collab_api.S = types.SimpleNamespace(DATA=None, CFG={})
        os.environ.pop("CHORUS_TRUST_PROXY", None)
        self.assertFalse(os.environ.get("CHORUS_TRUST_PROXY"))
