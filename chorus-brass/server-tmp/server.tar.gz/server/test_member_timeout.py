"""Offline timeout regressions; fake answers, isolated DATA, no production calls."""
import asyncio
import json
import pathlib
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import server as s
from test_review_fixes import Request


class MemberTimeout(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.enterContext(patch("collab_api.consent_block", return_value=None))
        self.enterContext(patch("chorus2.account_block", return_value=None))
        self.enterContext(patch("chorus2.reserve_low"))
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.enterContext(patch.object(s, "DATA", pathlib.Path(self.tmp.name)))
        (s.DATA / "chats").mkdir()
        for name in ("CHATS", "ROOTS", "TASKS", "LOCKS", "QUEUED", "STATUS", "TASK_STATUS", "PVER",
                     "STOPPED_ROOTS", "STOP_AT"):
            self.enterContext(patch.object(s, name, {}))
        self.enterContext(patch.object(s, "CFG", {"owner": "测试群主", "members": [], "member_timeout_ms": 480000}))
        self.enterContext(patch.object(s, "CHANGED", asyncio.Event()))
        self.enterContext(patch.object(s, "VER", 0))
        self.clock = 1000.0
        self.enterContext(patch.object(s, "time", SimpleNamespace(time=time.time, monotonic=lambda: self.clock)))
        self.release = asyncio.Event()
        self.started = asyncio.Event()
        self.tasks = []
        self.addAsyncCleanup(self.stop_tasks)

    async def stop_tasks(self):
        for task in self.tasks:
            task.cancel()
        await asyncio.wait_for(asyncio.gather(*self.tasks, return_exceptions=True), 5)

    async def start(self, name="A", pid="p", root="root", dm="", opts=None):
        async def answer(*args):
            self.started.set()
            await asyncio.wait_for(self.release.wait(), 5)
        self.enterContext(patch.object(s, "answer", answer))
        task = asyncio.create_task(s.run_member(pid, name, {"dm": dm}, {"root_id": root, **(opts or {})}))
        self.tasks.append(task)
        await asyncio.sleep(0)
        return task

    def advance(self, seconds):
        self.clock += seconds
        s.scan_member_timeouts()

    async def test_boundary_warns_once_and_does_not_stop_execution(self):
        task = await self.start()
        self.advance(479)
        self.assertEqual(s.CHATS, {})
        self.advance(1)
        message = s.CHATS["p"][0]
        self.assertEqual((message["level"], message["type"], message["root_id"]),
                         ("warn", "member_timeout", "root"))
        self.assertEqual((message["elapsed_ms"], message["member"]), (480000, "A"))
        self.assertIn("@测试群主", message["text"])
        self.assertFalse(task.done())
        self.advance(999)
        self.assertEqual(len(s.CHATS["p"]), 1)
        self.assertEqual(len(s.load_chat("p")), 1)

    async def test_waiting_for_lock_does_not_count(self):
        lock = s.LOCKS[("p", "A")] = asyncio.Lock()
        await lock.acquire()
        task = await self.start()
        self.advance(900)
        self.assertEqual(s.CHATS, {})
        lock.release()
        await asyncio.sleep(0)
        self.advance(479)
        self.assertEqual(s.CHATS, {})
        self.advance(1)
        self.assertEqual(s.CHATS["p"][0]["elapsed_ms"], 480000)
        self.assertFalse(task.done())

    async def test_denied_budget_never_arms_warning(self):
        task = await self.start(opts={"_budget": {"stopped": True}})
        await asyncio.wait_for(task, 5)
        self.advance(900)
        self.assertEqual(s.CHATS, {})
        self.assertEqual(s.ROOTS, {})

    async def test_completion_clears_watch_and_next_run_can_warn(self):
        task = await self.start()
        self.release.set()
        await asyncio.wait_for(task, 5)
        self.assertEqual(s.ROOTS, {})
        self.advance(900)
        self.assertEqual(s.CHATS, {})
        self.release.clear()
        await self.start(root="next")
        self.advance(480)
        self.assertEqual(s.CHATS["p"][0]["root_id"], "next")

    async def test_cancel_clears_watch_and_releases_lock(self):
        task = await self.start()
        task.cancel()
        await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 5)
        self.advance(900)
        self.assertEqual(s.ROOTS, {})
        self.assertFalse(s.TASKS["A"])
        self.assertFalse(s.LOCKS[("p", "A")].locked())
        self.assertEqual(s.CHATS, {})

    async def test_parallel_members_are_timed_independently(self):
        await self.start(name="A")
        self.advance(300)
        await self.start(name="B")
        self.advance(180)
        self.assertEqual([m["member"] for m in s.CHATS["p"]], ["A"])
        self.advance(300)
        self.assertEqual([m["member"] for m in s.CHATS["p"]], ["A", "B"])

    async def test_same_member_priority_runs_keep_own_room_and_dm(self):
        await self.start(pid="p", root="public")
        await self.start(pid="q", root="private", dm="A", opts={"priority": "now"})
        self.advance(480)
        self.assertEqual((s.CHATS["p"][0]["dm"], s.CHATS["p"][0]["root_id"]), ("", "public"))
        self.assertEqual((s.CHATS["q"][0]["dm"], s.CHATS["q"][0]["root_id"]), ("A", "private"))

    async def test_wall_clock_jump_does_not_change_elapsed(self):
        await self.start()
        with patch.object(s.time, "time", return_value=1e12):
            self.advance(479)
        self.assertEqual(s.CHATS, {})
        with patch.object(s.time, "time", return_value=0):
            self.advance(1)
        self.assertEqual(s.CHATS["p"][0]["elapsed_ms"], 480000)

    async def test_settings_validate_before_mutating_and_persist(self):
        for value in (-1, True, "480000", None, 1.5, [], {}):
            with self.subTest(value=value), patch.object(s, "save_cfg") as save:
                with self.assertRaises(s.web.HTTPBadRequest):
                    await s.h_settings(Request({"name": "must not change", "member_timeout_ms": value}))
                self.assertNotIn("name", s.CFG)
                save.assert_not_called()
        with patch.object(s, "save_cfg") as save:
            res = await s.h_settings(Request({"member_timeout_ms": 10000}))
            self.assertEqual(json.loads(res.body)["member_timeout_ms"], 10000)
            save.assert_called_once()
        await self.start()
        self.advance(10)
        self.assertEqual(s.CHATS["p"][0]["elapsed_ms"], 10000)

    async def test_old_or_invalid_config_disables_warning(self):
        s.CFG.pop("member_timeout_ms")
        self.assertEqual(s.member_timeout_ms(), 0)
        self.assertEqual(s.SETTING_KEYS["member_timeout_ms"], 0)
        await self.start()
        self.advance(36000)
        self.assertEqual(s.CHATS, {})
        for value in (None, 0, -1, "bad", True, [], float("nan")):
            s.CFG["member_timeout_ms"] = value
            self.assertEqual(s.member_timeout_ms(), 0)
            self.advance(36000)
            self.assertEqual(s.CHATS, {})

    async def test_settings_zero_disables_running_watch_and_can_reenable(self):
        task = await self.start()
        with patch.object(s, "save_cfg") as save:
            res = await s.h_settings(Request({"member_timeout_ms": 0}))
            self.assertEqual(json.loads(res.body)["member_timeout_ms"], 0)
            save.assert_called_once()
        self.advance(900)
        self.assertEqual(s.CHATS, {})
        self.assertFalse(task.done())
        await s.h_settings(Request({"member_timeout_ms": 1000}))
        self.advance(1)
        self.assertEqual(s.CHATS["p"][0]["member"], "A")

    async def test_context_starts_and_stops_scanner(self):
        started = asyncio.Event()
        stopped = asyncio.Event()
        async def scanner():
            started.set()
            try:
                await asyncio.wait_for(asyncio.Event().wait(), 5)
            finally:
                stopped.set()
        with patch.object(s, "member_timeout_loop", scanner):
            ctx = s.member_timeout_context(None)
            await asyncio.wait_for(anext(ctx), 5)
            await asyncio.wait_for(started.wait(), 5)
            with self.assertRaises(StopAsyncIteration):
                await asyncio.wait_for(anext(ctx), 5)
        self.assertTrue(stopped.is_set())
        self.assertIn(s.member_timeout_context, s.make_app().cleanup_ctx)


if __name__ == "__main__":
    unittest.main()
