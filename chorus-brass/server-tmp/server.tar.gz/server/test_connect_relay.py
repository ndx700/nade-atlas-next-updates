import types, unittest, connect


class Relay(unittest.TestCase):
    def setUp(self):
        connect.S = types.SimpleNamespace(CATALOG=[])

    def test_odd_key_with_url(self):
        r = connect.detect("https://relay.example.com 密钥 abcDEF1234567890xyzABC")
        self.assertEqual([b for _k, _v, b in r], ["https://relay.example.com", "https://relay.example.com/v1"])

    def test_url_with_v1_not_duplicated(self):
        r = connect.detect("https://r.example.com/v1\nsk-abc12345678901234567890123456789012")
        self.assertEqual([b for _k, _v, b in r], ["https://r.example.com/v1"])

    def test_mimo_payg_key_is_probed(self):
        r = connect.detect("sk-abc12345678901234567890123456789012")
        self.assertIn("https://api.xiaomimimo.com/v1", [v[3] for _k, v, _b in r])

    def test_mimo_plan_key(self):
        r = connect.detect("tp-abcdefghij0123456789")
        self.assertEqual(r[0][1][3], "https://token-plan-cn.xiaomimimo.com/v1")


if __name__ == "__main__":
    unittest.main()
