"""完全托管 (autopilot) cost policy — deterministic, standard library only.

The autopilot is the default operating mode of Chorus.  Its single objective is
to minimise money spent and quota consumed while still finishing the work:

* prefer funded capacity (MiMo Token Plan / subscriptions / free tiers) over
  pay-as-you-go,
* pick the cheapest model that is *capable enough* for the tier of work,
* wake as few members as possible,
* batch cheap ready work into a single call,
* spend less (and review less) as the budget cap is approached,
* cache the stable prompt prefix so provider prefix caching actually hits.

Everything here is pure and deterministic — no I/O, no clock, no randomness.
"""

from __future__ import annotations

__all__ = [
    "FUNDING_ORDER",
    "TIER_ORDER",
    "LABEL",
    "funding_of",
    "rank_candidates",
    "escalate",
    "should_wake",
    "batch",
    "budget_mode",
    "review_policy",
    "cache_plan",
    "counterfactual",
    "stop_early",
]

#: Preferred funding sources, cheapest-for-the-user first.
FUNDING_ORDER = ("prepaid_plan", "subscription", "free", "payg")

#: Capability ladder, weakest first.
TIER_ORDER = ("weak", "mid", "strong")

#: Baseline figure is an estimate, never an invoice.
LABEL = "估算"

_FUNDING_INDEX = {name: idx for idx, name in enumerate(FUNDING_ORDER)}
_TIER_INDEX = {name: idx for idx, name in enumerate(TIER_ORDER)}

_PREFERRED_FUNDING = ("prepaid_plan", "subscription", "free")


# --------------------------------------------------------------------------- #
# small helpers
# --------------------------------------------------------------------------- #
def _num(value, default: float = 0.0) -> float:
    """Best-effort float conversion; never raises."""
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _tier_rank(tier) -> int:
    """Map a tier name (or number) onto the capability ladder."""
    if isinstance(tier, int) and not isinstance(tier, bool):
        return max(0, min(tier, len(TIER_ORDER) - 1))
    return _TIER_INDEX.get(str(tier), 1)


def _name_of(member: dict) -> str:
    member = member or {}
    name = member.get("name")
    if name is None:
        name = member.get("id")
    return "" if name is None else str(name)


def _quota_for(member: dict, quotas) -> dict | None:
    if not quotas or not isinstance(quotas, dict):
        return None
    member = member or {}
    for key in (member.get("name"), member.get("id")):
        if key is None:
            continue
        quota = quotas.get(key)
        if isinstance(quota, dict):
            return quota
        if quota is not None and not isinstance(quota, dict):
            return None
    return None


def _pct_of(quota: dict | None):
    if not quota:
        return None
    pct = quota.get("pct")
    if pct is None:
        used = _num(quota.get("used_pct"), None)
        return 100.0 - used if used is not None else None
    if pct is None:
        return None
    return _num(pct)


# --------------------------------------------------------------------------- #
# funding
# --------------------------------------------------------------------------- #
def funding_of(member: dict, quota: dict | None) -> str:
    """Which purse pays for this member right now.

    Order of precedence: explicit ``member["funding"]``, then a plan quota
    (MiMo Token Plan style prepaid), then CLI subscriptions / window quotas,
    then free tiers, and pay-as-you-go only as a last resort.
    """
    member = member or {}
    explicit = member.get("funding")
    if explicit:
        return str(explicit)

    if isinstance(quota, dict) and quota.get("kind") == "plan":
        return "prepaid_plan"

    if member.get("kind") == "cli":
        return "subscription"
    if isinstance(quota, dict) and quota.get("kind") == "window":
        return "subscription"

    price = member.get("price")
    if price is None and isinstance(quota, dict):
        price = quota.get("price")
    if price is not None and _num(price) == 0.0:
        return "free"

    return "payg"


# --------------------------------------------------------------------------- #
# ranking
# --------------------------------------------------------------------------- #
def rank_candidates(
    members: list[dict],
    quotas: dict,
    need_tier: str,
    price_of,
    tier_of,
    near_cap: bool = False,
) -> list[str]:
    """Return member names able to do ``need_tier`` work, cheapest policy first.

    Filtering removes anything not capable enough, anything in arrears and
    anything whose remaining quota is effectively exhausted (<5%).

    Ordering is ``(funding, tier, unit price, name)``: funded capacity first,
    then the *cheapest capable* tier, then the cheapest unit price.
    """
    need = _tier_rank(need_tier)
    rows: list[dict] = []

    for member in members or []:
        member = member or {}
        quota = _quota_for(member, quotas)

        try:
            tier = _tier_rank(tier_of(member))
        except Exception:  # pragma: no cover - defensive, tier_of is pure
            tier = _TIER_INDEX["mid"]
        if tier < need:
            continue

        if isinstance(quota, dict) and quota.get("state") == "arrears":
            continue

        pct = _pct_of(quota)
        if pct is not None and pct < 5:
            continue

        try:
            price = _num(price_of(member))
        except Exception:  # pragma: no cover - defensive
            price = 0.0

        rows.append(
            {
                "name": _name_of(member),
                "funding": funding_of(member, quota),
                "tier": tier,
                "price": price,
            }
        )

    if near_cap:
        preferred = [row for row in rows if row["funding"] in _PREFERRED_FUNDING]
        if preferred:
            rows = preferred
        else:
            rows = [row for row in rows if row["funding"] == "payg"]

    rows.sort(
        key=lambda row: (
            _FUNDING_INDEX.get(row["funding"], len(FUNDING_ORDER)),
            row["tier"],
            row["price"],
            row["name"],
        )
    )
    return [row["name"] for row in rows]


def escalate(current: str, members, quotas, price_of, tier_of) -> str | None:
    """Next member one tier up, following the same cost ordering."""
    members = members or []
    chosen = None
    for member in members:
        if _name_of(member) == current:
            chosen = member
            break
    if chosen is None:
        return None

    try:
        current_rank = _tier_rank(tier_of(chosen))
    except Exception:  # pragma: no cover - defensive
        current_rank = _TIER_INDEX["mid"]

    target_rank = current_rank + 1
    if target_rank >= len(TIER_ORDER):
        return None

    ordered = rank_candidates(
        members, quotas, TIER_ORDER[target_rank], price_of, tier_of, near_cap=False
    )
    for name in ordered:
        if name == current:
            continue
        for member in members:
            if _name_of(member) != name:
                continue
            try:
                rank = _tier_rank(tier_of(member))
            except Exception:  # pragma: no cover - defensive
                rank = -1
            if rank == target_rank:
                return name
            break
    return None


# --------------------------------------------------------------------------- #
# wake policy
# --------------------------------------------------------------------------- #
def should_wake(member_name: str, project: dict, segment: dict | None) -> bool:
    """Idle members are never woken; the lead only for plan/review events."""
    project = project or {}
    event = segment or {}

    mentions = event.get("mentions") or []
    if member_name in mentions:
        return True

    for seg in project.get("segments") or []:
        seg = seg or {}
        if seg.get("assignee") == member_name and seg.get("status") in ("ready", "running"):
            return True

    if event.get("assignee") == member_name and event.get("status") in ("ready", "running"):
        return True

    is_lead = project.get("lead") == member_name or event.get("lead") == member_name
    if is_lead:
        return event.get("kind") in ("plan", "review")

    return False


# --------------------------------------------------------------------------- #
# batching
# --------------------------------------------------------------------------- #
def batch(segments: list[dict], max_tokens: int = 6000) -> list[list[dict]]:
    """Group cheap ready work into one call; everything else goes alone.

    A segment may join the previous call only when it is READY, has difficulty
    ≤ 2, shares the assignee and keeps the estimated token sum within
    ``max_tokens``.  Input order is preserved in the output.
    """
    groups: list[list[dict]] = []
    meta: list[dict] = []

    for raw in segments or []:
        seg = raw or {}
        difficulty = _num(seg.get("difficulty"), 0.0)
        est = int(_num(seg.get("est_tokens"), 0.0))
        assignee = seg.get("assignee")
        batchable = (
            seg.get("status") == "ready"
            and difficulty <= 2
            and assignee not in (None, "")
        )

        if (
            batchable
            and groups
            and meta[-1]["batchable"]
            and meta[-1]["assignee"] == assignee
            and meta[-1]["tokens"] + est <= max_tokens
        ):
            groups[-1].append(seg)
            meta[-1]["tokens"] += est
            continue

        groups.append([seg])
        meta.append({"batchable": batchable, "assignee": assignee, "tokens": est})

    return groups


# --------------------------------------------------------------------------- #
# budget
# --------------------------------------------------------------------------- #
def budget_mode(spent: float, cap: float) -> str:
    """``normal`` / ``frugal`` / ``minimal`` / ``stop`` from spend ratio."""
    spent = _num(spent)
    cap = _num(cap)
    if cap <= 0:
        return "stop" if spent > 0 else "normal"
    ratio = spent / cap
    if ratio < 0.7:
        return "normal"
    if ratio < 0.9:
        return "frugal"
    if ratio < 1.0:
        return "minimal"
    return "stop"


def review_policy(mode: str, seg: dict, pass_rate: float) -> bool:
    """Whether a review round is worth paying for in this budget mode."""
    seg = seg or {}
    if seg.get("quality") == "max":
        return True
    difficulty = _num(seg.get("difficulty"), 0.0)
    rate = _num(pass_rate, 0.0)

    if mode == "normal":
        return difficulty >= 3 or rate < 0.7
    if mode == "frugal":
        return difficulty >= 4 or rate < 0.5
    if mode == "minimal":
        return difficulty == 5
    return False


# --------------------------------------------------------------------------- #
# prompt caching
# --------------------------------------------------------------------------- #
def cache_plan(system: str, persona: str, skills: str, task: str) -> list[dict]:
    """OpenAI-style messages with the stable, cacheable prefix first."""
    parts = [part for part in (system, persona, skills) if part]
    prefix = "\n\n".join(parts)
    return [
        {"role": "system", "content": prefix, "cache": True},
        {"role": "user", "content": task},
    ]


# --------------------------------------------------------------------------- #
# counterfactual savings
# --------------------------------------------------------------------------- #
def counterfactual(ledger: list[dict], strongest_price: tuple[float, float, float]) -> dict:
    """What the same tokens would have cost on the strongest model.

    ``strongest_price`` is ``(input, cached_input, output)`` per 1e6 tokens.
    """
    try:
        price_in, price_cached, price_out = strongest_price
    except (TypeError, ValueError):
        price_in, price_cached, price_out = 0.0, 0.0, 0.0

    price_in = _num(price_in)
    price_cached = _num(price_cached)
    price_out = _num(price_out)

    actual = 0.0
    baseline = 0.0
    for raw in ledger or []:
        row = raw or {}
        tokens_in = _num(row.get("in"), 0.0)
        tokens_out = _num(row.get("out"), 0.0)
        tokens_cached = _num(row.get("cached"), 0.0)
        actual += _num(row.get("cost"), 0.0)
        baseline += (
            (tokens_in - tokens_cached) * price_in
            + tokens_cached * price_cached
            + tokens_out * price_out
        ) / 1_000_000.0

    saved = baseline - actual
    pct = (saved / baseline * 100.0) if baseline else 0.0
    return {
        "actual": actual,
        "baseline": baseline,
        "saved": saved,
        "pct": pct,
        "label": LABEL,
    }


# --------------------------------------------------------------------------- #
# early stop
# --------------------------------------------------------------------------- #
def stop_early(acceptance_results: list[bool]) -> bool:
    """True once every acceptance check passed — no extra review/polish round."""
    results = list(acceptance_results or [])
    if not results:
        return False
    return all(bool(item) for item in results)


def enabled(config: dict, key: str) -> bool:
    options = config.get("autopilot")
    return isinstance(options, dict) and options.get(key) is True


def validate_options(value):
    keys = {"batch", "cache_plan"}
    if not isinstance(value, dict) or value.keys() - keys or any(type(v) is not bool for v in value.values()):
        raise ValueError("autopilot 只接受 batch/cache_plan 布尔开关")
    return {key: value.get(key, False) for key in sorted(keys)}


def merge_ready(project: dict) -> bool:
    """Contract fresh cheap siblings before dispatch; retain every check and task card."""
    import copy
    import orchestra
    if project.get("quality") == "max":
        return False
    ready_ids = {s["id"] for s in orchestra.ready(project["segments"])}
    eligible = []
    for seg in project["segments"]:
        # Missing estimates, recovery state and per-task policies are unsafe to combine.
        safe = (seg["id"] in ready_ids and not seg.get("started")
                and not seg.get("ladder") and not seg.get("batch_segments")
                and not seg.get("retry_action") and not seg.get("retry_at")
                and not (seg.get("spend") or {}).get("cost")
                and seg.get("quality", "standard") != "max"
                and isinstance(seg.get("est_tokens"), int) and 0 < seg["est_tokens"] <= 6000
                and seg.get("difficulty") in (1, 2))
        eligible.append({**seg, "status": "ready" if safe else "ineligible"})
    aliases = {}
    by_id = {s["id"]: s for s in project["segments"]}
    for group in batch(eligible):
        # Same dependencies and execution policy; no dependency contraction cycles.
        if len(group) < 2 or any(set(s.get("inputs", [])) != set(group[0].get("inputs", [])) for s in group):
            continue
        task_fields = {"id", "title", "goal", "deliverable", "acceptance", "checks", "context",
                       "est_tokens", "status", "events", "difficulty"}
        def policy(seg):
            return {k: v for k, v in seg.items() if k not in task_fields}
        if any(policy(seg) != policy(group[0]) for seg in group[1:]):
            continue
        originals = [copy.deepcopy(by_id[s["id"]]) for s in group]
        target = by_id[group[0]["id"]]
        target["batch_segments"] = originals
        for key in ("title", "goal", "deliverable", "context"):
            target[key] = "\n".join(f"[{s['id']}] {s.get(key, '')}" for s in originals)
        for key in ("acceptance", "checks"):
            target[key] = [item for s in originals for item in s.get(key, [])]
        target["difficulty"] = max(s["difficulty"] for s in originals)
        target["est_tokens"] = sum(s["est_tokens"] for s in originals)
        aliases.update({s["id"]: target["id"] for s in originals[1:]})
    if not aliases:
        return False
    project["segments"] = [s for s in project["segments"] if s["id"] not in aliases]
    for seg in project["segments"]:
        seg["inputs"] = list(dict.fromkeys(aliases.get(i, i) for i in seg.get("inputs", [])))
    return True
