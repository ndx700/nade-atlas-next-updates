"""server/hooks.py 的离线单测（pytest / unittest 均可运行）。

运行：
    python -m pytest server/test_hooks.py -q
    python -m unittest server.test_hooks -v
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from hooks import (  # noqa: E402
    DEFAULT_POLICIES,
    TRUNCATE_LIMIT_BYTES,
    AuditLogger,
    Decision,
    HookEngine,
    HookEvent,
    Policy,
    Matcher,
    AskRequest,
    redact_args,
    truncate_text,
)


def run(coro):
    """同步跑协程的辅助（兼容 unittest 与 pytest）。"""
    return asyncio.run(coro)


class BaseHookTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.audit_path = Path(self.tmp.name) / "audit.jsonl"
        self.engine = HookEngine(audit_path=self.audit_path, session_id="test-session")

    def tearDown(self) -> None:
        self.tmp.cleanup()


# --------------------------------------------------------------------------- #
# 策略 1：危险命令 -> deny
# --------------------------------------------------------------------------- #
class TestDangerousCommandPolicy(BaseHookTest):
    async def test_rm_rf_root_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL,
            tool="bash",
            args={"command": "rm -rf /"},
        )
        self.assertIs(result.decision, Decision.DENY)
        self.assertEqual(result.policy_id, "dangerous-command")

    async def test_mkfs_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "sudo mkfs.ext4 /dev/sda1"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_dd_of_dev_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "dd if=/dev/zero of=/dev/sda"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_shutdown_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "shutdown -h now"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_git_push_force_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "git push --force origin main"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_safe_command_allowed(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls -la"}
        )
        self.assertIs(result.decision, Decision.ALLOW)


# --------------------------------------------------------------------------- #
# 策略 2：敏感文件 -> deny（读也记审计）
# --------------------------------------------------------------------------- #
class TestSensitiveFilePolicy(BaseHookTest):
    async def test_env_file_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/app/.env"}
        )
        self.assertIs(result.decision, Decision.DENY)
        self.assertEqual(result.policy_id, "sensitive-file")

    async def test_pem_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/etc/ssl/server.pem"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_id_rsa_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/home/u/.ssh/id_rsa"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_credentials_glob_denied(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/app/credentials.json"}
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_read_is_audited(self) -> None:
        await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/app/.env"}
        )
        records = self.engine.audit_logger.query(decision=Decision.DENY)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].policy_id, "sensitive-file")
        self.assertEqual(records[0].tool, "read_file")

    async def test_normal_file_allowed(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "/app/src/main.py"}
        )
        self.assertIs(result.decision, Decision.ALLOW)


# --------------------------------------------------------------------------- #
# 策略 3：不可逆操作 -> ask（定音卡）
# --------------------------------------------------------------------------- #
class TestIrreversiblePolicy(BaseHookTest):
    async def test_delete_project_asks(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="delete_project", args={"project_id": "demo"}
        )
        self.assertIs(result.decision, Decision.ASK)
        self.assertIsNotNone(result.ask)

    async def test_irreversible_match_still_requires_before_tool(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.ON_STOP, tool="publish", args={"command": "发布到生产"}
        )
        self.assertIs(result.decision, Decision.ALLOW)

    async def test_unrelated_tool_and_args_allowed(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="bash", args={"command": "echo hello"}
        )
        self.assertIs(result.decision, Decision.ALLOW)

    async def test_publish_asks(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="publish", args={"target": "production"}
        )
        self.assertIs(result.decision, Decision.ASK)
        self.assertIsNotNone(result.ask)
        self.assertEqual(result.ask.policy_id, "irreversible-action")

    async def test_keyword_in_command_asks(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL,
            tool="bash",
            args={"command": "请帮我发布到生产环境"},
        )
        self.assertIs(result.decision, Decision.ASK)

    async def test_payment_asks(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="payment", args={"amount": 99}
        )
        self.assertIs(result.decision, Decision.ASK)

    async def test_send_email_asks(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="send_email", args={"to": "a@b.com"}
        )
        self.assertIs(result.decision, Decision.ASK)

    async def test_ask_request_is_structured(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="publish", args={"target": "production"}
        )
        payload = result.ask.to_dict()
        for key in ("request_id", "policy_id", "event", "summary", "reason", "options", "args_preview"):
            self.assertIn(key, payload)
        self.assertEqual(payload["event"], "before_tool")
        self.assertTrue(payload["options"])

    async def test_ask_request_resolvable_by_relay(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="publish", args={"target": "production"}
        )
        request_id = result.ask.request_id
        self.assertIsNotNone(self.engine.get_ask_request(request_id))
        resolution = self.engine.resolve_ask(request_id, "approve")
        self.assertEqual(resolution["decision"], "allow")
        self.assertEqual(resolution["request_id"], request_id)

    async def test_ask_request_deny_resolution(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="publish", args={"target": "production"}
        )
        resolution = self.engine.resolve_ask(result.ask.request_id, "deny")
        self.assertEqual(resolution["decision"], "deny")

    async def test_ask_request_serializable_roundtrip(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL, tool="publish", args={"target": "production"}
        )
        raw = json.dumps(result.ask.to_dict(), ensure_ascii=False)
        restored = AskRequest.from_dict(json.loads(raw))
        self.assertEqual(restored.request_id, result.ask.request_id)
        self.assertEqual(restored.policy_id, "irreversible-action")


# --------------------------------------------------------------------------- #
# 策略 4：输出过长 -> truncate
# --------------------------------------------------------------------------- #
class TestTruncatePolicy(BaseHookTest):
    async def test_long_output_truncated(self) -> None:
        long_output = "A" * (TRUNCATE_LIMIT_BYTES + 1000)
        result = await self.engine.dispatch(
            HookEvent.AFTER_TOOL,
            tool="bash",
            args={"command": "cat big.log"},
            output=long_output,
        )
        self.assertIs(result.decision, Decision.TRUNCATE)
        self.assertIsNotNone(result.truncated_output)
        self.assertTrue(result.truncate_meta["truncated"])
        self.assertLess(
            len(result.truncated_output.encode("utf-8")),
            len(long_output.encode("utf-8")),
        )

    async def test_truncated_output_keeps_head_and_tail(self) -> None:
        head_marker = "HEAD_MARKER"
        tail_marker = "TAIL_MARKER"
        body = head_marker + "x" * (TRUNCATE_LIMIT_BYTES + 500) + tail_marker
        result = await self.engine.dispatch(
            HookEvent.AFTER_TOOL, tool="bash", args={"command": "cat"}, output=body
        )
        self.assertIn(head_marker, result.truncated_output)
        self.assertIn(tail_marker, result.truncated_output)

    async def test_truncated_output_has_citation(self) -> None:
        body = "y" * (TRUNCATE_LIMIT_BYTES + 10)
        result = await self.engine.dispatch(
            HookEvent.AFTER_TOOL, tool="bash", args={"command": "cat"}, output=body
        )
        self.assertIn("引用", result.truncated_output)
        self.assertIn("sha256", result.truncated_output)

    async def test_short_output_not_truncated(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.AFTER_TOOL, tool="bash", args={"command": "cat"}, output="short"
        )
        self.assertIs(result.decision, Decision.ALLOW)

    def test_truncate_text_helper(self) -> None:
        text = "z" * 20000
        out, meta = truncate_text(text, limit=1000, head=400, tail=200)
        self.assertTrue(meta["truncated"])
        self.assertLess(len(out), len(text))
        self.assertIn("sha256", out)


# --------------------------------------------------------------------------- #
# 策略 5：全量审计 -> audit.jsonl（不含敏感值）
# --------------------------------------------------------------------------- #
class TestAuditPolicy(BaseHookTest):
    async def test_all_before_tool_audited(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="read_file", args={"path": "a.txt"})
        records = self.engine.audit_logger.query(event=HookEvent.BEFORE_TOOL)
        self.assertEqual(len(records), 2)

    async def test_audit_file_is_jsonl(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        self.assertTrue(self.audit_path.exists())
        lines = self.audit_path.read_text(encoding="utf-8").strip().splitlines()
        self.assertEqual(len(lines), 1)
        payload = json.loads(lines[0])
        self.assertIn("audit_id", payload)
        self.assertIn("decision", payload)
        self.assertIn("args", payload)

    async def test_audit_does_not_contain_sensitive_values(self) -> None:
        secret = "super-secret-token-123456"
        await self.engine.dispatch(
            HookEvent.BEFORE_TOOL,
            tool="http_request",
            args={"token": secret, "password": "hunter2", "url": "https://api.example.com"},
        )
        raw = self.audit_path.read_text(encoding="utf-8")
        self.assertNotIn(secret, raw)
        self.assertNotIn("hunter2", raw)
        self.assertIn("redacted", raw)

    async def test_audit_records_policy_and_decision(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "rm -rf /"})
        record = self.engine.audit_logger.read_all()[0]
        self.assertEqual(record.decision, Decision.DENY)
        self.assertEqual(record.policy_id, "dangerous-command")
        self.assertEqual(record.session_id, "test-session")

    async def test_audit_query_by_tool(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="git", args={"command": "status"})
        records = self.engine.audit_logger.query(tool="git")
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].tool, "git")

    async def test_audit_export_jsonl(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        target = Path(self.tmp.name) / "export.jsonl"
        self.engine.audit_logger.export_jsonl(target)
        self.assertTrue(target.exists())
        lines = target.read_text(encoding="utf-8").strip().splitlines()
        self.assertEqual(len(lines), 1)

    async def test_audit_export_json(self) -> None:
        await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        target = Path(self.tmp.name) / "export.json"
        self.engine.audit_logger.export_json(target)
        payload = json.loads(target.read_text(encoding="utf-8"))
        self.assertIsInstance(payload, list)
        self.assertEqual(len(payload), 1)


# --------------------------------------------------------------------------- #
# 引擎通用行为
# --------------------------------------------------------------------------- #
class TestHookEngine(BaseHookTest):
    def test_default_policies_count(self) -> None:
        self.assertEqual(len(DEFAULT_POLICIES), 5)
        ids = {policy.id for policy in DEFAULT_POLICIES}
        self.assertEqual(
            ids,
            {"dangerous-command", "sensitive-file", "irreversible-action", "output-too-long", "audit-all"},
        )

    def test_default_policies_cover_all_decisions(self) -> None:
        decisions = {policy.decision for policy in DEFAULT_POLICIES}
        self.assertIn(Decision.DENY, decisions)
        self.assertIn(Decision.ASK, decisions)
        self.assertIn(Decision.TRUNCATE, decisions)
        self.assertIn(Decision.ALLOW, decisions)

    async def test_deny_takes_precedence_over_ask(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL,
            tool="publish",
            args={"command": "rm -rf /", "target": "production"},
        )
        self.assertIs(result.decision, Decision.DENY)

    async def test_rewrite_strips_skip_approval_flags(self) -> None:
        policy = Policy(
            id="strip-skip",
            name="剥离跳过审批参数",
            description="",
            matcher=Matcher(events=frozenset({HookEvent.BEFORE_TOOL}), tools=("bash",)),
            decision=Decision.REWRITE,
            priority=5,
        )
        self.engine.add_policy(policy)
        result = await self.engine.dispatch(
            HookEvent.BEFORE_TOOL,
            tool="bash",
            args={"command": "deploy --yes --no-approve"},
        )
        self.assertIs(result.decision, Decision.REWRITE)
        self.assertNotIn("--yes", result.rewritten_args["command"])
        self.assertNotIn("--no-approve", result.rewritten_args["command"])

    async def test_custom_handler_overrides(self) -> None:
        policy = Policy(
            id="custom",
            name="custom",
            description="",
            matcher=Matcher(events=frozenset({HookEvent.BEFORE_TOOL})),
            decision=Decision.ALLOW,
            priority=1,
        )
        self.engine.add_policy(policy)

        def handler(ctx):
            from hooks import HookResult

            return HookResult(decision=Decision.DENY, reason="custom deny", policy_id="custom")

        self.engine.register_handler("custom", handler)
        result = await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        self.assertIs(result.decision, Decision.DENY)
        self.assertEqual(result.reason, "custom deny")

    async def test_on_stop_event_allowed(self) -> None:
        result = await self.engine.dispatch(HookEvent.ON_STOP, tool=None, args={})
        self.assertIs(result.decision, Decision.ALLOW)

    async def test_before_llm_event(self) -> None:
        result = await self.engine.dispatch(
            HookEvent.BEFORE_LLM, tool=None, args={"prompt": "hello"}
        )
        self.assertIs(result.decision, Decision.ALLOW)

    async def test_result_serializable(self) -> None:
        result = await self.engine.dispatch(HookEvent.BEFORE_TOOL, tool="bash", args={"command": "ls"})
        payload = result.to_dict()
        self.assertEqual(payload["decision"], "allow")
        self.assertIn("audit_id", payload)


# --------------------------------------------------------------------------- #
# redact_args
# --------------------------------------------------------------------------- #
class TestRedactArgs(unittest.TestCase):
    def test_sensitive_keys_redacted(self) -> None:
        out = redact_args({"token": "abc123", "password": "pw", "url": "https://x"})
        self.assertTrue(out["token"]["redacted"])
        self.assertTrue(out["password"]["redacted"])
        self.assertEqual(out["url"], "https://x")

    def test_no_plaintext_secret(self) -> None:
        secret = "TOP-SECRET-VALUE"
        out = redact_args({"api_key": secret})
        self.assertNotIn(secret, json.dumps(out))

    def test_long_value_summarized(self) -> None:
        out = redact_args({"body": "x" * 5000})
        self.assertIn("summary", out["body"])
        self.assertEqual(out["body"]["length"], 5000)

    def test_empty_args(self) -> None:
        self.assertEqual(redact_args({}), {})
        self.assertEqual(redact_args(None), {})


# --------------------------------------------------------------------------- #
# AuditLogger 独立测试
# --------------------------------------------------------------------------- #
class TestAuditLogger(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "audit.jsonl"
        self.logger = AuditLogger(self.path)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_write_and_read(self) -> None:
        from hooks import AuditRecord

        record = AuditRecord(
            audit_id="a1",
            ts=1,
            event=HookEvent.BEFORE_TOOL,
            decision=Decision.ALLOW,
            tool="bash",
            policy_id="audit-all",
            policy_name="全量审计",
            reason="ok",
        )
        self.logger.write_sync(record)
        records = self.logger.read_all()
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].audit_id, "a1")

    def test_query_filters(self) -> None:
        from hooks import AuditRecord

        for idx, tool in enumerate(["bash", "git", "bash"]):
            self.logger.write_sync(
                AuditRecord(
                    audit_id=f"a{idx}",
                    ts=idx,
                    event=HookEvent.BEFORE_TOOL,
                    decision=Decision.ALLOW,
                    tool=tool,
                    policy_id=None,
                    policy_name=None,
                    reason="",
                )
            )
        self.assertEqual(len(self.logger.query(tool="bash")), 2)
        self.assertEqual(len(self.logger.query(since=1)), 2)
        self.assertEqual(len(self.logger.query(limit=1)), 1)

    def test_export(self) -> None:
        from hooks import AuditRecord

        self.logger.write_sync(
            AuditRecord(
                audit_id="a1",
                ts=1,
                event=HookEvent.BEFORE_TOOL,
                decision=Decision.DENY,
                tool="bash",
                policy_id="dangerous-command",
                policy_name="危险命令",
                reason="bad",
            )
        )
        target = Path(self.tmp.name) / "out.jsonl"
        self.logger.export_jsonl(target)
        self.assertTrue(target.exists())
        self.assertEqual(len(target.read_text(encoding="utf-8").strip().splitlines()), 1)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
