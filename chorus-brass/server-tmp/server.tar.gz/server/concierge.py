"""「我想做 X」in a 私信: the AI asks a few clarifying questions, then a deterministic planner drafts the 乐章
(name, mode 协奏/交响, members by capability × price × quota, budget) as a confirmation card. Confirm -> the server
creates the project, adds the members and starts the 乐章. Spending beyond the budget still goes through consent cards.
No LLM in the planning maths; the member only phrases the questions."""
from __future__ import annotations

import re
import secrets
import time

import adapters as A
import designopts

INTENT = re.compile(r"(我想|我要|想要|帮我|给我)(做|搞|写|开发|建|弄)(一个|个|一款|款|套)?|\bI (want|would like) to (build|make|create)\b|\bbuild me\b", re.I)
SYMPHONY = re.compile(r"完整|上线|产品|一条龙|从头到尾|全套|app|应用|网站|小程序|end.to.end|full", re.I)
NEEDS = {"code_exec": re.compile(r"代码|程序|app|应用|网站|脚本|小程序|接口|后端|前端|bug|code|api", re.I),
         "vision": re.compile(r"图|设计|界面|ui|截图|logo|海报|image|design", re.I),
         "web": re.compile(r"调研|搜索|查资料|竞品|网上|research|search", re.I)}
QUESTIONS = ["给谁用、最想解决的一件事是什么？", "有没有必须用的技术、平台或参考样例？", "预算上限和希望多久完成？"]
BUDGET = {"concerto": 20.0, "symphony": 50.0}


def wants_project(text: str) -> bool:
    return bool(INTENT.search(text or ""))


def needs_of(text: str) -> set:
    return {k for k, rx in NEEDS.items() if rx.search(text)}


def money_in(text: str):
    matches = re.finditer(r"(?:预算|budget|上限)?\s*[¥￥$]?\s*(\d+(?:\.\d+)?)\s*(元|块|刀|美元|usd|\$)?", text or "", re.I)
    candidates = [m for m in matches if m.group(2) or re.search(r"预算|budget|上限|[¥￥$]", m.group(0), re.I)]
    if not candidates:
        return None
    m = max(candidates, key=lambda m: bool(re.search(r"预算|budget|上限", m.group(0), re.I)))
    return float(m.group(1)), ("$" if (m.group(2) or "").lower() in ("刀", "美元", "usd", "$") or "$" in m.group(0) else "¥")


def draft(brief: str, answers: list, members: list, price_of, stats: dict, healthy, account_cap=None) -> dict:
    """Deterministic plan: mode, 指挥 (strongest healthy), workers (cheapest covering each need), budget."""
    text = brief + "\n" + "\n".join(answers)
    mode = "symphony" if SYMPHONY.search(text) else "concerto"
    pool = [m for m in members if healthy(m["name"])]
    if not pool:
        return {"error": "现在没有可用的成员，请在设置中检查成员余额和休息状态", "fix": "settings"}

    def strength(m):
        return ((stats.get(m["name"]) or {}).get("pass", 0.8), (price_of(m) or {}).get("out", 0))
    lead = max(pool, key=strength)
    need = needs_of(text)
    workers, why = [], {lead["name"]: "指挥：通过率与能力最高"}
    for n in sorted(need) or ["general"]:
        w = A.pick([m for m in pool if m["name"] != lead["name"]] or pool, {n} if n != "general" else set(), price_of, stats,
                   exclude=[x["name"] for x in workers])
        if w and w["name"] not in why:
            workers.append(w)
            why[w["name"]] = {"code_exec": "能跑代码里最便宜", "vision": "能看图里最便宜", "web": "能联网里最便宜"}.get(n, "最便宜的可用成员")
    if not workers:
        cheap = A.pick([m for m in pool if m["name"] != lead["name"]], set(), price_of, stats)
        if cheap:
            workers.append(cheap)
            why[cheap["name"]] = "最便宜的可用成员"
    got = None
    for a in answers[::-1] + [brief]:
        got = money_in(a)
        if got:
            break
    cap, cur = got if got else (BUDGET[mode], "¥")
    if account_cap and account_cap > 0 and cap > account_cap:
        cap = account_cap
    name = re.sub(INTENT, "", brief).strip(" ，,。.!！")[:16] or "新乐章"
    return {"name": name, "mode": mode, "lead": lead["name"], "members": [lead["name"]] + [w["name"] for w in workers],
            "why": why, "budget": {"cap": round(cap, 2), "cur": cur}, "brief": text.strip(), "needs": sorted(need)}


class Concierge:
    """Per-私信 state machine: idle -> asking -> card -> done. Hosted by server.py (S) with chorus2 helpers (C)."""

    def __init__(self, S, C, ask=None):
        self.S, self.C, self.ask = S, C, ask

    def store(self):
        return self.S.CFG.setdefault("intents", {})

    def active(self, pid, name):
        return next((i for i in self.store().values() if i["pid"] == pid and i["member"] == name and i["stage"] in ("asking", "card")), None)

    def claims(self, pid, name, text) -> bool:
        i = self.active(pid, name)
        return bool(i and i["stage"] == "asking") or (not i and wants_project(text))

    async def on_user(self, pid, name, text):
        i = self.active(pid, name)
        if not i:
            iid = secrets.token_hex(4)
            i = self.store()[iid] = {"id": iid, "pid": pid, "member": name, "stage": "asking", "brief": text,
                                     "answers": [], "at": time.time()}
            design = designopts.speculate(self.S, pid, text, "symphony" if SYMPHONY.search(text) else "concerto")
            if design:
                i["design_sid"] = design["sid"]
            qs = QUESTIONS
            if self.ask:
                try:
                    out = await self.ask(name, text)
                    got = [q.strip(" -•0123456789.、") for q in (out or "").splitlines() if q.strip().endswith(("？", "?"))][:3]
                    qs = got or QUESTIONS
                except Exception:  # noqa: BLE001 - phrasing is optional; fixed questions are fine
                    qs = QUESTIONS
            i["questions"] = qs
            self.S.add_msg(pid, name, "开工前想确认几件事：\n" + "\n".join(f"{n + 1}. {q}" for n, q in enumerate(qs)) +
                           "\n（一次回答就行，不想答回「直接做」）", name, intent=i["id"])
            self.S.save_cfg()
            return i
        if i["stage"] == "asking":
            if not re.fullmatch(r"\s*(直接做|就这样|跳过|skip)\s*", text, re.I):
                i["answers"].append(text)
            return self.card(i)
        return i

    def card(self, i):
        C = self.C
        acct = (self.S.CFG.get("account_caps") or {}).get("day")
        plan = draft(i["brief"], i["answers"], list(C.members()), C.price_of, C.stats(), C.healthy, account_cap=acct)
        if plan.get("error"):
            self.S.add_msg(i["pid"], i["member"], plan["error"], i["member"], intent=i["id"])
            i["stage"] = "done"
            self.S.save_cfg()
            return i
        i["plan"], i["stage"] = plan, "card"
        mode = {"concerto": "协奏", "symphony": "交响"}[plan["mode"]]
        lines = [f"乐章「{plan['name']}」· {mode} · 预算 {plan['budget']['cur']}{plan['budget']['cap']:g}",
                 *[f"- {n}：{plan['why'].get(n, '')}" for n in plan["members"]], "确认后我来建乐章、拉人、开始。"]
        self.S.add_msg(i["pid"], i["member"], "\n".join(lines), i["member"], intent=i["id"], card={"type": "plan", **plan, "intent": i["id"]})
        self.S.save_cfg()
        return i

    async def confirm(self, iid, edits=None):
        i = self.store().get(iid)
        if not i:
            return None
        recovered = next((p for p in self.S.PROJECTS if p.get("concierge_intent") == iid), None)
        if recovered and not i.get("project"):
            i.update(stage="done", project=recovered["id"], plan=recovered["concierge_plan"])
            self.S.save_cfg()
        if i.get("project"):
            pid = i["project"]
            p = self.S.project(pid)
            if p and p.get("planning") in ("queued", "planning", "failed"):
                self.C.queue_plan(pid, i["plan"]["brief"])
            return pid
        if i["stage"] != "card":
            return None
        plan = {**i["plan"], **{k: v for k, v in (edits or {}).items() if k in ("name", "mode", "members", "budget", "lead")}}
        plan["members"] = [n for n in plan["members"] if self.S.member(n)]
        if plan.get("lead") not in plan["members"]:
            plan["lead"] = plan["members"][0] if plan["members"] else ""
        if plan.get("mode") not in ("concerto", "symphony"):
            plan["mode"] = "concerto"
        pid = self.S.create_project(plan["name"], plan["brief"], plan["members"], plan["mode"], plan["budget"], lead=plan["lead"],
            initial={"planning": "queued", "planning_brief": plan["brief"], "plan_start": True,
                     "concierge_intent": iid, "concierge_plan": plan})
        service = getattr(self.S, "design_options", None)
        if service and i.get("design_sid") in service.sessions:
            service.attach(i["design_sid"], pid, plan["mode"])
            self.S.project(pid)["design_sid"] = i["design_sid"]
        i.update(stage="done", project=pid, plan=plan)
        p = self.S.project(pid)
        p.update(planning="queued", planning_brief=plan["brief"], plan_start=True)
        self.C.save_projects()
        self.S.save_cfg()
        self.C.queue_plan(pid, plan["brief"])
        self.S.add_msg(i["pid"], i["member"], f"已建好乐章「{plan['name']}」，正在后台写谱稿。", i["member"], intent=iid, open_project=pid)
        return pid

    def cancel(self, iid):
        i = self.store().get(iid)
        if not i or i["stage"] == "done":
            return False
        i["stage"] = "done"
        service = getattr(self.S, "design_options", None)
        if service and i.get("design_sid") in service.sessions:
            service.cancel(i["design_sid"])
        self.S.add_msg(i["pid"], i["member"], "好，先不建。", i["member"], intent=iid)
        self.S.save_cfg()
        return True
