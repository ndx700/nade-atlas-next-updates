"""Design contract tests use events and real route handlers, without a TCP listener."""
import asyncio
import json
import pathlib
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from aiohttp import web
from aiohttp.test_utils import make_mocked_request

import chorus2
import adapters
import concierge
import designopts as D
import server


def spec(title="Budget dashboard"):
    return {"screens": [{"name": title, "blocks": [{"type": "hero", "props": {"title": title}}]}],
            "palette": ["#FFFFFF", "#222222", "#336699"], "type": {"heading": "Georgia", "body": "Arial"}}


async def until(predicate, timeout=2):
    async def wait():
        while not predicate():
            await asyncio.sleep(0.001)
    await asyncio.wait_for(wait(), timeout)


async def inline_thread_call(fn, *args, **kwargs):
    # Exercise real disk I/O without this sandbox's broken cross-thread wakeups.
    return fn(*args, **kwargs)


class DesignBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        threading = patch.object(D.asyncio, "to_thread", inline_thread_call)
        threading.start()
        self.addCleanup(threading.stop)
        self.tmp = tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).parent)
        self.addCleanup(self.tmp.cleanup)
        self.members = [{"name": "strong", "price": {"in": 10, "out": 20}},
                        {"name": "cheap", "price": {"in": 0.1, "out": 0.3}},
                        {"name": "unhealthy", "price": {"in": 0, "out": 0}},
                        {"name": "incapable", "price": {"out": 0}, "caps": {"design": False}}]
        self.calls = []
        self.notifications = []
        self.config = {"design_autopick_s": 0.01}

        async def ask(m, system, prompt, pid):
            data = json.loads(prompt)
            self.calls.append((m["name"], data, pid))
            return spec(str(data.get("option", "expanded")))
        self.ask = ask
        self.service = self.make_service()

    def make_service(self, **kw):
        service = D.DesignOptions(pathlib.Path(self.tmp.name), ask=lambda *args: self.ask(*args),
                                  members=lambda: self.members, price_of=lambda m: m.get("price"),
                                  healthy=lambda n: n != "unhealthy", config=self.config,
                                  notify=lambda pid: self.notifications.append(pid), **kw)
        self.addAsyncCleanup(service.close)
        return service

    async def drafts(self, service=None, **kw):
        service = service or self.service
        result = service.start("p", "Budget app", **kw)
        s = service.sessions[result["sid"]]
        await asyncio.gather(*s["_workers"])
        return s


class DesignTests(DesignBase):

    async def test_parallel_streaming_order_and_metrics(self):
        gates = [asyncio.Event() for _ in range(3)]
        started = set()

        async def ask(m, system, prompt, pid):
            i = json.loads(prompt)["option"]
            self.assertEqual(m["name"], "cheap")
            started.add(i)
            await gates[i].wait()
            return json.dumps(spec(str(i)))
        self.ask = ask
        initial = self.service.start("p", "Budget app", 3)
        s = self.service.sessions[initial["sid"]]
        self.assertEqual([x["state"] for x in initial["options"]], ["pending"] * 3)
        await until(lambda: len(started) == 3)
        order = []
        for i in (2, 0, 1):
            before = len(self.notifications)
            gates[i].set()
            await until(lambda: s["options"][i]["state"] == "ready")
            self.assertGreater(len(self.notifications), before)
            order.append([x["id"] for x in self.service.snapshot(s["sid"])["options"] if x["state"] == "ready"])
        await asyncio.gather(*s["_workers"])
        self.assertEqual(order, [[2], [0, 2], [0, 1, 2]])
        self.assertLess(s["metrics"]["time_to_first_option"], 5)
        self.assertGreaterEqual(s["metrics"]["time_to_all"], s["metrics"]["time_to_first_option"])

    async def test_normalized_memory_and_disk_cache_and_lru(self):
        service = self.make_service(cache_size=1)
        s = await self.drafts(service)
        hit = service.start("q", "  ＢＵＤＧＥＴ   APP\n", 3)
        self.assertTrue(hit["cache_hit"])
        self.assertEqual(hit["metrics"]["time_to_first_option"], 0)
        self.assertEqual(len(self.calls), 3)
        hit["options"][0]["spec"]["screens"].clear()
        self.assertTrue(s["options"][0]["spec"]["screens"])
        restored = self.make_service(cache_size=1)
        self.assertTrue(restored.start("p", "budget app", 3)["cache_hit"])
        fresh = service.start("p", "other brief", 1)
        await asyncio.gather(*service.sessions[fresh["sid"]]["_workers"])
        self.assertEqual(len(service.cache), 1)
        self.assertNotIn(D.cache_key("budget app", 3), service.cache)
        self.assertNotEqual(D.cache_key("budget app", 2), D.cache_key("budget app", 3))

    async def test_early_pick_cancels_before_expansion(self):
        cancelled = []
        began = set()

        async def ask(m, system, prompt, pid):
            data = json.loads(prompt)
            if "chosen" in data:
                self.assertEqual(m["name"], "strong")
                self.assertEqual(sorted(cancelled), [1, 2])
                return spec("expanded")
            i = data["option"]
            began.add(i)
            if i == 0:
                return spec()
            try:
                await asyncio.Event().wait()
            finally:
                cancelled.append(i)
        self.ask = ask
        result = self.service.start("p", "Budget app")
        s = self.service.sessions[result["sid"]]
        await until(lambda: len(began) == 3 and s["options"][0]["state"] == "ready")
        picked = await self.service.pick(s["sid"], 0)
        self.assertEqual(picked["render"]["state"], "pending")
        await s["_render"]
        self.assertEqual(s["render"]["state"], "ready")
        self.assertEqual(s["metrics"]["cancelled"], 2)
        self.assertIsNotNone(s["metrics"]["time_to_all"])
        self.assertEqual([x["state"] for x in s["options"]], ["ready", "cancelled", "cancelled"])

    async def test_repick_replaces_even_if_previous_call_ignores_cancellation(self):
        s = await self.drafts()
        entered = asyncio.Event()
        release = asyncio.Event()
        calls = []

        async def expand(m, system, prompt, pid):
            calls.append(json.loads(prompt)["chosen"]["screens"][0]["name"])
            if len(calls) == 1:
                entered.set()
                try:
                    await asyncio.Event().wait()
                except asyncio.CancelledError:
                    await release.wait()
                return spec("stale")
            return spec("new")
        self.ask = expand
        await self.service.pick(s["sid"], 0)
        previous = s["_render"]
        await entered.wait()
        await self.service.pick(s["sid"], 1)
        await s["_render"]
        release.set()
        await previous
        self.assertEqual(s["picked"], 1)
        self.assertEqual(s["render"]["spec"], spec("new"))
        self.assertEqual(s["metrics"]["cancelled"], 1)

    async def test_autopick_scores_overlap_then_cost_and_user_can_repick(self):
        async def ask(m, system, prompt, pid):
            data = json.loads(prompt)
            return spec("Budget app" if data.get("option") == 1 else "Unrelated")
        self.ask = ask
        s = await self.drafts(mode="symphony")
        await s["_auto"]
        await s["_render"]
        self.assertEqual((s["picked"], s["picked_by"]), (1, "auto"))
        await self.service.pick(s["sid"], 0)
        await s["_render"]
        self.assertEqual((s["picked"], s["picked_by"]), (0, "user"))
        a, b = {"id": 0, "spec": spec(), "cost_estimate": 1}, {"id": 1, "spec": spec(), "cost_estimate": 2}
        self.assertGreater(D.DesignOptions.score("Budget", a), D.DesignOptions.score("Budget", b))

    async def test_autopick_waits_for_first_ready_after_deadline(self):
        gate = asyncio.Event()

        async def ask(m, system, prompt, pid):
            await gate.wait()
            return spec()
        self.ask = ask
        self.config["design_autopick_s"] = 0
        result = self.service.start("p", "Budget app", 1, "symphony")
        s = self.service.sessions[result["sid"]]
        await asyncio.sleep(0.01)
        self.assertIsNone(s["picked"])
        gate.set()
        await s["_auto"]
        await s["_render"]
        self.assertEqual(s["picked"], 0)

    async def test_schema_and_member_errors_are_isolated_and_not_cached(self):
        async def ask(m, system, prompt, pid):
            i = json.loads(prompt)["option"]
            if i == 0:
                return {"screens": []}
            if i == 1:
                raise RuntimeError("private-provider-key")
            return spec()
        self.ask = ask
        s = await self.drafts(mode="symphony")
        await s["_auto"]
        self.assertEqual([x["state"] for x in s["options"]], ["failed", "failed", "ready"])
        self.assertEqual(s["options"][0]["error"], "schema_rejected")
        self.assertNotIn("private-provider-key", json.dumps(self.service.snapshot(s["sid"])))
        self.assertFalse(self.service.cache)
        await s["_render"]

    async def test_timeouts_no_members_and_failed_render(self):
        self.config["design_timeout_s"] = 0.01

        async def slow(*args):
            await asyncio.Event().wait()
        self.ask = slow
        s = await self.drafts(n=1, mode="symphony")
        await s["_auto"]
        self.assertEqual(s["options"][0]["error"], "timeout")
        self.assertIsNone(s["metrics"]["time_to_first_option"])
        self.members.clear()
        s = await self.drafts(n=1)
        self.assertEqual(s["options"][0]["error"], "no_member")
        self.members.append({"name": "only", "price": {"out": 1}})

        async def ask(*args):
            return spec()
        self.ask = ask
        s = await self.drafts(n=1)
        self.ask = slow
        await self.service.pick(s["sid"], 0)
        await s["_render"]
        self.assertEqual(s["render"]["state"], "failed")
        self.assertEqual(s["options"][0]["state"], "ready")

    async def test_corrupt_cache_disk_failure_and_cleanup(self):
        self.service.path.write_text("{broken")
        service = self.make_service()
        self.assertFalse(service.cache)
        self.service.path.unlink()
        self.service.path.mkdir()
        s = await self.drafts()
        self.assertEqual(len(self.service.cache), 1)
        self.assertTrue(all(x["state"] == "ready" for x in s["options"]))
        await self.service.close()
        self.assertFalse(self.service.tasks)

    async def test_no_eligible_member_during_expansion_retains_draft(self):
        s = await self.drafts(n=1)
        self.members[:] = [m for m in self.members if m["name"] in ("unhealthy", "incapable")]
        await self.service.pick(s["sid"], 0)
        await s["_render"]
        self.assertEqual(s["render"], {"state": "failed", "option": 0, "error": "no_member"})
        self.assertEqual(s["options"][0]["state"], "ready")
        self.assertEqual(len(self.calls), 1)


class SchemaTests(unittest.TestCase):
    def test_schema_rejects_invalid_shapes_types_and_non_json_props(self):
        mutations = [lambda s: s.pop("type"), lambda s: s.update(screens=[]),
                     lambda s: s["screens"][0]["blocks"][0].update(type="script"),
                     lambda s: s.update(palette=["red", "green", "blue"]),
                     lambda s: s["type"].update(body=123), lambda s: s.update(extra="x"),
                     lambda s: s["screens"][0]["blocks"][0].update(props=[]),
                     lambda s: s["screens"][0]["blocks"][0]["props"].update(x=float("nan")),
                     lambda s: s["screens"][0]["blocks"][0]["props"].update(x="x" * 200_000)]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                value = spec()
                mutate(value)
                with self.assertRaises(ValueError):
                    D.validate_spec(value)
        self.assertEqual(D.parse_spec("```json\n" + json.dumps(spec()) + "\n```"), spec())
        for raw in ("PASS", "[]", "null", "```json\n{}"):
            with self.assertRaises(ValueError):
                D.parse_spec(raw)


class RouteTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        threading = patch.object(D.asyncio, "to_thread", inline_thread_call)
        threading.start()
        self.addCleanup(threading.stop)
        self.tmp = tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).parent)
        self.addCleanup(self.tmp.cleanup)
        self.project = {"id": "p", "mode": "concerto"}
        self.s = SimpleNamespace(DATA=pathlib.Path(self.tmp.name), CFG={},
                                 project=lambda pid: self.project if pid == "p" else None, bump=lambda pid: None)
        self.c = SimpleNamespace(members=lambda: [{"name": "cheap"}], price_of=lambda m: {"out": 1},
                                 healthy=lambda name: True, save_projects=lambda: None,
                                 ROLE=chorus2.ROLE)

        async def ask(*args):
            return spec()
        self.c.ask_model = ask
        self.app = web.Application()
        self.service = D.register(self.app, self.s, self.c)
        self.addAsyncCleanup(self.service.close)

    async def request(self, method, path, body=None):
        req = make_mocked_request(method, path, app=self.app)
        if body is not None:
            async def get_json():
                return body
            req.json = get_json
        match = await self.app.router.resolve(req)
        req._match_info = match
        return await match.handler(req)

    async def test_acp_requires_successful_nonempty_text_and_accounts_every_result(self):
        member = {"name": "acp", "kind": "cli", "protocol": "acp", "model": "test"}
        text = json.dumps(spec())
        reported = {"in": 120, "out": 80, "cached": 20}
        cases = [
            (True, text, reported), (True, text, {}),
            (True, text, {"in": 0, "out": 0, "cached": 0}),
            (False, text, reported), (False, "private-provider-body", {}),
            (True, "", reported), (True, "", {}), (True, "   ", {}),
        ]
        self.c.account_block = lambda: None
        self.c.cli_guard = Mock()
        for ok, output, usage in cases:
            with self.subTest(ok=ok, empty=not output.strip(), usage=usage):
                result = adapters.Result(ok, text=output, usage=usage, error="private-provider-error")
                run = AsyncMock(return_value=result)
                self.s.record_usage = Mock()
                role = self.c.ROLE.get()
                with patch.object(adapters.AcpAdapter, "run", run):
                    if ok and output.strip():
                        self.assertEqual(await self.service.ask(member, "system", "prompt", "p"), output)
                    else:
                        with self.assertRaises(RuntimeError) as caught:
                            await self.service.ask(member, "system", "prompt", "p")
                        self.assertEqual(str(caught.exception), "Design member failed")
                self.assertEqual(self.c.ROLE.get(), role)
                self.s.record_usage.assert_called_once()
                billed_member, model, billed, pid = self.s.record_usage.call_args.args
                self.assertEqual((billed_member, model, pid), (member, "test", "p"))
                if any(usage.values()):
                    self.assertEqual(billed, usage)
                else:
                    self.assertEqual(billed, {"in": 3, "out": (len(output) + 3) // 4,
                                             "cached": 0, "estimated": True})
                # This branch must still deny tool requests.
                self.assertFalse(await run.call_args.args[2]("Write", {}))

    async def test_library_routes_pending_poll_pick_and_invalid_requests(self):
        t = time.perf_counter()
        library = await self.request("GET", "/api/design/library")
        self.assertLess(time.perf_counter() - t, 0.05)
        data = json.loads(library.body)
        self.assertGreaterEqual(len(data["styles"]), 8)
        self.assertEqual(len({x["id"] for x in data["styles"]}), len(data["styles"]))
        self.assertEqual(library.body, (await self.request("GET", "/api/design/library")).body)
        for style in data["styles"]:
            self.assertTrue(style["thumbnail"].startswith("<svg"))
            self.assertLess(len(style["thumbnail"]), 1000)
        response = await self.request("POST", "/api/design/start", {"pid": "p", "brief": "Budget app", "n": 2})
        result = json.loads(response.body)
        self.assertEqual([x["state"] for x in result["options"]], ["pending"] * 2)
        sid = result["sid"]
        self.assertEqual(self.project["design_sid"], sid)
        await asyncio.gather(*self.service.sessions[sid]["_workers"])
        polled = json.loads((await self.request("GET", f"/api/design/{sid}")).body)
        self.assertEqual([x["state"] for x in polled["options"]], ["ready"] * 2)
        picked = await self.request("POST", f"/api/design/{sid}/pick", {"option": 1})
        self.assertEqual(json.loads(picked.body)["picked"], 1)
        for option in (True, -1, 2, "1", None):
            r = await self.request("POST", f"/api/design/{sid}/pick", {"option": option})
            self.assertEqual(r.status, 400)
        for n in (True, 0, 9, "3"):
            r = await self.request("POST", "/api/design/start", {"pid": "p", "brief": "app", "n": n})
            self.assertEqual(r.status, 400)
        for method, path, body in [("GET", "/api/design/missing", None),
                                   ("POST", "/api/design/start", {"pid": "missing", "brief": "app"})]:
            with self.assertRaises(web.HTTPNotFound):
                await self.request(method, path, body)
        for body in ([], "bad"):
            with self.assertRaises(web.HTTPBadRequest):
                await self.request("POST", "/api/design/start", body)

    async def test_pending_pick_is_rejected_and_auth_middleware_protects_design(self):
        pending = self.service.start("p", "app")
        r = await self.request("POST", f"/api/design/{pending['sid']}/pick", {"option": 0})
        self.assertEqual(r.status, 400)
        with patch.object(server, "CFG", {"password": "test-password"}):
            for path in ("/api/design/library", "/api/design/start", "/api/design/sid/pick"):
                req = make_mocked_request("POST", path)
                r = await server.auth(req, lambda req: None)
                self.assertEqual(r.status, 401)

    async def test_websocket_pushes_pending_then_ready_session(self):
        incoming = asyncio.Queue()
        frames = []

        class Socket:
            closed = False

            async def prepare(self, request):
                return None

            def __aiter__(self):
                return self

            async def __anext__(self):
                return await incoming.get()

            async def send_json(self, frame):
                frames.append(frame)

        ws = Socket()
        gate = asyncio.Event()

        async def ask(*args):
            await gate.wait()
            return spec()
        self.c.ask_model = ask
        self.service.notify = server.bump
        req = make_mocked_request("GET", "/api/ws")
        with patch.multiple(server, PROJECTS=[self.project], CHANGED=asyncio.Event(), VER=0, PVER={},
                            orchestra_view=None, index_view=lambda: {}, chat_view=lambda *a: {}), \
                patch.object(server, "design_options", self.service, create=True), \
                patch.object(server.web, "WebSocketResponse", return_value=ws):
            task = asyncio.create_task(server.h_ws(req))
            try:
                await incoming.put(SimpleNamespace(type=server.WSMsgType.TEXT, data=json.dumps({"sub": "p"})))
                initial = self.service.start("p", "Budget app", 1)
                sid = initial["sid"]
                await until(lambda: any(f["type"] == "design" and f["data"]["sessions"] for f in frames))
                pending = next(f for f in frames if f["type"] == "design" and f["data"]["sessions"])
                self.assertEqual(pending["data"]["sessions"][0]["options"][0]["state"], "pending")
                gate.set()
                await until(lambda: any(f["type"] == "design" and f["data"]["sessions"]
                                       and f["data"]["sessions"][0]["options"][0]["state"] == "ready" for f in frames))
                self.assertEqual(frames[-1]["data"]["sessions"][0]["sid"], sid)
            finally:
                ws.closed = True
                server.bump("p")
                await asyncio.wait_for(task, 2)


class ConciergeTests(DesignBase):
    async def test_starts_before_questions_and_survives_confirmation(self):
        projects = {"dm": {"id": "dm"}}
        planning = []
        messages = []
        entered = asyncio.Event()
        release = asyncio.Event()

        async def ask_questions(name, brief):
            entered.set()
            await release.wait()
            return "Who uses it?"

        def create(*args, **kwargs):
            projects["new"] = {"id": "new", **kwargs.get("initial", {})}
            s.PROJECTS.append(projects["new"])
            return "new"

        async def plan(pid, brief):
            D.speculate(s, pid, brief, "symphony")

        s = SimpleNamespace(CFG={}, PROJECTS=list(projects.values()), design_options=self.service, project=projects.get,
                            add_msg=lambda *a, **kw: messages.append((a, kw)), save_cfg=lambda: None,
                            member=lambda name: {"name": name}, create_project=create)
        c = SimpleNamespace(members=lambda: self.members, healthy=lambda n: True,
                            price_of=lambda m: m.get("price"), stats=lambda: {}, plan=plan, start=lambda pid: None,
                            save_projects=lambda: None,
                            queue_plan=lambda pid, brief: planning.append(asyncio.create_task(plan(pid, brief))))
        cg = concierge.Concierge(s, c, ask_questions)
        task = asyncio.create_task(cg.on_user("dm", "strong", "I want to build a budget app"))
        await entered.wait()
        self.assertFalse(task.done())
        i = cg.active("dm", "strong")
        self.assertIn(i["design_sid"], self.service.sessions)
        await until(lambda: len(self.calls) >= 3)
        release.set()
        await task
        await cg.on_user("dm", "strong", "For myself")
        sid = i["design_sid"]
        await cg.confirm(i["id"])
        await asyncio.gather(*planning)
        self.assertEqual(projects["new"]["design_sid"], sid)
        self.assertEqual(self.service.sessions[sid]["pid"], "new")
        self.assertEqual(len(self.service.sessions), 1)

    async def test_concierge_cancel_stops_speculative_work(self):
        p = {"id": "dm"}
        s = SimpleNamespace(CFG={}, design_options=self.service, project=lambda pid: p,
                            add_msg=lambda *a, **kw: None, save_cfg=lambda: None)
        cg = concierge.Concierge(s, None)
        i = await cg.on_user("dm", "strong", "我想做一个网站")
        self.assertTrue(cg.cancel(i["id"]))
        session = self.service.sessions[i["design_sid"]]
        await asyncio.gather(*session["_workers"], return_exceptions=True)
        self.assertEqual(session["metrics"]["cancelled"], 3)
        replacement = D.speculate(s, "dm", i["brief"], "concerto")
        self.assertNotEqual(replacement["sid"], i["design_sid"])
        D.speculate(s, "dm", i["brief"], "symphony")
        self.assertEqual(self.service.sessions[replacement["sid"]]["mode"], "symphony")

    async def test_selected_direction_is_in_engine_context(self):
        s = await self.drafts()
        await self.service.pick(s["sid"], 1)
        await s["_render"]
        fake = SimpleNamespace(design_options=self.service, project=lambda pid: {"design_sid": s["sid"]})
        with patch.object(chorus2, "S", fake):
            self.assertIn("expanded", chorus2.design_context("p"))

    async def test_cancelled_expansion_or_option_does_not_inject_draft(self):
        s = await self.drafts(n=1)
        entered = asyncio.Event()

        async def expand(*args):
            entered.set()
            await asyncio.Event().wait()
        self.ask = expand
        await self.service.pick(s["sid"], 0)
        await entered.wait()
        fake = SimpleNamespace(design_options=self.service, project=lambda pid: {"design_sid": s["sid"]})
        with patch.object(chorus2, "S", fake):
            self.assertIn('"name": "0"', chorus2.design_context("p"))
            self.service.cancel(s["sid"])
            await asyncio.gather(s["_render"], return_exceptions=True)
            self.assertEqual(s["options"][0]["state"], "ready")
            self.assertEqual(s["render"]["state"], "cancelled")
            self.assertEqual(chorus2.design_context("p"), "")
            # Ordinary render failure still retains a valid selected draft.
            s["render"] = {"state": "failed", "error": "render_failed"}
            self.assertIn('"name": "0"', chorus2.design_context("p"))
            s["options"][0]["state"] = "cancelled"
            self.assertEqual(chorus2.design_context("p"), "")
            s["render"] = {"state": "ready", "spec": spec("stale")}
            self.assertEqual(chorus2.design_context("p"), "")


class ReplayTests(DesignBase):
    async def test_replay_real_engine_and_seeded_accounting(self):
        from bench.replay import HERE, Replay, percentile
        fixture = json.loads((HERE / "fixtures" / "budget.json").read_text())
        first = await Replay(fixture, 0, 123, 0.001).run()
        second = await Replay(fixture, 0, 123, 0.001).run()
        self.assertEqual(first["cards_passed"], 3)
        self.assertEqual(first["review_rejections"], 1)
        self.assertGreater(first["tokens"], 0)
        self.assertGreater(first["cost_usd"], 0)
        for key in ("tokens", "cost_usd", "review_rejections"):
            self.assertEqual(first[key], second[key])
        self.assertGreater(first["design_time_to_first_option_s"], 0)
        self.assertEqual(percentile([5, 1, 3, 2, 4], 0.5), 3)
        self.assertEqual(percentile([5, 1, 3, 2, 4], 0.95), 5)


if __name__ == "__main__":
    unittest.main()
