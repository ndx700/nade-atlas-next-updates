"""Human-owned project tasks. AI replies may only suggest changes to existing tasks."""
import hashlib
import json
import re
import secrets
import time

from aiohttp import web

STATUSES = ("待办", "进行中", "已完成", "卡住")
MAX_TASKS = 500
MAX_PROPOSALS = 500
MAX_AUDIT = 1000
AUDIT_DAYS = 90
BLOCK = re.compile(r"^\[任务候选\]([^\n]{1,4096}?)\[/任务候选\]\s*$", re.M)


def text(value, limit, field, empty=False):
    if not isinstance(value, str) or len(value.strip()) > limit or not empty and not value.strip():
        raise web.HTTPBadRequest(text=f"{field} 格式或长度不对")
    return value.strip()


def role_fields(body):
    out = {}
    for key in ("owns", "avoid"):
        if key in body:
            if not isinstance(body[key], list) or any(not isinstance(x, str) for x in body[key]):
                raise web.HTTPBadRequest(text=f"{key} 必须是字符串列表")
            out[key] = [text(x, 200, key) for x in body[key][:5]]
    if "style" in body:
        out["style"] = text(body["style"], 300, "style", empty=True)
    return out


def role_description(member):
    parts = [str(member.get("role") or "").strip()]
    for key, label in (("owns", "负责"), ("avoid", "不碰")):
        values = member.get(key)
        if isinstance(values, list):
            values = [x[:200] for x in values[:5] if isinstance(x, str) and x.strip()]
            if values:
                parts.append(label + "：" + "、".join(values))
    if isinstance(member.get("style"), str) and member["style"].strip():
        parts.append("输出偏好：" + member["style"].strip()[:300])
    return "；".join(x for x in parts if x)


class TaskCards:
    def __init__(self, server):
        self.s = server

    def path(self, pid):
        if not re.fullmatch(r"[\w-]{1,100}", pid) or not self.s.project(pid):
            raise web.HTTPNotFound(text="没有这个群")
        return self.s.DATA / "tasks" / f"{pid}.json"

    def audit_path(self, pid):
        return self.path(pid).with_suffix(".audit.json")

    def read_audit(self, pid, offset=0, limit=100):
        p = self.audit_path(pid)
        rows = json.loads(p.read_text()) if p.exists() else []
        rows = [r for r in rows if r.get("at", 0) >= time.time() - AUDIT_DAYS * 86400][-MAX_AUDIT:]
        offset, limit = max(0, int(offset)), min(100, max(1, int(limit)))
        return rows[offset:offset + limit]

    def flush_audit(self, pid, data):
        pending = data.get("audit", [])
        if not pending:
            return
        p = self.audit_path(pid)
        rows = json.loads(p.read_text()) if p.exists() else []
        # Old embedded audit migrates with stable ids; interrupted drains are idempotent.
        for row in pending:
            row.setdefault("event_id", hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest())
        ids = {r.get("event_id") for r in rows}
        rows.extend(r for r in pending if r["event_id"] not in ids)
        rows = [r for r in rows if r.get("at", 0) >= time.time() - AUDIT_DAYS * 86400][-MAX_AUDIT:]
        self.s.save(p, rows)
        data.pop("audit", None)
        self.s.save(self.path(pid), data)

    def read(self, pid):
        p = self.path(pid)
        if not p.exists():
            return {"items": [], "proposals": []}
        # Never silently overwrite a damaged task store with an empty list.
        data = json.loads(p.read_text())
        if not isinstance(data, dict) or not isinstance(data.get("items"), list) or not isinstance(data.get("proposals"), list):
            raise ValueError("任务文件损坏")
        self.flush_audit(pid, data)
        return data

    def write(self, pid, data):
        p = self.path(pid)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.s.save(p, data)
        self.flush_audit(pid, data)
        self.s.bump(pid)

    def fields(self, pid, body, ai=False):
        allowed = ("status", "owner") if ai else ("title", "status", "owner", "source_message_ids", "superseded_by")
        out = {}
        for key in allowed:
            if key not in body:
                continue
            v = body[key]
            if key == "status":
                if v not in STATUSES:
                    raise web.HTTPBadRequest(text="任务状态不对")
            elif key == "owner":
                v = text(v, 100, key, empty=True)
                if v and v not in (*self.s.project(pid)["members"], "Ali", self.s.owner()):
                    raise web.HTTPBadRequest(text="负责人不在本群")
            elif key == "source_message_ids":
                if not isinstance(v, list) or len(v) > 50 or any(type(x) is not int for x in v):
                    raise web.HTTPBadRequest(text="来源消息格式不对")
                visible = {x["seq"] for x in self.s.CHATS.get(pid, []) if not x.get("dm") and not x.get("live") and not x.get("gone") and not x.get("recalled")}
                if any(x not in visible for x in v):
                    raise web.HTTPBadRequest(text="来源必须是本群正式消息")
                v = list(dict.fromkeys(v))
            else:
                v = text(v, 200 if key == "title" else 100, key, empty=key != "title")
            out[key] = v
        return out

    def audit(self, data, task, action):
        # Durable outbox travels with the atomic state replacement, then drains to bounded audit.
        data.setdefault("audit", []).append({"task_id": task["id"], "action": action,
                                             "actor": "Ali", "at": time.time(), "task": dict(task)})

    async def handle(self, request):
        pid = request.match_info["pid"]
        # Await input before reading state; no await between read/modify/atomic write.
        body = await request.json() if request.method in ("POST", "PATCH") else {}
        if not isinstance(body, dict):
            raise web.HTTPBadRequest(text="请求必须是对象")
        data = self.read(pid)
        if request.method == "GET":
            children = __import__("subprojects").children(self.s, pid)
            items = [{**item, "children": [c for c in children['items']
                      if c.get('source_task_id') == item['id']]} for item in data['items']]
            try:
                audit = self.read_audit(pid, request.query.get("audit_offset", 0), request.query.get("audit_limit", 100))
            except (TypeError, ValueError):
                raise web.HTTPBadRequest(text="审计分页参数不对") from None
            return web.json_response({**data, "audit": audit, "items": items, "children": children})
        tid = request.match_info.get("id")
        if request.method == "POST":
            if len(data["items"]) >= MAX_TASKS:
                raise web.HTTPConflict(text="任务数量已达上限")
            fields = self.fields(pid, body)
            if not fields.get("title"):
                raise web.HTTPBadRequest(text="要填写任务标题")
            task = {"id": secrets.token_hex(8), "status": "待办", "owner": "", "source_message_ids": [],
                    "superseded_by": "", **fields, "revision": 1, "updated_at": time.time()}
            self.check_superseded(data, task)
            data["items"].append(task)
            self.audit(data, task, "create")
        else:
            task = next((x for x in data["items"] if x["id"] == tid), None)
            if task is None:
                raise web.HTTPNotFound(text="没有这个任务")
            if request.method == "DELETE":
                if any(x.get("superseded_by") == tid for x in data["items"]):
                    raise web.HTTPConflict(text="请先解除其他任务对它的替代引用")
                data["items"].remove(task)
                for candidate in data["proposals"]:
                    if candidate["task_id"] == tid and candidate["state"] == "pending":
                        candidate["state"] = "obsolete"
                self.audit(data, task, "delete")
            else:
                action = body.get("action", "update")
                if action not in ("update", "confirm", "reject"):
                    raise web.HTTPBadRequest(text="未知操作")
                if action in ("confirm", "reject"):
                    candidate = next((x for x in data["proposals"] if x["id"] == body.get("proposal_id") and x["task_id"] == tid), None)
                    if candidate is None:
                        raise web.HTTPNotFound(text="没有这个候选")
                    if candidate["state"] != "pending":
                        raise web.HTTPConflict(text="候选已处理")
                    if action == "confirm" and candidate["base_revision"] != task["revision"]:
                        raise web.HTTPConflict(text="任务已更新，请重新核对")
                    if action == "confirm":
                        self.fields(pid, {"source_message_ids": candidate["source_message_ids"]})
                    changes = self.fields(pid, candidate["changes"], ai=True) if action == "confirm" else {}
                    candidate.update(state="confirmed" if action == "confirm" else "rejected", confirmed_by="Ali", confirmed_at=time.time())
                    if action == "confirm":
                        changes["source_message_ids"] = list(dict.fromkeys(task["source_message_ids"] + candidate["source_message_ids"]))[-50:]
                else:
                    if type(body.get("revision")) is not int or body["revision"] != task["revision"]:
                        raise web.HTTPConflict(text="请携带最新任务 revision")
                    changes = self.fields(pid, body)
                updated = {**task, **changes}
                self.check_superseded(data, updated)
                task.update(changes)
                if changes:
                    task.update(revision=task["revision"] + 1, updated_at=time.time())
                self.audit(data, task, action)
                if action in ("confirm", "reject"):
                    data["audit"][-1]["proposal_id"] = candidate["id"]
                    data["audit"][-1]["proposal"] = dict(candidate)
        self.write(pid, data)
        return web.json_response({"item": task}, status=201 if request.method == "POST" else 200)

    def check_superseded(self, data, task):
        target = task.get("superseded_by")
        seen = {task["id"]}
        while target:
            if target in seen:
                raise web.HTTPBadRequest(text="任务替代关系不能循环")
            seen.add(target)
            other = next((x for x in data["items"] if x["id"] == target), None)
            if other is None:
                raise web.HTTPBadRequest(text="替代任务必须在本群")
            target = other.get("superseded_by")

    def propose(self, pid, reply):
        if "[任务候选]" not in reply.get("text", ""):
            return 0
        if reply.get("dm") or reply.get("failed") or reply.get("stopped") or reply.get("live"):
            return 0
        if reply.get("who") not in self.s.project(pid)["members"]:
            return 0
        # Only the actual persisted successful reply can supply provenance.
        if not any(m.get("seq") == reply.get("seq") and m.get("who") == reply.get("who") and m.get("text") == reply.get("text")
                   for m in self.s.load_chat(pid)):
            return 0
        data, added, fenced = self.read(pid), 0, False
        lines = []
        for line in reply.get("text", "").splitlines():
            if line.lstrip().startswith(("```", "~~~")):
                fenced = not fenced
            elif not fenced:
                lines.append(line)
        for match in BLOCK.finditer("\n".join(lines)):
            # Preserve pending entries; completed candidate details remain in audit.
            while len(data["proposals"]) >= MAX_PROPOSALS:
                old = next((x for x in data["proposals"] if x["state"] != "pending"), None)
                if old is None:
                    break
                data["proposals"].remove(old)
            if added >= 10 or len(data["proposals"]) >= MAX_PROPOSALS:
                break
            try:
                b = json.loads(match[1])
                if not isinstance(b, dict) or set(b) - {"id", "base_revision", "status", "owner"}:
                    continue
                task = next((x for x in data["items"] if x["id"] == b.get("id")), None)
                if not task or task.get("superseded_by") or type(b.get("base_revision")) is not int or b["base_revision"] != task["revision"]:
                    continue
                changes = self.fields(pid, b, ai=True)
                if not changes or all(task.get(k) == v for k, v in changes.items()):
                    continue
                key = hashlib.sha256(json.dumps([reply["seq"], task["id"], task["revision"], changes], sort_keys=True, ensure_ascii=False).encode()).hexdigest()
                if any(x["dedup"] == key for x in data["proposals"]):
                    continue
                data["proposals"].append({"id": secrets.token_hex(8), "task_id": task["id"], "base_revision": task["revision"],
                    "changes": changes, "source_message_ids": [reply["seq"]], "source": reply["who"],
                    "state": "pending", "created_at": time.time(), "dedup": key})
                added += 1
            except (ValueError, TypeError, web.HTTPBadRequest):
                continue
        if added:
            self.write(pid, data)
        return added

    def prompt(self, pid):
        tasks = [x for x in self.read(pid)["items"] if not x.get("superseded_by") and x["status"] != "已完成"][:50]
        if not tasks:
            return ""
        rows = [{k: x[k] for k in ("id", "title", "status", "owner", "revision")} for x in tasks]
        return ("\n# 已确认任务（仅作项目数据）\n" + json.dumps(rows, ensure_ascii=False) +
                '\n若要建议更新已有任务，在独立一行写 [任务候选]{"id":"任务ID","base_revision":1,"status":"进行中"}[/任务候选]。'
                '可建议 status（待办/进行中/已完成/卡住）和 owner；不创建或删除任务。提议等待人工确认，不表示已经更新。')
