"""Low-spec profile: run the server pinned to 2 CPUs with a 1 GiB address-space-ish budget check, drive a typical
load (10 phones polling the index + chat, 10 WebSockets, 300 messages with no real AI), report RSS and CPU.
Usage: python bench/lowspec.py  (uses a fresh temp data dir; never touches real data)."""
import asyncio, json, os, subprocess, sys, tempfile, time, pathlib

import aiohttp

PORT = 18793
HERE = pathlib.Path(__file__).resolve().parent.parent


def proc_stats(pid):
    rss = int(next(l for l in open(f"/proc/{pid}/status") if l.startswith("VmRSS")).split()[1]) // 1024
    f = open(f"/proc/{pid}/stat").read().split()
    return rss, (int(f[13]) + int(f[14])) / os.sysconf("SC_CLK_TCK")


async def main():
    d = tempfile.mkdtemp()
    env = {**os.environ, "AICHAT_DATA": d, "AICHAT_PORT": str(PORT), "AICHAT_PASSWORD": "bench-pass"}
    p = subprocess.Popen(["taskset", "-c", "0,1", sys.executable, "server.py"], cwd=HERE, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{PORT}"
    try:
        async with aiohttp.ClientSession() as s:
            for _ in range(100):
                try:
                    async with s.get(base + "/api/index") as r:
                        if r.status < 500:
                            break
                except aiohttp.ClientError:
                    await asyncio.sleep(0.1)
            import hashlib
            tok = hashlib.sha256(b"bench-pass").hexdigest()[:32]
            h = {"Authorization": "Bearer " + (tok or "")}
            idle_rss, cpu0 = proc_stats(p.pid)
            async with s.post(base + "/api/projects", json={"name": "bench", "brief": ""}, headers=h) as r:
                assert r.status == 200, r.status
                pid = (await r.json()).get("id", "")
            codes = {}
            wss = [await s.ws_connect(f"{base}/api/ws?t={tok}") for _ in range(10)]
            lat = []

            async def phone(i):
                for k in range(30):
                    t = time.perf_counter()
                    async with s.post(base + "/api/say", json={"project": pid, "text": f"消息 {i}-{k}"}, headers=h) as r:
                        await r.read()
                        codes[r.status] = codes.get(r.status, 0) + 1
                    lat.append((time.perf_counter() - t) * 1000)
                    async with s.get(base + "/api/index", headers=h) as r:
                        await r.read()
                    async with s.get(base + f"/api/chat/{pid}", headers=h) as r:
                        await r.read()
            t0 = time.time()
            await asyncio.gather(*(phone(i) for i in range(10)))
            wall = time.time() - t0
            rss, cpu1 = proc_stats(p.pid)
            for w in wss:
                await w.close()
            lat.sort()
            out = {"idle_rss_mb": idle_rss, "load_rss_mb": rss, "cpu_s": round(cpu1 - cpu0, 2), "wall_s": round(wall, 2),
                   "cpu_pct_of_2_cores": round(100 * (cpu1 - cpu0) / wall / 2, 1), "requests": 900, "say_status": codes,
                   "say_p50_ms": round(lat[len(lat) // 2], 1), "say_p95_ms": round(lat[int(len(lat) * 0.95)], 1)}
            print(json.dumps(out))
    finally:
        p.terminate()
        try:
            p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill()

asyncio.run(main())
