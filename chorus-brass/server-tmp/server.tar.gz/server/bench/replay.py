"""Seeded, offline replay through the real Ensemble, git workspaces and design service.

Run from server/: python bench/replay.py --rounds 3 --scale 1
--scale accelerates model sleeps only; token/cost samples remain unchanged.
"""
from __future__ import annotations

import argparse
import asyncio
import copy
import hashlib
import json
import math
import pathlib
import random
import re
import sys
import tempfile
import time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import adapters as A
import designopts as D
import ensemble as E


MEMBERS = [
    {"name": "flash", "kind": "cli", "price": {"in": 0.15, "out": 0.6}, "median_s": 2.0},
    {"name": "standard", "kind": "cli", "price": {"in": 1.0, "out": 4.0}, "median_s": 3.0},
    {"name": "lead", "kind": "cli", "price": {"in": 3.0, "out": 15.0}, "median_s": 3.8},
]


def percentile(values, q):
    ordered = sorted(values)
    return ordered[max(0, math.ceil(len(ordered) * q) - 1)] if ordered else None


class Replay:
    def __init__(self, fixture, round_id, seed, scale):
        self.fixture, self.scale = fixture, scale
        self.seed = f"{seed}:{fixture['id']}:{round_id}"
        self.calls, self.bills, self.events = {}, [], []
        self.review_rejections = 0

    async def model(self, member, role, key, effort=1):
        call_key = (role, key)
        attempt = self.calls[call_key] = self.calls.get(call_key, 0) + 1
        digest = hashlib.sha256(f"{self.seed}:{role}:{key}:{attempt}".encode()).digest()
        rng = random.Random(int.from_bytes(digest, "big"))
        median = member["median_s"] * (1.0 + 0.25 * effort if role == "execute" else 0.65 if role == "draft" else 1)
        latency = min(15, max(0.3, rng.lognormvariate(math.log(median), 0.35)))
        usage = {"in": int(rng.uniform(450, 1200) * effort),
                 "out": int(rng.uniform(180, 500) * effort) if role != "review" else int(rng.uniform(20, 80))}
        await asyncio.sleep(latency * self.scale)
        self.account(member, usage, role)
        return usage, attempt

    def account(self, member, usage, role):
        cost = sum(usage.get(k, 0) * member["price"][k] for k in ("in", "out")) / 1e6
        self.bills.append({"member": member["name"], "role": role, "tokens": sum(usage.values()), "cost_usd": cost})

    async def design_ask(self, member, system, prompt, pid):
        data = json.loads(prompt)
        expanded = "chosen" in data
        await self.model(member, "expand" if expanded else "draft", str(data.get("option", "chosen")))
        if expanded:
            result = copy.deepcopy(data["chosen"])
            for screen in result["screens"]:
                for block in screen["blocks"]:
                    block["props"].update(padding=24, label=screen["name"], responsive={"mobile": "stack", "desktop": "grid"})
            return result
        return {"screens": [{"name": data["brief"], "blocks": [
            {"type": "header", "props": {"title": data["brief"]}},
            {"type": "card", "props": {"direction": data["style"]}}]}],
            "palette": data["palette"], "type": data["type"]}

    def adapter(self, member):
        replay = self

        class FakeMember(A.Adapter):
            kind = "cli"

            async def run(self, packet, emit, approve, cwd="", system=""):
                review = packet.startswith("审核任务卡 ")
                cid = re.search(r"任务卡 ([\w-]+)", packet).group(1)
                card = next(c for c in replay.fixture["cards"] if c["id"] == cid)
                role = "review" if review else "execute"
                emit(A.Step(self.name, "start", role))
                _, attempt = await replay.model(self.member, role, cid, card.get("effort", 1))
                if review:
                    reject = attempt == 1 and cid in replay.fixture.get("reject_first_review", [])
                    replay.review_rejections += int(reject)
                    return A.Result(True, text="FIX: Include the required empty state" if reject else "PASS")
                filename = card["deliverable"]
                dest = pathlib.Path(cwd) / filename
                if not await approve("Write", {"file_path": str(dest)}):
                    return A.Result(False, error="Write denied")
                dest.write_text(f"{card['goal']}\nAttempt {attempt}: requirements and empty states covered.\n")
                return A.Result(True, text=f"Delivered {filename}", artifacts=[filename])

        return FakeMember(member)

    async def run(self):
        # Everything, including temporary git metadata, stays within this repo.
        with tempfile.TemporaryDirectory(prefix="replay-", dir=HERE) as tmp:
            root = pathlib.Path(tmp)
            service = D.DesignOptions(root, ask=self.design_ask, members=lambda: MEMBERS,
                                      price_of=lambda m: m["price"], config={"design_autopick_s": 20 * self.scale})
            project = copy.deepcopy(self.fixture)
            engine = E.Ensemble(project["id"], project, MEMBERS, self.adapter, E.Workspace(root / "work"),
                                self.approve, lambda *args: None, self.events.append, lambda m: m["price"], {}, lead="lead")
            t0 = time.perf_counter()
            session = service.sessions[service.start(project["id"], project["brief"], project["design_options"], project["mode"])["sid"]]
            try:
                async def direction():
                    await asyncio.gather(*session["_workers"])
                    if project["mode"] == "symphony":
                        await session["_auto"]
                    else:
                        ready = [x for x in session["options"] if x["state"] == "ready"]
                        if not ready:
                            raise RuntimeError("No valid design options")
                        choice = max(ready, key=lambda x: service.score(project["brief"], x))
                        await service.pick(session["sid"], choice["id"])
                    await session["_render"]
                    if session["render"]["state"] != "ready":
                        raise RuntimeError("Design expansion failed")

                pct, _ = await asyncio.gather(engine.run(), direction())
                if pct != 100 or engine.errors:
                    raise RuntimeError(f"Replay did not finish: {pct}, {engine.errors}")
                return {"project": project["id"], "mode": project["mode"], "wall_s": round(time.perf_counter() - t0, 4),
                        "tokens": sum(b["tokens"] for b in self.bills),
                        "cost_usd": round(sum(b["cost_usd"] for b in self.bills), 6),
                        "review_rejections": self.review_rejections,
                        "design_time_to_first_option_s": session["metrics"]["time_to_first_option"],
                        "design_time_to_all_s": session["metrics"]["time_to_all"],
                        "design_cancelled": session["metrics"]["cancelled"], "cards_passed": len(project["cards"])}
            finally:
                await service.close()

    async def approve(self, who, tool, inp):
        return tool == "Write"


async def main(args):
    fixtures = [json.loads(f.read_text()) for f in sorted((HERE / "fixtures").glob("*.json"))]
    semaphore = asyncio.Semaphore(args.concurrency)

    async def replay(fixture, round_id):
        async with semaphore:
            return await Replay(fixture, round_id, args.seed, args.scale).run()

    # Periodic ticks also allow subprocess/thread completions in restricted
    # executors whose self-pipe wakeups are delayed. No model timings are mocked.
    async def tick():
        while True:
            await asyncio.sleep(0.01)
    ticker = asyncio.create_task(tick())
    t0 = time.perf_counter()
    try:
        runs = await asyncio.gather(*(replay(f, r) for r in range(args.rounds) for f in fixtures))
        await asyncio.get_running_loop().shutdown_default_executor()
    finally:
        ticker.cancel()
        await asyncio.gather(ticker, return_exceptions=True)
    first = [r["design_time_to_first_option_s"] for r in runs]
    result = {"seed": args.seed, "rounds": args.rounds, "latency_scale": args.scale, "concurrency": args.concurrency,
              "fixtures": len(fixtures), "samples": len(runs), "wall_s": round(time.perf_counter() - t0, 4),
              "tokens": sum(r["tokens"] for r in runs), "cost_usd": round(sum(r["cost_usd"] for r in runs), 6),
              "review_rejections": sum(r["review_rejections"] for r in runs),
              "design_time_to_first_option_p50_s": round(percentile(first, 0.5), 4),
              "design_time_to_first_option_p95_s": round(percentile(first, 0.95), 4), "runs": runs}
    payload = json.dumps(result, indent=2)
    if args.output:
        args.output.write_text(payload + "\n")
    print(payload)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--concurrency", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20261030)
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args()
    if args.rounds < 1 or args.scale <= 0 or args.concurrency < 1:
        parser.error("rounds, scale and concurrency must be positive")
    asyncio.run(main(args))
