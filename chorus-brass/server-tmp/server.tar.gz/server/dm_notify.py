"""Proactive private notifications. Await notify_user; limits survive server restarts.

The daily limit uses CFG.tz. Equal text is coalesced across projects/reasons for
that member and day. Consent cards count toward the same three-message limit.
"""
import asyncio
import datetime
import hashlib
import json
import re
import secrets
import time

import hooks
import redline

S = None


def bind(server):
    global S
    S = server


def _risk(reason, text, link):
    payload = {"reason": reason, "text": text, "link": link}
    verdict = redline.check(reason, payload)
    if verdict.action != "allow":
        return verdict
    flat = json.dumps(payload, ensure_ascii=False)
    for line, pattern in (
        ("money", r"花钱|付费|付款|支付|购买|充值|扣费|转账|下单|订阅|\b(pay(?:ment)?|purchase|buy|charge|checkout|spend)\b"),
        ("external", r"外发|对外|发给|转发|发帖|邮件|短信|发送.*消息|发布|\b(send[_ ]?(?:email|sms|message)|email|sms|webhook|publish|post[_ ]message)\b"),
    ):
        if re.search(pattern, flat, re.I):
            return redline.Verdict("ask", line, redline.LINES[line], "需要定音")
    return verdict


async def notify_user(member, reason, text, link):
    """Return {status, message?}; never execute an action after consent.

    member is a configured member name or dict; link is a string or a dict
    containing pid/project. Without a project link, use an active member project.
    """
    s = S
    if s is None:
        import chorus2
        s = chorus2.S
    if s is None:
        raise RuntimeError("dm_notify is not bound to a server")
    name = member.get("name") if isinstance(member, dict) else member
    if not isinstance(name, str) or not s.member(name):
        raise ValueError("unknown notification member")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("notification text must not be empty")
    audit_path = s.DATA / "audit.jsonl"
    engine = getattr(s, "_dm_hook_engine", None)
    if engine is None or engine.audit_logger.path != audit_path:
        engine = s._dm_hook_engine = hooks.HookEngine(audit_path=audit_path, session_id="dm-notify")
    args = {"member": name, "reason": redline.scrub(str(reason)),
            "text": redline.scrub(text), "link": redline.scrub(str(link))}
    decision = await hooks.run_hooks(engine, hooks.HookEvent.BEFORE_TOOL, tool="dm_notify", args=args)

    async def done(status, message=None):
        await hooks.run_hooks(engine, hooks.HookEvent.AFTER_TOOL, tool="dm_notify",
                              args={**args, "status": status})
        return {"status": status, **({"message": message} if message else {})}

    if decision.decision == hooks.Decision.DENY:
        return await done("denied")
    if s.CFG.get("dm_prefs", {}).get(name, {}).get("muted"):
        return await done("muted")
    verdict = _risk(str(reason), text, link)
    day = datetime.datetime.now(s.tz()).date().isoformat()
    key = hashlib.sha256((text.strip() + verdict.action + verdict.line).encode()).hexdigest()
    todays = [(pid, m) for pid, msgs in s.CHATS.items() for m in msgs
              if m.get("dm") == name and m.get("notification", {}).get("day") == day]
    for pid, m in todays:
        if m["notification"]["key"] == key:
            m["notification"]["count"] += 1
            s.persist(pid)
            m["rev"] = s.bump(pid)
            return await done("merged", m)
    if len(todays) >= 3:
        return await done("limited")
    pid = (link.get("pid") or link.get("project")) if isinstance(link, dict) else None
    if pid and not s.project(pid):
        raise ValueError("unknown notification project")
    if not pid:
        p = next((p for p in s.PROJECTS if not p.get("archived") and name in p.get("members", [])), None)
        if p is None:
            pid = "dm-" + secrets.token_hex(6)
            s.PROJECTS.append({"id": pid, "name": "私信", "members": [name], "created": time.time()})
            s.save(s.DATA / "projects.json", s.PROJECTS)
        else:
            pid = p["id"]
    extra = {"notification": {"day": day, "key": key, "count": 1, "reason": redline.scrub(str(reason)), "link": link}}
    if verdict.action == "deny":
        return await done("denied")
    if verdict.action == "ask" or decision.decision == hooks.Decision.ASK:
        aid = secrets.token_hex(6)
        card = redline.card(str(reason), {"text": text, "link": link}, verdict)
        extra["approval"] = {"id": aid, "tool": "dm_notify", "summary": redline.scrub(text),
            "state": "pending", "line": verdict.line, "who": name,
            "why": card["why"], "impact": card["impact"], "cost": card["cost"],
            "deadline": time.time() + s.CFG.get("consent_timeout", 600)}
        message = s.add_msg(pid, name, "请求定音：" + (verdict.why or decision.reason), dm=name, **extra)
        future = asyncio.get_running_loop().create_future()
        s.APPROVALS[aid] = {"pid": pid, "msg": message, "future": future, "who": name, "line": verdict.line}

        def finish(_=None):
            if not future.done():
                future.set_result(False)
                message["approval"]["state"] = "timeout"
                s.persist(pid)
                message["rev"] = s.bump(pid)
            s.APPROVALS.pop(aid, None)
        timer = asyncio.get_running_loop().call_later(s.CFG.get("consent_timeout", 600), finish)
        future.add_done_callback(lambda f: (timer.cancel(), finish()))
        return await done("consent", message)
    message = s.add_msg(pid, name, redline.scrub(text), dm=name, **extra)
    return await done("sent", message)
