"""Unit tests for server/autopilot.py — runnable from repo root or server/."""

from __future__ import annotations

import os
import sys
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _path in (_HERE, _ROOT):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import autopilot  # noqa: E402  (path set up above)
from autopilot import (  # noqa: E402
    FUNDING_ORDER,
    batch,
    budget_mode,
    cache_plan,
    counterfactual,
    escalate,
    funding_of,
    rank_candidates,
    review_policy,
    should_wake,
    stop_early,
)


def price_of(member):
    return member.get("price", 0.0)


def tier_of(member):
    return member.get("tier", "mid")


def seg(sid, assignee="a", status="ready", difficulty=1, est=100):
    return {
        "id": sid,
        "assignee": assignee,
        "status": status,
        "difficulty": difficulty,
        "est_tokens": est,
    }


def ids(groups):
    return [[s["id"] for s in group] for group in groups]


class FundingTests(unittest.TestCase):
    def test_funding_order_constant(self):
        self.assertEqual(
            FUNDING_ORDER, ("prepaid_plan", "subscription", "free", "payg")
        )

    def test_explicit_funding_wins(self):
        member = {"name": "x", "funding": "payg", "price": 0}
        self.assertEqual(funding_of(member, {"kind": "plan"}), "payg")

    def test_plan_quota_is_prepaid(self):
        member = {"name": "mimo", "price": 0.6, "tier": "strong"}
        self.assertEqual(funding_of(member, {"kind": "plan"}), "prepaid_plan")

    def test_cli_member_is_subscription(self):
        self.assertEqual(funding_of({"kind": "cli", "price": 5.0}, None), "subscription")

    def test_window_quota_is_subscription(self):
        self.assertEqual(funding_of({"name": "x"}, {"kind": "window"}), "subscription")

    def test_free_and_payg(self):
        self.assertEqual(funding_of({"price": 0}, None), "free")
        self.assertEqual(funding_of({"price": 0.14}, None), "payg")


class RankTests(unittest.TestCase):
    def test_prefers_plan_over_cheaper_payg(self):
        mimo = {"name": "mimo", "tier": "strong", "price": 0.6}
        deepseek = {"name": "deepseek", "tier": "strong", "price": 0.14}
        quotas = {"mimo": {"kind": "plan", "pct": 40}}
        ranked = rank_candidates([deepseek, mimo], quotas, "weak", price_of, tier_of)
        self.assertEqual(ranked, ["mimo", "deepseek"])

    def test_subscription_before_payg(self):
        claude = {"name": "claude", "kind": "cli", "tier": "strong", "price": 3.0}
        deepseek = {"name": "deepseek", "tier": "strong", "price": 0.14}
        ranked = rank_candidates([deepseek, claude], {}, "mid", price_of, tier_of)
        self.assertEqual(ranked, ["claude", "deepseek"])

    def test_filters_arrears(self):
        a = {"name": "a", "tier": "mid", "price": 0.1}
        b = {"name": "b", "tier": "mid", "price": 0.2}
        quotas = {"a": {"state": "arrears", "pct": 50}}
        ranked = rank_candidates([a, b], quotas, "weak", price_of, tier_of)
        self.assertEqual(ranked, ["b"])

    def test_filters_quota_below_five_percent(self):
        a = {"name": "a", "tier": "mid", "price": 0.1}
        b = {"name": "b", "tier": "mid", "price": 0.2}
        quotas = {"a": {"pct": 4.9}, "b": {"pct": 5}}
        ranked = rank_candidates([a, b], quotas, "weak", price_of, tier_of)
        self.assertEqual(ranked, ["b"])

    def test_filters_tier_below_need(self):
        weak = {"name": "w", "tier": "weak", "price": 0.01}
        mid = {"name": "m", "tier": "mid", "price": 0.5}
        self.assertEqual(
            rank_candidates([weak, mid], {}, "mid", price_of, tier_of), ["m"]
        )
        self.assertEqual(
            rank_candidates([weak, mid], {}, "strong", price_of, tier_of), []
        )

    def test_sorts_by_price_within_same_funding(self):
        a = {"name": "a", "tier": "mid", "price": 0.1}
        b = {"name": "b", "tier": "mid", "price": 0.3}
        ranked = rank_candidates([b, a], {}, "weak", price_of, tier_of)
        self.assertEqual(ranked, ["a", "b"])

    def test_near_cap_keeps_funded_capacity(self):
        mimo = {"name": "mimo", "tier": "strong", "price": 0.6}
        deepseek = {"name": "deepseek", "tier": "strong", "price": 0.05}
        quotas = {"mimo": {"kind": "plan", "pct": 80}}
        ranked = rank_candidates(
            [deepseek, mimo], quotas, "weak", price_of, tier_of, near_cap=True
        )
        self.assertEqual(ranked, ["mimo"])

    def test_near_cap_falls_back_to_cheapest_payg(self):
        deepseek = {"name": "deepseek", "tier": "strong", "price": 0.1}
        kimi = {"name": "kimi", "tier": "strong", "price": 0.3}
        ranked = rank_candidates(
            [kimi, deepseek], {}, "weak", price_of, tier_of, near_cap=True
        )
        self.assertEqual(ranked[0], "deepseek")
        self.assertEqual(
            sorted(ranked), ["deepseek", "kimi"]
        )


class EscalateTests(unittest.TestCase):
    def _members(self):
        return [
            {"name": "w", "tier": "weak", "price": 0.1, "funding": "payg"},
            {"name": "m1", "tier": "mid", "price": 0.5, "funding": "payg"},
            {"name": "m2", "tier": "mid", "price": 0.9, "funding": "prepaid_plan"},
            {"name": "s", "tier": "strong", "price": 1.0, "funding": "payg"},
        ]

    def test_goes_exactly_one_tier_up(self):
        self.assertEqual(
            escalate("w", self._members(), {}, price_of, tier_of), "m2"
        )

    def test_none_at_strongest_tier(self):
        self.assertIsNone(escalate("s", self._members(), {}, price_of, tier_of))

    def test_none_when_no_higher_capable_member(self):
        members = [
            {"name": "w", "tier": "weak", "price": 0.1},
            {"name": "s", "tier": "strong", "price": 1.0},
        ]
        self.assertIsNone(escalate("w", members, {}, price_of, tier_of))

    def test_unknown_member_is_none(self):
        self.assertIsNone(escalate("ghost", self._members(), {}, price_of, tier_of))


class WakeTests(unittest.TestCase):
    def test_idle_member_never_woken(self):
        project = {
            "lead": "lead",
            "segments": [{"assignee": "other", "status": "ready"}],
        }
        self.assertFalse(should_wake("bystander", project, {"kind": "build"}))
        self.assertFalse(should_wake("bystander", project, None))

    def test_assignee_of_ready_or_running_is_woken(self):
        project = {
            "lead": "lead",
            "segments": [{"assignee": "dev", "status": "running"}],
        }
        self.assertTrue(should_wake("dev", project, {"kind": "build"}))

    def test_mention_always_wakes(self):
        project = {"lead": "lead", "segments": []}
        event = {"kind": "build", "mentions": ["qa"]}
        self.assertTrue(should_wake("qa", project, event))

    def test_lead_only_for_plan_or_review(self):
        project = {"lead": "lead", "segments": []}
        self.assertTrue(should_wake("lead", project, {"kind": "plan"}))
        self.assertTrue(should_wake("lead", project, {"kind": "review"}))
        self.assertFalse(should_wake("lead", project, {"kind": "build"}))


class BatchTests(unittest.TestCase):
    def test_groups_consecutive_cheap_ready_segments(self):
        segments = [seg("s1"), seg("s2"), seg("s3", assignee="b")]
        self.assertEqual(ids(batch(segments)), [["s1", "s2"], ["s3"]])

    def test_respects_token_cap(self):
        segments = [seg("s1", est=100), seg("s2", est=100), seg("s3", est=100)]
        self.assertEqual(ids(batch(segments, max_tokens=150)), [["s1"], ["s2"], ["s3"]])
        self.assertEqual(ids(batch(segments, max_tokens=200)), [["s1", "s2"], ["s3"]])

    def test_hard_and_non_ready_go_alone(self):
        segments = [
            seg("s1", difficulty=4),
            seg("s2", status="running"),
            seg("s3", difficulty=1),
        ]
        self.assertEqual(ids(batch(segments)), [["s1"], ["s2"], ["s3"]])

    def test_preserves_input_order(self):
        segments = [seg("s1"), seg("s2", difficulty=3), seg("s3")]
        self.assertEqual(ids(batch(segments)), [["s1"], ["s2"], ["s3"]])

    def test_difficulty_boundary_is_two(self):
        segments = [seg("s1", difficulty=2), seg("s2", difficulty=2)]
        self.assertEqual(ids(batch(segments, max_tokens=10_000)), [["s1", "s2"]])


class BudgetModeTests(unittest.TestCase):
    def test_thresholds(self):
        self.assertEqual(budget_mode(0.0, 1000.0), "normal")
        self.assertEqual(budget_mode(699.9, 1000.0), "normal")
        self.assertEqual(budget_mode(700.0, 1000.0), "frugal")
        self.assertEqual(budget_mode(899.9, 1000.0), "frugal")
        self.assertEqual(budget_mode(900.0, 1000.0), "minimal")
        self.assertEqual(budget_mode(999.9, 1000.0), "minimal")
        self.assertEqual(budget_mode(1000.0, 1000.0), "stop")
        self.assertEqual(budget_mode(1500.0, 1000.0), "stop")

    def test_zero_cap(self):
        self.assertEqual(budget_mode(0.0, 0.0), "normal")
        self.assertEqual(budget_mode(1.0, 0.0), "stop")


class ReviewPolicyTests(unittest.TestCase):
    def test_normal(self):
        self.assertTrue(review_policy("normal", {"difficulty": 3}, 0.95))
        self.assertFalse(review_policy("normal", {"difficulty": 2}, 0.95))
        self.assertTrue(review_policy("normal", {"difficulty": 1}, 0.5))
        self.assertFalse(review_policy("normal", {"difficulty": 1}, 0.7))

    def test_frugal(self):
        self.assertTrue(review_policy("frugal", {"difficulty": 4}, 0.95))
        self.assertFalse(review_policy("frugal", {"difficulty": 3}, 0.95))
        self.assertTrue(review_policy("frugal", {"difficulty": 2}, 0.49))
        self.assertFalse(review_policy("frugal", {"difficulty": 2}, 0.5))

    def test_minimal(self):
        self.assertTrue(review_policy("minimal", {"difficulty": 5}, 0.1))
        self.assertFalse(review_policy("minimal", {"difficulty": 4}, 0.1))

    def test_stop_never_reviews(self):
        self.assertFalse(review_policy("stop", {"difficulty": 5}, 0.1))
        self.assertFalse(review_policy("unknown", {"difficulty": 5}, 0.1))


class CachePlanTests(unittest.TestCase):
    def test_prefix_is_stable_across_tasks(self):
        first = cache_plan("SYS", "PERSONA", "SKILLS", "task one")
        second = cache_plan("SYS", "PERSONA", "SKILLS", "task two")
        self.assertEqual(first[0], second[0])
        self.assertNotEqual(first[1]["content"], second[1]["content"])

    def test_shape_and_order(self):
        messages = cache_plan("SYS", "PERSONA", "SKILLS", "do the thing")
        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0]["role"], "system")
        self.assertIs(messages[0]["cache"], True)
        for part in ("SYS", "PERSONA", "SKILLS"):
            self.assertIn(part, messages[0]["content"])
        self.assertEqual(messages[1]["role"], "user")
        self.assertEqual(messages[1]["content"], "do the thing")

    def test_empty_parts_are_dropped(self):
        messages = cache_plan("SYS", "", "", "task")
        self.assertEqual(messages[0]["content"], "SYS")


class CounterfactualTests(unittest.TestCase):
    def test_math(self):
        ledger = [{"in": 1_000_000, "out": 200_000, "cached": 400_000, "cost": 0.5}]
        result = counterfactual(ledger, (3.0, 0.3, 15.0))
        self.assertAlmostEqual(result["baseline"], 4.92, places=9)
        self.assertAlmostEqual(result["actual"], 0.5, places=9)
        self.assertAlmostEqual(result["saved"], 4.42, places=9)
        self.assertAlmostEqual(result["pct"], 4.42 / 4.92 * 100.0, places=9)
        self.assertEqual(result["label"], "估算")

    def test_empty_ledger(self):
        result = counterfactual([], (3.0, 0.3, 15.0))
        self.assertEqual(result["actual"], 0.0)
        self.assertEqual(result["baseline"], 0.0)
        self.assertEqual(result["saved"], 0.0)
        self.assertEqual(result["pct"], 0.0)

    def test_multiple_rows_sum(self):
        ledger = [
            {"in": 2_000_000, "out": 0, "cached": 0, "cost": 1.0},
            {"in": 0, "out": 1_000_000, "cached": 0, "cost": 0.6},
        ]
        result = counterfactual(ledger, (1.0, 1.0, 2.0))
        self.assertAlmostEqual(result["actual"], 1.6, places=9)
        self.assertAlmostEqual(result["baseline"], 4.0, places=9)
        self.assertAlmostEqual(result["saved"], 2.4, places=9)


class StopEarlyTests(unittest.TestCase):
    def test_all_passed_stops(self):
        self.assertTrue(stop_early([True, True, True]))

    def test_any_failed_continues(self):
        self.assertFalse(stop_early([True, False]))
        self.assertFalse(stop_early([False]))

    def test_empty_does_not_stop(self):
        self.assertFalse(stop_early([]))


class ModuleTests(unittest.TestCase):
    def test_public_api_is_present(self):
        for name in (
            "funding_of",
            "rank_candidates",
            "escalate",
            "should_wake",
            "batch",
            "budget_mode",
            "review_policy",
            "cache_plan",
            "counterfactual",
            "stop_early",
        ):
            self.assertTrue(callable(getattr(autopilot, name)), name)


if __name__ == "__main__":
    unittest.main(verbosity=2)


class UsedPercentRegression(unittest.TestCase):
    def test_used_percent_is_converted_to_remaining(self):
        for quota, expected in [({'used_pct': 97}, []), ({'used_pct': '97'}, []),
                                ({'used_pct': 0}, ['a']), ({'pct': 80, 'used_pct': 97}, ['a'])]:
            with self.subTest(quota=quota):
                self.assertEqual(rank_candidates([{'name': 'a', 'tier': 'mid'}], {'a': quota}, 'weak', price_of, tier_of), expected)

    def test_missing_usage_stays_unknown(self):
        for quota in ({'state': 'ok'}, {'used_pct': None}, {'used_pct': 'unknown'}):
            self.assertIsNone(autopilot._pct_of(quota))

    def test_null_remaining_uses_usage_and_preserves_five_percent_boundary(self):
        for used, expected in [(97, []), ('97', []), (100, []), (95, ['a']), (0, ['a'])]:
            with self.subTest(used=used):
                quota = {'pct': None, 'used_pct': used}
                self.assertEqual(autopilot._pct_of(quota), 100 - float(used))
                self.assertEqual(rank_candidates([{'name': 'a', 'tier': 'mid'}], {'a': quota}, 'weak', price_of, tier_of), expected)
        self.assertEqual(autopilot._pct_of({'pct': 0, 'used_pct': 0}), 0)
