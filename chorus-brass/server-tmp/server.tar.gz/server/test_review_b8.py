"""B8: adversarial checks of MiMo's B7 review and verified regressions."""
import asyncio
import json
import unittest
from unittest.mock import AsyncMock, Mock, patch

import adapters as A
import checkpoints as CK
import ensemble as E
import orchestra as O
from test_faults import Base, Fake, cards


class TestB8(Base):
    async def test_older_call_and_rejected_calls_cannot_release_live_probe(self):
        e = self.ens(cards(1), [self.lead()])
        now = [0]
        e.breaker = E.Breaker(threshold=1, cooldown=10, now=lambda: now[0])
        entered = [asyncio.Event(), asyncio.Event()]
        release = [asyncio.Event(), asyncio.Event()]
        calls = 0

        class Controlled(Fake):
            async def run(self, *args, **kwargs):
                nonlocal calls
                i = calls
                calls += 1
                entered[i].set()
                await asyncio.wait_for(release[i].wait(), 5)
                return A.Result(ok=False, error="503")

        ad = Controlled(self.lead())
        # Independent worktrees may overlap; the same cwd intentionally queues.
        old = asyncio.create_task(e.call(ad, "", lambda st: None, self._ok, cwd=str(self.root / "old")))
        self.addAsyncCleanup(self._drain, old)
        await asyncio.wait_for(entered[0].wait(), 1)
        e.breaker.fail("L")
        now[0] = 11
        probe = asyncio.create_task(e.call(ad, "", lambda st: None, self._ok, cwd=str(self.root / "probe")))
        self.addAsyncCleanup(self._drain, probe)
        await asyncio.wait_for(entered[1].wait(), 1)
        release[0].set()
        await asyncio.wait_for(old, 1)
        for _ in range(10):
            denied = await e.call(ad, "", lambda st: None, self._ok)
            self.assertEqual(denied.error, E.BREAKER_BUSY)
            self.assertIn("L", e.breaker.probing)
        probe.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(probe, 1)
        self.assertNotIn("L", e.breaker.probing)
        self.assertEqual(calls, 2)

    async def test_cwd_queue_timeout_releases_probe_without_unlocking_owner(self):
        e = self.ens(cards(1), [self.lead()], card_timeout=0.05)
        e.breaker = E.Breaker(threshold=1, cooldown=0)
        e.breaker.fail("L")
        cwd = str(self.root / "shared")
        lock = E.background.cwd_lock(cwd)
        ad = Fake(self.lead())
        with patch.object(ad, "run", AsyncMock()) as run:
            async with lock:
                result = await asyncio.wait_for(e.call(ad, "", lambda st: None, self._ok, cwd=cwd), 1)
                self.assertEqual(result.error, "timeout")
                self.assertNotIn("L", e.breaker.probing)
                self.assertTrue(lock.locked())
                run.assert_not_awaited()
            run.return_value = A.Result(ok=True)
            result = await asyncio.wait_for(e.call(ad, "", lambda st: None, self._ok, cwd=cwd), 1)
            self.assertTrue(result.ok)
            run.assert_awaited_once()
        self.assertFalse(lock.locked())

    async def _drain(self, task):
        task.cancel()
        await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 1)

    async def test_busy_execution_waits_and_resumes_without_failure_or_billing(self):
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        p = cards(1)
        members = [self.lead(), {"name": "w"}]
        e = self.ens(p, members, ckpt=db, available=lambda m: m["name"] == "w")
        e.account = Mock()
        # A real await between choose() and call(): another task trips the member.
        async def share(card, member):
            e.breaker.until[member["name"]] = e.breaker.now() + 10
            return []
        e.share = share
        await e.run()
        card = p["cards"][0]
        self.assertEqual(card["state"], "waiting")
        self.assertTrue(card["_execute_pending"])
        self.assertNotIn("_review_pending", card)
        self.assertEqual(e.stats, {})
        self.assertEqual(e.breaker.fails, {})
        self.assertEqual(Fake.log, [])
        e.account.assert_not_called()
        self.assertFalse(any("失败" in ev.text for ev in self.events))
        p2 = cards(1)
        e2 = self.ens(p2, members, ckpt=db)
        e2.resume()
        self.assertEqual(p2["cards"][0]["retry_at"], card["retry_at"])
        with patch.object(E.time, "time", return_value=card["retry_at"] - 1):
            self.assertEqual(e2.ready(), [])
        with patch.object(E.time, "time", return_value=card["retry_at"] + 1):
            # Execution waits for a worker, not for a reviewer.
            with patch.object(e2, "reviewer", return_value=None):
                self.assertEqual(e2.ready(), p2["cards"])
            self.assertEqual(await e2.run(), 100)
        self.assertEqual(e2.stats["w"]["runs"], 1)
        self.assertNotIn("_execute_pending", p2["cards"][0])

    async def test_resumed_candidate_keeps_usage_cost_without_double_billing(self):
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        p = cards(1)
        p["cards"][0]["_candidate"] = True
        members = [self.lead(), {"name": "w", "price": 5}]
        e = self.ens(p, members, ckpt=db)
        await e.ws.init()
        e.review = AsyncMock(return_value=None)
        e.account = Mock()
        await e.run_card(p["cards"][0])
        self.assertEqual(p["cards"][0]["_review_pending"]["usage"], {"in": 1, "out": 1})
        e.account.assert_called_once_with(members[1], {"in": 1, "out": 1}, "execute")
        p2 = cards(1)
        e2 = self.ens(p2, members, ckpt=db)
        e2.resume()
        e2.account = Mock()
        e2.review = AsyncMock(return_value="PASS")
        await e2.run_card(p2["cards"][0])
        self.assertEqual(p2["cards"][0]["_cost"], 6)
        self.assertEqual(p2["cards"][0]["_passed_by"], "w")
        self.assertEqual([n for n, _ in Fake.log], ["w"])
        e2.account.assert_not_called()
        self.assertNotIn("w", e2.stats)

    async def test_busy_member_uses_available_alternative_immediately(self):
        p = cards(1)
        members = [self.lead(), {"name": "busy", "price": 0.1}, {"name": "w"}]
        e = self.ens(p, members)
        async def share(card, member):
            if member["name"] == "busy":
                e.breaker.until["busy"] = e.breaker.now() + 10
            return []
        e.share = share
        self.assertEqual(await e.run(), 100)
        self.assertEqual(p["cards"][0]["assignee"], "w")
        self.assertNotIn("busy", e.stats)
        self.assertNotIn("busy", e.breaker.fails)
        self.assertNotIn("busy", [name for name, _ in Fake.log])

    async def test_review_does_not_retry_failed_reviewer_despite_failover(self):
        members = [self.lead("down"), {"name": "w"},
                   {"name": "r1", "lead_role": True, "mode": "down", "price": 30},
                   {"name": "r2", "lead_role": True, "mode": "down", "price": 20}]
        e = self.ens(cards(1), members)
        verdict = await e.review({"id": "c0", "title": "t", "assignee": "w"}, A.Result(ok=True), "")
        self.assertIsNone(verdict)
        self.assertEqual([n for n, _ in Fake.log], ["L", "r1", "r2"])

    async def test_legacy_effect_keeps_saved_delivery(self):
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        db.save_card("p", dict(cards(1)["cards"][0], state="review", summary="saved", artifacts=["out.txt"]))
        db.done_effect("p:merge:c0", {"by": "w"})
        p = cards(1)
        e = self.ens(p, [self.lead(), {"name": "w"}], ckpt=db)
        e.resume()
        self.assertEqual(e.done["c0"]["summary"], "saved")
        self.assertEqual(e.done["c0"]["artifacts"], ["out.txt"])
        self.assertEqual(e.done["c0"]["state"], "passed")

    async def test_best_of_sqlite_failure_does_not_erase_merged_winner(self):
        db = CK.Checkpoints(self.root / "ck.db")
        self.addCleanup(db.close)
        p = cards(1)
        p["cards"][0]["best_of"] = 2
        e = self.ens(p, [self.lead(), {"name": "a"}, {"name": "b"}], ckpt=db)
        await e.ws.init()
        with patch.object(db, "done_effect", side_effect=RuntimeError("sqlite write failed")):
            with self.assertRaisesRegex(RuntimeError, "sqlite write failed"):
                await e.best_of(p["cards"][0])
        winner = p["cards"][0]["artifacts"][0]
        self.assertEqual((e.ws.repo / winner).read_text(), "ok")
        _, committed = await E.git(e.ws.repo, "show", f"main:{winner}")
        self.assertEqual(committed, "ok")
        self.assertEqual(list(e.ws.trees.glob("*-bo*")), [])
        _, branches = await E.git(e.ws.repo, "branch", "--list", "card/*-bo*")
        self.assertFalse(branches.strip())
        self.assertIsNone(db.effect("p:merge:c0"))  # the cross-system transaction gap still exists

    async def test_watchdog_logs_stalled_error_and_continues(self):
        e = self.ens(cards(1), [self.lead()])
        e.stall_check = 0.001
        checked = asyncio.Event()
        def stalled(*args, **kwargs):
            checked.set()
            raise RuntimeError("stalled failed")
        with patch.object(e.hb, "stalled", side_effect=stalled):
            task = asyncio.create_task(e.watchdog())
            try:
                await asyncio.wait_for(checked.wait(), 1)
                self.assertFalse(task.done())
                self.assertTrue(any("watchdog:" in err and "stalled failed" in err for err in e.errors))
            finally:
                await self._drain(task)


class TestB8Ids(unittest.TestCase):
    def test_ids_terminate_and_remain_unique_under_repeated_collisions(self):
        raw = [{"id": "s2"}, {"id": "s3"}, {"id": "s4"}] + [{"id": "s2"}] * 30
        out = O.parse_plan(json.dumps(raw))
        ids = [s["id"] for s in out]
        self.assertEqual(len(ids), 24)
        self.assertEqual(len(set(ids)), 24)
        self.assertEqual(ids[:4], ["s2", "s3", "s4", "s5"])
        huge = O.parse_plan('[{"id":"s999999999999999999"},{"id":"s999999999999999999"}]')
        self.assertEqual([s["id"] for s in huge], ["s999999999999999999", "s2"])
