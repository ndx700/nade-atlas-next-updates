"""
Tests for server/quota_probes.py — no network, mocked HTTP session.

Run from repo root:  python -m pytest -q server/test_quota_probes.py
Run from server/:    python -m pytest -q test_quota_probes.py
"""

import asyncio
import json
import os
import sys
import time
import unittest
from unittest import IsolatedAsyncioTestCase, TestCase

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import quota_probes as qp  # noqa: E402


# --------------------------------------------------------------------------- #
# fake HTTP session
# --------------------------------------------------------------------------- #

class FakeResp:
    def __init__(self, status=200, data=None, text=""):
        self.status = status
        self._data = data
        self._text = text

    async def json(self, content_type=None):
        if self._data is None:
            raise ValueError("no json")
        return self._data

    async def text(self):
        return self._text


class FakeCM:
    def __init__(self, resp):
        self._resp = resp

    async def __aenter__(self):
        return self._resp

    async def __aexit__(self, *exc):
        return False


class FakeSession:
    """Route by URL substring; raise on unmatched to simulate network failure."""

    def __init__(self, routes=None, default=None):
        self.routes = list(routes or [])
        self.default = default
        self.calls = []

    def _match(self, url):
        for substr, resp in self.routes:
            if substr in url:
                return resp
        return self.default

    def get(self, url, headers=None, **kw):
        self.calls.append(("GET", url, headers))
        resp = self._match(url)
        if resp is None:
            raise RuntimeError("network down")
        if isinstance(resp, Exception):
            raise resp
        return FakeCM(resp)

    def post(self, url, headers=None, **kw):
        self.calls.append(("POST", url, headers))
        resp = self._match(url)
        if resp is None:
            raise RuntimeError("network down")
        if isinstance(resp, Exception):
            raise resp
        return FakeCM(resp)


def make_ctx(session=None, **kw):
    return qp.Ctx(session if session is not None else FakeSession(), **kw)


# --------------------------------------------------------------------------- #
# tests
# --------------------------------------------------------------------------- #

class TestFromHeaders(unittest.TestCase):
    def test_openai_headers(self):
        res = qp.from_headers({
            "x-ratelimit-remaining-tokens": "3000",
            "x-ratelimit-limit-tokens": "10000",
            "x-ratelimit-reset-tokens": "6m0s",
        })
        self.assertIsNotNone(res)
        self.assertAlmostEqual(res["pct"], 30.0)
        self.assertEqual(res["method"], "headers")
        self.assertEqual(res["kind"], "window")
        self.assertTrue(res["reset"])  # parsed duration → ISO

    def test_anthropic_headers(self):
        res = qp.from_headers({
            "anthropic-ratelimit-tokens-remaining": "250",
            "anthropic-ratelimit-tokens-limit": "1000",
            "anthropic-ratelimit-tokens-reset": "2025-01-01T00:00:00Z",
        })
        self.assertIsNotNone(res)
        self.assertAlmostEqual(res["pct"], 25.0)
        self.assertEqual(res["reset"], "2025-01-01T00:00:00Z")

    def test_headers_none(self):
        self.assertIsNone(qp.from_headers({}))
        self.assertIsNone(qp.from_headers({"content-type": "application/json"}))


class TestFromError(unittest.TestCase):
    def test_402(self):
        res = qp.from_error(402, "")
        self.assertIsNotNone(res)
        self.assertEqual(res["state"], "arrears")
        self.assertEqual(res["accounts"][0]["amount"], 0.0)

    def test_insufficient_text(self):
        res = qp.from_error(429, "insufficient balance")
        self.assertEqual(res["state"], "arrears")

    def test_quota_text(self):
        res = qp.from_error(403, "You exceeded your current quota")
        self.assertEqual(res["state"], "arrears")

    def test_no_signal(self):
        self.assertIsNone(qp.from_error(500, "server error"))


class TestCliParsers(unittest.TestCase):
    def test_codex_rate_limits(self):
        res = qp.codex_rate_limits({
            "primary": {"used_percent": 37, "window_minutes": 300, "resets_at": "2025-01-01T05:00:00Z"},
            "secondary": {"used_percent": 10, "resets_in_seconds": 600},
        })
        self.assertAlmostEqual(res["pct"], 63.0)
        self.assertAlmostEqual(res["week"], 90.0)
        self.assertEqual(res["reset"], "2025-01-01T05:00:00Z")
        self.assertTrue(res["week_reset"])

    def test_latest_codex_rate_limits(self):
        lines = [
            '{"type":"message"}',
            '{"rate_limits":{"primary":{"used_percent":37},"secondary":{"used_percent":10}}}',
        ]
        res = qp.latest_codex_rate_limits(lines)
        self.assertAlmostEqual(res["pct"], 63.0)

class TestDetect(unittest.TestCase):
    def test_detect_known(self):
        self.assertEqual(qp.detect({"base": "https://api.deepseek.com"}), "deepseek")
        self.assertEqual(qp.detect({"base": "https://api.moonshot.cn/v1"}), "moonshot")
        self.assertEqual(qp.detect({"base": "https://openrouter.ai/api/v1"}), "openrouter")
        self.assertEqual(qp.detect({"base": "https://api.openai.com/v1"}), "openai")
        self.assertEqual(qp.detect({"base": "https://api.anthropic.com/v1"}), "anthropic")
        self.assertEqual(qp.detect({"base": "https://api.z.ai/api/anthropic"}), "glm")
        self.assertEqual(qp.detect({"base": "https://token-plan.xiaomimimo.com/v1"}), "mimo_plan")
        self.assertEqual(qp.detect({"base": "https://my-relay.example.com/v1"}), "relay")

    def test_detect_cli(self):
        self.assertEqual(qp.detect({"kind": "cli", "cli": "codex"}), "codex")
        self.assertEqual(qp.detect({"kind": "cli", "cli": "claude"}), "claude")


class TestAdapters(IsolatedAsyncioTestCase):
    async def test_deepseek_cny_and_zero_usd(self):
        sess = FakeSession([("api.deepseek.com/user/balance", FakeResp(200, {
            "balance_infos": [
                {"currency": "CNY", "total_balance": "12.30"},
                {"currency": "USD", "total_balance": "0"},
            ]
        }))])
        res = await qp.probe({"base": "https://api.deepseek.com", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["source"], "official")
        self.assertEqual(res["method"], "api")
        self.assertEqual(len(res["accounts"]), 1)  # zero USD dropped
        self.assertEqual(res["accounts"][0]["cur"], "¥")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 12.30)
        self.assertEqual(res["state"], "ok")

    async def test_moonshot(self):
        sess = FakeSession([("users/me/balance", FakeResp(200, {"data": {"available_balance": 5.5}}))])
        res = await qp.probe({"base": "https://api.moonshot.cn/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "¥")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 5.5)

    async def test_kimi_coding(self):
        sess = FakeSession([("api.kimi.com/coding/v1/usages", FakeResp(200, {
            "limits": [{"detail": {"limit": 1000, "remaining": 630, "resetTime": 1735689600000}}],
            "usage": {"limit": 10000, "remaining": 9000, "resetTime": 1736294400000},
        }))])
        res = await qp.probe({"base": "https://api.kimi.com/coding", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(res["pct"], 63.0)
        self.assertAlmostEqual(res["week"], 90.0)
        self.assertTrue(res["reset"])

    async def test_siliconflow(self):
        sess = FakeSession([("user/info", FakeResp(200, {"data": {"totalBalance": 8.25}}))])
        res = await qp.probe({"base": "https://api.siliconflow.cn/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "¥")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 8.25)

    async def test_openrouter(self):
        sess = FakeSession([("credits", FakeResp(200, {"data": {"total_credits": 10.0, "total_usage": 2.5}}))])
        res = await qp.probe({"base": "https://openrouter.ai/api/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "$")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 7.5)

    async def test_stepfun(self):
        sess = FakeSession([("api.stepfun.com/v1/accounts", FakeResp(200, {"balance": 3.0}))])
        res = await qp.probe({"base": "https://api.stepfun.com/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "¥")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 3.0)

    async def test_minimax_payg_has_no_balance_api(self):
        # MiniMax 按量没有公开余额接口：不再请求 api.minimax.chat，走「已花」+ 填一次余额
        sess = FakeSession([("api.minimax.chat/v1/user/balance", FakeResp(200, {"data": {"balance": 42.0}}))])
        res = await qp.probe({"base": "https://api.minimax.chat/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertFalse(any("minimax.chat" in c[1] for c in sess.calls))
        self.assertEqual(res["kind"], "spend")
        self.assertTrue(res["unset"])
        self.assertTrue(res["short"].startswith("已花 ¥"))

    async def test_minimax_plan_auto_detected(self):
        sess = FakeSession([("token_plan/remains", FakeResp(200, {
            "base_resp": {"status_code": 0},
            "model_remains": [{"current_interval_remaining_percent": 40, "current_weekly_remaining_percent": 70}]}))])
        res = await qp.probe({"base": "https://api.minimaxi.com/v1", "key": "k"}, {"name": "m"}, make_ctx(sess))  # 没开 plan 开关
        self.assertAlmostEqual(res["pct"], 40.0)
        self.assertAlmostEqual(res["week"], 70.0)

    async def test_glm_plan_auto_detected(self):
        sess = FakeSession([("open.bigmodel.cn/api/monitor/usage/quota/limit", FakeResp(200, {
            "data": {"limits": [{"type": "TOKENS_LIMIT", "percentage": 20}]}}))])
        res = await qp.probe({"base": "https://open.bigmodel.cn/api/paas/v4", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(res["pct"], 80.0)

    async def test_base_without_v1_still_works(self):
        sess = FakeSession([("api.moonshot.cn/v1/users/me/balance", FakeResp(200, {"data": {"available_balance": 9.5}})),
                            ("api.siliconflow.cn/v1/user/info", FakeResp(200, {"data": {"totalBalance": "3.5"}})),
                            ("openrouter.ai/api/v1/credits", FakeResp(200, {"data": {"total_credits": 10, "total_usage": 4}}))])
        for p, amt in (({"key": "k"}, 9.5),):
            r = await qp.probe({"base": "https://api.moonshot.cn", "key": "k"}, {"name": "m"}, make_ctx(sess))
            self.assertAlmostEqual(r["accounts"][0]["amount"], 9.5)
        r = await qp.probe({"base": "https://api.siliconflow.cn", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(r["accounts"][0]["amount"], 3.5)
        r = await qp.probe({"base": "https://openrouter.ai/api", "key": "k"}, {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(r["accounts"][0]["amount"], 6.0)

    async def test_minimax_plan(self):
        sess = FakeSession([("coding_plan/remains", FakeResp(200, {
            "model_remains": [{
                "current_interval_remaining_percent": 63,
                "current_weekly_remaining_percent": 80,
                "end_time": 1735689600000,
                "weekly_end_time": 1736294400000,
            }]
        }))])
        res = await qp.probe({"base": "https://api.minimaxi.com/v1", "key": "k", "plan": True},
                             {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(res["pct"], 63.0)
        self.assertAlmostEqual(res["week"], 80.0)
        self.assertTrue(res["reset"])
        self.assertTrue(res["week_reset"])

    async def test_glm_plan(self):
        sess = FakeSession([("api.z.ai/api/monitor/usage/quota/limit", FakeResp(200, {
            "data": {"limits": [{"type": "TOKENS_LIMIT", "percentage": 37, "nextResetTime": 1735689600000}]}
        }))])
        res = await qp.probe({"base": "https://api.z.ai/api/anthropic", "key": "k", "plan": True},
                             {"name": "m"}, make_ctx(sess))
        self.assertAlmostEqual(res["pct"], 63.0)  # used 37 → remaining 63
        self.assertTrue(res["reset"])

    async def test_xai_negative_cents(self):
        sess = FakeSession([("management-api.x.ai", FakeResp(200, {"total": {"val": -12345}}))])
        res = await qp.probe({"base": "https://api.x.ai/v1", "mgmt_key": "mk", "team_id": "t1"},
                             {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "$")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 123.45)

    async def test_relay_oneapi(self):
        sess = FakeSession([
            ("billing/subscription", FakeResp(200, {"hard_limit_usd": 100.0})),
            ("billing/usage", FakeResp(200, {"total_usage": 2500})),  # cents
        ])
        res = await qp.probe({"base": "https://relay.example.com/v1", "key": "k"},
                             {"name": "m"}, make_ctx(sess))
        self.assertEqual(res["accounts"][0]["cur"], "$")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 75.0)  # 100 - 25


class TestChain(IsolatedAsyncioTestCase):
    async def test_mimo_plan_estimate(self):
        ctx = make_ctx(FakeSession(), spent_tokens=lambda name: 1e8)
        res = await qp.probe({"base": "https://token-plan.xiaomimimo.com/v1", "plan_tokens": 4.1e9},
                             {"name": "m"}, ctx)
        self.assertEqual(res["source"], "estimate")
        self.assertEqual(res["method"], "ledger")
        self.assertEqual(res["kind"], "plan")
        self.assertAlmostEqual(res["pct"], (4.1e9 - 1e8) / 4.1e9 * 100.0, places=4)
        self.assertEqual(res["accounts"][0]["cur"], "tokens")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 4.0e9)

    async def test_openai_headers_are_rate_hint_not_quota(self):
        ctx = make_ctx(FakeSession(), last_headers=lambda name: {
            "x-ratelimit-remaining-tokens": "6300", "x-ratelimit-limit-tokens": "10000"})
        res = await qp.probe({"base": "https://api.openai.com/v1", "key": "k"}, {"name": "m"}, ctx)
        self.assertIsNone(res["pct"])            # 每分钟限速不是余额
        self.assertEqual(res["kind"], "spend")
        self.assertTrue(res["unset"])
        self.assertIn("63%", res["note"])

    async def test_wallet_beats_headers(self):
        ctx = make_ctx(FakeSession(), last_headers=lambda name: {
            "x-ratelimit-remaining-tokens": "100", "x-ratelimit-limit-tokens": "10000"})
        res = await qp.probe({"base": "https://api.openai.com/v1", "key": "k", "id": "p",
                              "wallet": {"amount": 50, "cur": "$", "spent0": 0}}, {"name": "m"}, ctx)
        self.assertEqual(res["method"], "wallet")
        self.assertEqual(res["state"], "ok")

    async def test_mimo_plan_exhausted_detected(self):
        ctx = make_ctx(FakeSession(), last_error=lambda n: {"status": 429, "at": time.time(),
                       "body": '{"message":"quota exhausted","type":"limitation"}'})
        res = await qp.probe({"base": "https://token-plan-cn.xiaomimimo.com/v1", "key": "tp-x"}, {"name": "m"}, ctx)
        self.assertEqual(res["state"], "arrears")
        self.assertEqual(res["short"], "本期用完")

    async def test_mimo_plan_without_total_shows_used(self):
        ctx = make_ctx(FakeSession(), spent_tokens=lambda n: 123456789)
        res = await qp.probe({"base": "https://token-plan-cn.xiaomimimo.com/v1", "key": "tp-x"}, {"name": "m"}, ctx)
        self.assertEqual(res["state"], "ok")
        self.assertIn("已用", res["short"])
        self.assertIn("亿", res["short"])

    async def test_arrears_uses_provider_currency(self):
        ctx = make_ctx(FakeSession(), last_error=lambda n: {"status": 402, "body": "", "at": time.time()})
        res = await qp.probe({"base": "https://api.deepseek.com", "key": "k"}, {"name": "m"}, ctx)
        self.assertEqual(res["accounts"][0]["cur"], "¥")
        ctx = make_ctx(FakeSession(), last_error=lambda n: {"status": 402, "body": "credit balance is too low", "at": time.time()})
        res = await qp.probe({"base": "https://api.anthropic.com", "key": "k"}, {"name": "m"}, ctx)
        self.assertEqual(res["accounts"][0]["cur"], "$")

    async def test_error_402_arrears(self):
        ctx = make_ctx(FakeSession(), last_error=lambda name: {"status": 402, "body": "", "at": time.time()})
        res = await qp.probe({"base": "https://api.deepseek.com", "key": "k"}, {"name": "m"}, ctx)
        self.assertEqual(res["state"], "arrears")
        self.assertEqual(res["method"], "error")
        self.assertEqual(res["accounts"][0]["amount"], 0.0)

    async def test_wallet_estimate(self):
        ctx = make_ctx(FakeSession(), spent_money=lambda pid, cur: 3.0)
        res = await qp.probe(
            {"base": "https://dashscope.aliyuncs.com/v1", "key": "k",
             "wallet": {"amount": 10.0, "cur": "¥", "set_at": 0, "spent0": 1.0}},
            {"name": "m"}, ctx)
        self.assertEqual(res["source"], "estimate")
        self.assertEqual(res["method"], "wallet")
        self.assertAlmostEqual(res["accounts"][0]["amount"], 8.0)  # 10 - (3 - 1)

    async def test_unknown_provider(self):
        res = await qp.probe({"base": "https://unknown.example.com/v1", "key": "k"},
                             {"name": "m"}, make_ctx(FakeSession()))
        self.assertEqual(res["kind"], "spend")       # 不再是「额度未知」：显示已花多少，并提示填一次余额
        self.assertTrue(res["unset"])
        self.assertTrue(res["short"].startswith("已花"))

    async def test_network_exception_falls_to_ledger(self):
        sess = FakeSession()  # every call raises
        ctx = make_ctx(sess, spent_tokens=lambda name: 0)
        res = await qp.probe({"base": "https://api.deepseek.com", "key": "k", "plan_tokens": 1000},
                             {"name": "m"}, ctx)
        self.assertEqual(res["method"], "ledger")
        self.assertEqual(res["source"], "estimate")
        self.assertAlmostEqual(res["pct"], 100.0)

    async def test_codex_cli_rate_limits(self):
        lines = [
            '{"type":"message"}',
            '{"rate_limits":{"primary":{"used_percent":37},"secondary":{"used_percent":10}}}',
        ]

        def read_file(path):
            return "\n".join(lines)

        ctx = make_ctx(FakeSession(), read_file=read_file)
        res = await qp.probe({"kind": "cli", "cli": "codex", "base": ""},
                             {"name": "m", "kind": "cli", "cli": "codex",
                              "quota": {"home": "/nonexistent-home"}}, ctx)
        # home dir doesn't exist → no lines read → unknown
        self.assertIn(res["source"], ("official", "estimate"))

    async def test_low_state(self):
        res = await qp.probe({"base": "https://api.openai.com/v1", "key": "k", "id": "p",
                              "wallet": {"amount": 0.5, "cur": "$", "spent0": 0}}, {"name": "m"}, make_ctx(FakeSession()))
        self.assertEqual(res["state"], "low")  # $0.5 < 阈值

    async def test_result_keys_complete(self):
        res = await qp.probe({"base": "https://unknown.example.com/v1"}, {"name": "m"}, make_ctx(FakeSession()))
        for k in ("kind", "source", "method", "accounts", "pct", "reset", "week",
                  "week_reset", "used", "limit", "state", "short", "checked_at"):
            self.assertIn(k, res)


if __name__ == "__main__":
    unittest.main()
