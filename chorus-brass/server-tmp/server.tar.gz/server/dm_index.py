"""Private-conversation cards derived from existing chats; no server read-state store."""
import json
import math

from aiohttp import web


def read_cursors(raw):
    if len(raw) > 4096:
        raise web.HTTPBadRequest(text="seen 参数过长")
    try:
        seen = json.loads(raw)
    except (ValueError, RecursionError):
        raise web.HTTPBadRequest(text="seen 必须为 JSON 对象") from None
    if not isinstance(seen, dict):
        raise web.HTTPBadRequest(text="seen 必须为 {项目ID:{成员名:已读seq}}")
    for names in seen.values():
        if not isinstance(names, dict) or any(type(n) is not int or n < 0 for n in names.values()):
            raise web.HTTPBadRequest(text="已读seq必须为非负整数")
    return seen


def timestamp(message):
    value = message.get("ts", 0)
    return value if type(value) in (int, float) and math.isfinite(value) else 0


def cards(server, seen):
    members = {m["name"]: m for m in server.CFG.get("members", [])}
    grouped = {}
    for project in server.PROJECTS:
        pid = project["id"]
        threads = {}
        for message in server.CHATS.get(pid, []):
            name = message.get("dm")
            if not isinstance(name, str) or not name or any(message.get(k) for k in ("gone", "recalled", "live")):
                continue
            thread = threads.setdefault(name, {"last": None, "unread": 0})
            # seq is authoritative within a project's append-only message sequence.
            if thread["last"] is None or message["seq"] > thread["last"]["seq"]:
                thread["last"] = message
            if message.get("who") == name and message["seq"] > seen.get(pid, {}).get(name, 0):
                thread["unread"] += 1
        for name, thread in threads.items():
            message = thread["last"]
            item = grouped.setdefault(name, {"name": name, "avatar": "", "avatar_version": "",
                "available": name in members, "unread": 0, "threads": [], "last": None})
            item["unread"] += thread["unread"]
            item["threads"].append({"pid": pid, "project_name": project.get("name", pid),
                "archived": bool(project.get("archived")), "last_seq": message["seq"], "unread": thread["unread"]})
            last = {"pid": pid, "seq": message["seq"], "who": message.get("who", ""),
                "text": " ".join(server.strip_todo(message.get("text", "")).split())[:200],
                "at": message.get("at", ""), "ts": timestamp(message)}
            if item["last"] is None or (last["ts"], pid, last["seq"]) > (item["last"]["ts"], item["last"]["pid"], item["last"]["seq"]):
                item["last"] = last
    # Once the avatar patch is merged, use precisely its manual-upload policy.
    avatar_module = getattr(server, "member_avatars", None)
    for name, item in grouped.items():
        if name in members and avatar_module is not None:
            item.update(avatar_module.view(server.DATA, members[name]))
        item["threads"].sort(key=lambda t: t["pid"])
    # N17: 每个加入过（现在还在）的声部都有私信入口，没聊过也显示；已移除的声部隐藏，历史保留，重新接入后自动恢复。
    for name, m in members.items():
        if name not in grouped:
            item = {"name": name, "avatar": "", "avatar_version": "", "available": True, "unread": 0, "threads": [],
                    "last": {"pid": "", "seq": 0, "who": "", "text": "", "at": "", "ts": 0}}
            if avatar_module is not None:
                item.update(avatar_module.view(server.DATA, m))
            grouped[name] = item
    grouped = {n: i for n, i in grouped.items() if n in members}
    prefs = server.CFG.get("dm_prefs", {})
    out = []
    for name, item in grouped.items():
        pr = prefs.get(name, {})
        newest = max((t["last_seq"] for t in item["threads"]), default=0)
        hidden = pr.get("hidden_cursors")
        if (hidden is not None and all(t["last_seq"] <= hidden.get(t["pid"], 0) for t in item["threads"])) or (
                hidden is None and pr.get("hidden_seq") and newest <= pr["hidden_seq"]):
            continue   # deleted thread (in 最近删除); a newer message brings it back
        item["pinned"], item["muted"] = bool(pr.get("pinned")), bool(pr.get("muted"))
        out.append(item)
    return sorted(out, key=lambda i: (not i["pinned"], -i["last"]["ts"], i["name"]))


async def prefs(request, server):
    """Long-press on a 私信 thread: PUT {pinned?, muted?, hidden?} — hidden=true is delete (undoable), false restores."""
    name = request.match_info["name"]
    b = await request.json()
    pr = server.CFG.setdefault("dm_prefs", {}).setdefault(name, {})
    for k in ("pinned", "muted"):
        if k in b:
            pr[k] = bool(b[k])
    if "hidden" in b:
        if b["hidden"]:
            seqs = [m["seq"] for p in server.PROJECTS for m in server.CHATS.get(p["id"], []) if m.get("dm") == name]
            if not seqs:
                raise web.HTTPNotFound()
            pr["hidden_cursors"] = {p["id"]: max((m["seq"] for m in server.CHATS.get(p["id"], [])
                if m.get("dm") == name), default=0) for p in server.PROJECTS}
            pr.pop("hidden_seq", None)
            pr["hidden_at"] = __import__("time").time()
        else:
            pr.pop("hidden_seq", None)
            pr.pop("hidden_cursors", None)
            pr.pop("hidden_at", None)
    server.save_cfg()
    server.bump()
    return web.json_response({"ok": True, "prefs": pr})


async def handle(request, server):
    seen = read_cursors(request.query.get("seen", "{}"))
    response = web.json_response({"epoch": server.EPOCH, "v": server.VER, "owner": server.owner(),
        "read_state_supplied": "seen" in request.query, "dms": cards(server, seen)})
    response.headers["Cache-Control"] = "no-store"
    return response
