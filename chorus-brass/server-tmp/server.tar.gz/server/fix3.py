"""Authenticated project lifecycle and execution contracts for FIX3.

Execution adapters are administrator-installed callables, never client supplied commands.
Missing adapters are explicitly unavailable, rather than simulated successful work.
"""
import asyncio
import datetime as dt
import json
import secrets
import time

from aiohttp import ClientSession, web
from urllib.parse import urlsplit
import api_errors as errors
import capabilities
import orchestra


def initial_config(body):
    raw = body.get('project_caps', {})
    if not isinstance(raw, dict):
        raise web.HTTPBadRequest(text='project_caps 必须是对象')
    out = {k: body.get(k, raw[k] if k in raw else None)
           for k in ('caps', 'connectors', 'skills', 'ask_first') if k in body or k in raw}
    for key in ('caps', 'connectors'):
        if key in out and not isinstance(out[key], dict):
            raise web.HTTPBadRequest(text=key + ' 必须是对象')
    if 'skills' in out and (not isinstance(out['skills'], list) or any(not isinstance(x, str) for x in out['skills'])):
        raise web.HTTPBadRequest(text='skills 必须是字符串列表')
    if 'caps' in out and any(not isinstance(v, bool) for v in out['caps'].values()):
        raise web.HTTPBadRequest(text='caps 必须是布尔开关')
    if 'ask_first' in out and not isinstance(out['ask_first'], bool):
        raise web.HTTPBadRequest(text='ask_first 必须是布尔值')
    if any(v not in ('read', 'write') for v in out.get('connectors', {}).values()):
        raise web.HTTPBadRequest(text='连接器权限必须为 read/write')
    return out


def configuration(s, p):
    return {'lead': p.get('lead', ''), 'project_caps': {k: p.get(k) for k in
            ('caps', 'connectors', 'skills', 'ask_first')},
            'effective': capabilities.effective(s.CFG.get('account', {}), p)}


def week_spend(s, cur, now=None):
    now = time.time() if now is None else now
    zone = dt.timezone(dt.timedelta(hours=s.CFG.get('tz', 8)))
    local = dt.datetime.fromtimestamp(now, zone)
    monday = local.date() - dt.timedelta(days=local.weekday())
    start = dt.datetime.combine(monday, dt.time(), tzinfo=zone)
    lo = int(start.timestamp() // 60)
    buckets = s.CFG.get('spend_buckets', {})
    totals = {}
    for key, values in buckets.items():
        if lo <= int(key) <= int(now // 60):
            for currency, value in values.items():
                totals[currency] = round(totals.get(currency, 0) + value, 6)
    # The persistent day ledger survives minute-bucket eviction. Its dates use CFG.tz.
    legacy_unpriced = False
    if hasattr(s, 'spend_file'):
        totals = {}
        for days in s.load(s.spend_file(), {}).values():
            for day, values in days.items():
                if monday.isoformat() <= day <= local.date().isoformat():
                    costs = values.get('cost_by_currency', {})
                    if values.get('cost') and not costs:
                        legacy_unpriced = True
                    for currency, value in costs.items():
                        totals[currency] = round(totals.get(currency, 0) + value, 6)
    return {'spent_week': round(totals.get(cur, 0), 4), 'week_complete': not legacy_unpriced, 'week_by_currency': totals,
            'week_start': start.isoformat(), 'week_end': local.isoformat(),
            'timezone': str(local.tzinfo), 'resolution_s': 86400 if hasattr(s, 'spend_file') else 60}


def assignment_event(p, seg, target):
    version = seg.get('assignment_version', 0) + 1
    event = {'id': secrets.token_hex(8), 'src': seg.get('assignee', ''), 'dst': target,
             'seg': seg['id'], 'at': time.time(), 'version': version, 'state': 'applied'}
    seg.update(assignee=target, assignment_version=version)
    p.setdefault('assignment_events', []).append(event)
    return event


class Service:
    def __init__(self, s, c):
        self.s, self.c = s, c
        self.locks = {}
        self.tasks = set()
        self.instance = secrets.token_hex(16)
        self.started = time.time()

    def persist(self):
        self.c.save_projects()
        self.s.bump()

    def project(self, request):
        p = self.s.project(request.match_info['pid'])
        if not p or p.get('archived'):
            raise web.HTTPNotFound()
        return p

    async def archive(self, request):
        if request.method == 'GET':
            return web.json_response({'items': [p for p in self.s.PROJECTS if p.get('filed') and not p.get('archived')]})
        p = self.project(request)
        async with self.locks.setdefault(p['id'], asyncio.Lock()):
            enabled = request.method == 'POST'
            if enabled:
                p['filed'] = True
                p['paused'] = True
                await self.cancel(p)
            p['filed'] = enabled
            self.persist()
        return web.json_response({'id': p['id'], 'archived': enabled, 'paused': p.get('paused', False)})

    async def cancel(self, p):
        """Stop only this project's work and await cancellation before modifying assignment."""
        tasks = {self.c.RUNNING.get(p['id']), self.c.PLANNING.get(p['id'])}
        self.s.STOP_AT[p['id']] = time.time()
        for root in self.s.ROOTS.values():
            if root.get('pid') == p['id']:
                root['budget']['stopped'] = True
                tasks.update(root['tasks'])
        tasks.discard(None)
        tasks.discard(asyncio.current_task())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def reassign(self, request):
        p = self.project(request)
        b = await errors.json_object(request)
        rid = b.get('request_id')
        if not isinstance(rid, str) or not rid or len(rid) > 128:
            raise web.HTTPBadRequest(text='需要 request_id')
        async with self.locks.setdefault(p['id'], asyncio.Lock()):
            sid = request.match_info['sid']
            signature = json.dumps({'sid': sid, 'body': b}, sort_keys=True)
            receipts = p.setdefault('assignment_receipts', {})
            if rid in receipts:
                old = receipts[rid]
                if old['signature'] != signature:
                    raise web.HTTPConflict(text='request_id 已用于其他操作')
                return web.json_response(old['result'])
            seg = next((x for x in p.get('segments', []) if x['id'] == sid), None)
            if seg is None:
                raise web.HTTPNotFound()
            if p.get('filed') or not p.get('paused') or seg.get('stage') in ('working', 'running', 'done'):
                raise web.HTTPConflict(text='请先休止；运行中或已完成段落不可重派')
            version = seg.get('assignment_version', 0)
            if b.get('expected_version') != version or b.get('expected_assignee') != seg.get('assignee', ''):
                raise web.HTTPConflict(text='分派已变化，请刷新')
            pool = self.c.execution_pool(p, seg, exclude=(seg.get('assignee'),))
            target = orchestra.assign({**seg, 'assignee': ''}, pool, self.c.QUOTA2) if pool else ''
            if not target:
                raise web.HTTPConflict(text='没有符合能力和额度要求的候选成员')
            old = seg.get('assignee', '')
            event = {'id': secrets.token_hex(8), 'src': old, 'dst': target, 'seg': sid,
                     'at': time.time(), 'version': version + 1, 'state': 'applied'}
            seg.update(assignee=target, assignment_version=version + 1, stage='waiting')
            p.setdefault('assignment_events', []).append(event)
            result = {'request_id': rid, 'target': target, 'event': event,
                      'lead': orchestra.pick_lead(p, self.c.candidates(p), self.c.QUOTA2),
                      'reason': '按能力、额度、价格和历史表现确定候选', 'version': version + 1}
            receipts[rid] = {'signature': signature, 'result': result}
            self.persist()
            return web.json_response(result)

    async def withdraw(self, request):
        p = self.project(request)
        b = await errors.json_object(request)
        async with self.locks.setdefault(p['id'], asyncio.Lock()):
            event = next((e for e in p.get('assignment_events', []) if e['id'] == request.match_info['eid']), None)
            if event is None:
                raise web.HTTPNotFound()
            rid = b.get('request_id')
            if not isinstance(rid, str) or not rid or len(rid) > 128:
                raise web.HTTPBadRequest(text='需要 request_id')
            signature = json.dumps(b, sort_keys=True)
            if event.get('withdraw_request') == rid:
                if event.get('withdraw_signature') != signature:
                    raise web.HTTPConflict(text='request_id 已用于其他操作')
                return web.json_response(event['receipt'])
            seg = next((x for x in p['segments'] if x['id'] == event['seg']), None)
            if seg is None:
                raise web.HTTPConflict(text='段落已不存在')
            if not event.get('src') or event['src'] not in p.get('members', []):
                raise web.HTTPConflict(text='原执行者已不在项目中')
            if event['state'] != 'applied' or time.time() > event['at'] + 600 or seg.get('stage') == 'done':
                raise web.HTTPConflict(text='接棒已失效或段落已完成')
            if b.get('expected_version') != seg.get('assignment_version', 0) or seg.get('assignee') != event['dst']:
                raise web.HTTPConflict(text='分派已变化')
            # Keep progress/files/branches. No destructive filesystem rollback is implied.
            p['paused'] = True
            await self.cancel(p)
            if seg.get('stage') == 'done' or seg.get('assignee') != event['dst'] or seg.get('assignment_version') != b['expected_version']:
                raise web.HTTPConflict(text='取消期间分派已变化')
            seg.update(assignee=event['src'], assignment_version=seg['assignment_version'] + 1, stage='waiting')
            result = {'request_id': rid, 'event_id': event['id'], 'target': event['src'],
                      'version': seg['assignment_version'], 'cancelled': True, 'progress_policy': 'preserve',
                      'branch_policy': 'preserve', 'paused': True}
            event.update(state='withdrawn', withdraw_request=rid, withdraw_signature=signature, receipt=result)
            self.persist()
            return web.json_response(result)

    def adapters(self):
        adapters = dict(getattr(self.s, 'execution_adapters', {}))
        for name, config in self.s.CFG.get('execution_services', {}).items():
            if name not in ('build', 'search', 'github') or not isinstance(config, dict):
                continue
            url = config.get('url', '')
            if not isinstance(url, str) or urlsplit(url).scheme != 'https' or not urlsplit(url).netloc:
                continue
            async def invoke(pid, payload, config=config):
                headers = {'Authorization': 'Bearer ' + config['token']} if config.get('token') else {}
                async with ClientSession() as session:
                    async with session.post(config['url'], json={'project_id': pid, 'input': payload}, headers=headers) as response:
                        if response.status >= 400:
                            raise web.HTTPBadGateway(text='执行服务返回失败')
                        return await response.json()
            adapters.setdefault(name, invoke)
        return adapters

    def restart_adapter(self):
        hook = getattr(self.s, 'restart_service', None)
        if callable(hook):
            return hook
        argv = self.s.CFG.get('management_restart_argv')
        if not isinstance(argv, list) or not argv or any(not isinstance(x, str) or not x for x in argv):
            return None
        async def invoke():
            process = await asyncio.create_subprocess_exec(*argv, stdout=asyncio.subprocess.DEVNULL,
                                                           stderr=asyncio.subprocess.DEVNULL)
            if await process.wait():
                raise RuntimeError('进程管理器拒绝重启')
        return invoke

    async def available(self, request):
        account = self.s.CFG.get('account', {})
        return web.json_response({'capabilities': {name: {
            'available': callable(self.adapters().get(name)),
            'enabled': (capabilities._norm_connector(account.get('connectors', {}).get('github'))[0]
                        if name == 'github' else bool(account.get('execution', {}).get(name))),
            'reason': '' if callable(self.adapters().get(name)) else '服务器尚未配置执行适配器'}
            for name in ('build', 'search', 'github')}})

    async def execute(self, request):
        p = self.project(request)
        name = request.match_info['capability']
        b = await errors.json_object(request)
        adapter = self.adapters().get(name)
        if name not in ('build', 'search', 'github') or not callable(adapter):
            raise web.HTTPServiceUnavailable(text='执行适配器不可用')
        account = self.s.CFG.get('account', {})
        effective = capabilities.effective(account, p)
        allowed = effective['connectors'].get('github') == 'write' if name == 'github' else (
            account.get('execution', {}).get(name) and p.get('caps', {}).get(name))
        if p.get('filed') or p.get('archived') or not allowed:
            raise web.HTTPForbidden(text='账户或项目未授权')
        if effective['ask_first'] and b.get('confirmed') is not True:
            raise web.HTTPConflict(text='此操作需要用户确认')
        if self.c.account_block():
            raise web.HTTPConflict(text=self.c.account_block())
        result = await adapter(p['id'], b.get('input', {}))
        return web.json_response({'state': 'completed', 'result': result})

    async def duty(self, request):
        p = self.project(request)
        if request.method == 'PUT':
            b = await errors.json_object(request)
            if not isinstance(b.get('enabled'), bool):
                raise web.HTTPBadRequest(text='enabled 必须是布尔值')
            if b['enabled'] and not capabilities.effective(self.s.CFG.get('account', {}), p)['caps']['nocturne']:
                raise web.HTTPForbidden(text='项目未启用夜曲能力')
            interval = b.get('interval_s', 3600)
            if isinstance(interval, bool) or not isinstance(interval, int) or interval <= 0:
                raise web.HTTPBadRequest(text='interval_s 必须是正整数')
            p['duty'] = {'enabled': b['enabled'], 'interval_s': interval, 'next_at': time.time(), 'state': 'waiting'}
            self.persist()
        return web.json_response(p.get('duty', {'enabled': False}))

    async def tick(self):
        for p in self.s.PROJECTS:
            d = p.get('duty', {})
            if not d.get('enabled') or p.get('paused') or p.get('filed') or p.get('archived') or d.get('next_at', 0) > time.time():
                continue
            if not capabilities.effective(self.s.CFG.get('account', {}), p)['caps']['nocturne']:
                d.update(state='blocked', error='夜曲能力已关闭')
            elif self.c.account_block():
                d.update(state='blocked', error=self.c.account_block())
            elif p['id'] in self.c.RUNNING or p['id'] in self.c.PLANNING:
                continue
            else:
                self.c.start(p['id'])
                d.update(state='dispatched', request_id=secrets.token_hex(8), last_at=time.time())
                task = self.c.RUNNING.get(p['id'])
                if task:
                    request_id = d['request_id']
                    def finished(task, p=p, d=d, request_id=request_id):
                        if p.get('duty') is not d or d.get('request_id') != request_id:
                            return
                        if task.cancelled():
                            d['state'] = 'cancelled'
                        else:
                            exc = task.exception()
                            d.update(state='failed' if exc else 'completed', error=type(exc).__name__ if exc else '')
                        d['finished_at'] = time.time()
                        self.persist()
                    task.add_done_callback(finished)
            d['next_at'] = time.time() + d['interval_s']
            self.persist()

    async def management(self, request):
        state = self.s.CFG.get('management_restart')
        if request.method == 'GET':
            return web.json_response({'instance_id': self.instance, 'started_at': self.started,
                                      'restart': state, 'available': callable(self.restart_adapter()),
                                      'impact': '所有连接断开；立即策略会停止正在执行的任务'})
        b = await errors.json_object(request)
        rid, policy = b.get('request_id'), b.get('policy')
        if not isinstance(rid, str) or not rid or len(rid) > 128 or policy not in ('immediate', 'when_idle'):
            raise web.HTTPBadRequest(text='需要 request_id 与 immediate/when_idle 策略')
        if state and state['request_id'] == rid:
            if state['policy'] != policy:
                raise web.HTTPConflict()
            return web.json_response(state, status=202)
        hook = self.restart_adapter()
        if not callable(hook):
            raise web.HTTPServiceUnavailable(text='未配置进程管理器重启适配器')
        if state and state.get('state') in ('accepted', 'restarting'):
            raise web.HTTPConflict(text='已有重启请求')
        state = {'request_id': rid, 'policy': policy, 'state': 'accepted', 'instance_id': self.instance, 'at': time.time()}
        self.s.CFG['management_restart'] = state
        self.s.save_cfg()
        async def restart():
            try:
                if policy == 'when_idle':
                    while self.c.RUNNING or self.c.PLANNING or self.s.ROOTS:
                        await asyncio.sleep(1)
                else:
                    for p in self.s.PROJECTS:
                        await self.cancel(p)
                state['state'] = 'restarting'
                self.s.save_cfg()
                await hook()
            except Exception as exc:
                state.update(state='failed', error=type(exc).__name__)
                self.s.save_cfg()
        task = asyncio.create_task(restart())
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return web.json_response(state.copy(), status=202)


def register(app, s, c):
    service = Service(s, c)
    app['fix3'] = service
    r = app.router
    r.add_get('/api/projects/archived', service.archive)
    r.add_post('/api/projects/{pid}/archive', service.archive)
    r.add_delete('/api/projects/{pid}/archive', service.archive)
    r.add_post('/api/orchestra/{pid}/segments/{sid}/reassign', service.reassign)
    r.add_post('/api/orchestra/{pid}/handovers/{eid}/withdraw', service.withdraw)
    r.add_get('/api/account/capabilities', service.available)
    r.add_post('/api/projects/{pid}/execute/{capability}', service.execute)
    r.add_get('/api/orchestra/{pid}/duty', service.duty)
    r.add_put('/api/orchestra/{pid}/duty', service.duty)
    r.add_get('/api/management/restart', service.management)
    r.add_post('/api/management/restart', service.management)
    async def lifecycle(app):
        state = s.CFG.get('management_restart')
        if state and state.get('instance_id') != service.instance and state.get('state') == 'restarting':
            state.update(state='completed', new_instance_id=service.instance, started_at=service.started)
            s.save_cfg()
        async def loop():
            while True:
                await service.tick()
                await asyncio.sleep(1)
        task = asyncio.create_task(loop())
        yield
        for pending in [task, *service.tasks]:
            pending.cancel()
        await asyncio.gather(task, *service.tasks, return_exceptions=True)
    app.cleanup_ctx.append(lifecycle)
