"""Tests for server/recovery.py — pure stdlib unittest.

Runnable from the repo root (``python server/test_recovery.py``) and from
inside ``server/`` (``python test_recovery.py``).
"""

import email.utils
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import recovery  # noqa: E402
from recovery import (  # noqa: E402
    BACKOFF_CAP,
    ELLIPSIS,
    KINDS,
    N_BACKOFF,
    N_RETRY,
    Decision,
    bump,
    classify,
    cooldown_until,
    decide,
    log_line,
    trim_messages,
)

SEG = {"id": "seg-1"}


def _decide(kind, attempts=None, alternatives=None, critical=True, rng=lambda: 0.0, member="DeepSeek"):
    return decide(kind, SEG, member, attempts or {}, alternatives or [], critical=critical, rng=rng)


class TestClassify(unittest.TestCase):
    def test_kinds_tuple(self):
        self.assertEqual(len(KINDS), 10)
        self.assertIn("acceptance", KINDS)
        self.assertEqual(list(KINDS), list(recovery.KINDS))

    def test_arrears_status(self):
        self.assertEqual(classify(402), "arrears")

    def test_arrears_markers(self):
        self.assertEqual(classify(400, body="insufficient_quota"), "arrears")
        self.assertEqual(classify(None, body="Insufficient Balance"), "arrears")
        self.assertEqual(classify(None, exc="exceeded your current quota"), "arrears")
        self.assertEqual(classify(None, body="credit balance is too low"), "arrears")
        self.assertEqual(classify(None, body="Arrearage on account"), "arrears")

    def test_arrears_chinese(self):
        self.assertEqual(classify(None, body="余额不足"), "arrears")
        self.assertEqual(classify(None, body="账户欠费"), "arrears")

    def test_rate_limit_status(self):
        self.assertEqual(classify(429), "rate_limit")

    def test_rate_limit_markers(self):
        self.assertEqual(classify(400, body="Rate limit reached"), "rate_limit")
        self.assertEqual(classify(400, body="Too Many Requests"), "rate_limit")
        self.assertEqual(classify(None, body="请求过于频繁"), "rate_limit")

    def test_rate_limit_529(self):
        self.assertEqual(classify(529), "rate_limit")
        self.assertEqual(classify(529, body="overloaded"), "rate_limit")

    def test_server_range(self):
        self.assertEqual(classify(500), "server")
        self.assertEqual(classify(503), "server")
        self.assertEqual(classify(599), "server")
        self.assertNotEqual(classify(529), "server")

    def test_timeout(self):
        self.assertEqual(classify(None, exc="Timeout"), "timeout")
        self.assertEqual(classify(504, exc="request timed out"), "timeout")
        self.assertEqual(classify(None, exc="请求超时"), "timeout")

    def test_network(self):
        self.assertEqual(classify(None, exc="aiohttp.ClientConnectorError: boom"), "network")
        self.assertEqual(classify(None, exc="Connection reset by peer"), "network")
        self.assertEqual(classify(None, exc="ECONNREFUSED"), "network")
        self.assertEqual(classify(None, exc="Name or service not known"), "network")

    def test_context_length(self):
        self.assertEqual(classify(None, body="context_length_exceeded"), "context_length")
        self.assertEqual(classify(400, body="maximum context length is 8192"), "context_length")
        self.assertEqual(classify(None, body="too many tokens"), "context_length")
        self.assertEqual(classify(None, exc="prompt is too long"), "context_length")
        self.assertEqual(classify(None, body="上下文过长"), "context_length")
        self.assertEqual(classify(400, body="context"), "context_length")

    def test_refusal(self):
        self.assertEqual(classify(200, body="I can't help with that"), "refusal")
        self.assertEqual(classify(200, body="I cannot assist here"), "refusal")
        self.assertEqual(classify(200, body="无法协助"), "refusal")
        self.assertEqual(classify(200, body="content_filter triggered"), "refusal")

    def test_auth(self):
        self.assertEqual(classify(401), "auth")
        self.assertEqual(classify(403), "auth")
        self.assertEqual(classify(None, body="invalid api key"), "auth")
        self.assertEqual(classify(None, body="Unauthorized"), "auth")

    def test_acceptance(self):
        self.assertEqual(classify(None, exc="acceptance"), "acceptance")
        self.assertEqual(classify(None, body="acceptance"), "acceptance")

    def test_unknown(self):
        self.assertEqual(classify(None), "unknown")
        self.assertEqual(classify(200, body="all good"), "unknown")
        self.assertEqual(classify(418), "unknown")


class TestArrears(unittest.TestCase):
    def test_reassign(self):
        d = _decide("arrears", alternatives=["MiMo"])
        self.assertEqual(d.action, "reassign")
        self.assertEqual(d.member_state, "resting")
        self.assertEqual(d.delay, 0.0)
        self.assertIn("MiMo", d.note)
        self.assertIn("余额不足", d.note)
        self.assertEqual(d.hud, "改派")

    def test_ask_user(self):
        d = _decide("arrears")
        self.assertEqual(d.action, "ask_user")
        self.assertEqual(d.member_state, "resting")
        self.assertEqual(d.hud, "等你定")
        self.assertIn("需要你定", d.note)

    def test_noncritical_skips(self):
        d = _decide("arrears", critical=False)
        self.assertEqual(d.action, "skip")
        self.assertEqual(d.hud, "跳过")
        self.assertEqual(d.member_state, "resting")
        self.assertIn("非关键段落已跳过", d.note)


class TestRateLimit(unittest.TestCase):
    def test_backoff_jitter_bounds(self):
        d = _decide("rate_limit", rng=lambda: 1.0)
        self.assertEqual(d.action, "backoff")
        self.assertAlmostEqual(d.delay, 2.0)  # min(cap, 2 * 2**0)
        d2 = _decide("rate_limit", attempts={"backoff": 1}, rng=lambda: 1.0)
        self.assertAlmostEqual(d2.delay, 4.0)
        d3 = _decide("rate_limit", attempts={"backoff": 0}, rng=lambda: 0.0)
        self.assertEqual(d3.delay, 0.0)

    def test_backoff_hud_counts(self):
        d = _decide("rate_limit", attempts={"backoff": 2})
        self.assertEqual(d.hud, f"重试 3/{N_BACKOFF}")

    def test_reassign_after_backoff_exhausted(self):
        d = _decide("rate_limit", attempts={"backoff": N_BACKOFF}, alternatives=["MiMo"])
        self.assertEqual(d.action, "reassign")
        self.assertEqual(d.member_state, "cooldown")
        self.assertEqual(d.delay, 0.0)
        self.assertIn("MiMo", d.note)

    def test_capped_backoff_without_alternatives(self):
        d = _decide("rate_limit", attempts={"backoff": N_BACKOFF})
        self.assertEqual(d.action, "backoff")
        self.assertEqual(d.member_state, "cooldown")
        self.assertEqual(d.delay, BACKOFF_CAP)

    def test_noncritical_ask_user_becomes_skip(self):
        d = _decide("rate_limit", attempts={"backoff": 99}, critical=False)
        # capped backoff is not ask_user, so it stays a backoff
        self.assertEqual(d.action, "backoff")


class TestRetryKinds(unittest.TestCase):
    def test_retry_cap_logic(self):
        self.assertAlmostEqual(_decide("server", rng=lambda: 1.0).delay, 2.0)
        self.assertAlmostEqual(_decide("server", attempts={"retry": 1}, rng=lambda: 1.0).delay, 4.0)
        self.assertAlmostEqual(_decide("server", attempts={"retry": 2}, rng=lambda: 1.0).delay, 8.0)

    def test_retry_zero_jitter(self):
        d = _decide("timeout", rng=lambda: 0.0)
        self.assertEqual(d.delay, 0.0)
        self.assertEqual(d.action, "retry")

    def test_retry_default_rng_in_bounds(self):
        d = _decide("network", attempts={"retry": 2})
        self.assertGreaterEqual(d.delay, 0.0)
        self.assertLessEqual(d.delay, 8.0)

    def test_hud_progress(self):
        d = _decide("server", attempts={"retry": 0})
        self.assertEqual(d.hud, f"重试 1/{N_RETRY}")

    def test_kind_labels(self):
        self.assertIn("服务端错误", _decide("server").note)
        self.assertIn("请求超时", _decide("timeout").note)
        self.assertIn("网络异常", _decide("network").note)

    def test_exhausted_reassign(self):
        for kind in ("server", "timeout", "network"):
            d = _decide(kind, attempts={"retry": N_RETRY}, alternatives=["MiMo"])
            self.assertEqual(d.action, "reassign")
            self.assertEqual(d.delay, 0.0)
            self.assertIn("MiMo", d.note)

    def test_exhausted_ask_user(self):
        d = _decide("server", attempts={"retry": N_RETRY})
        self.assertEqual(d.action, "ask_user")
        self.assertEqual(d.hud, "等你定")

    def test_exhausted_noncritical_skip(self):
        d = _decide("timeout", attempts={"retry": N_RETRY}, critical=False)
        self.assertEqual(d.action, "skip")
        self.assertEqual(d.hud, "跳过")
        self.assertIn("非关键段落已跳过", d.note)


class TestContextLength(unittest.TestCase):
    def test_first_trim(self):
        d = _decide("context_length")
        self.assertEqual(d.action, "trim_retry")
        self.assertEqual(d.hud, "压缩上下文")
        self.assertIn("压缩", d.note)

    def test_second_trim_mentions_summary(self):
        d = _decide("context_length", attempts={"trim": 1})
        self.assertEqual(d.action, "trim_retry")
        self.assertIn("摘要压缩", d.note)

    def test_reassign_when_exhausted(self):
        d = _decide("context_length", attempts={"trim": 2}, alternatives=["BigCtx", "Small"])
        self.assertEqual(d.action, "reassign")
        self.assertIn("BigCtx", d.note)

    def test_ask_user_without_alternatives(self):
        d = _decide("context_length", attempts={"trim": 2})
        self.assertEqual(d.action, "ask_user")
        self.assertEqual(d.hud, "等你定")

    def test_noncritical_skips(self):
        d = _decide("context_length", attempts={"trim": 2}, critical=False)
        self.assertEqual(d.action, "skip")
        self.assertIn("非关键段落已跳过", d.note)


class TestRefusal(unittest.TestCase):
    def test_rephrase_once(self):
        d = _decide("refusal")
        self.assertEqual(d.action, "rephrase_retry")

    def test_reassign_after_rephrase(self):
        d = _decide("refusal", attempts={"rephrase": 1}, alternatives=["MiMo"])
        self.assertEqual(d.action, "reassign")
        self.assertIn("MiMo", d.note)

    def test_critical_ask_user(self):
        d = _decide("refusal", attempts={"rephrase": 1}, critical=True)
        self.assertEqual(d.action, "ask_user")

    def test_noncritical_skip(self):
        d = _decide("refusal", attempts={"rephrase": 1}, critical=False)
        self.assertEqual(d.action, "skip")
        self.assertIn("非关键段落已跳过", d.note)


class TestAcceptance(unittest.TestCase):
    def test_feedback_twice(self):
        self.assertEqual(_decide("acceptance", attempts={"feedback": 0}).action, "feedback_retry")
        self.assertEqual(_decide("acceptance", attempts={"feedback": 1}).action, "feedback_retry")

    def test_upgrade_once(self):
        d = _decide("acceptance", attempts={"feedback": 2, "upgrade": 0})
        self.assertEqual(d.action, "upgrade")
        self.assertEqual(d.hud, "升级")

    def test_ask_user_critical(self):
        d = _decide("acceptance", attempts={"feedback": 2, "upgrade": 1}, critical=True)
        self.assertEqual(d.action, "ask_user")

    def test_skip_noncritical(self):
        d = _decide("acceptance", attempts={"feedback": 2, "upgrade": 1}, critical=False)
        self.assertEqual(d.action, "skip")
        self.assertIn("非关键段落已跳过", d.note)


class TestAuthUnknown(unittest.TestCase):
    def test_auth_broken_reassign(self):
        d = _decide("auth", alternatives=["MiMo"])
        self.assertEqual(d.action, "reassign")
        self.assertEqual(d.member_state, "broken")

    def test_auth_ask_user(self):
        d = _decide("auth")
        self.assertEqual(d.action, "ask_user")
        self.assertEqual(d.member_state, "broken")

    def test_auth_noncritical_skip(self):
        d = _decide("auth", critical=False)
        self.assertEqual(d.action, "skip")
        self.assertEqual(d.member_state, "broken")

    def test_unknown_retries_once(self):
        d = _decide("unknown")
        self.assertEqual(d.action, "retry")
        self.assertEqual(d.hud, "重试 1/1")

    def test_unknown_then_reassign(self):
        d = _decide("unknown", attempts={"retry": 1}, alternatives=["MiMo"])
        self.assertEqual(d.action, "reassign")

    def test_unknown_then_ask_user(self):
        d = _decide("unknown", attempts={"retry": 1})
        self.assertEqual(d.action, "ask_user")

    def test_unknown_kind_string_falls_back(self):
        d = _decide("something-else")
        self.assertEqual(d.action, "retry")


class TestBump(unittest.TestCase):
    def test_mapping(self):
        a = {}
        self.assertEqual(bump(a, "retry")["retry"], 1)
        self.assertEqual(bump(a, "backoff")["backoff"], 1)
        self.assertEqual(bump(a, "trim_retry")["trim"], 1)
        self.assertEqual(bump(a, "rephrase_retry")["rephrase"], 1)
        self.assertEqual(bump(a, "feedback_retry")["feedback"], 1)
        self.assertEqual(bump(a, "upgrade")["upgrade"], 1)
        self.assertEqual(bump(a, "reassign")["reassign"], 1)

    def test_noop_actions(self):
        a = {"retry": 2}
        self.assertEqual(bump(a, "skip"), a)
        self.assertEqual(bump(a, "ask_user"), a)

    def test_no_mutation(self):
        a = {"retry": 1}
        b = bump(a, "retry")
        self.assertEqual(a, {"retry": 1})
        self.assertEqual(b["retry"], 2)

    def test_drives_decide(self):
        attempts = {}
        self.assertEqual(decide("server", SEG, "A", attempts, [], rng=lambda: 0.0).action, "retry")
        attempts = bump(attempts, "retry")
        self.assertEqual(decide("server", SEG, "A", attempts, [], rng=lambda: 0.0).hud, f"重试 2/{N_RETRY}")


class TestCooldown(unittest.TestCase):
    def test_retry_after_seconds(self):
        self.assertAlmostEqual(cooldown_until("rate_limit", {"Retry-After": "120"}, 1000.0), 1120.0)

    def test_retry_after_http_date(self):
        stamp = "Wed, 21 Oct 2015 07:28:00 GMT"
        expected = email.utils.parsedate_to_datetime(stamp).timestamp()
        got = cooldown_until("rate_limit", {"retry-after": stamp}, 0.0)
        self.assertAlmostEqual(got, expected)

    def test_reset_strings(self):
        self.assertAlmostEqual(
            cooldown_until("rate_limit", {"x-ratelimit-reset-requests": "1m30s"}, 1000.0), 1090.0)
        self.assertAlmostEqual(
            cooldown_until("rate_limit", {"x-ratelimit-reset-tokens": "6ms"}, 1000.0), 1000.006)
        self.assertAlmostEqual(
            cooldown_until("rate_limit", {"x-ratelimit-reset-requests": "2s"}, 1000.0), 1002.0)

    def test_longest_wins(self):
        got = cooldown_until(
            "rate_limit",
            {"retry-after": "1", "x-ratelimit-reset-requests": "2s"},
            1000.0,
        )
        self.assertAlmostEqual(got, 1002.0)

    def test_none_cases(self):
        self.assertIsNone(cooldown_until("rate_limit", None, 0.0))
        self.assertIsNone(cooldown_until("rate_limit", {}, 0.0))
        self.assertIsNone(cooldown_until("rate_limit", {"Retry-After": "garbage"}, 0.0))
        self.assertIsNone(cooldown_until("auth", {"Retry-After": "10"}, 0.0))


class TestTrimMessages(unittest.TestCase):
    def test_noop_when_small(self):
        msgs = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "hi"},
        ]
        out = trim_messages(msgs, 1000)
        self.assertEqual(out, msgs)

    def test_drops_oldest_middle(self):
        msgs = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "a" * 10},
            {"role": "assistant", "content": "b" * 10},
            {"role": "user", "content": "c" * 10},
        ]
        out = trim_messages(msgs, 21)
        self.assertEqual([m["role"] for m in out], ["system", "assistant", "user"])
        self.assertEqual(out[-1]["content"], "c" * 10)
        self.assertEqual(out[0]["content"], "S")

    def test_truncates_long_middle(self):
        msgs = [
            {"role": "system", "content": "S"},
            {"role": "assistant", "content": "A" * 1000},
            {"role": "user", "content": "U"},
        ]
        out = trim_messages(msgs, 850)
        self.assertEqual(len(out), 3)
        body = out[1]["content"]
        self.assertIn(ELLIPSIS, body)
        self.assertTrue(body.startswith("A" * 400))
        self.assertTrue(body.endswith("A" * 400))
        self.assertEqual(len(body), 400 + len(ELLIPSIS) + 400)

    def test_never_drops_last_user(self):
        msgs = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "a" * 10},
            {"role": "user", "content": "b" * 10},
        ]
        out = trim_messages(msgs, 1)
        self.assertEqual(out[-1]["content"], "b" * 10)
        self.assertEqual(out[0]["content"], "S")

    def test_keeps_all_system_messages(self):
        msgs = [
            {"role": "system", "content": "S1"},
            {"role": "assistant", "content": "x" * 50},
            {"role": "system", "content": "S2"},
            {"role": "user", "content": "U"},
        ]
        out = trim_messages(msgs, 30)
        roles = [m["role"] for m in out]
        self.assertEqual(roles.count("system"), 2)
        self.assertEqual(out[-1]["content"], "U")

    def test_empty(self):
        self.assertEqual(trim_messages([], 10), [])
        self.assertEqual(trim_messages(None, 10), [])

    def test_returns_copies(self):
        msgs = [{"role": "system", "content": "S"},
                {"role": "assistant", "content": "A" * 100},
                {"role": "user", "content": "U"}]
        out = trim_messages(msgs, 50)
        self.assertEqual(msgs[1]["content"], "A" * 100)
        self.assertIsNot(out[0], msgs[0])


class TestLogLine(unittest.TestCase):
    def test_shape(self):
        d = Decision("reassign", 0.0, "resting", "DeepSeek 余额不足，转给 MiMo", "改派")
        line = log_line("seg-1", "DeepSeek", "arrears", d)
        self.assertEqual(set(line), {"at", "seg", "who", "kind", "action", "note"})
        self.assertEqual(line["seg"], "seg-1")
        self.assertEqual(line["who"], "DeepSeek")
        self.assertEqual(line["kind"], "arrears")
        self.assertEqual(line["action"], "reassign")
        self.assertEqual(line["note"], d.note)
        self.assertIsInstance(line["at"], float)


class TestDecisionDataclass(unittest.TestCase):
    def test_defaults(self):
        d = Decision("retry")
        self.assertEqual(d.delay, 0.0)
        self.assertEqual(d.member_state, "")
        self.assertEqual(d.note, "")
        self.assertEqual(d.hud, "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
