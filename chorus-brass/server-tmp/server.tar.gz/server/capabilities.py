"""Chorus 能力层：账户 → 乐章 → 段落 的继承、收窄与组合校验。

纯标准库实现，不做任何 IO。
规则要点：
  * 连接器 / 乐谱：账户开通，乐章勾选并定级 read|write，段落只能收窄；
  * 花费上限：三层取 min，None 表示该层不设限；
  * 先问我再做：仅向下更严，账户 True 则全层 True；
  * 段落可以改演奏方式（必须在 MODES 内），但能力开关沿用乐章设置。
"""

CAPS = ("connectors", "skills", "nocturne", "metronome", "memory", "build", "search")  # 工位 is not in this release (see workstation.py)
MODES = ("solo", "parallel", "concerto", "symphony")

CAP_CN = {
    "connectors": "连接器",
    "skills": "乐谱",
    "nocturne": "夜曲",
    "metronome": "节拍器",
    "memory": "记忆",
    "build": "云端构建",
    "search": "网页搜索",
}

MODE_CN = {
    "solo": "独奏",
    "parallel": "并行",
    "concerto": "协奏",
    "symphony": "交响",
}

LEVEL_RANK = {"read": 1, "write": 2}


def defaults_for_mode(mode: str) -> dict:
    """按演奏方式给出默认能力开关；记忆对所有模式默认开启。"""
    caps = {name: False for name in CAPS}
    caps["memory"] = True
    if mode == "symphony":
        caps["connectors"] = True
        caps["skills"] = True
    return caps


def _lowest_level(*levels):
    """取最低权限；不认识的一律忽略，全不识别则返回 None。"""
    best = None
    for level in levels:
        rank = LEVEL_RANK.get(level)
        if rank is None:
            continue
        if best is None or rank < LEVEL_RANK[best]:
            best = level
    return best


def _norm_connector(value):
    """账户侧连接器可写成 {"enabled","max_level"} 或直接写 bool。"""
    if isinstance(value, dict):
        level = value.get("max_level") or "read"
        return bool(value.get("enabled")), level
    if isinstance(value, bool):
        return value, "write"
    return False, "read"


def effective(account: dict, project: dict, segment: dict | None = None) -> dict:
    """计算三层叠加后真正生效的能力。"""
    account = account or {}
    project = project or {}
    segment = segment or {}
    notes: list[str] = []

    # ---- 演奏方式 ----
    base_mode = project.get("mode") or "solo"
    if base_mode not in MODES:
        notes.append("乐章模式「%s」不认识，按独奏处理" % base_mode)
        base_mode = "solo"

    mode = base_mode
    seg_mode = segment.get("mode")
    if seg_mode:
        if seg_mode not in MODES:
            notes.append("段落模式「%s」不认识，沿用乐章模式" % seg_mode)
        elif seg_mode != mode:
            notes.append("段落改用%s，能力开关沿用乐章设置" % MODE_CN[seg_mode])
            mode = seg_mode

    # ---- 能力开关：乐章默认 + 乐章勾选，段落只能关不能开 ----
    caps = defaults_for_mode(base_mode)
    for name, on in (project.get("caps") or {}).items():
        if name not in caps:
            notes.append("未知能力「%s」，已忽略" % name)
            continue
        caps[name] = bool(on)

    for name, on in (segment.get("caps") or {}).items():
        if name not in caps:
            continue
        if not on and caps[name]:
            caps[name] = False
            notes.append("段落关闭了%s" % CAP_CN[name])
        elif on and not caps[name]:
            notes.append("段落想开%s，乐章没开，不生效" % CAP_CN[name])

    for name in ("build", "search"):
        if caps[name] and not account.get("execution", {}).get(name):
            caps[name] = False
            notes.append(name + " 未在账户授权")

    # ---- 连接器 ----
    acct_conn = account.get("connectors") or {}
    connectors: dict[str, str] = {}

    for cid, level in (project.get("connectors") or {}).items():
        enabled, max_level = _norm_connector(acct_conn.get(cid))
        if not enabled:
            notes.append("连接器 %s 未在账户启用，已忽略" % cid)
            continue
        got = _lowest_level(level, max_level) if level in LEVEL_RANK else None
        if got is None:
            notes.append("连接器 %s 权限「%s」不认识，已忽略" % (cid, level))
            continue
        if got != level:
            notes.append("连接器 %s 超出账户上限 %s，收窄为 %s" % (cid, max_level, got))
        connectors[cid] = got

    for cid, level in (segment.get("connectors") or {}).items():
        if cid not in connectors:
            notes.append("段落要的连接器 %s 乐章没开，已忽略" % cid)
            continue
        got = _lowest_level(level, connectors[cid])
        if got is None:
            notes.append("连接器 %s 权限「%s」不认识，保持 %s" % (cid, level, connectors[cid]))
            continue
        if got != level:
            notes.append(
                "段落把连接器 %s 提到 %s，超出乐章权限 %s，收窄为 %s"
                % (cid, level, connectors[cid], got)
            )
        connectors[cid] = got

    # ---- 乐谱：三层取交集 ----
    acct_skills = list(account.get("skills") or [])
    allowed: list[str] = []
    for sid in project.get("skills") or []:
        if sid in acct_skills:
            if sid not in allowed:
                allowed.append(sid)
        else:
            notes.append("乐谱 %s 不在账户曲库，已忽略" % sid)

    seg_skills = segment.get("skills")
    if seg_skills is None:
        skills = allowed
    else:
        seg_list = list(seg_skills)
        skills = [sid for sid in allowed if sid in seg_list]
        for sid in allowed:
            if sid not in seg_list:
                notes.append("段落没有选乐谱 %s，已收窄" % sid)
        for sid in seg_list:
            if sid not in allowed:
                notes.append("段落想加乐谱 %s，乐章没选，不生效" % sid)

    # ---- 花费上限：非 None 取 min ----
    candidates = [
        v
        for v in (account.get("cap"), project.get("cap"), segment.get("cap"))
        if v is not None
    ]
    cap = min(candidates) if candidates else None
    seg_cap = segment.get("cap")
    if seg_cap is not None and cap is not None and seg_cap > cap:
        notes.append("段落预算 %g 高于上层上限 %g，按 %g 执行" % (seg_cap, cap, cap))

    # ---- 先问我再做：只向下更严 ----
    ask_first = (
        bool(account.get("ask_first"))
        or bool(project.get("ask_first"))
        or bool(segment.get("ask_first"))
    )
    if account.get("ask_first"):
        notes.append("账户开着先问我再做，各层一律继承")
    elif project.get("ask_first") and segment.get("ask_first") is False:
        notes.append("段落想关掉先问我再做，乐章开着，不生效")

    return {
        "mode": mode,
        "caps": caps,
        "connectors": connectors,
        "skills": skills,
        "cap": cap,
        "ask_first": ask_first,
        "notes": notes,
    }


def validate_combo(mode: str, caps: dict) -> list[str]:
    """校验一个演奏方式 + 能力组合，返回中文提示（空列表表示没问题）。"""
    warnings: list[str] = []
    caps = caps or {}

    if mode not in MODES:
        warnings.append("未知演奏方式「%s」，可用：%s" % (mode, "、".join(MODES)))

    for name in caps:
        if name not in CAPS:
            warnings.append("未知能力「%s」，已忽略" % name)

    if caps.get("nocturne") and not caps.get("metronome"):
        warnings.append("夜曲需要节拍器定时，已默认每小时")
    if caps.get("nocturne") and not caps.get("memory"):
        warnings.append("夜曲没有记忆，早上序曲只能看到昨晚的原始记录")
    if caps.get("metronome") and not caps.get("connectors"):
        warnings.append("节拍器没有连接器，只能按时间叫醒，收不到事件")
    if mode == "symphony":
        missing = [c for c in ("connectors", "skills") if not caps.get(c)]
        if missing:
            warnings.append("交响默认启用连接器和乐谱，关掉后要有人手动安排")

    return warnings


COMBOS = [
    {
        "name": "交响 + 夜曲",
        "mode": "symphony",
        "caps": ["nocturne", "metronome"],
        "story": "白天写需求，早上序曲里有 APK",
    },
    {
        "name": "协奏 + GitHub + 节拍器",
        "mode": "concerto",
        "caps": ["connectors", "metronome", "memory"],
        "connectors": ["github"],
        "story": "CI 一红就开工，评审完只在你该定音时才叫你",
    },
    {
        "name": "独奏 + 乐谱 + 网页",
        "mode": "solo",
        "caps": ["skills", "connectors"],
        "skills": ["web-review"],
        "story": "一个人顺着乐谱把网页从头改到尾，不铺开",
    },
    {
        "name": "协奏（指定指挥）+ 飞书",
        "mode": "concerto",
        "caps": ["connectors", "skills"],
        "connectors": ["feishu"],
        "story": "指挥成员定调，其余成员按段接活，结果发飞书",
    },
]
