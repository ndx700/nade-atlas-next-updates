"""User-uploaded avatars only; no bundled images or external avatar URLs."""
import asyncio
import compat
import io
import os
import re
import secrets
import tempfile
from pathlib import Path

from aiohttp import web
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_BYTES = 5 << 20
MAX_PIXELS = 16_000_000
MAX_EDGE = 256
MIME_FORMAT = {"image/png": "PNG", "image/jpeg": "JPEG", "image/webp": "WEBP"}
REFERENCE = re.compile(r"^/files/(avatar-([0-9a-f]{32})\.png)\?v=\2$")


def stored_name(value):
    match = REFERENCE.fullmatch(value) if isinstance(value, str) else None
    return match[1] if match else None


def view(data, member):
    """Legacy/bundled/data/remote values are never exposed as manual avatars."""
    value = member.get("avatar", "")
    name = stored_name(value)
    path = Path(data) / "files" / name if name else None
    if (path is None or path.parent.is_symlink() or path.is_symlink() or not path.is_file()
            or member.get("avatar_version") != name[7:-4]):
        return {"avatar": "", "avatar_version": ""}
    return {"avatar": value, "avatar_version": member["avatar_version"]}


def normalize(raw, mime):
    """Bound decode work, orient, scale and re-encode without EXIF/ICC/text."""
    try:
        with Image.open(io.BytesIO(raw)) as source:
            if source.format != MIME_FORMAT[mime]:
                raise ValueError("图片内容与 Content-Type 不一致")
            if source.width * source.height > MAX_PIXELS:
                raise ValueError("头像最多 1600 万像素")
            if getattr(source, "is_animated", False):
                raise ValueError("头像须为静态图片")
            source.load()  # Reject truncated/corrupt data before publishing anything.
            oriented = ImageOps.exif_transpose(source)
            oriented.thumbnail((MAX_EDGE, MAX_EDGE), Image.Resampling.LANCZOS)
            converted = oriented.convert("RGBA")
            clean = Image.new("RGBA", converted.size)
            clean.paste(converted)
            out = io.BytesIO()
            clean.save(out, format="PNG")
            return out.getvalue(), clean.width, clean.height
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError, SyntaxError) as exc:
        raise ValueError("无法解码头像图片") from exc


async def read_upload(request):
    if request.content_length is not None and request.content_length > MAX_BYTES:
        raise web.HTTPRequestEntityTooLarge(max_size=MAX_BYTES, actual_size=request.content_length)
    raw = bytearray()
    async for chunk in request.content.iter_chunked(65536):
        raw.extend(chunk)
        if len(raw) > MAX_BYTES:
            raise web.HTTPRequestEntityTooLarge(max_size=MAX_BYTES, actual_size=len(raw))
    if not raw:
        raise web.HTTPBadRequest(text="头像不能为空")
    return bytes(raw)


def clean_unused(server, value):
    name = stored_name(value)
    directory = server.DATA / "files"
    if not name or directory.is_symlink():
        return
    if any(stored_name(m.get("avatar")) == name for m in server.CFG["members"]):
        return
    try:
        (directory / name).unlink(missing_ok=True)
    except OSError:
        pass  # A completed configuration update must not fail on obsolete-file GC.


class Avatars:
    def __init__(self, server):
        self.server = server
        self.decoders = asyncio.Semaphore(2)

    async def handle(self, request):
        s = self.server
        name = request.match_info["name"]
        member = s.member(name)
        if member is None:
            raise web.HTTPNotFound(text="成员不存在")
        dimensions = {}
        new_path = None
        if request.method == "POST":
            mime = request.content_type.lower()
            if mime not in MIME_FORMAT:
                raise web.HTTPUnsupportedMediaType(text="只接受 image/png、image/jpeg、image/webp 原始图片数据")
            # Includes time waiting for a decode slot and a stalled request body.
            try:
                async with compat.timeout(30):
                    async with self.decoders:
                        raw = await read_upload(request)
                        png, width, height = await asyncio.to_thread(normalize, raw, mime)
            except TimeoutError:
                raise web.HTTPRequestTimeout(text="头像上传超时") from None
            except ValueError as exc:
                raise web.HTTPBadRequest(text=str(exc)) from None
            # The member may have been deleted/renamed/recreated while streaming.
            if s.member(name) is not member:
                raise web.HTTPConflict(text="成员已变更，请重新上传")
            version = secrets.token_hex(16)
            filename = f"avatar-{version}.png"
            for directory in (s.DATA / "files", s.DATA / "tmp"):
                directory.mkdir(parents=True, exist_ok=True)
                if directory.is_symlink() or directory.resolve().parent != s.DATA.resolve():
                    raise web.HTTPBadRequest(text="头像存储目录无效")
            new_path = s.DATA / "files" / filename
            # Publish an immutable file before its config reference. Backup snapshots
            # run synchronously on the event loop and see either entire transaction.
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(dir=s.DATA / "tmp", prefix="avatar-", delete=False) as fh:
                    tmp_path = Path(fh.name)
                    fh.write(png)
                    fh.flush()
                    os.fsync(fh.fileno())
                tmp_path.replace(new_path)
            finally:
                if tmp_path is not None:
                    tmp_path.unlink(missing_ok=True)
            values = {"avatar": f"/files/{filename}?v={version}", "avatar_version": version}
            dimensions = {"width": width, "height": height, "size": len(png)}
        else:
            values = {"avatar": "", "avatar_version": ""}
        previous = {k: member[k] for k in values if k in member}
        old_avatar = member.get("avatar")
        member.update(values)
        try:
            s.save_cfg()
        except Exception:
            for key in values:
                member.pop(key, None)
            member.update(previous)
            if new_path is not None:
                new_path.unlink(missing_ok=True)
            raise
        s.bump()
        clean_unused(s, old_avatar)
        return web.json_response({"ok": True, **values, **dimensions})


def register(app, server):
    avatars = Avatars(server)
    app.router.add_post("/api/member/{name}/avatar", avatars.handle)
    app.router.add_delete("/api/member/{name}/avatar", avatars.handle)
