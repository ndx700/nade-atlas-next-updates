"""Capability sharing: when a member lacks vision / video / web, the server turns the input into text once
(by a capable member or a cheap tool), caches it by content hash, and injects the digest into handoff packets.

  image -> description + OCR (a vision-capable member)
  video -> keyframes (ffmpeg, if present) + transcript/summary (a video-capable member, else keyframes via vision)
  web   -> fetched readable text (public URLs only; no cookies, no login)
Every model call goes through the same approve/account callbacks, so red lines and quota apply unchanged.
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import json
import pathlib
import re
import shutil
import time
from typing import Awaitable, Callable, Optional

import adapters as A

KIND_NEED = {"image": "vision", "video": "video", "web": "web"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def readable(page: str, limit: int = 12000) -> str:
    """Rule-based HTML -> text: drop script/style/nav, keep headings and paragraphs."""
    page = re.sub(r"(?is)<(script|style|noscript|svg|nav|footer|header)[^>]*>.*?</\1>", " ", page)
    page = re.sub(r"(?i)<(br|/p|/div|/h\d|/li|/tr)>", "\n", page)
    text = html.unescape(re.sub(r"<[^>]+>", " ", page))
    lines = [re.sub(r"[ \t\r\f\v]+", " ", ln).strip() for ln in text.splitlines()]
    return "\n".join(ln for ln in lines if ln)[:limit]


class AssetHub:
    def __init__(self, store: pathlib.Path, members: list[dict], make_adapter: Callable[[dict], A.Adapter],
                 approve: Callable[[str, str, dict], Awaitable[bool]], account: Callable[[dict, dict, str], None],
                 price_of: Callable[[dict], Optional[dict]], stats: dict,
                 fetch: Optional[Callable[[str], Awaitable[str]]] = None, public_url: Callable[[str], bool] = lambda u: True):
        self.store = pathlib.Path(store)
        self.members, self.make, self.approve, self.account = members, make_adapter, approve, account
        self.price_of, self.stats, self.fetch, self.public_url = price_of, stats, fetch, public_url
        self.cache: dict = json.loads(self.store.read_text()) if self.store.exists() else {}
        self.locks: dict[str, asyncio.Lock] = {}
        self.calls = 0

    def save(self):
        self.store.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.store.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.cache, ensure_ascii=False))
        tmp.replace(self.store)

    def expert(self, need: str, exclude=()) -> Optional[dict]:
        return A.pick(self.members, {need}, self.price_of, self.stats, exclude)

    async def digest(self, kind: str, ref: str, data: bytes = b"", for_member: Optional[dict] = None) -> str:
        """Text digest of one asset, computed once per content hash and shared by everyone."""
        key = f"{kind}:{sha(data) if data else sha(ref.encode())}"
        if key in self.cache:
            return self.cache[key]["text"]
        lock = self.locks.setdefault(key, asyncio.Lock())
        async with lock:  # concurrent requests for the same asset wait for one computation
            if key in self.cache:
                return self.cache[key]["text"]
            text, by = await self._compute(kind, ref, data, for_member)
            self.cache[key] = {"text": text, "by": by, "at": time.time(), "ref": ref[:200]}
            self.save()
            return text

    async def _ask(self, m: dict, prompt: str) -> str:
        self.calls += 1

        async def gate(tool, inp, who=m["name"]):
            return await self.approve(who, tool, inp)
        r = await self.make(m).run(prompt, lambda st: None, gate)
        if r.usage:
            self.account(m, r.usage, "share")
        if not r.ok:
            raise RuntimeError(r.error or "处理失败")
        return r.text.strip()

    async def _compute(self, kind, ref, data, for_member):
        if kind == "web":
            if not self.public_url(ref):
                return "（这个地址不是公开网页，没有抓取）", "服务器"
            if self.fetch is None:
                return "（没有可用的网页抓取）", "服务器"
            return readable(await self.fetch(ref)), "服务器抓取"
        need = KIND_NEED[kind]
        ex = self.expert(need, exclude=((for_member or {}).get("name", ""),))
        if kind == "video" and not ex:
            frames = await keyframes(ref) if ref else []
            vis = self.expert("vision")
            if not vis or not frames:
                return "（没有能看视频的成员，也抽不了关键帧）", "服务器"
            notes = [await self._ask(vis, f"[图片] {f}\n用一两句话描述这一帧。") for f in frames[:6]]
            return "关键帧：\n" + "\n".join(f"- {n}" for n in notes), vis["name"]
        if not ex:
            return f"（没有成员能处理{ {'image': '图片', 'video': '视频'}[kind] }）", "服务器"
        ask = {"image": f"[图片] {ref}\n请给出：1) 一段客观描述；2) 图中所有文字（OCR，原样）。",
               "video": f"[视频] {ref}\n请给出：1) 关键帧时间点和画面；2) 语音转写；3) 三句话摘要。"}[kind]
        return await self._ask(ex, ask), ex["name"]

    async def for_card(self, card: dict, member: dict) -> list[str]:
        """Digests for the card's assets that this member cannot read natively (others go to it untouched)."""
        caps = A.capabilities(member, self.price_of(member), self.stats.get(member["name"]))
        out = []
        for a in card.get("assets", []):
            kind, ref = a["kind"], a["ref"]
            need = KIND_NEED.get(kind)
            if need and caps.get(need) and kind != "web":
                out.append(f"{kind} {ref}（你可以直接看）")
                continue
            data = pathlib.Path(ref).read_bytes() if kind != "web" and pathlib.Path(ref).is_file() else b""
            text = await self.digest(kind, ref, data, member)
            who = self.cache[f"{kind}:{sha(data) if data else sha(ref.encode())}"]["by"]
            out.append(f"{kind} {ref}（由 {who} 代为处理，细节可 @{who} 追问）：\n{text}")
        return out


async def keyframes(path: str, every: float = 5.0) -> list[str]:
    """Keyframe JPEGs next to the video via ffmpeg (if installed)."""
    if not shutil.which("ffmpeg") or not pathlib.Path(path).is_file():
        return []
    out = pathlib.Path(path).with_suffix("")
    out.mkdir(exist_ok=True)
    p = await asyncio.create_subprocess_exec("ffmpeg", "-loglevel", "error", "-i", path, "-vf", f"fps=1/{every}",
                                             str(out / "f%03d.jpg"))
    await p.wait()
    return sorted(str(x) for x in out.glob("f*.jpg"))


def image_content(prompt, refs, anthropic=False, inline_limit=4 << 20):
    """Attach original small images; large images use a bounded JPEG thumbnail and local reference."""
    import base64
    import io
    import mimetypes
    from PIL import Image
    parts = [{"type": "text", "text": prompt}]
    for ref in refs:
        path = pathlib.Path(ref)
        if not path.is_file():
            continue
        mime = mimetypes.guess_type(str(path))[0]
        if mime not in {"image/png", "image/jpeg", "image/webp", "image/gif"}:
            continue
        if path.stat().st_size > inline_limit:
            with Image.open(path) as im:
                im.thumbnail((768, 768))
                buf = io.BytesIO()
                im.convert("RGB").save(buf, format="JPEG", quality=75)
                data, mime = buf.getvalue(), "image/jpeg"
            parts.append({"type": "text", "text": f"原文件引用：{path}（附缩略图）"})
        else:
            data = path.read_bytes()
        encoded = base64.b64encode(data).decode("ascii")
        if anthropic:
            parts.append({"type": "image", "source": {"type": "base64", "media_type": mime, "data": encoded}})
        else:
            parts.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}})
    return parts if len(parts) > 1 else prompt
