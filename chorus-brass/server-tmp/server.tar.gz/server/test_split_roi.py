"""server/split_roi.py 的离线单测（Task card N3）。

运行::

    python -m unittest server.test_split_roi
    # 或
    pytest server/test_split_roi.py
"""

from __future__ import annotations

import unittest

from split_roi import (
    DEFAULT_THRESHOLDS,
    SplitPrices,
    SplitThresholds,
    replay,
    split_decision,
)


def _plan(segments, **extra):
    return {"segments": segments, **extra}


def _seg(tokens, price=None):
    seg = {"est_tokens": tokens}
    if price is not None:
        seg["member_price"] = price
    return seg


class TestSplitDecisionBasics(unittest.TestCase):
    def test_returns_required_keys(self):
        result = split_decision(_plan([_seg(1000), _seg(1000)]))
        for key in ("serial_cost", "parallel_cost", "expected_gain", "verdict", "reason"):
            self.assertIn(key, result)

    def test_empty_plan_defaults(self):
        result = split_decision(_plan([]))
        self.assertEqual(result["verdict"], "merge")
        self.assertGreaterEqual(result["serial_cost"], 0.0)
        self.assertGreaterEqual(result["parallel_cost"], 0.0)

    def test_none_plan(self):
        result = split_decision(None)
        self.assertIn(result["verdict"], ("split", "merge"))

    def test_plan_as_list_of_segments(self):
        result = split_decision([_seg(500), _seg(500)])
        self.assertIn(result["verdict"], ("split", "merge"))


class TestCosts(unittest.TestCase):
    def test_serial_cost_formula(self):
        # Σ est_tokens × lead_price + Σ est_tokens × context_repeat_factor
        plan = _plan([_seg(1000), _seg(2000)])
        prices = SplitPrices(lead_price=2.0, member_price=1.0)
        thresholds = SplitThresholds(context_repeat_factor=0.1)
        result = split_decision(plan, prices=prices, thresholds=thresholds)
        expected = 3000 * 2.0 + 3000 * 0.1
        self.assertAlmostEqual(result["serial_cost"], expected, places=4)

    def test_parallel_cost_formula(self):
        plan = _plan(
            [_seg(1000), _seg(2000)],
            orchestrator_tokens=500,
        )
        prices = SplitPrices(lead_price=2.0, member_price=1.0)
        thresholds = SplitThresholds(
            handoff_tokens_per_segment=100.0,
            handoff_overhead_factor=0.5,
        )
        result = split_decision(plan, prices=prices, thresholds=thresholds)
        # orchestrator: 500*2 = 1000
        # member: 1000*1 + 2000*1 = 3000
        # handoff: 1 segment extra * 100 tokens * 1.0 * 0.5 = 50
        expected = 1000 + 3000 + 50
        self.assertAlmostEqual(result["parallel_cost"], expected, places=4)

    def test_per_segment_member_price_override(self):
        plan = _plan([_seg(1000, price=0.5), _seg(1000, price=1.5)], orchestrator_tokens=0)
        prices = SplitPrices(lead_price=1.0, member_price=1.0)
        thresholds = SplitThresholds(handoff_tokens_per_segment=0.0)
        result = split_decision(plan, prices=prices, thresholds=thresholds)
        self.assertAlmostEqual(result["parallel_cost"], 1000 * 0.5 + 1000 * 1.5, places=4)


class TestExpectedGain(unittest.TestCase):
    def test_single_segment_gain_is_zero(self):
        result = split_decision(_plan([_seg(1000)]))
        self.assertAlmostEqual(result["expected_gain"], 0.0, places=4)

    def test_gain_uses_explicit_parallelism_and_reduction(self):
        plan = _plan(
            [_seg(1000), _seg(1000), _seg(1000)],
            parallelism=4.0,
            critical_path_reduction=0.5,
        )
        result = split_decision(plan)
        self.assertAlmostEqual(result["expected_gain"], 4.0 * 0.5, places=4)

    def test_gain_capped_by_max_parallelism(self):
        plan = _plan([_seg(100)] * 20, parallelism=100.0)
        thresholds = SplitThresholds(max_parallelism=3.0)
        result = split_decision(plan, thresholds=thresholds)
        self.assertLessEqual(result["expected_gain"], 3.0 * 0.9)


class TestVerdictRules(unittest.TestCase):
    def test_merge_when_cost_high_and_gain_low(self):
        # 极高成本 + 低并行度 → merge
        plan = _plan([_seg(1000), _seg(1000)], orchestrator_tokens=100000)
        thresholds = SplitThresholds(cost_ratio=1.5, gain_floor=1.3)
        result = split_decision(plan, thresholds=thresholds)
        self.assertEqual(result["verdict"], "merge")
        self.assertIn("降级", result["reason"])

    def test_split_when_gain_high_despite_cost(self):
        plan = _plan(
            [_seg(1000), _seg(1000)],
            orchestrator_tokens=100000,
            parallelism=4.0,
            critical_path_reduction=0.5,
        )
        thresholds = SplitThresholds(cost_ratio=1.5, gain_floor=1.3)
        result = split_decision(plan, thresholds=thresholds)
        self.assertEqual(result["verdict"], "split")

    def test_split_when_cost_low_despite_low_gain(self):
        plan = _plan([_seg(1000)], orchestrator_tokens=1)
        thresholds = SplitThresholds(cost_ratio=1.5, gain_floor=1.3)
        result = split_decision(plan, thresholds=thresholds)
        self.assertEqual(result["verdict"], "split")

    def test_split_when_both_good(self):
        plan = _plan(
            [_seg(1000), _seg(1000), _seg(1000)],
            orchestrator_tokens=100,
            parallelism=3.0,
            critical_path_reduction=0.5,
        )
        result = split_decision(plan)
        self.assertEqual(result["verdict"], "split")
        self.assertIn("该拆", result["reason"])

    def test_thresholds_are_configurable(self):
        plan = _plan([_seg(1000), _seg(1000)], orchestrator_tokens=5000,
                     parallelism=2.0, critical_path_reduction=0.4)
        # 收益为 0.8，严格阈值触发降级；放宽阈值保留拆分
        strict = split_decision(plan, thresholds={"cost_ratio": 1.0, "gain_floor": 1.0})
        relaxed = split_decision(plan, thresholds={"cost_ratio": 1000.0, "gain_floor": 0.0})
        self.assertEqual(strict["verdict"], "merge")
        self.assertEqual(relaxed["verdict"], "split")

    def test_strict_cost_boundary_does_not_merge(self):
        plan = _plan([_seg(1000), _seg(1000)], orchestrator_tokens=1800)
        result = split_decision(plan, prices={"member_price": 0.6}, thresholds={
            "context_repeat_factor": 0, "handoff_tokens_per_segment": 0,
        })
        self.assertEqual(result["serial_cost"], 2000)
        self.assertEqual(result["parallel_cost"], 3000)
        self.assertEqual(result["verdict"], "split")

    def test_strict_gain_boundary_does_not_merge(self):
        plan = _plan([_seg(1000), _seg(1000)], orchestrator_tokens=100000)
        result = split_decision(plan, thresholds={"gain_floor": 1.0})
        self.assertEqual(result["expected_gain"], 1.0)
        self.assertEqual(result["verdict"], "split")

    def test_thresholds_from_mapping_partial(self):
        thr = SplitThresholds.from_mapping({"cost_ratio": 2.5})
        self.assertEqual(thr.cost_ratio, 2.5)
        self.assertEqual(thr.gain_floor, DEFAULT_THRESHOLDS["gain_floor"])


class TestReplay(unittest.TestCase):
    def test_replay_returns_one_result_per_plan(self):
        plans = [_plan([_seg(1000 * (i + 1)), _seg(500)]) for i in range(10)]
        results = replay(plans)
        self.assertEqual(len(results), 10)
        for idx, item in enumerate(results):
            self.assertEqual(item["index"], idx)
            self.assertIn(item["verdict"], ("split", "merge"))
            self.assertIn("serial_cost", item)
            self.assertIn("parallel_cost", item)
            self.assertIn("expected_gain", item)
            self.assertIn("reason", item)

    def test_replay_with_custom_thresholds(self):
        plans = [_plan([_seg(1000), _seg(1000)], orchestrator_tokens=100000)]
        results = replay(plans, thresholds={"cost_ratio": 1.5, "gain_floor": 1.3})
        self.assertEqual(results[0]["verdict"], "merge")


class TestHistoricalReplayDoD(unittest.TestCase):
    """DoD：对 10 个历史需求回放，输出"该拆/不该拆"的判断与对照成本。"""

    def test_ten_historical_requirements(self):
        historical = [
            _plan([_seg(800), _seg(900)], orchestrator_tokens=400),
            _plan([_seg(1500), _seg(1500), _seg(1500)], orchestrator_tokens=600),
            _plan([_seg(5000), _seg(5000)], orchestrator_tokens=20000),
            _plan([_seg(300)], orchestrator_tokens=100),
            _plan([_seg(2000), _seg(2000), _seg(2000), _seg(2000)], orchestrator_tokens=800),
            _plan([_seg(10000), _seg(10000)], orchestrator_tokens=50000),
            _plan([_seg(1200), _seg(1100), _seg(1300)], orchestrator_tokens=500),
            _plan([_seg(250), _seg(250)], orchestrator_tokens=150),
            _plan([_seg(7000), _seg(7000), _seg(7000)], orchestrator_tokens=30000),
            _plan([_seg(4000), _seg(4000)], orchestrator_tokens=1500),
        ]
        results = replay(historical)
        self.assertEqual(len(results), 10)
        self.assertEqual([r["verdict"] for r in results], [
            "split", "split", "merge", "split", "split",
            "merge", "split", "split", "split", "split",
        ])
        for r in results:
            self.assertIn(r["verdict"], ("split", "merge"))
            self.assertGreaterEqual(r["serial_cost"], 0.0)
            self.assertGreaterEqual(r["parallel_cost"], 0.0)
            self.assertGreaterEqual(r["expected_gain"], 0.0)
            self.assertTrue(r["reason"])


if __name__ == "__main__":
    unittest.main()
