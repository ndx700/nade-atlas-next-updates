"""Targeted checks for ①② (room stop, hand-off gap, per-room cap, by_project spend)."""
import asyncio
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
import server as s
from test_review_fixes import Request


class Rhythm(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        s.DATA = pathlib.Path(self.tmp.name)
        for n in ("chats", "tmp", "memory", "summaries", "skills"):
            (s.DATA / n).mkdir()
        s.CFG = {"password": "x", "providers": [{"id": "pr", "base": "http://invalid", "key": "k"}],
                 "members": [{"name": n, "provider": "pr", "model": "model"} for n in ("A", "B")]}
        s.CHATS.clear(); s.ROOTS.clear(); s.STOPPED_ROOTS.clear(); s.STOP_AT.clear()

    async def test_room_max_hops_override_and_zero(self):
        s.CFG["max_hops"] = 5
        self.assertEqual(s._room_max_hops("p"), 5)
        s.CFG["room_overrides"] = {"p": {"max_hops": 0}}
        self.assertEqual(s._room_max_hops("p"), 0)

    async def test_stop_cancels_running_round_and_cleans_roots(self):
        started = asyncio.Event()

        async def slow(pid, name, trigger, opts):
            started.set()
            await asyncio.sleep(30)
        with patch.object(s, "answer", slow), patch.object(s, "save_cfg", lambda: None), patch("collab_api.consent_block", return_value=None):
            t = asyncio.ensure_future(s.run_chain("p", ["A"], {"seq": 1, "client_id": "r1"}, {}))
            await asyncio.wait_for(started.wait(), 2)
            r = json.loads((await s.h_room_stop(Request(query={"root_id": "r1"}))).body)
            await asyncio.gather(t, return_exceptions=True)
        self.assertEqual(r["cancelled"], 1)
        self.assertEqual(s.ROOTS, {})
        self.assertEqual(s.CHATS["p"][-1].get("level"), "warn")

    async def test_stop_in_handoff_gap_blocks_next_member(self):
        budget = {"used": 0, "limit": 0, "notified": False, "t0": 1.0}
        r = json.loads((await s.h_room_stop(Request(query={"root_id": "r2"}))).body)
        self.assertEqual(r["cancelled"], 0)
        self.assertNotIn("p", s.CHATS)  # nothing cancelled → no system message
        self.assertFalse(s.reserve_call("p", {"_budget": budget, "root_id": "r2"}))
        await s.h_room_stop(Request())  # whole room, no root_id
        self.assertFalse(s.reserve_call("p", {"_budget": {**budget}, "root_id": "other"}))
        self.assertTrue(s.reserve_call("p", {"_budget": {**budget, "t0": 9e12}, "root_id": "new"}))

    async def test_reused_root_id_does_not_inherit_old_stop(self):
        with patch.object(s.time, "time", return_value=100):
            await s.stop_round("p", "reused")
        for started, allowed in ((99, False), (100, False), (101, True)):
            with self.subTest(started=started):
                budget = {"used": 0, "limit": 8, "notified": False, "t0": started}
                self.assertEqual(s.reserve_call("p", {"root_id": "reused", "_budget": budget}), allowed)
                self.assertEqual(budget["used"], int(allowed))
        budget = {"used": 0, "limit": 8, "notified": False, "t0": 101, "stopped": True}
        self.assertFalse(s.reserve_call("p", {"root_id": "reused", "_budget": budget}))

    async def test_spend_by_project_and_warn(self):
        m = {"name": "A", "provider": "pr", "model": "model"}
        with patch.object(s, "price", lambda m, model: {"in": 1e6, "out": 0, "cur": "¥"}):
            s.record_usage(m, "model", {"in": 1, "out": 0}, "p")
        d = s.load(s.spend_file(), {})["A"][s.today()]
        self.assertEqual(d["by_project"]["p"]["cost_by_currency"]["¥"], 1.0)
        s.CFG["room_overrides"] = {"p": {"budget": 1.2}}
        r = json.loads((await s.h_spend_summary(Request(query={"pid": "p"}))).body)
        self.assertEqual((r["used"], r["warn"]), (1.0, True))

    async def test_rhythm_post_validates(self):
        with patch.object(s, "save_cfg", lambda: None):
            req = Request(body={"max_hops": -1}); req.method = "POST"
            with self.assertRaises(s.web.HTTPBadRequest):
                await s.h_rhythm(req)
            req = Request(body={"max_hops": 3}); req.method = "POST"
            self.assertEqual(json.loads((await s.h_rhythm(req)).body)["max_hops"], 3)


if __name__ == "__main__":
    unittest.main()
